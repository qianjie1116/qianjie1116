<template>
	<header class="common_header">
		<!-- <view class="header_title" :style="{color:color}">{{title}}</view> -->
		<view class="header_search flex " @click="linkSearch()">
			<image class="margin-left-5" mode="aspectFit" src="/static/search.png" :style="$util.setImageSize(40)"></image>
			<view class="font-size-11 color-white margin-left-10">주식 이름 또는 기호 검색</view>
		</view>
		<image mode="aspectFit" src="/static/notification.png" :style="$util.setImageSize(40)" @click="linkNotifiy()"
			style="padding-right: 8rpx;"></image>
		<!-- <Translate></Translate> -->
	</header>
</template>

<script>
	import {
		NOTIFICATION,
		// SERVICE,
		SEARCH
	} from '@/common/paths.js';
	import Translate from '@/components/Translate.vue';
	export default {
		name: 'HeaderPrimary', 
		components: {
			Translate
		},
		props: {
			// 标题
			title: {
				type: String,
				default: ''
			},
			// 标题文字颜色
			color: {
				type: String,
				default: '#FFFFFF'
			}
		},
		data() {
			return {};
		},
		methods: {
			// 跳转到通知页面
			linkNotifiy() {
				uni.navigateTo({
					url: NOTIFICATION
				})
			},

			// // 跳转到客服
			// linkService() {
			// 	uni.navigateTo({
			// 		url: SERVICE
			// 	})
			// },
			// 跳转到查询页面
			linkSearch() {
				uni.navigateTo({
					url: SEARCH
				})
			}
		}
	}
</script>