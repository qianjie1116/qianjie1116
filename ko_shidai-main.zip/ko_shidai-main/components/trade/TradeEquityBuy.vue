<template>
	<view>
		<view style="padding: 10px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view style="margin-bottom: 20px;background-color: #FFFFFF;border-radius: 8px;padding: 10px;">
					<view style="display: flex;align-items: center;">
						<view style="flex:0%">
							<!-- <template v-if="!item.goods.logo || item.goods.logo==''">
								<view :style="$util.setImageSize(80)"
									style="background-color:#2d2c62;text-align: center;line-height: 80rpx;color: #FFFFFF;margin-bottom: 4px;border-radius: 100%;font-size: 18px;">
									{{item.goods.name.slice(0,1)}}
								</view>
							</template>
							<template v-else>
								<image mode="aspectFit" :src="$util.setLogo(item.goods.logo)"
									:style="$util.setImageSize(80)" style="border-radius: 100%;"></image>
							</template> -->
						</view>
						<view style="flex:94%;">
							<view style="padding-left: 10px;font-size: 36rpx;font-weight: 700;color:#585858;">
								{{item.goods.name}}
							</view>
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<text style="font-size: 28rpx;padding-left: 10px;"
									:style="{color:$theme.LABEL}">{{item.goods.code}}</text>
								<view
									style="color:#FFFFFF;padding:4px 10px; border-radius: 20px;width: 160rpx;text-align: center;"
									:style="{backgroundColor:'#FF6700'}" @click="handleDetail(item)">
									{{$lang.BTN_BUY}}
								</view>
							</view>
							
						</view>
					</view>

					<view
						style="display: flex;align-items: center;justify-content: space-between;margin-top: 6px;line-height: 1.6;">
						<text :style="{color:$theme.LABEL}">{{$lang.TRADE_LARGE_PRICE}}</text>
						<text style="font-size: 28rpx;" :style="{color:'#121212'}">
							{{$util.formatNumber(item.price)}} {{$lang.CURRENCY_UNIT}}</text>
						<text :style="{color:$theme.LABEL}">{{$lang.TRADE_IPO_POST_QTY}}</text>
						<text style="font-size:28rpx;" :style="{color:'#121212'}">
							{{$util.formatNumber(item.fx_num)}}</text>
					</view>

					<!-- <view style="display: flex;align-items: center;margin-top: 10px;">
						<view style="width:70%;height: 10px;border:1px solid #F5B71C;border-radius: 22px;">
							<view :style="$util.setProgress(!item.sale_num?0:item.sale_num,item.fx_num)"></view>
						</view>
						<view style="padding-left: 10px;" :style="{color:$theme.PRIMARY}">
							{{$lang.TRADE_EQUITY_SURPLUS}}：{{!item.sale_num?item.fx_num: item.fx_num-item.sale_num}}
						</view>
					</view> -->
				</view>
			</block>
		</view>
		<template v-if="isShow">
			<view class="common_mask">
				<view class="common_popup" style="min-height:35vh;margin:auto;margin-bottom: 0;">
					<view class="popup_header" style="">
						{{$lang.TRADE_LARGE_ORDER_TITLE}}
						<image src="/static/close.png" mode="aspectFit" :style="$util.setImageSize(40)"
							style="position: absolute;top:50%;right: 30px;transform: translateY(-50%);"
							@click="handleCancel()"></image>
					</view>
					<view style="">
						<view
							style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;margin-top: 10px;">
							<text :style="{color:$theme.TIP}">{{$lang.TRADE_LARGE_BUY_AMOUNT}}</text>
							<text :style="{color:'#FF6700'}">
								{{$util.formatNumber(detail.price)}}{{$lang.CURRENCY_UNIT}}</text>
						</view>
						<view class="common_input_wrapper"
							style="margin:20px;margin-top: 10px; background-color:#FFFFFF;border: 1px solid #E8EAF3;padding-left: 20px;">
							<input v-model="amount" :placeholder="$lang.TRADE_LARGE_TIP_BUY_COUNT" type="number"
								style="width: 80%;" :placeholder-style="$util.setPlaceholder()"></input>
							<view style="padding:0 4px;color: #999;">{{$lang.QUANTITY_UNIT}}</view>
						</view>

						<view
							style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;margin: 10px 40px ;">
							<view :style="{color:$theme.TITLE}">{{$lang.TRADE_LARGE_BUY_TOTAL_AMOUNT}}</view>
							<view :style="{color:'#FF6700'}">
								{{$util.formatNumber(buyAmount)}}{{$lang.CURRENCY_UNIT}}
							</view>
						</view>

						<view
							style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;margin: 10px 40px ;">
							<text :style="{color:$theme.TITLE}">{{$lang.TIP_AMOUNT_AVAIL}}</text>
							<text :style="{color:'#FF6700'}">
								{{availBal}} {{$lang.CURRENCY_UNIT}}</text>
						</view>

						<view class="trade_modal_btn" style="background-color: #FF6700;width: 90%; margin: 30px auto;"
							@click="handleConfirm()">
							{{$lang.BTN_CONFIRM}}
						</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import {
		getEquityList,
		postBuyEquity,
		userFastInfo,
	} from '@/common/api.js';
	export default {
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
				detail: {},
				isShow: false, // 显示弹层
				amount: "", // 金额
				password: '',
				leverList: [], // 杠杆值数组
				current: 0,
				availBal: 0,
			}
		},
		computed: {
			curLever() {
				return this.leverList[this.current];
			},
			buyAmount() {
				return !this.curLever ? 0 : this.detail.price * this.amount / Number(this.curLever.index);
			}
		},
		created() {
			this.getData();
			this.available()
		},
		methods: {
			// 选择杠杆
			handleChgangeLever(val) {
				this.current = val;
			},
			// 查看详情
			async handleDetail(item) {
				console.log('item:', item);
				this.isShow = true;
				this.detail = item;
			},

			handleCancel() {
				this.isShow = false;
				this.amount = "";
				this.password = "";
				this.current = 0;
			},
			handleConfirm() {
				if (this.checkForm()) {
					this.buy();
				}
			},
			checkForm() {
				if (this.amount == '') {
					uni.$u.toast(this.$lang.TRADE_LARGE_TIP_BUY_COUNT);
					return false;
				}
				return true;
			},

			async buy() {
				// 购买
				const result = await postBuyEquity({
					id: this.detail.id,
					num: this.amount,
					// pay_pass: '',
					// ganggan: this.curLever.index,
				});
				if (result.code == 0) {
					uni.$u.toast(result.message);
					this.handleCancel();
					// 1 为驱动父事件，实现切换Tab效果
					this.$emit('action', 1);
				} else {
					this.handleCancel();
					uni.$u.toast(result.message);
				}
			},

			async getData() {
				const result = await getEquityList();
				console.log('result', result);
				if (result.code == 0) {
					this.list = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
			async available() {
				const result = await userFastInfo();
				if (result.code == 0) {
					this.availBal = this.$util.formatNumber(result.data.money);
					this.leverList = [{
						name: 1,
						index: 1
					}];
					if (result.data.ganggan) {
						this.leverList.push(...result.data.ganggan);
					}
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>