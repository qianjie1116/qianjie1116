<template>
	<view class="common_block">
		<view style="display: flex;align-items: center;justify-content: space-between;padding:10px 20px;">
			<block v-for="(item,index) in $lang.STOCK_OVERVIEW_KLINE_TABS" :key="index">
				<view style="flex:25%;text-align: center;font-size: 32rpx;"
					:style="{color:curKLine==index? '#e48a88':'#666'}" @click="handleShowKLine(index)">
					{{item}}
				</view>
			</block>
		</view>

		<view class="chart" id="chart-type-k-line" style="width: 100%;height: 500rpx;">
		</view>
	</view>
</template>

<script>
	import {
		getKLineData,
	} from '@/common/api.js';
	import {
		init,
		registerLocale,
		dispose
	} from 'klinecharts';
	export default {
		name: 'StockKline',
		props: ['code', 'id', 'type'],
		data() {
			return {
				kLineChart: null, // Kline实例化
				curKLine: 0, // 当前显示的Kline数据图标
			}
		},
		created() {
			console.log('StockKline created', 'code:', this.code, 'id:', this.id,'type:',this.type);
			// this.genKLineData();
			this.getData();
		},
		mounted() {
			// console.log('StockKline mounted',this.kLineChart);
			// if (!this.kLineChart) {
			// 	this.kLineChart = init('chart-type-k-line');
			// 	this.kLineInit(); // 初始化Kline
			// }
			// console.log(this.kLineChart);
		},
		methods: {
			getData(){
				console.log(1);
			},
			
			handleShowKLine(val) {
				this.curKLine = val;
				this.genKLineData();
			},
			
			kLineInit() {
				this.kLineChart.setStyles({
					"candle": {
						"type": "area",
						"tooltip": {
							"showRule": "none",
						},
						area: {
							lineSize: 2,
							lineColor: this.$theme.PRIMARY,
							value: 'close',
							backgroundColor: [{
								offset: 0,
								color: '#ffbfb9'
							}, {
								offset: 1,
								color: this.$theme.PRIMARY,
							}]
						},
						bar: {
							upColor: '#3779CD',
							downColor: '#F92855',
							noChangeColor: '#888888',
							upBorderColor: '#3779CD',
							downBorderColor: '#F92855',
							noChangeBorderColor: '#888888',
							upWickColor: '#3779CD',
							downWickColor: '#F92855',
							noChangeWickColor: '#888888'
						},
					},
				});
				this.kLineChart.createIndicator('MA', false);
			},
			// 获取并生成KLine数据
			async genKLineData() {
				const result = await getKLineData({
					stock_id: this.id,
					ac_time: this.curKLine,
					project_type_id: this.type,
					code: this.code
				})
				console.log('k data:', result);
				if (!this.kLineChart) {
					this.kLineChart = init('chart-type-k-line');
					this.kLineInit(); // 初始化Kline
				}
				console.log(this.kLineChart);
				this.kLineChart.setStyles({
					"candle": {
						"type": this.curKLine == 0 ? "area" : "candle_solid",
					},
				});
				this.kLineChart.setPriceVolumePrecision(0, 0)
				this.kLineChart.applyNewData(result.data);
				console.log('genKLineData:',this.kLineChart);
			},
		}
	}
</script>

<style>
</style>