<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view class="" style="margin-bottom:20px;padding:15px;border-radius: 10px;line-height: 2;">
				<!-- <view style="text-align: right;" :style="{color:$theme.RISE}">
					{{item.desc_type}}
				</view> -->
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TIP}">{{$lang.LOG_TRADE_DW}}[{{$lang.CURRENCY_UNIT}}]
					</view>
					<view 
						style="flex:70%;font-size: 16px;text-align: right;">
						{{$util.formatNumber(item.money)}}
					</view>
				</view>

				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TIP}">{{$lang.LOG_TRADE_ORDER_SN}}:</view>
					<view style="flex:70%;text-align: right;font-size: 16px;" >
						{{item.order_sn}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TIP}">{{$lang.LOG_TRADE_CREATE_TIME}}:</view>
					<view style="flex:70%;text-align: right;font-size: 16px;" >
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TIP}">상태:</view>
					<view style="flex:70%;text-align: right;font-size: 16px;" :style="{color:$theme.RISE}">
						{{item.desc_type}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TIP}">{{$lang.LOG_TRADE_DW_DESC}}:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$theme.TEXT}">
						{{item.reason}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:6%;">
						<image :src="item.icon" :style="$util.setImageSize(24)"></image>
					</view>
					<text style="flex:97%;white-space:pre-wrap;" :style="{color:item.color}">{{item.text}}</text>
				</view>
			</view>
			<view style="padding:0px 15px;">
				<view style="border-top: 1px #ccc solid; color: #fff;width: 100%;">.</view>
			</view>
		</block>
	</view>
</template>

<script>
	import {
		getAccountDeposit
	} from '@/common/api.js';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogDeposit",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList()
		},
		methods: {
			async getList() {
				const result = await getAccountDeposit();
				if (result.code == 0) {
					this.list = result.data
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>

<style>

</style>