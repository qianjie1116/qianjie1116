<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view class="" style="padding:20px;border-radius: 10px;line-height: 2;">
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TITLE}">
						{{$lang.LOG_TRADE_AMOUNT_BEFORE}}[{{$lang.CURRENCY_UNIT}}]:
					</view>
					<view  style="flex:70%;text-align: right;font-size: 16px;" >
						{{$util.formatNumber(item.before)}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TITLE}">
						{{$lang.LOG_TRADE_AMOUNT_AFTER}}[{{$lang.CURRENCY_UNIT}}]
					</view>
					<view style="flex:70%;font-size: 16px;text-align: right;"
						>
						{{$util.formatNumber(item.after)}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TITLE}">
						{{$lang.LOG_TRADE_DW}}[{{$lang.CURRENCY_UNIT}}]：
					</view>
					<view style="flex:70%;text-align: right;font-size: 16px;">
						{{$util.formatNumber(item.money)}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TITLE}">{{$lang.LOG_TRADE_CREATE_TIME}}:</view>
					<view style="flex:70%;text-align: right;font-size: 16px;" >
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TITLE}">{{$lang.LOG_TRADE_DESC}}:</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;"></view>
					<text 
						style="white-space:pre-wrap;text-align: right;font-size: 16px;">{{item.desc}}</text>
				</view>
			</view>
			<view style="padding:0px 15px;">
				<view style="border-top: 1px #ccc solid; color: #fff;width: 100%;">.</view>
			</view>
			
		</block>
	</view>
</template>

<script>
	import {
		getAccountFinance
	} from '@/common/api.js';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogTrade",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList()
		},
		methods: {
			async getList() {
				const result = await getAccountFinance();
				if (result.code == 0) {
					this.list = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>

<style>

</style>