<!-- 用于纵向导航，如：个人中心 -->
<template>
	<view style="padding-top:20px;">
		<block v-for="(item,index) in list" :key="index">
			<view style="display: flex;align-items: center;margin:10px;padding-bottom: 10px;"
				@click="actionEvent(item,index)">
				<view style="flex: 12%;padding-left: 20px;">
					<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$util.setImageSize(48)"></image>
				</view>
				<text style="flex: 78%;font-size: 15px;color: #333333;">{{item.name}}</text>
				<view style="flex: 10%;">
					<view class="arrow rotate_45" :style="$util.setImageSize(15)"></view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import {
		signOut
	} from '@/common/api.js';
	import {
		ACCOUNT_ACCESS
	} from '@/common/paths.js';
	export default {
		name: "NavList",
		props: ['list'],
		data() {
			return {};
		},
		methods: {
			actionEvent(item, index) {
				if(item.url=="/pages/servicePush"){
					this.$util.linkService();
					return 
				}
				if (item.mode == 'sign_out') {
					this.handleSignOut();
					return false;
				}
				console.log(item)
				uni.navigateTo({
					url: item.url,
				})
			},
			// 登出
			handleSignOut() {
				signOut();
				try {
					let version = uni.getStorageSync('version')
					uni.removeStorageSync('token');
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast(this.$lang.TIP_SIGN_OUT_SUCCESS);
				setTimeout(() => {
					uni.navigateTo({
						url: ACCOUNT_ACCESS
					});
					this.$router.go(0)
				}, 500)
			}
		}
	}
</script>

<style>

</style>