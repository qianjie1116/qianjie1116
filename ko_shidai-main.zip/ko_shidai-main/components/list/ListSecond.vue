<template>
	<scroll-view :scroll-x="true" style="white-space: nowrap;padding: 0 10px 0 10px;">
		<block v-for="(item,index) in list" :key="index">
			<view class=""
				style="background-color: #F8F8F8; display: inline-block; border-radius: 6px;width: 109px;margin: 0px 5px;"
				@click="linkStockInfo(item.code)">
				<view class="flex justify-center" style="display: flex;align-items: center;">
					<view style=" text-align: center;">
						<!-- <template v-if="!item.logo || item.logo==''">
							<view :style="$util.setImageSize(35)"
								style="background-color:#2d2c62;color: #FFFFFF;border-radius: 50%;font-size: 5px;">
								{{item.name.slice(0,1)}}
							</view>
						</template>
						<template v-else>
							<image mode="aspectFit" :src="$util.setLogo(item.logo)" :style="$util.setImageSize(35)"
								style="border-radius: 50%;margin-top: 15px;"></image>
						</template> -->
					</view>
					<view class="">
						<view class="bold font-size-14 margin-top-15 margin-left-5"> {{item.name}}</view>
						<!-- <view :style="{color:$theme.LABEL}" style="font-size: 24rpx;">{{item.code}}</view> -->
					</view>
					<!-- <view style="margin-left: auto;text-align: right;">
						<view :style="$util.setStockRiseFall(item.rate>0)">
							<image :src="`/static/arrow_${item.rate>0?'rise':'fall'}.png`" mode="aspectFit"
								:style="$util.setImageSize(24)"></image>
							{{($util.formatNumber($util.formatMathABS(item.rate),2))}}%
						</view>
					</view> -->
				</view>
				<view class="flex justify-center margin-top-10" style="display: flex;">
					<view style="font-size: 32rpx;font-weight: 700;" :style="{color:$theme.TEXT}">
						{{$util.formatNumber(item.price)}}{{$lang.CURRENCY_UNIT}}
					</view>
					<!-- <image :src="`/static/line_${item.rate>0?'rise':'fall'}.png`" mode="aspectFit"
						:style="$util.setImageSize(176,78)"></image> -->
				</view>
				<view class="margin-10">
					<view class="flex justify-center" :style="$util.setStockRiseFall(item.rate>0)">
						<image :src="`/static/arrow_${item.rate>0?'rise':'fall'}.png`" mode="aspectFit"
							:style="$util.setImageSize(24)"></image>
							<view class="margin-left-5">
								{{($util.formatNumber($util.formatMathABS(item.rate),2))}}%
							</view>
						
					</view>
				</view>
			</view>
		</block>
	</scroll-view>
</template>

<script>
	import {
		STOCK_OVERVIEW
	} from '@/common/paths.js';
	export default {
		name: 'ListSecond',
		props: {
			// 列表数据
			list: {
				type: Array,
				default: []
			},
		},
		methods: {
			// 跳转到股票详情
			linkStockInfo(code) {
				uni.navigateTo({
					url: `${STOCK_OVERVIEW}?code=${code}`
				});
			}
		}
	}
</script>

<style>
</style>