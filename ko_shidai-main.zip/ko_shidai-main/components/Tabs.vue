<template>
	<scroll-view :scroll-x="true" style="white-space: nowrap;width: 96%;padding: 0px 10px;">
		<block v-for="(item,index) in btns" :key="index">
			<view @click="handleChange(index)"
				style="display: inline-block; width:max-content;height: 20px;padding:8px 20px;text-align: center;font-size: 16px;"
				:style="$util.setTabActive(current === index)">
				{{item}}
			</view>
		</block>
	</scroll-view>
</template>

<script>
	export default {
		name: "Tabs",
		props: ['btns'],
		data() {
			return {
				current: 0,
			};
		},
		methods: {
			handleChange(val) {
				this.current = val;
				this.$emit('action', val);
			},
		}
	}
</script>

<style>

</style>