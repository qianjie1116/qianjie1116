<!-- 用户基本信息 -->
<template>
	<view>
		<view style="display: flex;align-items: center;padding-bottom: 10px;">
			<view style="flex:20%;text-align: center;" >
				<!-- @click="handleLink()" -->
				<!-- :src="info.avatar?info.avatar:'/static/avatar.png'" -->
				<image style="border-radius: 100px;" mode="aspectFit"
					src="/static/logo.png"
					 :style="$util.setImageSize(130)"></image>
			</view>
			<view style="flex:60%;padding-left: 10px;">
				<view style="font-size: 36rpx;text-align: left;color:#fff;">
					{{info.nick_name}}
				</view>
				<view style="font-size:26rpx;text-align: left;color:#fff;margin-top: 8px;">
					{{info.mobile}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		ACCOUNT_AVATAR
	} from '@/common/paths.js';
	export default {
		name: "Profile",
		props: ['info'],
		data() {
			return {};
		},
		methods: {
			// 进入信息修改页面
			handleLink() {
				uni.navigateTo({
					url: ACCOUNT_AVATAR,
				})
			},
		}
	}
</script>

<style>

</style>