<template>
	<view>
		<view style="background-image: linear-gradient(180deg, #de0f1c, transparent);">
			<HeaderSecond :title="$lang.ACCOUNT_TRADE_LOG"></HeaderSecond>
		</view>

		<TabsPrimary :tabs="$lang.TRADE_LOG_BTNS" @action="changeTab" :acitve="curTab"></TabsPrimary>

		<template v-if="curTab == 0">
			<LogTrade></LogTrade>
		</template>

		<template v-if="curTab == 1">
			<LogDeposit></LogDeposit>
		</template>

		<template v-if="curTab == 2">
			<LogWithdraw></LogWithdraw>
		</template>
		<!-- </view> -->
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';
	import LogTrade from '@/components/trade-log/LogTrade.vue';
	import LogDeposit from '@/components/trade-log/LogDeposit.vue';
	import LogWithdraw from '@/components/trade-log/LogWithdraw.vue';
	export default {
		components: {
			HeaderSecond,
			TabsPrimary,
			LogTrade,
			LogDeposit,
			LogWithdraw,
		},
		data() {
			return {
				curTab: 0,
			};
		},
		onLoad(item) {
			console.log(item);
			this.curTab = Number(item.index) || 0;
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
			},
		},
	}
</script>