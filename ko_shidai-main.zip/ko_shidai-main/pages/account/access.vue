<!-- 登入 注册 -->
<template>
	<view class="access_bg">
		<view class="access_header"></view>
		<template v-if="isSignIn">
			<view class="access_signin">
				<!-- <view style="font-size: 28px;color: #fff;margin-left: 10px;margin-top: 100px;">로그인 시작</view> -->
			</view>
		</template>
		<template v-else>
			<view class="access_signup"></view>
		</template>
		<view style="position: fixed;right:3vw;top:1vh;z-index: 11115;">
			<!-- <Translate></Translate> -->
		</view>

		<view class="access_wrapper">
			<!-- {{isSignIn?$lang.SIGN_IN:$lang.SIGN_UP}} -->
			<view class="flex" style="justify-content: space-around; ">
				<view class="bold font-size-18" @click="handleChange()">{{$lang.SIGN_IN}}</view>
				<view class=" font-size-18" @click="handleChange()">{{$lang.SIGN_UP}}</view>
			</view>
			<view style="border-bottom: 2.5px #f6f7fb solid; margin: 0  30px;color: #fff;">.</view>

			<view style="padding:20px 30px 10px 30px;">
				<view class="bold font-size-12">로그인 계정</view>
				<view class="access_input_wrapper" style="">
					<image src="/static/account_name.png" mode="aspectFit" :style="$util.setImageSize(40)"></image>
					<input v-model="user" type="number" :placeholder="$lang.ENTER_USER_NAME" maxlength="11"
						:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
				</view>
			</view>
			<view style="padding:0 30px 10px 30px;">
				<view class="flex" style="justify-content: space-between;">
					<view class="bold font-size-12">로그인 비밀번호</view>
					<u-checkbox-group v-if="isSignIn">
						<u-checkbox shape="" :activeColor="$theme.PRIMARY" :label="$lang.TIP_REMEMBER_PWD"
							v-model="isRemember" labelSize="20rpx" @change="changeRemember"
							:checked="isRemember"></u-checkbox>
					</u-checkbox-group>

				</view>
				<view class="access_input_wrapper" style="">
					<image src="/static/account_password.png" mode="aspectFit" :style="$util.setImageSize(40)">
					</image>
					<template v-if="isShow">
						<input v-model="password" type="text" :placeholder="$lang.ENTER_PASSWORD"
							:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
					</template>
					<template v-else>
						<input v-model="password" type="password" :placeholder="$lang.ENTER_PASSWORD"
							:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
					</template>

					<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
						:style="$util.setImageSize(40)" @click="toggleShow">
					</image>
				</view>
			</view>

			<template v-if="!isSignIn">
				<view style="padding:0 30px 10px 30px;">
					<view class="bold font-size-12">비밀번호 확인</view>
					<view class="access_input_wrapper" style="">
						<image src="/static/account_password.png" mode="aspectFit" :style="$util.setImageSize(40)">
						</image>
						<template v-if="isShow">

							<input v-model="verifyPassword" type="text" :placeholder="$lang.VERIFY_PASSWORD"
								:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
						</template>
						<template v-else>
							<input v-model="verifyPassword" type="password" :placeholder="$lang.VERIFY_PASSWORD"
								:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
						</template>

						<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
							:style="$util.setImageSize(40)" @click="toggleShow">
						</image>
					</view>
				</view>
				<view style="padding:0 30px 20px 30px;">
					<view class="bold font-size-12">초대 코드</view>
					<view class="access_input_wrapper" style="">
						<image src="/static/account_code.png" mode="aspectFit" :style="$util.setImageSize(40)">
						</image>
						<input v-model="code" type="text" :placeholder="$lang.INVITATION_CODE" maxlength="11"
							:placeholder-style="$util.setPlaceholder()" style="width: 80%;"></input>
					</view>
				</view>
			</template>

			<view style="margin-top: 80px;width: 100%;justify-content: flex-end; display: flex;" @click="kefu()">
				<image src="/static/kefu.png" mode="widthFix" style="width: 50px;"></image>
				<view style="color:#fff ;">
					......
				</view>
			</view>

			<view style="padding:30px 30px 10px 30px;display: flex;align-items: center;justify-content: center;"
				>

				<u-checkbox-group>
					<u-checkbox shape="" :activeColor="$theme.PRIMARY" :label="$lang.TIP_AGREE" v-model="isAgree"
						labelColor="#666666" labelSize="24rpx" @change="changeAgree" :checked="isAgree"></u-checkbox>
				</u-checkbox-group>
				<view style="font-size:24rpx;margin-left: 8px;" :style="{color:$theme.PRIMARY}" @click="linkPact()">
					{{$lang.TIP_PRVITE_PACT}}
				</view>
			</view>

			<view style="padding: 25px 0px;">
				<view class="access_btn" style="margin-top: 20px;background-color: #dc0112;color: #fff;"
					@click="handleConfirm()">
					{{isSignIn?$lang.SIGN_IN:$lang.SIGN_UP}}
				</view>
			</view>


			<!-- <template v-if="isSignIn">
				<view
					style="padding:20px 30px 10px 30px;display: flex;align-items: center;justify-content: space-between;">

					<view style="font-size: 28rpx;margin-right: 4px;" :style="{color:$theme.PRIMARY}"
						@click="handleChange()">
						{{isSignIn?$lang.SIGN_UP:$lang.GO_TO_SIGN_IN}}0
					</view>
				</view>
			</template>

			<template v-else>
				<view class="access_btn" @click="handleChange()" style="background-color: transparent;border-radius: 0;"
					:style="{color:$theme.PRIMARY}">
					{{$lang.SIGN_IN}}1
				</view>
			</template> -->


		</view>

		<!-- <view class="access_wrapper">
			<view style="width: 100%;height: 100vh; border-radius: 30px 30px 0px 0px;padding-top: 20px;">
				<h3 style="font-size: 40rpx;text-align: center;padding-bottom:20px;" :style="{color:'#333333'}">
					{{isSignIn?$lang.SIGN_IN:$lang.SIGN_UP}}
				</h3>

				
			</view> -->
	</view>
	</view>
</template>

<script>
	import {
		HOME,
		ACCOUNT_PRVITE_PACT
	} from '@/common/paths.js';
	import {
		postSignIn,
		postSignUp
	} from '@/common/api.js';

	import Translate from '@/components/Translate.vue';
	import CustomDivider from '@/components/CustomDivider.vue';
	export default {
		components: {
			Translate,
			CustomDivider
		},
		data() {
			return {
				isShow: false, // 密码显隐
				user: "",
				password: '',
				verifyPassword: '',
				code: '',
				isSignIn: true,
				isRemember: false, // 记住密码
				isAgree: false, // 同意隐私协议
			};
		},
		onShow() {
			// 读取缓存中的页面信息
			this.getStorageData();
			this.changeRemember(this.isRemember);
			this.changeAgree(this.isAgree);
		},
		onHide() {
			// 缓存页面信息
			this.setStorageData();
		},
		methods: {
			// 设置页面缓存信息
			setStorageData() {
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				uni.setStorageSync('pwd1', this.verifyPassword);
				uni.setStorageSync('code', this.code);
				uni.setStorageSync('remember', this.isRemember);
				uni.setStorageSync('agree', this.isAgree);
			},
			// 获取页面缓存信息
			getStorageData() {
				this.user = uni.getStorageSync('user') || '';
				this.password = uni.getStorageSync('pwd') || '';
				this.verifyPassword = uni.getStorageSync('pwd1') || '';
				this.code = uni.getStorageSync('code') || '';
				this.isRemember = uni.getStorageSync('remember') || false;
				this.isAgree = uni.getStorageSync('agree') || false;
			},
			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
			},
			// 勾选记住密码
			changeRemember(e) {
				this.isRemember = e;
				uni.setStorageSync('remember', this.isRemember);
			},

			// 勾选用户隐私协议
			changeAgree(e) {
				this.isAgree = e;
				uni.setStorageSync('agree', this.isAgree);
			},
			kefu() {
				uni.navigateTo({
					url: '/pages/servicePush'
				})
				// this.$util.linkCustomerService();
			},

			// 用户隐私协议
			linkPact() {
				this.setStorageData();
				uni.navigateTo({
					url: ACCOUNT_PRVITE_PACT
				})
			},

			handleChange() {
				this.isSignIn = !this.isSignIn;
				this.setStorageData();
				this.getStorageData();
			},
			handleConfirm() {
				if (this.checkForm()) {
					if (this.isSignIn) {
						this.signIn();
					} else {
						this.register();
					}
				}
			},
			checkForm() {
				if (this.user == '') {
					uni.$u.toast(this.$lang.ENTER_USER_NAME);
					return false;
				}
				if (this.password == '') {
					uni.$u.toast(this.$lang.ENTER_PASSWORD);
					return false;
				}
				if (!this.isSignIn && this.verifyPassword == '') {
					uni.$u.toast(this.$lang.ENTER_VERIFY_PASSWORD);
					return false;
				}
				if (!this.isSignIn && this.verifyPassword != this.password) {
					uni.$u.toast(this.$lang.TIP_PWD_NOEQUAL);
					return false;
				}
				if (!this.isSignIn && !this.code) {
					uni.$u.toast(this.$lang.ENTER_INVITATION_CODE);
					return false;
				}
				if (this.isAgree != true) {
					uni.$u.toast(this.$lang.TIP_CHECK_AGREE);
					return false;
				}
				return true;
			},

			async signIn() {
				const result = await postSignIn({
					username: this.user,
					password: this.password,
				}, this.$lang.TIP_SIGNIN_ING)
				if (result.code == 0) {
					const token = result.data.token.access_token
					uni.setStorageSync('token', token);
					uni.$u.toast(this.$lang.TIP_SUCCESS_SIGNIN);
					this.setStorageData();
					uni.$u.sleep(500).then(() => {
						uni.switchTab({
							url: HOME,
						});
					});
				} else {
					uni.$u.toast(result.message);
				}
			},
			async register() {
				const result = await postSignUp({
					mobile: this.user,
					password: this.password,
					confirmpass: this.verifyPassword,
					invite: this.code,
					code: 123456,
				}, this.$lang.TIP_SIGNUP_ING)
				if (result.code == 0) {
					uni.$u.toast(this.$lang.TIP_SUCCESS_REGISTER);
					this.setStorageData();
					this.signIn();
				} else {
					uni.$u.toast(result.message);
				}
			},
		}
	}
</script>