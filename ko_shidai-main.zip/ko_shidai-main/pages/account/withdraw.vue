<!-- 실시간 이체 -->
<template>
	<view style="background-color: #FFFFFF;min-height: 100vh;">
		<view>
			<view style="background-image: linear-gradient(180deg, #de0f1c, transparent);">
				<HeaderSecond :title="$lang.PAGE_TITLE_WITHDRAW" color="#FFFFFF"></HeaderSecond>
			</view>

			<view class="deposit_info_bg" style="border: 1px dashed #de0d1b;">
				<view style="display: flex;align-items: center;  padding:40px 20px 0 20px;">
					<view style="color:#9f9e99;font-size: 32rpx;">
						총자산[원]
					</view>
					<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
						:style="$util.setImageSize(40)" style="margin-left: 20px;">
					</image>
				</view>
				<view style="color:#000;font-size: 54rpx;font-weight: 700;padding-left:20px;line-height:2.5;">
					{{showAmount?$util.formatNumber(userInfo.totalZichan):hideAmount}}
				</view>
				<view class="flex" style="padding: 0px 20px;">
					<view style="color:#9f9e99;font-size: 16px;">사용가능 자금[원]</view>
					<view style="margin-left: 10px;font-size: 16px;">
						{{showAmount?(userInfo.money*1>userInfo.freezeMoney*1?$util.formatNumber(userInfo.money-userInfo.freezeMoney):0):hideAmount}}</view>
				</view>
			</view>

		</view>


		<view style="padding:20px;margin-top: 10px;margin-bottom: 20px;">
			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;" :style="{color:$theme.TEXT}">
				{{$lang.WITHDRAW_WITH_AMOUNT}}
			</view>
			<view class="common_input_wrapper" style="background-color: #f8f8fa;padding-left: 30px;">
				<input v-model="formattedValue" :placeholder="$lang.TIP_AMOUNT_WITHDRAW" type="text"
					:placeholder-style="$util.setPlaceholder()" style="flex: auto;" @input="formatInput"></input>
				<!-- <view @click="handleAllAmount(userInfo.money)" class="btn_small">{{$lang.TIP_AMOUNT_ALL}}</view> -->
			</view>

			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;" :style="{color:$theme.TEXT}">
				{{$lang.WITHDRAW_PAY_PWD}}
			</view>
			<view class="common_input_wrapper" style="background-color: #f8f8fa;padding-left: 30px;">
				<input v-model="password" :placeholder="$lang.TIP_WITHDRAW_PWD" type="password"
					:placeholder-style="$util.setPlaceholder()" style=""></input>
			</view>
		</view>


		<view style="margin:10px; padding:0px 20px;" :style="{color:$theme.TITLE}">
			<block v-for="(item,index) in $lang.WITHDRAW_TIP_TEXT" :key="index">
				<view style="padding-bottom: 6px;" :style="{color:index==5?'#FF6700' :$theme.TITLE}">
					{{item}}
				</view>
			</block>
		</view>
		<view class="access_btn"
			style="margin:20px auto; width: 90%;background-color: #FF6700;margin-top: 50px;color: #FFFFFF;"
			@click="handleWithdraw()">
			{{$lang.BTN_CONFIRM}}
		</view>
	</view>
</template>

<script>
	import {
		postWithdarw,
		accountInfo
	} from '@/common/api.js';
	import {
		ACCOUNT_CENTER
	} from '@/common/paths.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				amount: '',
				password: '',
				userInfo: {},
			};
		},
		computed: {
			formattedValue: {
				get() {
					return this.amount ? this.addThousandSeparator(this.amount) : '';
				},
				set(newValue) {
					this.amount = newValue.replace(/,/g, ''); // 去掉千分符
				},
			},
		},
		onShow() {
			this.getInfo()
		},
		methods: {
			addThousandSeparator(num) {
				console.log(`num:`, num)
				num = num.toString();
				// 转换为数字，如果不是数字则返回空字符串
				num = num.replace(/[^\d]/g, ''); // 只允许数字输入
				const intPart = num.split('.')[0]; // 获取整数部分
				const decimalPart = num.split('.')[1] ? '.' + num.split('.')[1] : ''; // 获取小数部分
				// 添加千分符
				const formattedIntPart = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
				return formattedIntPart + decimalPart;
			},
			formatInput(event) {
				// 获取输入的值，并更新数据属性
				this.formattedValue = event.target.value;
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// handleAllAmount(val) {
			// 	this.amount = val
			// },
			async handleWithdraw() {
				const result = await postWithdarw({
					type: 1,
					total: this.amount,
					pay_pass: this.password,
					remakes: "",
				}, this.$lang.WITHDRAWING_POST_TIP)
				if (result.code == 0) {
					uni.$u.toast(result.message);
					setTimeout(() => {
						uni.switchTab({
							url: ACCOUNT_CENTER
						});
					}, 500)
				} else {
					uni.$u.toast(result.message);
				}
			},
			async getInfo() {
				const result = await accountInfo();
				if (result.code == 0) {
					this.userInfo = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>