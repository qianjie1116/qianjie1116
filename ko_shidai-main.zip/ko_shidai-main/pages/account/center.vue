<template>
	<view>
		<view class="center_header">
			<HeaderPrimary :title="$lang.TABBAR_ACCOUNT"></HeaderPrimary>
			<view class="margin-top-20">
				<Profile :info="userInfo"></Profile>
			</view>
			
		</view>
		

		<view
			style="background-color:#F8F8F8;width: 100%;margin-top: -60px;border-radius: 30px 30px 0 0;padding-top: 20px;padding-bottom: 30px;">
			<view class="account_center_info_bg" style="position: relative;border: #ff6700 dashed 1px;">
				<view
					style="display: flex;padding:10px;padding-right: 20px;color:#999999;font-size: 32rpx;">
					총자산[원]
					<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
						:style="$util.setImageSize(40)" style="margin-left: 10PX;">
					</image>
				</view>
				<view
					style="font-size: 48rpx;font-weight: 500;padding: 0px 10px;">
					<!-- {{showAmount?$util.formatNumber(userInfo.totalZichan):hideAmount}} -->
					{{showAmount?$util.formatNumber(userInfo.totalZichan):hideAmount}}
				</view>

				<view style="position: absolute;left: 0;bottom: 30px;width: 100%;line-height: 2;">
					<view style="display: flex;align-items: center;">
						<view style="font-size: 30rpx;padding-left: 10px;color: #999999;">
							{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}[{{$lang.CURRENCY_UNIT}}]
						</view>
						<view style="font-size: 30rpx;font-weight: 500;margin-left: 15px;">
							{{showAmount?$util.formatNumber(userInfo.money):hideAmount}}
						</view>
					</view>
				</view>
			</view>

			<view style="display: flex;align-items: center;justify-content: space-around;margin-top: 10px;">
				<view class="trade_modal_btn"
					style="background-color: #FF6700;height: 40px;line-height:32px;display: flex;align-items: center;justify-content:center;"
					@click="handleDeposit()">
					<!-- <image src="/static/center_left.png" mode="aspectFit" :style="$util.setImageSize(28)"
						style="padding-right: 20px;"></image> -->
					{{$lang.PAGE_TITLE_DEPOSIT}}
				</view>
				<view class="trade_modal_btn"
					style="background-color:#F5B71C;height: 40px;line-height:32px;display: flex;align-items: center;justify-content:center;"
					@click="handleWithDraw()">
					<!-- <image src="/static/center_right.png" mode="aspectFit" :style="$util.setImageSize(28)"
						style="padding-right: 20px;"></image> -->
					{{$lang.PAGE_TITLE_WITHDRAW}}
				</view>
			</view>

			<!-- <view class="btn_withdraw" @click="handleWithDraw()">
				<image src="/static/center_right.png" mode="aspectFit" :style="$util.setImageSize(60)"></image>
				<view style="padding-left: 10px;font-size: 32rpx;">{{$lang.PAGE_TITLE_WITHDRAW}}</view>
				<image src="/static/btn_withdraw_arrow.png" mode="aspectFit" :style="$util.setImageSize(60)"
					style="margin-left: auto;"></image>
			</view>
			
			<view class="btn_deposit" @click="handleDeposit()">
				<image src="/static/center_left.png" mode="aspectFit" :style="$util.setImageSize(40)"></image>
				<view style="display: inline-block;padding-left: 10px;font-size: 32rpx;">
					{{$lang.PAGE_TITLE_DEPOSIT}}
				</view>
			</view> -->

			<!-- <view style="padding:0 10px;">
				<CustomTitle :title="$lang.ACCOUNT_MORE_FEATURES"></CustomTitle>
			</view> -->

			<NavList :list="$util.setAccountCenterList(userInfo.is_check)"> </NavList>

			<view class="access_btn" style="margin:20px auto; width: 90%;" @click="handleSignOut()">
				{{$lang.SIMGN_OUT}}
			</view>
		</view>
	</view>
</template>

<script>
	import {
		ACCOUNT_WITHDRAW,
		ACCOUNT_DEPOSIT,
		ACCOUNT_ACCESS
	} from '@/common/paths.js';
	import {
		accountInfo,
		signOut
	} from '@/common/api.js';
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import Profile from '@/components/Profile.vue';
	import NavList from '@/components/NavList.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	export default {
		components: {
			HeaderPrimary,
			Profile,
			NavList,
			CustomTitle,
		},
		data() {
			return {
				showAmount: true, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 基本信息
				// isShow: false, // 显示弹层
				// value1: '', // 第一个输入框
				// value2: '', // 第二个输入框
				// value3: '', // 第三个输入框，绑卡所需
				// current: -1, // 当前显示的弹层
				// curConfig: {}, // 弹层中的配置
				// cardInfo: {}, // 银行卡信息，显示绑卡信息，或变更绑卡信息
			}
		},
		onShow() {
			this.gaint_info()
		},
		//下拉刷新
		onPullDownRefresh() {
			this.gaint_info()
			uni.stopPullDownRefresh()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},

			// 提款
			handleWithDraw() {
				uni.navigateTo({
					url: ACCOUNT_WITHDRAW
				})
			},
			handleDeposit() {
				uni.navigateTo({
					url: ACCOUNT_DEPOSIT
				})
			},

			// 登出
			handleSignOut() {
				signOut();
				try {
					let version = uni.getStorageSync('version')
					uni.removeStorageSync('token');
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast(this.$lang.TIP_SIGN_OUT_SUCCESS);
				setTimeout(() => {
					uni.navigateTo({
						url: ACCOUNT_ACCESS
					});
					this.$router.go(0)
				}, 500)
			},
			//用户信息
			async gaint_info() {
				const result = await accountInfo();
				if (result.code == 0) {
					this.userInfo = result.data
				} else {
					uni.$u.toast(result.message);
				}
			},
			// // 功能列表，点击事件
			// handleClick(val) {
			// 	console.log('val:', val);
			// 	// this.current = this.$util.MODE_DIALOG.findIndex(item => item.url == val.url);
			// 	// console.log('index:', this.current);
			// 	// this.curConfig = {
			// 	// 	title: val.name,
			// 	// 	input1ph: this.current == 2 ? this.$lang.REAL_NAME : this.$lang.NEW_PWD,
			// 	// 	input2ph: this.current == 2 ? this.$lang.BANK_NAME : this.$lang.NEW_PWD2,
			// 	// 	input3ph: this.$lang.BANK_CARD,
			// 	// 	type: this.current == 2 ? 'text' : 'password',
			// 	// };
			// 	// this.isShow = true;

			// 	// // 如果是绑卡弹层，请求已绑卡信息
			// 	// if (this.current == 2 && this.cardInfo) {
			// 	// 	this.value1 = this.cardInfo.realname;
			// 	// 	this.value2 = this.cardInfo.bank_name;
			// 	// 	this.value3 = this.cardInfo.card_sn;
			// 	// }
			// },
			// handleCancel() {
			// 	this.isShow = false;
			// 	this.value1 = "";
			// 	this.value2 = "";
			// 	this.value3 = "";
			// },
			// async handleConfirm() {
			// 	// 根据当前显示弹出，分别处理。其中，变更账户密码与支付密码逻辑相同
			// 	const urls = [this.$http.API_URL.SIGNIN_PASSWORD,
			// 		this.$http.API_URL.PAY_PASSWORD,
			// 		this.$http.API_URL.BIND_BANK_CARD,
			// 	];
			// 	let tempData = {};
			// 	if (this.current == 2) {
			// 		tempData = {
			// 			realname: this.value1,
			// 			bank_name: this.value2,
			// 			card_sn: this.value3,
			// 		}
			// 	} else {
			// 		tempData = {
			// 			newpass: this.value1,
			// 			confirmpass: this.value2,
			// 		};
			// 	}
			// 	let result = await this.$http.post(urls[this.current], tempData);
			// 	if (result.data.code == 0) {
			// 		uni.$u.toast(this.current == 2 ? '은행 카드 정보가 성공적으로 제출되었습니다.' : '수정되었습니다.');
			// 		this.isShow = false;
			// 		setTimeout(() => {
			// 			uni.switchTab({
			// 				url: this.$util.PAGE_URL.ACCOUNT_CENTER
			// 			});
			// 		}, 1000)
			// 	} else {
			// 		uni.$u.toast(result.data.message);
			// 	}
			// },

			// manages() {
			// 	if (this.cardManagement) {
			// 		uni.navigateTo({
			// 			url: this.$util.PAGE_URL.ACCOUNT_BANK_CARD
			// 		});
			// 	} else {
			// 		uni.navigateTo({
			// 			//保留当前页面，跳转到应用内的某个页面
			// 			url: '/pages/my/components/bankCard/renewal'
			// 		});
			// 	}
			// },
			// //版本更新
			// Update() {
			// 	uni.navigateTo({
			// 		url: '/pages/my/components/other/versionUpdate'
			// 	});
			// },
			// //用户协议
			// userAgreement() {
			// 	uni.navigateTo({
			// 		url: '/pages/my/components/other/userAgreement'
			// 	});
			// },
			// //隐私协议
			// privacyAgreement() {
			// 	uni.navigateTo({
			// 		url: '/pages/my/components/other/privacyAgreement'
			// 	});
			// },

			// //关于我们
			// aboutUs() {
			// 	uni.navigateTo({
			// 		url: this.$util.PAGE_URL.ABOUT
			// 	});
			// },
			// //实名认证
			// notCertified() {
			// 	uni.navigateTo({
			// 		url: this.$util.PAGE_URL.ACCOUNT_AUTH
			// 	});
			// },


		},
	}
</script>