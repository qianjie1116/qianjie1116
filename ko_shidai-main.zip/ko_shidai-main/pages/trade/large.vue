<!-- 大宗交易 -->
<template>
	<view style="background-color: #F8F8F8;min-height: 100vh;">
		<view style="background-image: linear-gradient(180deg, #e1262c, transparent);">
			<HeaderSecond :title="$lang.PAGE_TITLE_TRADE_LARGE"></HeaderSecond>
		</view>

		<TabsPrimary :tabs="$lang.TRADE_LARGE_TABS" @action="changeTab" :acitve="curTab"></TabsPrimary>

		<template v-if="curTab==0">
			<view style="padding: 10px;">
				<EmptyData v-if="list.length<=0"></EmptyData>
				<block v-for="(item,index) in list" :key="index">
					<view style="margin-bottom: 20px;background-color: #FFFFFF;border-radius: 8px;padding: 10px;">
						<TradeStockItem :item="item" @action="handleDetail"></TradeStockItem>
					</view>
				</block>
			</view>
		</template>
		<template v-else>
			<TradeLargeLog></TradeLargeLog>
		</template>

		<template v-if="isShow">
			<view class="common_mask">
				<view class="common_popup" style="min-height:35vh;margin:auto">
					<view class="popup_header" style="">
						{{$lang.TRADE_LARGE_ORDER_TITLE}}
						<image src="/static/close.png" mode="aspectFit" :style="$util.setImageSize(40)"
							style="position: absolute;top:50%;right: 30px;transform: translateY(-50%);"
							@click="handleCancel()"></image>
					</view>
					<view>
						<view
							style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;margin-top: 10px;">
							<text :style="{color:$theme.TIP}">{{$lang.TRADE_LARGE_BUY_AMOUNT}}</text>
							<text :style="{color:'#FF6700'}">
								{{$util.formatNumber(detail.price)}}{{$lang.CURRENCY_UNIT}}</text>
						</view>
						<view class="common_input_wrapper"
							style="margin:20px;margin-top: 10px; background-color:#FFFFFF;border: 1px solid #E8EAF3;padding-left: 20px;">
							<input v-model="amount" :placeholder="$lang.TRADE_LARGE_TIP_BUY_COUNT" type="number"
								style="width: 80%;" :placeholder-style="$util.setPlaceholder()"></input>
							<view style="padding:0 4px;color: #999;">{{$lang.QUANTITY_UNIT}}</view>
						</view>

						<!-- 杠杆默认有一个数组，当数组大于1，视为开启杠杆功能 -->
						<template v-if="leverList.length>1">
							<view style="padding-left: 30px;font-size: 14px;font-weight: 800;margin-top: 20px;"
								:style="{color:$theme.TEXT}">
								{{$lang.LEVER}}
							</view>
							<view class="common_input_wrapper"
								style="margin:20px;margin-top: 10px;background-color:#FFFFFF;border: 1px solid #E8EAF3;">
								<image mode="aspectFit" src='/static/leverage.png' :style="$util.setImageSize(36)">
								</image>
								<block v-for="(item,index) in leverList" :key="index">
									<text @click="handleChgangeLever(index)"
										style="display: inline-block;padding:0 16px;"
										:style="{borderBottom:`2px solid ${index==current? '#FF6700':'transparent'}`,color:index==current?'#FF6700':$theme.TEXT}">{{item.name}}</text>
								</block>
							</view>
						</template>

						<view
							style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;">
							<view :style="{color:$theme.TITLE}">{{$lang.TRADE_LARGE_BUY_TOTAL_AMOUNT}}</view>
							<view :style="{color:'#FF6700'}">
								{{$util.formatNumber(buyAmount)}}{{$lang.CURRENCY_UNIT}}
							</view>
						</view>

						<!-- <view class="common_input_wrapper"
							style="margin:20px;background-color:#FFFFFF;border: 1px solid #E8EAF3;padding-left: 20px;">
							<input v-model="password" :placeholder="$lang.TRADE_LARGE_TIP_BUY_PWD" type="password"
								:placeholder-style="$util.setPlaceholder()"></input>
						</view> -->

						<view
							style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;margin-top: 10px;">
							<text :style="{color:$theme.TITLE}">{{$lang.TIP_AMOUNT_AVAIL}}</text>
							<text :style="{color:'#FF6700'}">
								{{availBal}} {{$lang.CURRENCY_UNIT}}</text>
						</view>

						<view class="trade_modal_btn" style="background-color: #FF6700;width: 90%; margin: 30px auto;"
							@click="handleConfirm()">
							{{$lang.BTN_CONFIRM}}
						</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import {
		getTradeLargeDetail,
		getTradeLargeList,
		postTradeLargeBuy,
		getTradeLargeOrderLog,
		userFastInfo,
	} from '@/common/api.js';

	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import TradeLargeLog from '@/components/trade/TradeLargeLog.vue';
	import TradeStockItem from '@/components/trade/TradeStockItem.vue';
	import TabsPrimary from '@/components/tabs/TabsPrimary.vue';

	export default {
		components: {
			HeaderSecond,
			EmptyData,
			TradeLargeLog,
			TradeStockItem,
			TabsPrimary,
		},
		data() {
			return {
				curTab: 0,  
				list: [],
				detail: {},
				isShow: false, // 显示弹层
				amount: "", // 金额
				// password: '',
				leverList: [], // 杠杆值数组
				current: 0,
				availBal: 0,
			}
		},
		onShow() {
			this.getList()
			this.available()
		},
		computed: {
			curLever() {
				return this.leverList[this.current];
			},
			buyAmount() {
				return !this.curLever ? 0 : this.detail.price * this.amount / Number(this.curLever.index);
			}
		},

		methods: {
			// tab切换
			changeTab(val) {
				this.curTab = val;
				if (this.curTab == 0) {
					this.getList();
				}
			},
			// 选择杠杆
			handleChgangeLever(val) {
				this.current = val;
			},
			// 查看详情
			async handleDetail(id) {
				console.log('id:', id);
				this.isShow = true;
				const result = await getTradeLargeDetail(id);
				if (result.code == 0) {
					this.detail = result.data;
				} else {
					uni.$u.toast(result.message);
				}
			},
			handleCancel() {
				this.isShow = false;
				this.amount = "";
				// this.password = "";
				this.current = 0;
			},
			handleConfirm() {
				if (this.checkForm()) {
					this.buy();
				}
			},
			checkForm() {
				if (this.amount == '') {
					uni.$u.toast(this.$lang.TRADE_LARGE_TIP_BUY_COUNT);
					return false;
				}
				// if (this.password == '') {
				// 	uni.$u.toast(this.$lang.TRADE_LARGE_TIP_BUY_PWD);
				// 	return false;
				// }
				return true;
			},
			async buy() {
				const result = await postTradeLargeBuy({
					id: this.detail.id,
					num: this.amount,
					// pay_pass: this.password,
					ganggan: this.curLever.index,
				});
				if (result.code == 0) {
					uni.$u.toast(result.message);
					this.isShow = false;
					this.changeTab(1);
				} else {
					this.isShow = false;
					uni.$u.toast(result.message);
				}
			},
			async getList() {
				const result = await getTradeLargeList();
				if (result.code == 0 && result.data) {
					// 过滤掉不合格数据，当前以【gid】字段来判定。
					this.list = result.data.filter(item => item.gid && item.gid > 0);
				} else {
					uni.$u.toast(result.message);
				}
			},
			async available() {
				const result = await userFastInfo();
				if (result.code == 0) {
					this.availBal = this.$util.formatNumber(result.data.money);
					this.leverList = [{
						name: 1,
						index: 1
					}];
					if (result.data.ganggan) {
						this.leverList.push(...result.data.ganggan);
					}
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>