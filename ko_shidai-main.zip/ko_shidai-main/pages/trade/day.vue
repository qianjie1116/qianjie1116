<!-- 日内交易 -->
<template>
	<view>
		<view style="background-image: linear-gradient(180deg, #dc0112, transparent);">
			<HeaderSecond :title="$lang.PAGE_TITLE_TRADE_DAY"></HeaderSecond>
		</view>

		<TabsFourth :tabs="$lang.TRADE_DAY_TABS" color="#FFF" @action="changeTab" :acitve="curTab"></TabsFourth>


		<view style="padding: 10px;margin-bottom: 20px;">
			<template v-if="curTab==0">
				<TradeDayBuy @action="changeTab"></TradeDayBuy>
			</template>

			<template v-else-if="curTab==1">
				<TradeDayOrderList></TradeDayOrderList>
			</template>
			<template v-else>
				<TradeDaySuccessList></TradeDaySuccessList>
			</template>
		</view>


	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TabsFourth from '@/components/tabs/TabsFourth.vue';
	import TradeDayBuy from '@/components/trade/TradeDayBuy.vue';
	import TradeDayOrderList from '@/components/trade/TradeDayOrderList.vue';
	import TradeDaySuccessList from '@/components/trade/TradeDaySuccessList.vue';
	export default {
		components: {
			HeaderSecond,
			TabsFourth,
			TradeDayBuy,
			TradeDayOrderList,
			TradeDaySuccessList,
		},
		data() {
			return {
				options: {},
				curTab: 0,
			}
		},
		onLoad(opts) {
			this.options = opts;
		},
		computed: {
			title() {
				return this.options.tag;
			}
		},
		methods: {
			// 切换 tab
			changeTab(val) {
				this.curTab = val;
			},
		},
	}
</script>