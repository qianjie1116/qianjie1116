<template>
	<view>
		<view class="home_header">
			<HeaderPrimary :title="$lang.TABBAR_HOME"></HeaderPrimary>
		</view>

		<view
			style="background-color:#FFFFFF;width: 100%;margin-top: -50px;border-radius: 30px 30px 0 0;padding-top: 20px;">
			<ButtonGroup :btns="$util.homeBtns()"></ButtonGroup>

			<!-- <CustomTitle :title="$lang.STOCK_FOLLOW">
				<view style="font-size: 14px;margin-left: auto;" @click="linkFollow()" :style="{color:$theme.PRIMARY}">
					{{$lang.MORE}}
				</view>
			</CustomTitle> -->
          
		   <view style="padding: 15px 0px;">
			   <FollowList ref="follow"></FollowList>
		   </view>
			
             
			<CustomTitle :title="$lang.STOCK_ALL">
				<view style="font-size: 14px;margin-left: auto;" @click="linkAllList()" :style="{color:$theme.PRIMARY}">
					{{$lang.MORE}}
				</view>
			</CustomTitle>

			<GoodsList ref="goods"></GoodsList>
		</view>

		<!-- IPO申购成功弹层 -->
		<view class="mask" @click="handleClose()" v-if="isShow">
			<view style="position:absolute;left: 50%;transform: translateX(-50%);bottom: 15vh;" @click="handleClose()">
				<image src="/static/close_light.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
			</view>
			<view style="position:relative;left: 50%;transform: translateX(-35%);bottom: -18vh;" @click="handleClose()">
				<image src="/static/tanchuang.png" mode="widthFix" style="width: 280px;"></image>
			</view>
			<view style="position: fixed;top:25vh;left: 45%;transform: translateX(-50%);">
				<view class="" >
					
					<view
						style="width: 120%;border-radius: 6px;text-align: center;padding:10px 10px 20px 10px;margin-top:80rpx;">
						<view style="font-size: 40rpx;font-weight: 700;color: #000;padding:4px 40px;">
							{{info.name}}
						</view>
						<view style="font-size: 28rpx;font-weight: 700;color: #dc0313;padding:4px 40px;">
							{{info.code}}
						</view>

						<view style="font-size: 12px;color:#dc0313;padding:2px 0 10px 0;">
							{{$lang.DIALOG_IPO_SUCCESS_TIP_TEXT}}
						</view>
						<view
							style="padding: 10px 0;display: flex;align-items: center;justify-content: space-between;padding:10px 40px;">
							<view>{{$lang.DIALOG_IPO_SUCCESS_LABEL_QTY}}</view>
							<text style="font-weight: 700;color:#ff3636;font-size: 16px;">
								{{$util.formatNumber(info.success)}}</text>
						</view>
						<view
							style="padding: 10px 0;display: flex;align-items: center;justify-content: space-between;padding:10px 40px;">
							<view>{{$lang.DIALOG_IPO_SUCCESS_LABEL_TOTAL}}</view>
							<text
								style="font-weight: 700;color:#ff3636;font-size: 16px;">{{$util.formatNumber(info.total)}}</text>
						</view>
						<view
							style="padding: 10px 0;line-height: 1.5;background-color:#dc0313;border-radius: 100px;color:#FFF;margin:40rpx; margin-top: 80rpx;"
							@click="linkIPOSuccessLog()">{{$lang.BTN_DETAIL_NOW}}</view>
					</view>
				</view>
			</view>
		</view>

	</view>
</template>

<script>
	import {
		STOCK_ALL,
		STOCK_FOLLOW
	} from '@/common/paths.js';
	import {
		getIPOSuccess
	} from '@/common/api.js';
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import GoodsList from '@/components/GoodsList.vue';
	import FollowList from '@/components/FollowList.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	export default {
		components: {
			HeaderPrimary,
			ButtonGroup,
			GoodsList,
			FollowList,
			CustomTitle,
		},
		data() {
			return {
				// timer: null,
				isShow: false,
				info: {}, // 中签弹层
			}
		},

		onLoad() {
			console.log('onLoad', this.$refs.goods);
			console.log('onLoad', this.$refs.follow);
			this.ipoSuccess();
		},

		onShow() {
			console.log('onShow', this.$refs.goods);
			console.log('onShow', this.$refs.follow);
			if (this.$refs.goods) {
				this.$refs.goods.onSetTimeout();
			}
			if (this.$refs.follow) {
				this.$refs.follow.onSetTimeout();
			}
		},
		onReady() {
			console.log('onReady', this.$refs.goods);
			console.log('onReady', this.$refs.follow);
		},
		onHide() {
			console.log('onHide', this.$refs.goods);
			console.log('onHide', this.$refs.follow);
			this.$refs.goods.clearTimer();
			this.$refs.follow.clearTimer();
		},
		deactivated() {
			console.log('deactivated', this.$refs.goods);
			console.log('deactivated', this.$refs.follow);
			this.$refs.goods.clearTimer();
			this.$refs.follow.clearTimer();
		},
		methods: {
			// 跳转到全部股票
			linkAllList() {
				uni.navigateTo({
					url: STOCK_ALL
				})
			},
			// 
			linkFollow() {
				uni.switchTab({
					url: STOCK_FOLLOW
				})
			},
			handleClose() {
				this.isShow = false;
			},

			linkIPOSuccessLog() {
				uni.navigateTo({
					url: `/pages/trade/ipo?type=2`
				})
			},
			async ipoSuccess() {
				const result = await getIPOSuccess();
				console.log(result);
				if (result && result.data && result.data.length > 0) {
					this.isShow = true;
					const temp = result.data[0];
					this.info = {
						name: temp.goods.name,
						code: temp.goods.code,
						success: temp.success,
						total: temp.total
					}
				}

			}
		},
	}
</script>


<style>
	.mask {
		background-color: rgba(0, 0, 0, 0.35);
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 999;
	}

	.bg_ad {
		/* background-image: url(/static/dialog_bg_ipo_success.png); */
		background-image: linear-gradient(180deg, #edbf36, #FFFFFF);
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		height: 40vh;
		width: 80vw;
		display: flex;
		flex-wrap: nowrap;
		flex-direction: column;
		align-items: center;
		border-radius: 20px;
		padding: 20px 0;
	}
</style>