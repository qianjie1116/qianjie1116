<template>
	<view class="launch">
		<view>
			<image src='/static/tu.png' mode="widthFix" style="margin-bottom: 50px;width: 250px;">
				<!-- :style="$util.setImageSize(500)" -->
			</image>
		</view>

		<view class="launch_tip">
			<image src='/static/logo.png' style=" width: 100px; height: 80px;">
			</image>
			<!-- {{`${$lang.STATUS_LOADING} `}}
			(<u-count-to :startVal="1" :endVal="percentage" :duration="1500" :useEasing="true" fontSize="16"
				:color="$theme.PRIMARY"></u-count-to> {{` % `}}) -->
		</view>

		<view class="launch_progress">
			<u-line-progress :percentage="percentage" height="8" activeColor="#F5B71C"
				:showText="false"></u-line-progress>
		</view>
	</view>
</template>

<script>
	import {
		HOME
	} from '@/common/paths.js';
	export default {
		data() {
			return {
				percentage: 1, // 进度条初始值
			}
		},
		onLoad() {
			uni.$u.sleep(1800).then(() => {
				this.percentage = 100;
				//跳转到首页 缓一秒，否则看不到进度条加满效果
				uni.$u.sleep(1500).then(() => {
					uni.switchTab({
						url: HOME,
					})
				})
			})
		},
	}
</script>
