<!-- 下单 -->
<template>
	<view>
		<view style="background-image: linear-gradient(180deg,#dc0112, transparent);">
			<HeaderSecond :title="stockInfo.name"></HeaderSecond>
		</view>
		<view style="border-radius: 12px;margin:16px;">
			<view style="display: flex;padding:10px;">
				<view style="padding-left: 10px;color:#000;font-size: 32rpx;">{{$lang.TIP_AMOUNT_AVAIL}}</view>
				<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
					:style="$util.setImageSize(40)" style="margin-left: auto;">
				</image>
			</view>
			<view style="font-size: 64rpx;font-weight: 700;color:#000;padding-left: 20px;line-height: 2">
				{{showAmount?$util.formatNumber(userInfo.money)+$lang.CURRENCY_UNIT:hideAmount}}
			</view>
		</view>

		<view class="common_block" style=";margin-top: 20px;padding:20px 10px;">
			<view class="flex padding-bottom-10">
				<view style="margin-left: 10px;" :style="{color:$theme.TEXT}">{{stockInfo.name}}</view>
				<view class="text-right flex-1 bold margin-right-20">
					<view :style="{color:$theme.TEXT}">
						{{$util.formatNumber(stockInfo.current_price)}}<text
							style="padding:0 4px">{{$lang.CURRENCY_UNIT}}</text>
					</view>
					<view :style="$util.setStockRiseFall(stockInfo.rate>0)">{{stockInfo.rate}}%</view>
				</view>
			</view>

			<CustomTitle :title="$lang.STOCK_BUY_QUANTITY"></CustomTitle>

			<view class="btns">
				<block v-for="(item,index) in quantityList" :key="index">
					<view class="item"
						style="flex:30%;margin:4px;font-weight: 700;line-height: 60rpx;text-align: center;margin-bottom: 20rpx;border-radius: 6px;"
						:style="$util.setTabSecondActive(curQuantity==item,'#F6F8FC')" @click="chooseQTY(item)">
						{{item}}
					</view>
				</block>
			</view>

			<view class="common_input_wrapper" style="background-color:#FFFFFF;border: 1px solid #E8EAF3;">
				<view style="width: 20px;"></view>
				<input v-model="quantity" type="number" :placeholder="$lang.STOCK_BUY_TIP_QUANTITY" @input="handleInput"
					:placeholder-style="$util.setPlaceholder()"></input>
			</view>

			<!-- 杠杆数组大于1，视为开启杠杆功能 -->
			<template v-if="leverList.length>1">
				<CustomTitle :title="$lang.LEVER"></CustomTitle>
				<view class="btns">
					<block v-for="(item,index) in leverList" :key="index">
						<view class="item"
							style="flex:10%;margin:4px;font-weight: 700;line-height: 60rpx;text-align: center;margin-bottom: 20rpx;border-radius: 6px;"
							:style="$util.setTabSecondActive(curLever==item,'#F6F8FC')" @click="chooseLever(item)">
							{{$util.formatNumber(item)}}
						</view>
					</block>
				</view>
			</template>

			<view
				style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
				:style="{color:$theme.TEXT}">
				<view>{{$lang.STOCK_BUY_QUANTITY}}</view>
				<view :style="{color:$theme.PRIMARY}">
					{{$util.formatNumber(quantity)}}
				</view>
			</view>

			<template v-if="leverList.length>1">
				<view
					style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
					:style="{color:$theme.TEXT}">
					<view>{{$lang.LEVER}}</view>
					<view :style="{color:$theme.PRIMARY}">
						{{curLever}}
					</view>
				</view>
			</template>

			<view
				style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
				:style="{color:$theme.TEXT}">
				<view>{{$lang.STOCK_BUY_AMOUNT}}[{{$lang.CURRENCY_UNIT}}]</view>
				<view :style="{color:$theme.PRIMARY}">
					{{$util.formatNumber(stockInfo.current_price*curQuantity/curLever)}}
				</view>
			</view>
			<view
				style="font-size: 28rpx;display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
				:style="{color:$theme.TEXT}">
				<view>{{$lang.STOCK_BUY_FEE}}[{{$lang.CURRENCY_UNIT}}]</view>
				<view :style="{color:$theme.PRIMARY}">
					{{$util.formatNumber(stockInfo.current_price*curQuantity/curLever*fee)}}
				</view>
			</view>

			<view class="access_btn" style="margin:20px auto; width: 90%;background-color: #e1262c;color: #fff;" @click="placeOrder()">
				{{$lang.BTN_BUY}}
			</view>
		</view>
	</view>
</template>

<script>
	import {
		getAPPConfig,
		accountInfo,
		postStockBuy,
		getStockInfo
	} from '@/common/api';
	import {
		ACCOUNT_TRADE
	} from '@/common/paths';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	export default {
		components: {
			HeaderSecond,
			CustomTitle,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				quantityList: [100, 300, 500, 1000, 3000, 5000], // 预置数量
				curQuantity: 100, // 当前选中预置数量
				quantity: 100, // 数量输入框 
				leverList: [], // 杠杆值数组
				curLever: 1, // 当前选中杠杆值
				show: false,
				stockInfo: {},
				userInfo: {},
				fee: 1, // 手续费
			};
		},
		onLoad(option) {
			this.getStockDetail(option.code)
			this.getconfig();
			this.getUserInfo()
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// 选择数量
			chooseQTY(val) {
				this.curQuantity = val;
				this.quantity = this.curQuantity;
			},
			// 选择杠杆
			chooseLever(val) {
				this.curLever = val;
			},

			// 获取配置
			async getconfig() {
				const result = await getAPPConfig();
				if (result.code == 0) {
					const temp = result.data.reduce((map, item) => {
						map.set(item.key, item.value);
						return map;
					}, new Map());
					this.fee = temp.get('TransRate') || this.fee;
				}
			},

			// 输入值
			handleInput(e) {
				this.curQuantity = Number(e.detail.value)
			},

			// 产品详情
			async getStockDetail(code) {
				const result = await getStockInfo({
					code: code,
				})
				this.stockInfo = result.data[0]
			},
			//购买
			placeOrder() {
				const _this = this;
				let money = this.$util.formatNumber(this.stockInfo.current_price * this.curQuantity * 1)
				uni.showModal({
					title: this.$lang.STOCK_BUY_CONFIRM,
					content: `${this.stockInfo.name} ${this.$util.formatNumber(this.curQuantity)} ${this.$lang.QUANTITY_UNIT} ,${this.$lang.STOCK_BUY_AMOUNT} ${money} ${this.$lang.CURRENCY_UNIT}`,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					showCancel: true, // 是否显示取消按钮，默认为 true
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
					success: (res) => {
						if (res.confirm) {
							_this.buy()
						} else {}
					}
				})
			},
			async buy() {
				const result = await postStockBuy({
					num: this.quantity || 0,
					gid: this.stockInfo.gid,
					price: this.stockInfo.current_price,
					ganggan: this.curLever,
				});
				if (result.code == 0) {
					uni.$u.toast(result.message);
					setTimeout(() => {
						uni.switchTab({
							url: ACCOUNT_TRADE,
						});
					}, 1000)
				} else {
					uni.$u.toast(result.message);
				}
			},
			// 获取账户信息
			async getUserInfo() {
				const result = await accountInfo();
				if (result.code == 0) {
					this.userInfo = result.data;
					if (result.data.ganggan) {
						const temp = result.data.ganggan.map(item => Number(item));
						this.leverList = temp;
					}
				} else {
					uni.$u.toast(result.message);
				}
			},
		},
	}
</script>