# 타임 스마트
## 当前尚未使用

![LOGO](https://github.com/github1413/타임 스마트/raw/main/static/logo.png)

# TODO
- 完全替换uview-ui。
- 

# Update Log 2024.05.05
- 添加股权交易

# Update Log 2024.05.03
- 日内交易，添加可用金额

# Update Log 2024.05.01
- 优化`access`页面，记住密码及用户隐私协议完整逻辑。