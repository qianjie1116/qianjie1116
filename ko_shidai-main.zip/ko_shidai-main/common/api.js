import http from '@/common/http.js';

const POST = 'POST';

// 登录
export const postSignIn = (data, title) => http(`app/login`, {
	method: POST,
	data,
	title
});
// 注册 创建账户
export const postSignUp = (data, title) => http(`app/register`, {
	method: POST,
	data,
	title
});
// 登出 
export const signOut = () => http(`app/logout`);

// 获取APP config
export const getAPPConfig = () => http(`app/config`);
// 用户信息
export const accountInfo = () => http(`user/info`);
// 可用金额
export const userFastInfo = () => http(`user/fastInfo`);
// 变更登入密码
export const putSignInPwd = (data) => http(`user/updateLoginPassword`, {
	method: POST,
	data
});
// 变更支付密码
export const putPayPwd = (data) => http(`user/updatePayPassword`, {
	method: POST,
	data
});
// 绑定银行卡
export const bindBankCard = (data) => http(`user/bindBankCard`, {
	method: POST,
	data
});
// 提款
export const postWithdarw = (data) => http(`app/withdraw`, {
	method: POST,
	data
});
// 入金
export const postDeposit = (data) => http(`app/recharge`, {
	method: POST,
	data
});

// 更新个人信息
export const putAccountInfo = (data) => http(`user/updateAvatar`, {
	method: POST,
	data
});

// 资金明细
export const getAccountFinance = () => http(`user/finance`);
// 充值记录
export const getAccountDeposit = () => http(`user/recharge`);
// 提现记录
export const getAccountWithdraw = () => http(`user/withdraw`);
// 取消 提现记录中使用
export const postCancelWithdraw = () => http('app/qx', {
	method: POST,
	data
});
// 持股和卖出 的订单
export const getTradeList = (data) => http(`user/order`, {
	data,
	hide: true,
});
// 卖出
export const postStockSell = (data, title) => http(`user/sell`, {
	method: POST,
	data,
	title
});

// 实名认证
export const postAuth = (data, title) => http(`user/real-auth1`, {
	method: POST,
	data,
	title,
});

// 获取股票列表
export const getStockList = (data) => http(`goods/list`, {
	data,
	hide: true,
});
// 获取关注的股票列表
export const getFollowList = () => http(`user/collect_list`, {
	hide: true,
});
// 取消关注
export const updateFollow = (data) => http(`user/collect_edit`, {
	method: POST,
	data
});

// 股票详情
export const getStockInfo = (data) => http(`product/info`, {
	data,
	hide: true
});

// 单股 K线数据
export const getKLineData = (data) => http(`product/lishi`, {
	data,
	hide: true
});
// 单股购买
export const postStockBuy = (data) => http(`product/purchase`, {
	method: POST,
	data
});


// 单股详情 tab2数据
export const getStockInfoMore = (data) => http(`product/info_two`, {
	data
});
// 单股详情 tab2数据 
export const getStockInfoSales = (data) => http(`product/info_two1`, {
	data
});

// 单股新闻
export const getStockNews = (data) => http(`product/news`, {
	data
});

// 查询页面 根据股票名称或代码查询
export const postSearchList = (data) => http(`product/list`, {
	data
});


// 日内交易 购买
export const postTradeDayBuy = (data, title) => http(`rinei/buy`, {
	method: POST,
	data,
	title
});
// 日内交易 申请列表
export const getTradeDayOrderList = () => http(`rinei/sq-list`);
// 日内交易 持仓列表，即申请成功
export const getTradeDaySuccessList = () => http(`rinei/order-list`);


// 大宗交易 产品列表
export const getTradeLargeList = () => http(`goods-bigbill/list`);
// 大宗交易 产品详情
export const getTradeLargeDetail = (code) => http(`goods-bigbill/detail?id=${code}`);
// 大宗交易 产品下单
export const postTradeLargeBuy = (data) => http(`goods-bigbill/doOrder`, {
	method: POST,
	data
});
// 大宗交易，交易记录
export const getTradeLargeOrderLog = () => http(`goods-bigbill/user-order-log`);

// 折价交易 列表
export const getTradeDiscountList = () => http(`goods-discount/list`);
//  折价交易 单数据详情
export const getTradeDiscountDetail = (code) => http(`goods-discount/detail?id=${code}`);
//  折价交易 下单
export const postTradeDiscountBuy = (data) => http(`goods-discount/doOrder`, {
	method: POST,
	data
});
// 折价交易，交易记录
export const getTradeDiscountOrderLog = () => http(`goods-discount/user-order-log`);

// IPO交易 列表
export const getIPOList = (data) => http(`goods-shengou/calendar`, {
	data
});
// IPO 交易 申购
export const postBuyIPO = (data) => http(`goods-shengou/doOrder`, {
	method: POST,
	data
});
// IPO交易，交易记录
export const getIPOOrderLog = () => http(`goods-shengou/user-order-log`);
// IPO交易 成功列表
export const getIPOSuccessList = (data) => http(`goods-shengou/user-success-log`, {
	data
});
// IPO 交易 支付
export const postIPOPay = (data) => http(`goods-shengou/pay`, {
	method: POST,
	data
});

// EA 股权列表
export const getEquityList = () => http(`goods-guquan/list`);
// 购买 
export const postBuyEquity = (data) => http(`goods-guquan/doOrder`, {
	method: POST,
	data
});
// 交易记录
export const getEquityOrderLog = () => http(`goods-guquan/user-order-log`);
// 补缴
export const postEquityDeficiency = (data) => http(`goods-guquan/renjiao`, {
	method: POST,
	data
})

// 市场概况 折线数据、最近新闻
export const getMarketOverview = (data) => http(`goods/top1`, {
	data,
	hide: true
});
// 市场排行top1-5
export const getMarketOverviewHot = (data) => http(`goods/top2`, {
	data
});



// 市场新闻
export const getMarketNews = (data) => http(`goods/get_news`, {
	data
});
// 市场指标
export const postMarketIndex = (data) => http(`goods/zhibiao`, {
	method: POST,
	data
});
// 市场排行
export const postMarketHot = (data) => http(`goods/paihang`, {
	method: POST,
	data
});



// 关于我们
export const getAboutInfo = () => http('article/about-us');
// 隐私
export const getPactInfo = () => http(`article/privacy`);
// 用户协议
export const getAgreeInfo = () => http(`article/user-agree`);


export const getIPOSuccess=()=>http(`goods-shengou/tanchuang`);



// 一些未用到的API，从一些未知页面整理，备用。
/* 
tradingShares.vue
//상하이市
async topTenshang() {
	let list = await this.$http.get('api/stock-api/BaseTop10Active', {
		exchange_kind: 1
	})
	this.shangHai = list.data.data
	// console.log(this.shangHai, '1111111111');

},
//깊은市
async topTenshen() {
	let list = await this.$http.get('api/stock-api/BaseTop10Active', {
		exchange_kind: 3
	})
	this.deep = list.data.data
	// console.log(this.deep, '222222222');
},

 stopResumeTrading.vue
get('api/stock-api/BaseSuspensionList', {})

dragonTiger.vue
// 列表 
async tigerList() {
	let list = await this.$http.get('api/stock-api/BaseDragonTiger', {})
	this.dragon = list.data.data
},
// 弹窗详情 
async popNotification(item) {
	let list = await this.$http.get('api/stock-api/BaseDragonTigerInfo', {secu_code: item.secu_code})
	this.detailed = list.data.data
},

dailyLimit.vue
get('api/stock-api/PoolZT', {})

ration/ration.vue
get('api/goodsscramble/userApplyLog', {})

placeOrder.vue
let list = await this.$http.post('api/product/buy_vip_scramble', {
	num: this.quantity * 100,
	id: this.objData.id,
})

offlinePlacement.vue
async scrambleForFunds(id) {
	let list = await this.$http.get('api/goods-scramble/detail', {id: this.id})
	this.scrambleFor = list.data.data
},
async placeOrder(id) {
	let list = await this.$http.post('api/goods-scramble/doOrder', {
		num: this.quantity,
		id: id,
		price: this.scrambleFor.price,
		double: 1
	})
	
duihuan.vue

版本更新
async edition() {
	let list = await this.$http.get('api/version/detail', {
		// language: this.$i18n.locale
	})
	this.agreement = list.data.data
},

*/

// export const TRADE_SHORT_LIST = `goods-duanda/list`; // 短打交易 列表
// export const TRADE_SHORT_DETAIL = `goods-duanda/detail`; // 短打交易 单数据详情
// export const TRADE_SHORT_ORDER = `goods-duanda/doOrder`; // 短打交易 下单