import enUS from '@/locale/en-US.js';
import zhHK from '@/locale/zh-hant.js';
// import zhCN from '@/locale/zh-hans.js';
import jaJP from '@/locale/ja-JP.js';
// import koKR from '@/locale/ko-KR.js';
import Arabic from '@/locale/Arabic.js';
import French from '@/locale/French.js';
import Portuguese from '@/locale/Portuguese.js';
import Spanish from '@/locale/Spanish.js';
import Russian from '@/locale/Russian.js';

// 到处前，根据项目需求，注释不需要的语言包。
// 注意：此处需与`Translate`中定义的数组对应。
export default {
	'en-US': enUS, // 英语
	'zh-hant': zhHK, // 繁中
	// 'zh-CN': zhCN, // 简中
	// 'ko-KR': koKR, // 韩语
	'ja-JP': jaJP, // 日语
	'fr-FR': French, // 法语
	'ar-IL': Arabic, // 阿拉伯语
	'pt-BR': Portuguese, // 葡萄牙语
	'es-ES': Spanish, // 西班牙语
	'ru-RU': Russian, // 俄语
};