<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view
				style="background-color: #FFFFFF; padding:20rpx 30rpx;border-radius: 28rpx;line-height: 1.8;margin:0 20rpx 20rpx 20rpx;">

				<view style="display: flex;align-items: center;margin-bottom: 16rpx;">
					<view style="flex: 1 0 45%; border-bottom: 1px Solid #F3F3F3;">
						<view :style="{color:$theme.LOG_LABEL}">
							{{$lang.LOG_TRADE_AMOUNT_AFTER}}
						</view>
						<view style="font-size: 36rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatMoney(item.after)}}
						</view>
					</view>
					<view style="flex:1 0 10%;"></view>
					<view style="flex: 1 0 45%; border-bottom: 1px Solid #F3F3F3;">
						<view :style="{color:$theme.LOG_LABEL}">
							{{$lang.LOG_TRADE_AMOUNT_BEFORE}}
						</view>
						<view style="font-size: 36rpx;" :style="{color:$theme.LOG_VALUE}">
							{{$util.formatMoney(item.before)}}
						</view>
					</view>
				</view>

				<view style="display: flex;align-items: center;margin-bottom: 16rpx;">
					<view style="flex: 1 0 45%; border-bottom: 1px Solid #F3F3F3;">
						<view :style="{color:$theme.LOG_LABEL}">
							{{$lang.LOG_TRADE_DW}}
						</view>
						<view :style="{color:$theme.PRIMARY}">
							{{$util.formatMoney(item.money)}}
						</view>
					</view>
					<view style="flex:1 0 10%;"></view>
					<view style="flex: 1 0 45%; border-bottom: 1px Solid #F3F3F3;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.LOG_TRADE_CREATE_TIME}}</view>
						<view :style="{color:$theme.LOG_VALUE}">
							{{item.created_at}}
						</view>
					</view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.LOG_TRADE_DESC}}</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;"></view>
					<text :style="{color:$theme.LOG_VALUE}"
						style="white-space:pre-wrap;text-align: right;">{{item.desc}}</text>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogTrade",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		computed: {},
		created() {
			this.getList()
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.get(`api/user/finance`);
				this.list = result || [];
			},
		}
	}
</script>

<style>

</style>