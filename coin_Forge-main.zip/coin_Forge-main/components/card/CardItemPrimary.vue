<template>
	<view>
		<view style="display: flex;align-items: center;line-height: 1.6;">
			<view style="color:#FFFFFF;font-size: 32rpx;">
				{{labels[0]}}
			</view>
			<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click.stop="handleShowAmount"
				:style="$theme.setImageSize(40)" style="margin-left: 10px;">
			</image>
		</view>
		<view style="font-size: 58rpx;font-weight: 500;color:#FFFFFF;line-height: 1.6;">
			{{showAmount?info.value1:hideAmount}}
		</view>

		<view style="display: flex;align-items: center;color:#FFFFFF;font-size: 28rpx;">
			<view style="flex:1 0 50%;">
				<view>{{labels[1]}}</view>
				<view>{{showAmount?info.value2:hideAmount}}</view>
			</view>
			<view style="flex:1 0 50%;text-align: right;">
				<view>{{labels[2]}}</view>
				<view>{{showAmount?info.value3:hideAmount}}</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'CardItemPrimary',
		props: {
			info: {
				type: Object,
				default: {}
			},
			// label。单独分开，否则会因数据请求慢，导致label未加载
			labels: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				showAmount: uni.getStorageSync('show') || false, // 显示金额
				hideAmount: '****', // 隐藏金额
			}
		},
		methods: {
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
				this.$util.setShowData(this.showAmount);
			},
		}

	}
</script>