<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<header class="common_header" style="background-color: #2d3535;">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left_w.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text class="color-white">{{$lang.CONVERT_TITLE}}</text>
			</view>
			<view class="right">
				<!-- @click="linkRecord()" -->
				<!-- <image src="/static/icon_record.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image> -->
			</view>
		</header>

		<view style="padding:36rpx; padding-bottom: 200rpx;">
			<view :style="setBG">
				<view style="padding: 40rpx 0 20rpx 40rpx;font-size: 28rpx;">{{$lang.CONVERT_AVAILABLE}}({{curUnit}})
				</view>
				<view style="padding: 0 0 20rpx 40rpx;font-size: 40rpx;">{{$util.addThousandSeparator(available)}}
				</view>
			</view>

			<view class="common_input_wrapper"
				style="background-color:#242f3d;border-radius: 16rpx;padding-left:24rpx;margin:40rpx 0 ;">

				<template v-if="curMode==0">
					<input v-model="fromAmount" type="digit" :placeholder="$lang.DEPOSIT_ENTER_AMOUNT"
						:placeholder-style="$theme.setPlaceholder()" style="width: 60%;color: #FFFFFF;"></input>

					<view style="margin-left: auto;" @click="chooseCoin()">
						<view style="display: flex;align-items: center;padding-right: 20rpx;">
							<view style="padding-right: 20rpx;color: #ccc;">{{curCoin.unit}}</view>
							<CustomLogo :logo="curCoin.logo" :name="curCoin.label" :size="48" />
						</view>
					</view>
				</template>

				<template v-else>
					<input v-model="fromAmount" type="digit" :placeholder="$lang.DEPOSIT_ENTER_AMOUNT"
						:placeholder-style="$theme.setPlaceholder()" style="width: 70%;color: #FFFFFF;"></input>
					<view style="padding-right:10rpx;color:#295FFF;" @click="handleAll()">{{$lang.COMMON_ALL}}</view>
					<view style="margin-left: auto;">
						<view style="display: flex;align-items: center;padding-right: 20rpx;">
							<view style="padding-right: 20rpx;color: #ccc;">{{usdtInfo.unit}}</view>
							<CustomLogo :logo="``" :name="usdtInfo.unit" :size="48" />
						</view>
					</view>
				</template>
			</view>

			<view style="display: flex;align-items: center;justify-content: center;">
				<image src="/static/convert_toggle.png" mode="aspectFit" :style="$theme.setImageSize(80)"
					@click="toggleMode()"></image>
			</view>

			<view class="common_input_wrapper"
				style="background-color:#242f3d;border-radius: 16rpx;padding-left:24rpx;margin:40rpx 0 ;">
				<view style="padding-right: 20rpx;color: #FFFFFF;">{{toAmount}}</view>
				<view style="margin-left: auto;">
					<template v-if="curMode==0">
						<view style="display: flex;align-items: center;padding-right: 20rpx;">
							<view style="padding-right: 20rpx;color: #ccc;">{{toCoin.unit}}</view>
							<CustomLogo :logo="toCoin.logo" :name="toCoin.unit" :size="48" />
						</view>
					</template>
					<template v-else>
						<view style="display: flex;align-items: center;padding-right: 20rpx;" @click="chooseCoin()">
							<view style="padding-right: 20rpx;color: #ccc;">{{toCoin.unit}}</view>
							<CustomLogo :logo="toCoin.logo" :name="toCoin.unit" :size="48" />
						</view>
					</template>
				</view>
			</view>

			<view style="padding-top: 40rpx;color: #ccc;">
				{{$lang.CONVERT_RATES}}
			</view>
			<template v-if="curCoin.price>=0">
				<view style="text-align: right;color: #FFFFFF;">
					1{{curCoin.unit+` ≈ `+$util.addThousandSeparator(curRate) +` `+usdtInfo.unit}}
				</view>
			</template>
		</view>


		<view style="position: fixed;bottom: 10rpx;left: 0;right: 0;">
			<view style="margin:40rpx auto;width: 80%;min-height: 40px;line-height: 40px;font-size: 16px;"
				:style="setStyleSubmit()" @click="handleSubmit()">
				{{$lang.COMMON_SUBMIT}}
			</view>
		</view>

		<!-- Coin  選擇器 -->
		<u-picker :show="isShowCoinList" :columns="[coinList]" @change="changeCoin" @cancel="isShowCoinList=false"
			@confirm="confirmCoin" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" keyName="label"
			visibleItemCount="9"></u-picker>
	</view>
</template>

<script>
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		components: {
			CustomLogo
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isShowCoinList: false, // 是否顯示 coin選擇器
				coinList: [],
				curCoin: {}, // 当前选中币
				curMode: 0, // 当前模式[to usdt or from usdt]，0:转到USDT
				available: '', // 当前可用余额 
				fromAmount: '', // 转入的输入值
				curRate: '', // 当前汇率
			};
		},
		computed: {
			usdtInfo() {
				return {
					label: ``,
					code: ``,
					logo: ``,
					unit: `USDT`,

				}
			},

			//  to coin
			toCoin() {
				return this.curMode == 1 ? this.curCoin : this.usdtInfo
			},

			// 计算转出金额
			toAmount() {
				if (this.fromAmount == '' || this.fromAmount <= 0) return '';
				if (this.curMode == 0) {
					return this.fromAmount * this.curRate > 0 ? this.fromAmount * this.curRate : ''
				} else {
					return this.fromAmount / this.curRate > 0 ? this.fromAmount / this.curRate : ''
				}
			},

			// 当前余额 单位
			curUnit() {
				return this.curMode == 0 ? this.curCoin.unit : `USDT`
			},
			// 设置背景  to_usdt to_usdt
			setBG() {
				const temp = this.curMode == 0 ? `to` : `from`;
				return {
					backgroundImage: `url(/static/${temp}_usdt.png)`,
					backgroundPosition: '0 0',
					backgroundSize: `100% 100%`,
					color: '#FFFFFF',
					borderRadius: `8rpx`,
					width: `100%`,
					height: `120px`,
				}
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getCoinList();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 转入转出模式切换
			toggleMode() {
				this.curMode = this.curMode == 0 ? 1 : 0;
				// 重新获取资金中的可用余额
				this.getAccountAssets();
				this.fromAmount = '';
			},

			// from输入框的all
			handleAll() {
				this.fromAmount = this.available;
			},

			linkRecord() {
				// uni.navigateTo({
				// 	url: this.$paths.CONVERT_RECORD					
				// })
				uni.switchTab({
					url: this.$paths.HOME
				})
			},
			// 選擇一種coin
			chooseCoin() {
				// this.getCoinList();
				this.isShowCoinList = true;
			},
			changeCoin(e) {
				console.log(`changeMode e:`, e);
			},
			// coin選擇器確認事件
			confirmCoin(e) {
				console.log(`confirmMode e:`, e);
				this.curCoin = e.value[0];
				this.isShowCoinList = false;
				this.getAccountAssets();
				this.getRate();
			},

			// 获取汇率
			async getRate() {
				const result = await this.$http.post(`api/user/shandui_huilu`, {
					coin1: this.curCoin.unit,
					coin2: this.usdtInfo.unit,
				});
				if (!result) return false;
				console.log(`rate:`, result);
				this.curRate = result;
			},

			// 提交
			async handleSubmit() {
				if (!this.fromAmount || this.fromAmount <= 0) {
					uni.showToast({
						title: this.$lang.DEPOSIT_ENTER_AMOUNT,
						icon: 'none'
					});
					return false;
				}
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/user/shandui`, {
					coin1: this.curMode == 0 ? this.curCoin.unit : this.usdtInfo.unit,
					coin2: this.curMode == 0 ? this.usdtInfo.unit : this.curCoin.unit,
					money: this.fromAmount,
				});
				if (!result) return false;
				console.log('result:', result);
				uni.showToast({
					// title: result,
					icon: 'success'
				});
				setTimeout(() => {
					this.linkRecord();
				}, 1000);
			},

			// 在切換coin時，需請求列表，製作coin選擇器數組
			async getCoinList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/goods/list`);
				if (!result) return false;
				console.log(result);
				this.coinList = Object.values(result).map(item => {
					return {
						label: item.name,
						code: item.code,
						logo: item.logo,
						unit: item.name.split('/')[0],
						price: item.current_price * 1,
					}
				});
				// 獲取數據之後，顯示選擇器
				// this.isShowCoinList = true;
				this.curCoin = this.coinList[0];
				this.getAccountAssets();
				this.getRate();
			},

			// 获取账户 資產信息
			async getAccountAssets() {
				const result = await this.$http.post(`api/user/assets`, {
					type: 2,
					// coin to usdt 时，获取coin的余额，否则获取usdt余额
					name: this.curMode == 0 ? this.curCoin.code : this.usdtInfo.unit,
				});
				console.log(`assets:`, result);
				if (!result) return false;
				this.available = result.length > 0 ? result[0].money : '';
			},

			setStyleSubmit() {
				return {
					// backgroundColor: this.$theme.RGBConvertToRGBA('#6D41FF', 30),
					...this.$theme.linerGradient(90, '#295FFF', '#48DAFF'),
					backgroundRepeat: 'no-repeat',
					backgroundPosition: '0 0',
					backgroundSize: `100% 100%`,
					color: '#FFFFFF',
					borderRadius: `8rpx`,
					textAlign: `center`,
				}
			},
		},
	}
</script>

<style lang="scss" scoped>
	.common_header {
		padding: 32rpx;
		display: flex;
		align-items: center;

		.left {
			margin-right: auto;
		}

		.right {
			margin-left: auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 500;
			padding-left: 40rpx;
			flex: 1;
			text-align: left;
		}
	}
</style>