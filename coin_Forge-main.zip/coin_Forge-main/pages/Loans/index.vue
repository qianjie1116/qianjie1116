<template>
	<view>
		<view class="flex padding-20" style="background-color:#2d3535 ;">
			<view @click="daikuan()">
				<image src="/static/arrow_left_w.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="font-size-18 flex-1 text-center color-white">Borrowing</view>
		</view>
		
		<view style="width: 100%;justify-content: center;display: flex;">
			<image src="/static/jiedai.png" mode="aspectFill" style="width: 100%;border-radius: 10px;"></image>
		</view>

		<view style="padding: 20px;margin-top: -20px;">
			<view style="background-color: #242f3d;padding: 20px;border-radius: 10px;">
				<view class="flex"
					style="background-color: #2771f7;padding: 15px;border-radius: 10px;justify-content: center;display: flex;" @click="qianwang()">
					<view style="color: #fff;">Go to Loans</view>
					<image src="/static/youjt.png" mode="widthFix" style="width: 20px;margin-left: 10px;"></image>
				</view>

				<view class="flex padding-25" style="justify-content: center;display: flex;color: #fff;">
					<image src="/static/lx.png" mode="widthFix" style="width: 10px;margin-left: 20px;"></image>
					<view style="margin-left: 20px;">Product advantages</view>
					<image src="/static/lx.png" mode="widthFix" style="width: 10px;margin-left: 20px;"></image>
				</view>
				<view>
					<view>
						<view class="flex">
							<image src="/static/icon5.svg" mode="widthFix" style="width: 25px;"></image>
							<view class="bold margin-left-10 color-white">Customized VIP loan service</view>
						</view>
						<view class="font-size-13" style="color: #ccc;padding: 5px 0px;">
							The maximum loan amount is 10 million USDT, and the maximum support is 3X. The loan limit includes BTC, ETH, USDT, etc. 40+ mainstream</view>
					</view>

					<view style="margin-top: 20px;">
						<view class="flex">
							<image src="/static/iocn12.svg" mode="widthFix" style="width: 25px;"></image>
							<view class="bold margin-left-10 color-white">Interest rate level</view>
						</view>
						<view class="font-size-13" style="color: #ccc;padding: 5px 0px;">The higher the Prime level, the larger the loan amount and the lower the interest rate</view>
					</view>

					<view style="margin-top: 20px;">
						<view class="flex">
							<image src="/static/icon11.svg" mode="widthFix" style="width: 25px;"></image>
							<view class="bold margin-left-10 color-white">Flexible use of funds</view>
						</view>
						<view class="font-size-13" style="color: #ccc;padding: 5px 0px;">The loan period starts from 30 days, and you can repay as you borrow</view>
					</view>

					<view style="margin-top: 20px;">
						<view class="flex">
							<image src="/static/icon9.svg" mode="widthFix" style="width: 23px;"></image>
							<view class="bold margin-left-10 color-white">Simplified loan process</view>
						</view>
						<view class="font-size-13" style="color: #ccc;padding: 5px 0px;">1-3 days to complete the loan</view>
					</view>
				</view>

				<view class="flex padding-25" style="justify-content: center;display: flex;">
					<image src="/static/lx.png" mode="widthFix" style="width: 10px;margin-left: 20px;"></image>
					<view style="margin-left: 20px;color: #fff;">How to borrow</view>
					<image src="/static/lx.png" mode="widthFix" style="width: 10px;margin-left: 20px;"></image>
				</view>

				<view class="flex text-center" style=" justify-content: space-between;  ">
					<view class="flex-1 color-white">
						<image src="/static/icon8.svg" mode="widthFix" style="width: 20px;"></image>
						<view>Step.1</view>
						<view>Fill out the loan application form</view>
					</view>
					<view class="flex-1 color-white">
						<image src="/static/icon6.svg" mode="widthFix" style="width: 20px;"></image>
						<view>Step.2</view>
						<view>Confirmation of loan needs</view>
					</view>
				</view>

				<view class="flex text-center margin-top-20"
					style=" justify-content: space-between;">
					<view class="flex-1 color-white">
						<image src="/static/icon10.svg" mode="widthFix" style="width: 20px;"></image>
						<view>Step.3</view>
						<view>Sign loan contract</view>
					</view>
					<view class="flex-1 color-white">
						<image src="/static/icon7.svg" mode="widthFix" style="width: 20px;"></image>
						<view>Step.4</view>
						<view>Fund security lending</view>
					</view>
				</view>
			</view>



			<view style="margin-top: 20px;">
				<view style="background-color:#242f3d;border-radius: 10px;">
					<view class="flex padding-25" style="justify-content: center;display: flex;">
						<image src="/static/lx.png" mode="widthFix" style="width: 10px;margin-left: 20px;"></image>
						<view style="margin-left: 20px;color: #fff;">FAQ</view>
						<image src="/static/lx.png" mode="widthFix" style="width: 10px;margin-left: 20px;"></image>

					</view>


					<!-- 	<view class="flex">
				<view>使用场外借贷需要满足哪些条件?</view>
				<image src="/static/jia.png"></image>
			</view> -->

              <view style="padding: 10px;">
				  <template>
				  	<u-collapse @change="change" @close="close" @open="open" >
				  		<u-collapse-item  title="What conditions need to be met to use OTC lending?" name="Docs guide" >
				  			<text class="u-collapse-content" style="color: #ccc;">Market makers on this platform or customers with a VIP level ≥ 2 and professional trading capabilities, or professional customers with equivalent conditions on other platforms</text>
				  		</u-collapse-item>
				  		<u-collapse-item title="What are the cryptocurrencies that can be borrowed?">
				  			<text class="u-collapse-content" style="color: #ccc;">Borrowing currencies include BTC, ETH, USDT, USDC, 4 currencies (regularly update the margin and the list of borrowable currencies, and the popular currencies that meet the risk control requirements will be updated in time)</text>
				  		</u-collapse-item>
				  		<u-collapse-item title="How long is the loan term for OTC loans?" name="Numerous tools">
				  			<text class="u-collapse-content" style="color: #ccc;">Flexible loan cycle: 7 days to 1 year, loan can be repaid at any time, and the loan can be renewed upon maturity</text>
				  		</u-collapse-item>
				  	</u-collapse>
					<u-collapse @change="change" @close="close" @open="open">
						<u-collapse-item title="How to calculate interest?" name="Docs guide" >
							<text class="u-collapse-content" style="color: #ccc;">Interest is calculated daily. If the repayment is overdue, 0.5% of the total loan assets will be charged as interest per day.</text>
						</u-collapse-item>
						<u-collapse-item title="How to repay principal and interest?" name="Variety components">
							<text class="u-collapse-content" style="color: #ccc;">The interest is settled at the end of each month or the funds and interest are returned at the end of the period.</text>
						</u-collapse-item>
						<u-collapse-item title="Can I pay in advance?" name="Numerous tools">
							<text class="u-collapse-content" style="color: #ccc;">Yes, during the loan period, the user can increase the loan, repay in advance and defer repayment.</text>
						</u-collapse-item>
					</u-collapse>
				  </template>
			  </view>
					






				</view>
			</view>


		</view>




	</view>
</template>

<script>
export default {
		data() {
			return {
				
			}
		},
		methods: {
			open(e) {
				// console.log('open', e)
			},
			close(e) {
				// console.log('close', e)
			},
			change(e) {
				// console.log('change', e)
			},
			daikuan(){
				uni.navigateBack({
					delta:1,
				})
			},
			qianwang(){
				uni.navigateTo({
					url:'/pages/Loans/daikuan'
				})
			},
			
		}
	}
</script>

<style>
</style>