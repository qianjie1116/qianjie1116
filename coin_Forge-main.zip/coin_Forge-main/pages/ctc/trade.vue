<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<header class="common_header" style="background-color: #2d3535;">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left_w.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<view style="display: flex;align-items: center;padding-left: 48rpx;">
					<CustomLogo logo="" name="USDT" :size="48" />
					<view style="font-size: 28rpx;padding-left: 40rpx;color: #FFFFFF;">USDT </view>
				</view>
			</view>
			<view class="right"></view>
		</header>

		<view style="padding:36rpx; padding-bottom: 200rpx;">
			<view class="color-white">{{$lang.CTC_BY_AMOUNT}}</view>

			<view class="common_input_wrapper"
				style="border: 1px Solid #ccc;background-color:#242f3d;border-radius: 16rpx;padding-left:24rpx;color: #FFFFFF;">
				<!-- <view style="padding-right:10rpx;">$</view> -->
				<input v-model="amount" type="digit" :placeholder="$lang.DEPOSIT_ENTER_AMOUNT"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;color: #FFFFFF;"></input>
				<view style="padding-left:10rpx;">USD</view>
			</view>
			<view style="align-items: center;justify-content: space-between;">
				<!-- <view :style="{color:$theme.LOG_LABEL}">
					{{$lang.CTC_TIP2}}
				</view> -->
				<!-- Sell 是USD -->
				<view class="flex color-white">
					<view class="flex-1">{{$lang.CTC_MIN}}:</view>
					<view class="" style=" ">
						{{$util.formatCurrency(minxiane)}} USDT
					</view>
				</view>
				<view class="flex color-white">
					<view class="flex-1">{{$lang.CTC_MAX}}:</view>
					<view class="" style=" ">
						{{$util.formatCurrency(maxxiane)}} USDT
					</view>
				</view>
				<!-- <view class="" style=" justify-content: flex-end;">
					Min quantity:{{$util.formatCurrency(5000)}} USDT
				</view>
				<view :style="{color:$theme.LOG_VALUE}">
					Max quantity:{{$util.formatCurrency(500000)}} USDT
				</view> -->
			</view>

			<view
				style="display: flex;align-items: center;justify-content: space-between; padding:40rpx 0;padding-bottom: 20rpx;">
				<view style="font: 28rpx;font-weight: 700;padding-right: 20rpx;" :style="{color:$theme.LOG_LABEL}">
					{{$lang.CTC_AVAILABLE}}
				</view>
				<view style="font-size: 24rpx;color: #FFFFFF;">{{$util.formatCurrency(available)}} {{$lang.CTC_USDT}}</view>
			</view>
		</view>

		<view style="position: fixed;bottom: 10rpx;left: 0;right: 0;">
			<view style="margin:40rpx auto;width: 80%;min-height: 40px;line-height: 40px;font-size: 16px;"
				:style="setStyle()" @click="handleSubmit()">
				<!-- {{$lang.CTC_BUY_BTN}} -->
				{{curMode==0?$lang.CTC_BUY_BUY:$lang.CTC_BUY_BTN}}
			</view>
		</view>
	</view>
</template>

<script>
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		components: {
			CustomLogo
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curMode: 0, // 当前模式，[买|卖]
				amount: '', // 
				available: '', // 可用余额
				id: '', // url传参
				type: '', // 
				info: null, // 
				
				minxiane:'',
				maxxiane:'',
			
			};
		},
		computed: {},
		onLoad(opt) {
			this.id = Number(opt.id) || this.id;
			this.type = Number(opt.type) || this.type;
			this.curMode = this.type;
		},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo();
			this.getAccountlist();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/fastInfo`);
				if (!result) return false;
				this.available = result.money || this.available;
			},
			async getAccountlist() {
				const result = await this.$http.get(`api/app/c2clist`);
				if (!result) return false;
				  this.minxiane = result[0].xiane || this.minxiane; 
				  this.maxxiane = result[0].maxxiane || this.maxxiane; 
			},
			
			// async getAccountlist() {
			// 	uni.showLoading({
			// 		title: this.$lang.API_GET_ACCOUNT_INFO
			// 	});
			// 	const result = await this.$http.get(`api/app/c2clist`);
			// 	if (!result) return false;
			// 	this.minxiane = result.xiane;
				
			// },
			

			setStyle() {
				// this.curMode ==0?
				const _buy = this.$theme.linerGradient(90, '#295FFF', '#48DAFF');
				const _sell = this.$theme.linerGradient(90, '#FF8D29', '#FF533B');
				// const temp =

				return {
					// backgroundColor: this.$theme.RGBConvertToRGBA('#6D41FF', 30),
					...this.curMode == 0 ? _buy : _sell,
					backgroundRepeat: 'no-repeat',
					backgroundPosition: '0 0',
					backgroundSize: `100% 100%`,
					color: '#FFFFFF',
					borderRadius: `8rpx`,
					textAlign: `center`,
				}
			},
			// 提交
			async handleSubmit() {
				if (!this.amount || this.amount <= 0) {
					uni.showToast({
						title: this.$lang.DEPOSIT_ENTER_AMOUNT,
						icon: 'none'
					});
					return false;
				}
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/app/c2c`, {
					id: this.id,
					money: this.amount,
					type: this.curMode + 1,
				});
				if (!result) return false;
				console.log('result:', result);
				uni.showToast({
					// title: result,
					icon: 'success'
				});
				setTimeout(() => {
					uni.navigateTo({
						url: this.$paths.CTC_GENORDER + `?id=${this.id}&type=${this.curMode}`
					})
				}, 1000);
			},
		}
	}
</script>

<style lang="scss" scoped>
	.common_header {
		padding: 32rpx;
		display: flex;
		align-items: center;

		.left {
			margin-right: auto;
		}

		.right {
			margin-left: auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 500;
			padding-left: 40rpx;
			flex: 1;
			text-align: left;
		}
	}
</style>