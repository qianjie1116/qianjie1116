<template>
	<view>
		<view style="display: flex;align-items: center;justify-content: space-between; padding:0 24rpx;">
			<block v-for="(item,index) in topList" :key="index">
				<view style="flex:0 0 32%;" @click="linkInfo(item.locate)">
					<view style="background-color: #242f3d;border-radius: 12rpx;padding:12rpx;text-align: center;">
						<view style="font-size: 36rpx;color: #fff;">{{item.name}}</view>
						<view style="font-size: 32rpx;font-weight: 500;" :style="$theme.setStockRiseFall(item.rate>0)">
							{{$util.formatCurrency(item.current_price)}}
						</view>
						<view :style="$theme.setStockRiseFall(item.rate>0)">
							{{`${item.rate>0?'+':'-'} `+ ($util.formatNumber($util.formatMathABS(item.rate),2))}}%
						</view>
						<view style="display: flex;align-items: center;justify-content: center;">
							<image :src="`/static/line_${item.rate>0?'rise':'fall'}.png`" mode=" aspectFit"
								:style="$theme.setImageSize(160,80)"></image>
						</view>
					</view>
				</view>
			</block>
		</view>

		<view style="margin:10rpx 40rpx;">
			<TitlePrimary :title="$lang.TABBAR_MARKET" color="#fff" >
				<view style="font-size: 13px;margin-left: auto;color: #fff;" @click="linkMarket()" >
					{{$lang.COMMON_MORE}}
					<image src="/static/baiyoujiantou.png" mode="widthFix" style="width: 6px;margin-left: 5px;"></image>
				</view>
			</TitlePrimary>
		</view>

		<template v-if="list.length<=0">
			<EmptyData></EmptyData>
		</template>

		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view class="common_block" style="border-radius: 24rpx;padding:40rpx;background-color: #242f3d;">
					<view style="display: flex;align-items: center;" @click="linkInfo(item.locate)">
						<view style="margin-right: auto;">
							<CustomLogo :logo="item.logo" :name="item.name" :size="50"></CustomLogo>
						</view>
						<view style="padding-left: 30rpx;flex:auto">
							<view style="display: flex;align-items: center;">
								<view style="padding-right: 40rpx;font-size: 28rpx;color: #fff;" class="flex-1">
									{{item.name}}
								</view>
								<view style="font-size: 32rpx;font-weight: 500;color: #ccc;" class="flex-1">
									{{$util.formatCurrency(item.current_price)}}
								</view>
								<view class="flex-1 text-right" :style="$theme.setStockRiseFall(item.rate>0)">
									{{`${item.rate>0?'+':'-'} `+ ($util.formatNumber($util.formatMathABS(item.rate),2))}}%
								</view>
							</view>
						</view>
					</view>
					<!-- <view :style="{color:$theme.LOG_LABEL}" style="font-size: 24rpx;line-height: 1.4;">
						{{`24H: ` }}<template v-if="item.vol">{{item.vol}}</template>
					</view> -->
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	export default {
		name: 'CoinList',
		components: {
			EmptyData,
			CustomLogo,
			TitlePrimary,
		},
		data() {
			return {
				gpIndex: 0,
				curPage: 1, // 当前页码
				list: {},
				socket: null, // websocket
				isConnected: false, // 是否链接socket
			};
		},
		computed: {
			topList() {
				if (!this.list || !Object.values(this.list) || Object.values(this.list).length <= 0) return [];
				const temp = Object.values(this.list).filter(item => ['BTC/USDT', 'ETH/USDT', 'XRP/USDT'].includes(item
					.name));
				return temp.length > 0 ? temp : [];
			}
		},
		beforeMount() {
			if (this.socket) this.disconnect();
			this.getList();
		},

		deactivated() {
			console.log('CoinList deactivated');
		},
		beforeDestroy() {
			console.log(`CoinList beforeDestroy`);
			if (this.socket) this.disconnect();
		},
		destroyed() {
			console.log(`CoinList destroyed`);
			if (this.socket) this.disconnect();
		},
		methods: {
			// 跳转到市场
			linkMarket() {
				uni.reLaunch({
					url: this.$paths.MARKET_INDEX + `?type=0`,
				})
			},
			// 跳转到 coin trade index
			linkInfo(code) {
				uni.reLaunch({
					url: this.$paths.COIN_INDEX + `?code=${code}`
				});
			},
			// websocket 断线重连
			reconnectWebSocket() {
				// 连接中，并且非手动关闭
				if (this.isConnected) return;
				console.log(`reconnect!`, this.isConnected);
				this.socket = null;
				console.log(`reconnect! socket:`, this.socket);
				this.connect();
			},


			// websocket链接
			connect() {
				// websocket is connect ok?
				console.log(`ws:`, this.$http.WS_COIN_URL);
				this.socket = uni.connectSocket({
					url: this.$http.WS_COIN_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.info(`success res:`, res);
					},
					fail: (res) => {
						console.info(`fail res:`, res);
					}
				});
				console.log(`socket:`, this.socket);
				if (this.socket) {
					this.isConnected = true; // 已连接
					this.socket.onOpen((res) => {
						console.info("socket onOpen:", res)
					});
					this.socket.onClose((res) => {
						// code:1000(手动关闭) 1006(异常关闭) 
						console.log(`onClose:`, res);
						this.isConnected = false;
						if (res.code !== 1000) {
							this.reconnectWebSocket();
						}
					});

					this.socket.onError((err) => {
						console.log(`onError:`, err);
						this.isConnected = false;
						this.reconnectWebSocket();
					});

					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);
						// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
						if (this.list[data.market] && data.market && data.lastPrice > 0) {
							this.list[data.market].current_price = data.lastPrice;
							this.list[data.market].rate = data.rate || 0;
							this.list[data.market].vol = data.vol || 0;
						}
					});
				}
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					this.socket = null;
				}
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods/list`, {
					page: this.curPage,
					gp_index: this.gpIndex
				});
				console.log(`coin result:`, result);
				if (!result) return false;
				this.list = result;
				if (this.socket) this.disconnect();
				this.connect(); // 启动 websocket链接
			}
		}
	}
</script>

<style>
</style>