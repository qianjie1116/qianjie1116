<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 120vh;">
		<view style="background-color:#2d3535 ;">
			<HeaderSecond :title="$lang.AUTH_TITLE" :color="$theme.SECOND"></HeaderSecond>
		</view>
		

		<view style="margin-top: 20px;">

			<!-- <view style="background-color: #fef9fe;"> -->
			<!-- <view style="display: flex;align-items: center;padding-top: 30px;justify-content: center;">
				<image src="/static/bank_card_bnner.png" :style="$theme.setImageSize(600,300)"></image>
			</view> -->

			<view class="" style="padding:20px;background-color: #242f3d;border-radius: 10px;">
				<view style="padding-left: 10px;font-size: 14px;font-weight: 800;color: #FFFFFF;">
					{{$lang.AUTH_REAL_NAME}}
				</view>
				<view class="padding-10" style="padding-left: 10px;border: 1px #999999 solid;border-radius: 10px;margin-top: 10px;">
					<input v-model="realName" type="text" :placeholder="$lang.AUTH_REAL_NAME"
						style="width: 80%;color: #FFFFFF;"></input>
				</view>

				<view style="padding-left: 10px;font-size: 14px;font-weight: 800;margin-top: 20px;color: #FFFFFF;">
					{{$lang.AUTH_CARD_ID}}
				</view>
				<view class="flex padding-10" style="padding-left: 10px;margin-bottom: 20px;border: 1px #999999 solid;border-radius: 10px;margin-top: 10px;">
					<template v-if="showPwd">
						<input v-model="cardNo" type="text" :placeholder="$lang.AUTH_CARD_ID"
							placeholder-style="font-size:11px" style="width: 86%;color: #fff;"></input>
					</template>
					<template v-else>
						<input v-model="cardNo" type="password" :placeholder="$lang.AUTH_CARD_ID"
							placeholder-style="font-size:11px" style="width: 86%;color: #fff;"></input>
					</template>
					<image mode="aspectFit" :src="`/static/${showPwd?'show':'hide'}_dark.png`" @click="handleShowPwd"
						:style="$theme.setImageSize(40)">
					</image>
				</view>
			</view>

			<view style="margin-top: 30rpx;">
				<view style="padding:10px;font-size: 14px;font-weight: 800;padding-left: 20px;color:#ffffff;">
					{{$lang.AUTH_CARD_F}}
				</view>
				<view
					style="display: flex;align-items: center;justify-content: center;padding: 24px;background-color:#242f3d ;border-radius: 8rpx;margin: 20rpx;">
					<image :src="!obverseUrl?`/static/xiangji2.png`:obverseUrl" @click="selectImg('obverse')"
						style="margin: 10px;width: 240px;height: 120px;"></image>
				</view>

				<view style="padding:10px;font-size: 14px;font-weight: 800;padding-left: 20px;color:#ffffff;">
					{{$lang.AUTH_CARD_B}}
				</view>
				<view
					style="display: flex;align-items: center;justify-content: center;padding: 24px;background-color: #242f3d;border-radius: 8rpx;margin: 20rpx;">
					<image :src="!reverseUrl?`/static/xiangji2.png`:reverseUrl" @click="selectImg('reverse')"
						style="margin: 10px;width: 220px;height: 120px;"></image>
				</view>
			</view>
		</view>

		<view style="position: fixed;bottom: 0;left: 0;right: 0;">
			<view class="common_btn" style="margin:40rpx auto;width: 80%;" @click="handleSubmit()">
				{{$lang.COMMON_CONFIRM}}
			</view>
		</view>
	</view>
</template>

<script>
	import md5 from '@/common/md5.min.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import {
		BASE_URL,
	} from '@/common/http';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				realName: '', // 姓名
				cardNo: '', // 证件号码
				showPwd: uni.getStorageSync('show') || false, // 是否显示完整证件号
				obverseUrl: '',
				reverseUrl: '',
				userInfo: {},
			};
		},
		computed: {},
		onLoad() {
			this.getAccountInfo();
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
			this.setStorageData();
		},

		methods: {
			// 设置页面缓存信息
			setStorageData() {
				uni.setStorageSync('realName', this.realName);
				uni.setStorageSync('cardNo', this.cardNo);
				uni.setStorageSync('obverseUrl', this.obverseUrl);
				uni.setStorageSync('reverseUrl', this.reverseUrl);
			},
			// 获取页面缓存信息
			getStorageData() {
				this.realName = this.realName.length > 0 ? this.realName : (uni.getStorageSync('realName') || '');
				this.cardNo = this.cardNo.length > 0 ? this.cardNo : (uni.getStorageSync('cardNo') || '');
				this.obverseUrl = this.obverseUrl.length > 0 ?
					this.obverseUrl : (uni.getStorageSync('obverseUrl') || '');
				this.reverseUrl = this.reverseUrl.length > 0 ?
					this.reverseUrl : (uni.getStorageSync('reverseUrl') || '');
			},

			// ID号显隐
			handleShowPwd() {
				this.showPwd = !this.showPwd;
				this.$util.setShowData(this.showPwd);
			},

			// 点击上传
			async selectImg(name) {
				const result = await uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
				});
				console.log('result:', result);
				const imageFile = result[1].tempFiles[0];
				console.log('imageFile:', imageFile);

				if (name == "obverse") {
					this.upimg(1, imageFile.path)

				} else if (name == "reverse") {
					this.upimg(2, imageFile.path)
				}
			},
			// 上传图片
			async upimg(type, tempFilePath) {
				uni.showLoading({
					title: this.$lang.STATUS_UPLOAD,
				})
				let Request = "Qwd3N5yp"
				let time = parseInt(new Date().getTime() / 1000)
				let str_url = ("/api/app/upload").toLowerCase()

				let mdd = md5("XPFXMedS" + Request + str_url + time);

				const result = await uni.uploadFile({
					url: BASE_URL + '/api/app/upload?t=' + time + "&sign=" + mdd,
					filePath: tempFilePath,
					name: 'file',
				});

				console.log('result:', result);
				uni.hideLoading();
				if (result[1].statusCode == 200) {
					const temp = JSON.parse(result[1].data);
					console.log('temp:', temp);
					if (type == 1) {
						this.obverseUrl = temp[0].url;
					} else {
						this.reverseUrl = temp[0].url;
					}
				}
				this.setStorageData();
			},

			// 认证
			async handleSubmit() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT
				});
				const tempCardNo = this.cardNo;
				const result = await this.$http.post(`api/user/real-auth1`, {
					real_name: this.realName,
					idno: this.cardNo,
					front_image: this.obverseUrl,
					back_image: this.reverseUrl,
				});
				if (!result) return false;
				uni.showToast({
					title: result,
					icon: 'success'
				});
				setTimeout(() => {
					uni.switchTab({
						url: this.$paths.HOME
					});
				}, 1000);
			},

			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/fastInfo`);
				if (!result) return false;
				this.userInfo = result;
				this.realName = this.userInfo.real_name || '';
				this.cardNo = this.userInfo.idno || '';
				this.obverseUrl = this.userInfo.front_image || '';
				this.reverseUrl = this.userInfo.back_image || '';
				this.getStorageData();
			},
		},
	};
</script>