<template>
	<view>
		<view style="background-color: #2d3535;">
			<HeaderSecond :title="$lang.TRANSFER_RECORD_TITLE" :color="$theme.SECOND"></HeaderSecond>
		</view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<view style="padding-top: 20rpx;padding-bottom: 40rpx;">
				<block v-for="(item,index) in list" :key="index">
					<view
						style="background-color: #242f3d; padding:20rpx 30rpx;border-radius: 24rpx;line-height: 1.8;margin:0 20rpx 20rpx 20rpx;">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view class="color-white">
								{{item.leixing}}
							</view>
							<view :style="{color:$theme.FALL}">{{status[item.status]}}</view>
						</view>

						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view class="color-white">
								{{$lang.DEPOSIT_RECORD_AMOUNT}}
							</view>
							<view :style="{color:$theme.PRIMARY}" style="font-size: 18px;">
								{{$util.formatMoney(item.num)}}
							</view>
						</view>

						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view class="color-white">{{$lang.DEPOSIT_RECORD_SN}}</view>
							<view style="color: #ccc;">
								{{item.ordersn}}
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view class="color-white">{{$lang.DEPOSIT_RECORD_CT}}</view>
							<view style="color: #ccc;">
								{{item.created_at}}
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view class="color-white">{{$lang.TRANSFER_RECORD_DESC}}</view>
							<view style="color: #ccc;">
								{{item.fangxiang}}
							</view>
						</view>
						<!-- <view style="display: flex;align-items: center;justify-content: space-between;">
						<view style="flex:6%;">
							<image :src="item.icon" :style="$theme.setImageSize(24)"></image>
						</view>
						<text style="flex:97%;white-space:pre-wrap;" :style="{color:item.color}">{{item.text}}</text>
					</view> -->
					</view>
				</block>
			</view>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			HeaderSecond,
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		computed: {
			status() {
				return [this.$lang.TRASNFER_RECORD_REVIEW,
					this.$lang.TRANSFER_RECORD_PASS,
					this.$lang.TRANSFER_RECORD_REJECT
				]
			}
		},
		onShow() {
			this.getList();
		},
		onPullDownRefresh() {
			this.getList();
			uni.stopPullDownRefresh();
		},

		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/user/huazhuan_log`);
				if (!result) return false;
				console.log(`result:`, result);
				this.list = result;
			},
		}
	}
</script>

<style>
</style>