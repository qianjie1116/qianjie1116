<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<view style="background-color:#2d3535;">
			<HeaderSecond :title="$lang.ADDRESS_INDEX_TITLE" :color="$theme.SECOND"></HeaderSecond>
		</view>

		<view style="margin: 40rpx 20rpx;padding-bottom: 100rpx;min-height: 100vh;">
			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view class="padding-15" style="border-radius: 24rpx;background-color: #242f3d;" @click="link(item.id)">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="font-size: 32rpx;color: #fff;">
								{{item.name}}
							</view>
							<view>
								<view style="display: flex;align-items: center;">
									<image mode="aspectFit" :src="`/static/${isShow?'show':'hide'}_dark.png`"
										@click.stop="toggleShow()" style="padding-right: 40rpx;"
										:style="$theme.setImageSize(32)">
									</image>
									<view class="common_tag" style="color: #ccc;" @tap="handleCopy(item.address)">
										{{$lang.COMMON_COPY}}
									</view>
								</view>
							</view>
						</view>
						<view style="word-wrap: break-word;color: #ccc;">
							{{isShow?item.address:hideAddress}}
						</view>
					</view>
				</block>
			</template>
		</view>

		<view style="position: fixed;bottom: 0;left: 0;right: 0;">
			<view class="common_btn" style="margin:40rpx auto;width: 80%;" @click="linkAdd()">
				{{$lang.ADDRESS_ADD_TITLE}}
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		components: {
			HeaderSecond,
			TitlePrimary,
			EmptyData,
			CustomLogo,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isShow: uni.getStorageSync('show') || false, // 地址显隐
				hideAddress: '******', // 隐藏金额
				list: [{
					name: 'ERC20-USDT',
					address: ''
				}, {
					name: 'TRC20-USDT',
					address: ''
				}], // 提现地址列表
			};
		},
		computed: {
			setStyle() {
				return {
					// backgroundColor: this.$theme.RGBConvertToRGBA(this.$theme.RISE, 20),
					color: this.$theme.RISE,
				}
			}
		},
		onLoad() {},
		onShow() {
			this.isAnimat = true;
			this.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 切换地址显隐
			toggleShow() {
				this.isShow = !this.isShow;
				this.$util.setShowData(this.isShow);
			},
			linkAdd() {
				uni.navigateTo({
					url: this.$paths.ADDRESS_ADD
				})
			},
			link(id) {
				uni.navigateTo({
					url: this.$paths.ADDRESS_ADD + "?id=" + id
				})
			},
			async handleCopy(val) {
				const result = await uni.setClipboardData({
					data: val, //要被复制的内容
				});
				if (result[1].confirm) {
					uni.showToast({
						title: this.$lang.COMMON_COPY_SUCCESS,
						duration: 2000,
						icon: 'success'
					})
				}
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/user/fastinfo`);
				if (!result) return false;
				console.log(`result:`, result);
				if (result.bank_card_info) {
					this.list = !result.bank_card_info || result.bank_card_info.length <= 0 ? [] :
						result.bank_card_info.map(item => {
							return {
								name: item.huobi,
								address: item.address,
								id: item.id
							}
						})
				}

			}
		}
	}
</script>

<style>
</style>