<template>
	<view style="padding-bottom: 20px;">
		<!-- 股票基本信息 -->
		<template v-if="isInfoBase">
			<StockInfoBase :info="stockInfo.top1"></StockInfoBase>
		</template>

		<!-- 公司简介 -->
		<template v-if="isCompany">
			<CompanyProfile :info="stockInfo.top2"></CompanyProfile>
		</template>

		<!-- 销售额 -->
		<template v-if="isSales">
			<CustomTitle :title="$lang.STOCK_SALES">
				<view style="margin-left: auto;" :style="{color:$theme.LOG_VALUE}">
					{{salesDate }}
				</view>
			</CustomTitle>

			<view
				style="display: flex;align-items: center;justify-content: space-around;margin:0 80rpx;padding-right: 4rpx;">
				<block v-for="(item,index) in $lang.STOCK_SALES_TABS" :key="index">
					<view :style="setStyle(curSales ==index)" @click="changeSalesTab(index)">
						{{item}}
					</view>
				</block>
			</view>

			<view style="padding:30rpx 20rpx">
				<block v-for="(item,index) in formatSalesData" :key="index">
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
						<view :style="{color:$theme.LOG_LABEL}">{{formatSalesNames[index]}}</view>
						<view :style="$theme.setStockRiseFall(item>0)">
							{{ $util.hasDecimalPoint(item)?item:$util.formatNumber(item/ 100000000,2) }}
							{{$util.hasDecimalPoint(item)?`%`: $lang.UNIT_BILION }}
						</view>
					</view>
				</block>
			</view>

			<view style="padding-bottom: 30rpx;">
				<TabsFifth :tabs="$lang.STOCK_SALES_KLINE_TABS" @action="changeSalesKlineTab" :acitve="curSalesKline">
				</TabsFifth>
			</view>
			<canvas canvas-id="zhexian" id="zhexian" class="charts"></canvas>
		</template>

		<!-- 投资趋势 -->
		<template v-if="isTrend">
			<StockTrend :info="stockInfo.top4"></StockTrend>
			<StockTrendList :list="stockInfo.top5"></StockTrendList>
		</template>

		<!-- 饼图 -->
		<template v-if="isPieChart">
			<CustomTitle :title="$lang.STOCK_TRADE_TREND_PIE_TITLE"></CustomTitle>
			<canvas canvas-id="huan1" id="huan1" class="charts"></canvas>
		</template>

		<!-- 卖空 -->
		<template v-if="isSellEmpty">
			<ShortSellEmpty :info="stockInfo.top7"></ShortSellEmpty>
		</template>

		<!-- 行业排行 -->
		<template v-if="isIndustry">
			<StockIndustry :info="stockInfo.top8"></StockIndustry>
		</template>
	</view>
</template>

<script>
	import uCharts from '@/common/u-charts.js';
	import customUChart from '@/common/customUChart.js';

	import StockInfoBase from './StockInfoBase.vue';
	import CompanyProfile from './CompanyProfile.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import TabsFifth from '@/components/tabs/TabsFifth.vue';
	import TabsSixth from '@/components/tabs/TabsSixth.vue';
	import StockTrend from './StockTrend.vue';
	import StockTrendList from './StockTrendList.vue';
	import StockIndustry from './StockIndustry.vue';
	import ShortSellEmpty from './ShortSellEmpty.vue';

	var uChartsInstance = {};
	export default {
		name: 'StockDetail',
		props: ['code', 'id'],
		components: {
			CustomTitle,
			StockInfoBase,
			CompanyProfile,
			TabsFifth,
			TabsSixth,
			StockTrend,
			StockTrendList,
			StockIndustry,
			ShortSellEmpty,
		},
		data() {
			return {
				stockInfo: null, // 单股概况
				curSales: 0, // 销售额tab选中项
				salesData: [], // 销售额相关数据
				curSalesKline: 0, // 当前显示Kline数据
				curSalesKlinePos: 29, // 当前显示Kline的销售额数组中，下标值。(29:销售额;32:盈利;36:净利)
				cWidth: 0,
				cHeight: 0,
			}
		},
		computed: {
			// 是否显示公司基本信息
			isInfoBase() {
				return this.stockInfo && this.stockInfo.top1 && Object.keys(this.stockInfo.top1).length > 0;
			},
			// 是否显示公司简介
			isCompany() {
				return this.stockInfo && this.stockInfo.top2 && this.stockInfo.top2.description;
			},

			// 是否显示销售额
			isSales() {
				return this.stockInfo && this.salesData && this.salesData.length > 0;
			},
			// 是否显示卖空
			isSellEmpty() {
				return this.stockInfo && this.stockInfo.top7 && this.stockInfo.top7.length > 0;
			},
			// 投资交易趋势
			isTrend() {
				return this.stockInfo && this.stockInfo.top4 && Object.keys(this.stockInfo.top4).length > 0;
			},
			// 环状图
			isPieChart() {
				return this.stockInfo && this.stockInfo.top6.length > 0;
			},

			// 是否显示行业排名
			isIndustry() {
				return this.stockInfo && this.stockInfo.top8 && Object.keys(this.stockInfo.top8).length > 0;
			},

			// 销售额title日期
			salesDate() {
				return this.isSales ? this.salesData[0].report_year_month : ''
			},
			// 销售额数据Labels
			formatSalesNames() {
				if (this.isSales) {
					console.log('销售额:', this.salesData);
					const temp = this.salesData[0];
					let names = [] // 股票名字
					Object.keys(temp.fields).forEach((key, index) => {
						names.push(temp.fields[key].ko_name);
					});
					console.log('names:', names);
					return names;
				}
			},
			// 销售额数据格式化, 遍历对象的key
			formatSalesData() {
				if (this.isSales) {
					console.log('销售额:', this.salesData);
					// 29 32 42 81   29 32 36 42 81 83
					// 切换为季度：	 29 32 36 43 82 84
					const temp = this.salesData[0];
					let tempData = []; // 整理数据
					Object.keys(temp.fields).forEach((key, index) => {
						console.log('销售额 fields:', key, temp.fields[key].value);
						// tempData.push(this.$util.hasDecimalPoint(temp.fields[key].value) ?
						// 	Number(temp.fields[key].value.toFixed(2)) : temp.fields[key].value);
						tempData.push(this.$util.hasDecimalPoint(temp.fields[key].value) ?
							Number(temp.fields[key].value.toFixed(2)) : temp.fields[key].value);
					});
					console.log('tempData:', tempData);
					return tempData;
				}
			},
		},
		created() {
			this.getStockInfo();
			//这里的 750 对应 css .charts 的 width
			this.cWidth = uni.upx2px(680);
			//这里的 500 对应 css .charts 的 height
			this.cHeight = uni.upx2px(500);
			//模拟服务器返回数据，如果数据格式和标准格式不同，需自行按下面的格式拼接
			console.log(this.cWidth, this.cHeight)
		},

		methods: {
			// 设置样式
			setStyle(val, w = 120) {
				return {
					width: `${w}rpx`,
					margin: '16rpx',
					padding: `12rpx 32rpx`,
					borderRadius: `16rpx`,
					backgroundColor: val ? '#2D54AB3A' : '#14102B11',
					color: val ? this.$theme.PRIMARY : '#333333',
					textAlign: 'center',
				}
			},

			// 季度年度 销售额切换
			changeSalesTab(val) {
				this.curSales = val;
				if (this.curSales == 0) {
					this.getStockInfo()
				} else {
					this.getStockInfoYear()
				}
			},

			// 销售额 Kline切换
			changeSalesKlineTab(val) {
				this.curSalesKline = val;
				const temp = Object.keys(this.salesData[0].fields);
				this.curSalesKlinePos = temp[this.curSalesKline];
				// this.curSalesKline == 1 ? 32 :
				// this.curSalesKline == 2 ? 36 : 29;
				this.genKLine()
			},

			// 获取股票信息
			async getStockInfo() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/product/info_two`, {
					code: this.code,
					stock_id: this.id,
				});
				if (!result) return false;
				this.stockInfo = result[0];
				console.log('stockInfo:', this.stockInfo);
				this.salesData = this.stockInfo.top3;
				if (this.isSales) this.genKLine(); // 处理并显示折线数据
				if (this.isPieChart) {
					let res = {
						series: [{
							data: this.stockInfo.top6
						}]
					};
					const ctx = uni.createCanvasContext('huan1', this);
					uChartsInstance['huan1'] = new uCharts(customUChart.pieChart(ctx, res, this.cWidth, this
						.cHeight))
				}
			},

			// 生成折线数据，并显示
			genKLine() {
				let res = {
					categories: this.salesData.map(item => item.report_year_month),
					series: [{
						name: "",
						data: this.salesData.map(item => item.fields[this.curSalesKlinePos].value /
							100000000),
					}]
				};
				const ctx = uni.createCanvasContext("zhexian", this);
				uChartsInstance["zhexian"] = new uCharts(customUChart.lineChart(ctx, res, this.cWidth, this.cHeight))
			},
			// 获取年度销售额
			async getStockInfoYear() {
				const result = await this.$http.get(`api/product/info_two1`, {
					code: this.code,
					stock_id: this.id
				})
				console.log('getStockInfoYear:', result);
				this.salesData = result[0].top3; // 年度销售额
				this.changeSalesKlineTab(0)
			},
		},
	}
</script>

<style lang="scss" scoped>
	.charts {
		// width: 720rpx;
		// height: 500rpx;
		width: 680upx;
		height: 500upx;
	}
</style>