<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<view style="background-color: #2d3535;">
			<HeaderSecond :title="`Referral Rewards`" :color="$theme.SECOND"></HeaderSecond>
		</view>


		<view style="padding:24rpx;">
			<view style="border: 1px Solid #ccc;border-radius: 16rpx;padding:24rpx;">
				<template v-if="info">
					<view style="display: flex;align-items: center;padding-bottom: 48rpx;">
						<image src="/static/logo.png" mode="aspectFit" :style="$theme.setImageSize(80)"></image>
						<view style="padding-left: 40rpx;">
							<view style="font-size: 36rpx;color: #fff;">{{info.real_name}}</view>
							<view :style="{color:$theme.LOG_LABEL}">{{info.p_mobile}}</view>
						</view>
					</view>
				</template>

				<view style="color: #fff;">{{$lang.INVITE_CODE}}</view>
				<view style="display: flex;align-items: center;color: #fff;">
					<view>{{info.invite}}</view>
					<view style="padding-left: 48rpx;" @tap="handleCopy(info.invite)">
						<view style="display: flex;align-items: center;">
							<view style="font-size: 24rpx;color:#6D41FF;padding-right: 8rpx;">{{$lang.COMMON_COPY}}
							</view>
							<image src="/static/copy.svg" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
						</view>
					</view>
				</view>

				<view style="padding-top: 16rpx;color: #fff;">{{$lang.INVITE_LINK}}</view>
				<view style="display: flex;align-items: center;">
					<view style="width: 80%;">
						<view style="word-wrap: break-word;font-size: 22rpx;color: #fff;">{{shareLink}}</view>
					</view>
					<view style="padding-left: 48rpx;" @tap="handleCopy(shareLink)">
						<view style="display: flex;align-items: center;">
							<view style="font-size: 24rpx;color:#6D41FF;padding-right: 8rpx;width: 70%;">
								{{$lang.COMMON_COPY}}
							</view>
							<image src="/static/copy.svg" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
						</view>
					</view>
				</view>
			</view>

			<view style="display: flex;align-items: center;flex-wrap: wrap;">
				<view style="flex: 0 0 50%;">
					<view
						style="background-color:#242f3d ;border-radius: 24rpx;padding:24rpx 12rpx;margin:24rpx 24rpx 0 0;">
						<view style="text-align: center;font-size: 36rpx;color:#ccc;font-weight:bold;line-height: 2;">
							97</view>
						<view style="display: flex;align-items: center;justify-content: center;">
							<image src="/static/invite1.png" mode="aspectFit" :style="$theme.setImageSize(48)">
							</image>
							<view style="padding-left: 12rpx;color: #fff;">{{$lang.INVITE_INVITED}}</view>
						</view>
					</view>
				</view>
				<view style="flex: 0 0 50%;">
					<view
						style="background-color:#242f3d ;border-radius: 24rpx;padding:24rpx 12rpx;margin:24rpx 0 0 0;">
						<view style="text-align: center;font-size: 36rpx;color:#ccc;font-weight:bold;line-height: 2;">
							75</view>
						<view style="display: flex;align-items: center;justify-content: center;">
							<image src="/static/invite2.png" mode="aspectFit" :style="$theme.setImageSize(48)">
							</image>
							<view style="padding-left: 12rpx;color: #fff;">{{$lang.INVITE_ACT}}</view>
						</view>
					</view>
				</view>
				<view style="flex: 0 0 50%;">
					<view
						style="background-color:#242f3d ;border-radius: 24rpx;padding:24rpx 12rpx;margin:24rpx 24rpx 0 0;">
						<view style="text-align: center;font-size: 36rpx;color:#ccc;font-weight:bold;line-height: 2;">
							35,000</view>
						<view style="display: flex;align-items: center;justify-content: center;">
							<image src="/static/invite3.png" mode="aspectFit" :style="$theme.setImageSize(48)">
							</image>
							<view style="padding-left: 12rpx;color: #fff;">{{$lang.INVITE_DAY}}</view>
						</view>
					</view>
				</view>
				<view style="flex: 0 0 50%;">
					<view
						style="background-color:#242f3d ;border-radius: 24rpx;padding:24rpx 12rpx;margin:24rpx 0 0 0;">
						<view style="text-align: center;font-size: 36rpx;color:#ccc;font-weight:bold;line-height: 2;">
							79,000</view>
						<view style="display: flex;align-items: center;justify-content: center;">
							<image src="/static/invite4.png" mode="aspectFit" :style="$theme.setImageSize(48)">
							</image>
							<view style="padding-left: 12rpx;color: #fff;">{{$lang.INVITE_ACCRUE}}</view>
						</view>
					</view>
				</view>
			</view>

			<!--  -->
			<view style="border: 1px Solid #ccc;border-radius: 16rpx;padding:24rpx;margin:24rpx 0;">
				<view style="font: 28rpx;font-weight: 700;line-height: 3;color: #fff;">
					{{$lang.INVITE_RULE}}
				</view>

				<block v-for="(v,k) in $lang.RULE_ITEMS" :key="k">
					<view style="padding-bottom: 12rpx;color: #ccc;"><text style="font-size: 28rpx;">{{k+1+`. `}}</text>
						{{v}}
					</view>
				</block>

			</view>

			<!-- <view style="padding:80rpx 24rpx;border: 1px Solid #E8EAF3;border-radius: 16rpx;">
				<view class="common_btn" style="margin:80rpx auto;width: 80%;" @click="handleCopy()">
					{{$lang.SHARE_COPYLINK}}
				</view>

				<view class="common_block" style="padding:0;border-radius: 24rpx;margin-top: 40rpx;">
					<view style="font: 28rpx;font-weight: 700;line-height: 3;">
						{{$lang.REFERRAL_TIP}}
					</view>
					<view style="padding-bottom:10px;"> {{$lang.REFERRAL_DESC}}</view>
				</view>
			</view> -->
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				info: null,
				borrowInfo: null,
				imgUrl: null, // 二维码转为图片的 base64 
			};
		},

		computed: {
			// 二维码内容
			shareLink() {
				if (this.info) {
					const temp = window.location.origin + `/#`;
					return temp + this.$paths.ACCOUNT_ACCESS + `?code=${this.info.invite}`;
					// return temp
				}
			}
		},
		onLoad() {},
		onShow() {
			this.isAnimat = true;
			this.getAccountInfo();
		},
		onReady() {},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			async handleCopy(val) {
				const result = await uni.setClipboardData({
					data: val, //要被复制的内容
				});
				if (result[1].confirm) {
					uni.showToast({
						title: this.$lang.COMMON_COPY_SUCCESS,
						duration: 2000,
						icon: 'success'
					})
				}
			},

			// 获取账户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/fastInfo`);
				console.log('info result：', result);
				if (!result) return false;
				this.info = result;
				// this.genQRCode();
			},
		}
	}
</script>


<style lang="scss" scoped>
	.common_header {
		padding: 40rpx;
		display: flex;
		align-items: center;
		padding-top: 30px;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 500;
			padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: left;
		}
	}

	.qrcode {
		height: 420rpx;
		display: flex;
		flex-direction: column;
		justify-content: flex-end;
		align-items: center;
	}

	.qrcode>canvas {
		width: 420rpx;
		height: 420rpx;
	}
</style>