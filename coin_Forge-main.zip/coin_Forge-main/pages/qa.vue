<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<view style="background-color: #2d3535;">
			<HeaderSecond :title="$lang.PROFILE_QA" :color="$theme.SECOND"></HeaderSecond>
		</view>

		<view style="padding: 40rpx;">
			<template v-if="info.content && info.content.length>0">
				<view v-html="info.content" style="color:#ccc"></view>
			</template>
			<template v-else>
				<view style="color:#ccc;text-align: center;">{{$lang.API_EMPTY_CONTENT}}</view>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond, 
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				info: null,
			};
		},
		onLoad() {
			this.getData();
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			
			async getData() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/article/content`,{cate_id:22});
				console.log('result:', result);
				if (!result) return false;
				this.info = {
					title: result.title || this.$lang.PRVITE_PACT_TITLE,
					content: result.content,
				}
			}
		}
	}
</script>