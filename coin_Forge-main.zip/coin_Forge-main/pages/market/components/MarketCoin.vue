<template>
	<view style="padding-top: 20rpx;margin:20rpx;min-height: 100vh;">
		<view style="display: flex;justify-content: space-between;margin:0 10rpx;">
			<block v-for="(item,index) in theads" :key='index'>
				<view :style="setStyle2(false)"> {{item}} </view>
			</block>
		</view>

		<template v-if="setList.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in setList" :key="index">
				<view style="padding:10px;background-color: #242f3d;margin:20rpx 0;border-radius: 24rpx;"
					@click="linkInfo(item.locate)">
					<view style="display: flex;align-items: center;">
						<!-- <view style="width: 80rpx;margin:auto 0;">
							<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
						</view> -->
						<view style="flex:0 0 40%;">
							<view  style="font-size: 28rpx;line-height: 1.6;color: #fff;">
								{{item.name}}
							</view>
							<!-- <view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">24H:
								{{$util.formatNumber(item.vol,0)}}
							</view> -->
						</view>
						<view style="flex:0 0 30%;">
							<view style="font-size: 28rpx;font-weight: 700;color: #ccc;">
								{{$util.formatCurrency(item.current_price)}}
							</view>
						</view>
						<view style="margin-left: auto;">
							<view style="font-size: 26rpx;" :style="setStyle(item.rate*1>0)">
								{{`${item.rate>0?'+':'-'} `+ ($util.formatNumber($util.formatMathABS(item.rate),2))}}%
							</view>
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'MarketCoin',
		components: {
			EmptyData,
			CustomLogo,
		},
		data() {
			return {
				// curTab: 0,
				list: {},
				socket: null, // websocket
				isConnected: false, // 是否链接socket
			}
		},
		computed: {
			theads() {
				return [
					this.$lang.COIN_NAME,
					this.$lang.COIN_PRICE,
					this.$lang.COIN_CHANGE
				]
			},
			// tabs() {
			// 	return [
			// 		this.$lang.MARKET_INDEX_TAB_HOP,
			// 		this.$lang.MARKET_INDEX_TAB_RISE,
			// 		this.$lang.MARKET_INDEX_TAB_FALL,
			// 	]
			// },
			// 在此，根據val，對數據 排序[hot:val,rise:rate,fall:rate]
			setList() {
				if (!this.list || Object.values(this.list).length <= 0) {
					return []
				}
				const temp = Object.values(this.list);
				return temp;
				// if (this.curTab == 1) {
				// 	return temp.sort((a, b) => b.rate - a.rate);
				// } else {
				// 	return temp.sort((a, b) => a.rate - b.rate);
				// }
			}
		},
		beforeMount() {
			if (this.socket) this.disconnect();
			this.getList();
		},
		destroyed() {
			if (this.socket) this.disconnect();
		},
		deactivated() {
			if (this.socket) this.disconnect();
		},
		methods: {
			// changeTab(val) {
			// 	this.curTab = val;
			// },
			// 设置样式
			setStyle(val) {
				return {
					minWidth: `120rpx`,
					margin: '16rpx 0',
					padding: `12rpx 20rpx`,
					borderRadius: `16rpx`,
					textAlign: 'center',
					backgroundColor: val ? '#2b6cff' : this.$theme.FALL,
					color: '#FFFFFF',
					borderRadius: `20rpx`,
				}
			},
			setStyle2(val, w = 120) {
				return {
					minWidth: `${w}rpx`,
					margin: '16rpx',
					padding: `12rpx 20rpx`,
					borderRadius: `16rpx`,
					textAlign: 'center',
					backgroundColor: val ? '#242f3d' : '#242f3d',
					color: val ? '#FFFFFF' : '#fff',
					borderRadius: `20rpx`,
				}
			},


			// 跳转到详情
			linkInfo(val) {
				uni.reLaunch({
					url: this.$paths.COIN_INDEX + `?code=${val}`
				});
			},

			// websocket 断线重连
			reconnectWebSocket() {
				// 连接中，并且非手动关闭
				if (this.isConnected) return;
				console.log(`reconnect!`, this.isConnected);
				this.socket = null;
				console.log(`reconnect! socket:`, this.socket);
				this.connect();
			},
			// websocket链接
			connect() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_COIN_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
					fail: (res) => {
						console.log('fail', res);
					}
				})
				console.log('ws', this.socket);
				if (this.socket) {
					this.isConnected = true; // 已连接
					this.socket.onOpen((res) => {
						console.info("socket onOpen:", res)
					});
					this.socket.onClose((res) => {
						// code:1000(手动关闭) 1006(异常关闭) 
						console.log(`onClose:`, res);
						this.isConnected = false;
						if (res.code !== 1000) {
							this.reconnectWebSocket();
						}
					});

					this.socket.onError((err) => {
						console.log(`onError:`, err);
						this.isConnected = false;
						this.reconnectWebSocket();
					});
					// 接收websocket消息及处理
					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);
						// console.log(data);
						// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
						if (this.list[data.market] && data.market && data.lastPrice > 0) {
							this.list[data.market].current_price = data.lastPrice;
							this.list[data.market].rate = data.rate || 0;
							this.list[data.market].vol = data.vol || 0;
						}
					});
				}
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/goods/list`);
				console.log(result);
				if (!result) return false;
				this.list = result;
				console.log(this.list);
				if (this.socket) this.disconnect();
				// 启动 websocket链接
				this.connect();
			}
		}
	}
</script>

<style>
</style>