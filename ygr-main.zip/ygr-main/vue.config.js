// vue.config.js
module.exports = {
    // webpack-dev-server 相关配置
    devServer: {
        disableHostCheck: true
    },
	 lintOnSave: false
    //其他配置....
}