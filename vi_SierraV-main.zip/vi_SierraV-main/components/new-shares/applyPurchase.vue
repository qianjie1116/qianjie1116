<template>
	<!-- 新股申购 -->
	<view class="">
		<view style="display: flex;align-items: center;justify-content: space-around;padding-bottom: 24rpx;">
			<view style="display: flex;align-items: center;" @tap="applyPurchase()">
				<image src="/static/icon_0.png" mode="aspectFit"
					style="width: 64rpx;height: 64rpx;padding-right: 24rpx;"></image>
				<view style="color: #fff;">Lệnh đã gửi</view>
			</view>

			<view style="display: flex;align-items: center;" @tap="luckyNumber()">
				<image src="/static/icon_1.png" mode="aspectFit"
					style="width: 64rpx;height: 64rpx;padding-right: 24rpx;"></image>
				<view style="color: #fff;"> Lịch sử đăng ký </view>
			</view>
		</view>

		<!-- <view class="white-background">
			<view class="take-notes">
				<view class="purchase" @tap="applyPurchase()">
					<image src="/static/icon_0.png" mode="aspectFit" style="width: 64rpx;height: 64rpx;padding-right: 24rpx;"></image>
					<view class="">POR</view>
				</view>
				<view class="purchase" @tap="luckyNumber()">
					<image src="/static/icon_1.png" mode=""></image>
					<view class=""> Lịch sử đăng ký </view>
				</view>
			</view>
		</view> -->

		<view style="background-color: #333;" class="padding-10 margin-10 radius10"
			v-for="(item,index) in newShares_list" :key="index">
			<view class="flex gap10">
				<!-- <view
					style="background-color: #2c4f9f;width: 40px;height: 40px;color: #fff;text-align: center;line-height: 40px;border-radius: 5px;">
					{{item.goods.name.charAt(0)}}
				</view> -->
				<!-- <view>
					<view style="color: #fff;">{{item.goods.name}}</view>
					<view class="hui font-size-12">{{item.goods.code}}</view>
				</view> -->
				<view style="color: #fff;">{{item.goods.name}}</view>
			</view>
			<view class="flex flex-b color-white" style="line-height: 1.6;">
				<view style="color: #AAA;font-size: 13px;">Giá mua</view>
				<view>{{toThousandFilter(item.price)}}</view>
			</view>
			<view class="flex flex-b color-white" style="line-height: 1.6;">
				<view style="color: #AAA;font-size: 13px;">Khối lượng</view>
				<view>{{toThousandFilter(item.xianjia*1)}}</view>
			</view>
			<view class="flex flex-b color-white" style="line-height: 1.6;">
				<view style="color: #AAA;font-size: 13px;">Tổng khối lượng phát hành</view>
				<view>{{toThousandFilter(item.fa_amount)}}</view>
			</view>

			<view @click="to_skip(item.id)" class="btn_common"
				style="font-size: 32rpx;width: 80%;margin:6rpx auto;line-height: 36rpx;margin-top: 24rpx;"
				v-if="item.open==1">
				Chi tiết
			</view>
		</view>

	</view>

</template>

<script>
	export default {
		props: ['newShares_list', 'newShares_list2'],
		data() {
			return {
				content: 0,
				items: ['Có sẵn', 'Chờ mua'],

			};
		},
		methods: {
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			//申购记录
			applyPurchase() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/applyPurchase/applyPurchase'
				});
			},
			//中签记录
			luckyNumber() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/luckyNumber/luckyNumber'
				});
			},

			to_skip(id) {
				uni.navigateTo({
					url: '/pages/index/components/newShares/nullElement/nullElement' +
						`?id=${id}`
				});
				// console.log(gid, fa_price, '携带');

			},

			// nullElement(gid) {
			// 	uni.navigateTo({
			// 		url: '/pages/index/components/newShares/nullElement/nullElement?gid=${gid}'
			// 	});
			// },
		}
	}
</script>

<style lang="scss">
	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	//深北沪
	.area {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	//深
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #87b52c;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #3b4fde;
		font-size: 24rpx;
		vertical-align: middle;
	}

	//北
	.north {
		width: 30rpx;
		height: 30rpx;
		background: #ea6248;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.north-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #ea6248;
		background: rgba(234, 98, 72, .1);
	}

	//沪
	.shanghai {
		width: 30rpx;
		height: 30rpx;
		background: #aa3bde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.shanghai-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #aa3bde;
		background: rgba(170, 59, 222, .1);
	}

	//公共css 结束

	// 没有更多
	.finished-text {
		color: #969799;
		font-size: 28rpx;
		margin: 30rpx auto;
		text-align: center;
		padding: 30rpx 0;
	}

	// 新购申购 开始
	.white-background {
		margin-top: -50rpx;
		border-radius: 20rpx 20rpx 0 0;
		color: #fff;

		.take-notes {
			display: flex;
			justify-content: space-around;
			align-items: center;
			text-align: center;
			padding: 60rpx 60rpx 30rpx;

			.purchase {
				font-size: 28rpx;

				image {
					width: 40rpx;
					height: 40rpx;
				}
			}
		}
	}

	.tab-header {
		background-color: #87b52c;
		height: 60rpx;
		display: flex;
	}

	.tab-content {
		font-size: 28rpx;
		flex: 1;
		text-align: center;
		color: #363636;
		height: 60rpx;
		line-height: 60rpx;
		position: relative;
	}

	.content-selection {
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: bold;
		color: #121327;
	}

	.approve {
		padding: 30rpx 30rpx 0;

		.corporation {
			font-size: 30rpx;
			font-weight: 800;
			margin-bottom: 10rpx;
		}

		.zero {
			display: flex;
			justify-content: space-around;
			align-items: center;
			// background-image: url('../../static/erceng/sheng1.png');
			background-color: #86b42c;
			background-size: cover;
			border-radius: 20px;
			color: #fff;
			margin: 20rpx 0rpx 20rpx 20rpx;
			height: 50rpx;
			width: 220rpx;
			font-size: 24rpx;

		}

		.thousand {
			display: flex;
			justify-content: space-around;
			align-items: center;
			// background-image: url('../../static/erceng/shen2.png');
			background-color: #FF2D30;
			background-size: cover;
			color: #fff;
			margin: 20rpx 20rpx;
			height: 50rpx;
			width: 220rpx;
			font-size: 24rpx;
		}
	}

	.treat {
		display: flex;
		justify-content: flex-start;
		align-items: center;

		.subscription {
			margin-right: 100rpx;
		}
	}

	.subscription-time {
		margin: 6rpx 30rpx;
		font-size: 28rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;

		text {
			color: #121327;
			margin-left: 10rpx;
		}
	}

	.subscription-times {
		// margin: 10rpx 20rpx;
		font-size: 28rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 44%;

		text {
			color: #121327;
			// margin-left: 10rpx;
		}
	}

	.price {
		margin: 6rpx 30rpx;
		width: 42%;
		font-size: 28rpx;

		text {
			color: #121327;
			// margin-left: 10rpx;
		}
	}

	// 新购申购 结束
</style>