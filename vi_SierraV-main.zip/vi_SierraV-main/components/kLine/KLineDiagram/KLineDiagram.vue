<template>
	<view class="sp-area">
		<!--   控制图1 !-->
		<view class="button-sp-area">
			<view class="mini-btn" @click="ChangeMinutePeriod(1)">分时</view>
			<view class="mini-btn" @click="ChangeKLinePeriod(0)">日</view>
			<view class="mini-btn" @click="ChangeKLinePeriod(1)">周</view>
			<view class="mini-btn" @click="ChangeKLinePeriod(2)">月</view>
			<!-- <view class="mini-btn" @click="ChangeKLinePeriod(4)">1分</view> -->
			<!-- 	<view class="mini-btn" @click="ChangeKLinePeriod(5)">5分</view>
			<view class="mini-btn" @click="ChangeKLinePeriod(7)">30分</view> -->

		</view>
		<view style='background-color:#fff;'>
			<HQChartControl ref="HQChartCtrl" DefaultChart="{Type:'KLine'}" :DefaultSymbol="zyCode">
			</HQChartControl>
			<!-- <HQChartControl ref="HQChartCtrl" DefaultChart="{Type:'KLine'}" DefaultSymbol="301308.sz">
			</HQChartControl> -->
		</view>
	</view>
</template>

<script>
	import HQChartControl from '@/uni_modules/jones-hqchart2/js_sdk/HQChartControl.vue'


	export default {
		components: {
			HQChartControl
		},
		props: ['code'],

		data() {
			let data = {
				Symbol: '600000.sh',
				ChartWidth: 100,
				ChartHeight: 350,
			};


			return data;
		},
		computed: {
			//股票代码转义
			zyCode() {
				if (!this.code) return ''
				const list = this.code.split('')
				const index = list.findIndex(item => !isNaN(item))
				const nums = this.code.substring(index)
				const str = this.code.substring(0, index)
				// this.$refs.HQChartCtrl.CreateHQChart
				this.$nextTick(() => {
					this.ChangeMinutePeriod();
					// this.CreateHQChart();
				})
				this.Symbol = nums + '.' + str.toLowerCase()
				return nums + '.' + str.toLowerCase()
			}
		},
		onShow() {
			uni.getSystemInfo({
				success: (res) => {
					var width = res.windowWidth;
					var height = res.windowHeight;
					this.ChartWidth = width;
					this.ChartHeight = height - 130;
					this.$nextTick(() => {
						this.CreateHQChart();
					})
				}
			});
		},

		onHide() {
			this.ClearHQChart();
		},

		onUnload() {
			this.ClearHQChart();
		},

		methods: {
			CreateHQChart() {
				var chartHeight = this.ChartHeight;
				let hqchartCtrl = this.$refs.HQChartCtrl;
				//修改option
				//hqchartCtrl.KLine.Option.
				hqchartCtrl.NetworkFilter = this.NetworkFilter;
				hqchartCtrl.SetSize(this.ChartWidth, chartHeight);
				hqchartCtrl.OnSize();
				hqchartCtrl.CreateHQChart();
			},

			ClearHQChart() {
				let hqchartCtrl = this.$refs.HQChartCtrl;
				if (hqchartCtrl) hqchartCtrl.ClearChart();
			},
			ChangeMinutePeriod(days) {
				let hqchartCtrl = this.$refs.HQChartCtrl;
				hqchartCtrl.ChangeMinutePeriod(days);
			},
			ChangeKLinePeriod(period) {
				let hqchartCtrl = this.$refs.HQChartCtrl;
				hqchartCtrl.ChangeKLinePeriod(period);
			},

			NetworkFilter(data, callback) {
				console.log(`[App:NetworkFilter] Name=${data.Name} Explain=${data.Explain}`);
			},
		}
	}
</script>

<style>
	.sp-area {
		border: 1px solid #f5f5f5;
	}

	.button-sp-area {
		display: flex;
		justify-content: space-between;
		/* margin: 10rpx 0 0; */
		/* border: 1px solid #f5f5f5; */
		/* padding: 6rpx 0; */
	}

	.mini-btn {
		margin: 0 20rpx;
		font-size: 28rpx;
	}

	.mini-btn:hover {
		color: #0263e2;
		font-weight: 800;
		background: #f5f5f5;
		/* padding: 0 6rpx; */
		border-radius: 10rpx;
	}
</style>