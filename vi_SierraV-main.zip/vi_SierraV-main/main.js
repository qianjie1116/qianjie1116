import App from './App'

// #ifndef VUE3
import Vue from 'vue'
import uView from "@/node_modules/uview-ui";
import VueI18n from 'vue-i18n'
import theme from '@/common/theme.js';
import util from '@/common/util';


Vue.use(uView)
Vue.use(VueI18n)

Vue.config.productionTip = false


Vue.prototype.$theme = theme;
Vue.prototype.$util = util;

// 设置语言环境为中文
const i18n = new VueI18n({
	locale: 'zh-Hans', // 默认语言为中文
})

App.mpType = 'app'
const app = new Vue({
	i18n, // 将i18n实例注入到Vue实例中
	...App
})
app.$mount()
// #endif

// 引入封装的请求
import request from "./utils/api.js";
Vue.prototype.$http = request;




// #ifdef VUE3
import {
	createSSRApp
} from 'vue'
export function createApp() {
	const app = createSSRApp(App)
	return {
		app
	}
}
// #endif


// 白名单 将无需用户登录也可查看的页面写在这里。默认是启动页、登录页、隐私协议
const whiteList = [
	`/pages/index/index`,
	`/pages/logon/logon/logon`,
	`/pages/logon/register/register`,
	`/pages/logon/forgot/forgot`,
];
// uniapp 跳转行为
const list = ["navigateTo", "reLaunch", "switchTab"]
// 目标url是否需要权限
function hasPermission(url) {
	console.log(url);
	return (whiteList.indexOf(url) !== -1 || uni.getStorageSync("token").length > 0);
}

list.forEach((item) => {
	// 路由拦截
	uni.addInterceptor(item, {
		// 页面跳转前进行拦截, invoke根据返回值进行判断是否继续执行跳转
		invoke(e) {
			// console.log(`e?`, e);
			if (!hasPermission(e.url)) {
				// 将用户的目标路径保存下来 这样可以实现 用户登录之后，直接跳转到目标页面
				// uni.setStorageSync("URL", e.url)
				// linkTo.signIn();
				uni.navigateTo({
					url: `/pages/logon/logon/logon`
				});
				return false;
			}
			return true;
		}
	});
})