/**
 * @function 检查token
 * @description 用于设置需要检查token的跳转，如onShow，linkTo
 */
export const checkToken = () => {
	if (!uni.getStorageSync('token') ||
		uni.getStorageSync('token') == '') {
		// signIn();
		uni.navigateTo({
			url: `/pages/logon/logon/logon`
		});
		return false;
	} else {
		return true;
	}
};

export default {
	checkToken,

	// 数字格式化(值，是否货币) 唯有货币值需要千分符
	formatNumber: (num, currency = true) => {
		num = num.toString();
		// num = num.replace(/[^\d]/g, ''); // 只允许数字输入
		const intPart = num.split('.')[0]; // 获取整数部分
		const decimalPart = num.split('.')[1] ? '.' + num.split('.')[1] : ''; // 获取小数部分
		// 添加千分符
		if (currency) {
			const curLocale = 'vi-VN'; // 
			const formattedIntPart = new Intl.NumberFormat(curLocale, {
				style: 'decimal', // 不包含货币符号。currency:包含货币符号
				// currency: Vue.prototype.$CURRENCY
				// unit: "kilometer-per-hour", // 单位
			}).format(intPart);
			return formattedIntPart + decimalPart;
		}
		return intPart + decimalPart;
	},

	// 根据当前平台，执行回退方式
	goBack() {
		/*#ifdef APP-PLUS*/
		uni.navigateBack({
			delta: 1
		});
		/*#endif*/

		/*#ifdef H5*/
		history.back();
		/*#endif*/
	},
}