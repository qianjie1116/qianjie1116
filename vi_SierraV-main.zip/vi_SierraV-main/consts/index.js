export const TYPES = [{
		name: 'Tin tức',
		type: 11,
		index: 1
	}

]
