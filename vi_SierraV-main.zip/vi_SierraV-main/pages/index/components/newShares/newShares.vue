<template>
	<view>
		<!-- 头部选项卡 -->
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 24rpx;height: 24rpx;" @tap="goBack()">
			</image>
			<view style="flex:1;text-align: center;color: #fff;font-size: 32rpx;font-weight: 500;">
				{{list[current]}}
			</view>
		</view>

		<!-- 内容 -->
		<view class="margin-top-20">
			<!-- <view v-if="current == 2">
				<zhaijuan :newShares_list2='newShares_list2' ></zhaijuan>
			</view> -->


			<view v-if="current == 2">
				<applyPurchase :newShares_list='newShares_list'></applyPurchase>
			</view>

			<!-- <view v-if="current == 3">
				<newShareRaising></newShareRaising>
			</view> -->

			<view v-if="current == 1">
				<blockTrade></blockTrade>
			</view>

			<!-- <view v-if="current == 3">
				<newBondPlacement></newBondPlacement>
			</view> -->


			<view v-if="current == 0">
				<vipScramble></vipScramble>
			</view>

			<!-- <view v-if="current == 3">
				<subscriptionBonds></subscriptionBonds>
			</view> -->
		</view>
	</view>

	</view>
</template>

<script>
	import zhaijuan from "../../../../components/new-shares/zhaijuan.vue";
	import applyPurchase from "../../../../components/new-shares/applyPurchase.vue";
	import newShareRaising from "../../../../components/new-shares/newShareRaising.vue";
	// import subscriptionBonds from "../../../../components/new-shares/subscriptionBonds.vue";
	// import newBondPlacement from "../../../../components/new-shares/newBondPlacement.vue";
	import blockTrade from "../../../../components/new-shares/blockTrade.vue";
	import vipScramble from "../../../../components/new-shares/vipScramble.vue";
	export default {
		components: {
			zhaijuan,
			applyPurchase,
			newShareRaising,
			// subscriptionBonds,
			// newBondPlacement,
			blockTrade,
			vipScramble,

		},
		data() {
			return {
				current: 0,
				list: ['Giao dịch', 'Quyền mua', "CỔ PHIẾU MỚI"],
				newShares_list: "",
				newShares_list2: "",

			};
		},
		onLoad(option) {
			if (option.index) {
				this.current = option.index
				// this.newShares()
				if (this.current == 2) {
					this.newShares()
				}
				// this.newShares2()
			}
		},
		onShow() {
			if (!this.$util.checkToken()) return false;
		},

		methods: {
			// 根据当前平台，执行回退方式
			goBack() {
				/*#ifdef APP-PLUS*/
				uni.navigateBack({
					delta: 1
				});
				/*#endif*/

				/*#ifdef H5*/
				history.back();
				/*#endif*/
			},
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			select(item) {
				this.current = item.index;
			},
			//新股申购
			async newShares() {
				let list = await this.$http.post('api/goods-shengou/calendar', {
					type: 1,
				})
				this.newShares_list = list.data.data
			},
			async newShares2() {
				let list = await this.$http.post('api/goods-shengou/zhaijuan', {
					type: 2,
				})
				this.newShares_list2 = list.data.data
				// console.log(list.data.data, '待申购');
			},
		},

	}
</script>

<style lang="scss">
	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}


	.college-bg {
		padding: 48rpx 24rpx 24rpx 24rpx;
		background-color: #363636;
		margin-bottom: 24rpx;
		display: flex;
		align-items: center;
	}
</style>