<template>
	<view>
		<!-- 头部-->
		<view class="college-bg">
			<view class="account">
				<image src="../../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
				<!-- <u-icon name="arrow-left" color="#fff" size="20" @tap="home()" class="icon"></u-icon> -->
				<view class="college-text">每日停复牌</view>
				<image @tap="refresh()" class="renovate" src="../../../../../static/shuaxin.png" mode=""></image>
			</view>

			<view class="suo" @tap="searchFor()">
				<image src="../../../../../static/sousuo.png" mode=""></image>
			</view>
		</view>
		<!-- 选项卡 -->
		<view class="lookOver">
			<block v-for="(item,index) in items" :key="index">
				<view :class="['tab-content',content== index?'content-selection':'']" @click="content=index">
					{{item}}
				</view>
			</block>
		</view>



		<view class="lookContent">
			<!-- 选项卡一 -->
			<view class="one" v-show="content == 0">
				<view class="stockCode">
					<view class="">股票代码</view>
					<view class="">停牌日期</view>
					<view class="">停牌原因</view>
				</view>

				<view class="a-row" v-for="(item,index) in plate" :key="index">
					<view class="share">
						<h5>{{item.secu_abbr}}</h5>
						<view class="figure">
							{{item.secu_code}}
						</view>
					</view>
					<view class="figure"> {{item.suspend_date}}</view>
					<view class="figure">{{item.suspend_reason}}</view>
				</view>
			</view>


			<!-- 选项卡二 -->
			<view class="two" v-show="content == 1">
				<view class="stockCode">
					<view class="">股票代码</view>
					<view class="">复牌日期</view>
					<view class="">复牌时间</view>
				</view>
				<view class="a-row" v-for="(item,index) in plate" :key="index">
					<view class="share">
						<h5>{{item.secu_abbr}}</h5>
						<view class="figure">
							{{item.secu_code}}
						</view>
					</view>
					<view class="figure">{{item.suspend_date}}</view>
					<view class="figure">{{item.suspend_time}}</view>
				</view>
			</view>
		</view>



	</view>
</template>

<script>
	export default {
		data() {
			return {
				content: 0,
				items: [
					'停牌查看', '复牌查看'
				],
				plate: ''
			};
		},
		methods: {
			changeTab(Inv) {
				that.navIdx = Inv;
			},
			home() {
				uni.switchTab({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/index/index'
				});
			},
			//搜索
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			//刷新功能
			refresh() {
				uni.redirectTo({
					url: '/pages/index/components/secondRow/stopResumeTrading/stopResumeTrading'
				});
			},
			// 列表
			async stopResume() {
				let list = await this.$http.get('api/stock-api/BaseSuspensionList', {

				})
				this.plate = list.data.data
			},

		},
		mounted() {
			this.stopResume()
		},
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 20rpx;
		height: 280rpx;
				background-image: linear-gradient(to right, #FFB044, #FF2D30);

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.renovate {
			width: 40rpx;
		}

		.account {
			display: flex;
			justify-content: space-between;
			align-items: center;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

		.suo {
			background: hsla(0, 0%, 100%, .1);
			border-radius: 40rpx;
			padding: 10rpx 40rpx;
			margin: 40rpx 0 0;

			image {
				width: 40rpx;
				height: 40rpx;
				margin-top: 10rpx;
			}
		}
	}

	.lookOver {
		margin-top: -80rpx;
		border-radius: 30rpx 30rpx 0 0;
		background: #fff;
		display: flex;

		.tab-content {
			font-size: 32rpx;
			flex: 1;
			text-align: center;
			color: #666666;
			height: 100rpx;
			line-height: 100rpx;
			position: relative;
		}

		.content-selection {
			font-size: 32rpx;
			font-family: PingFang SC;
			font-weight: bold;
			color: #121327;
		}

		.content-selection:after {
			content: '';
			position: absolute;
			bottom: -2rpx;
			top: auto;
			left: 42%;
			height: 6rpx;
			width: 44rpx;
			background-color: #121327;
		}

	}

	.stockCode {
		border-top: 2rpx solid #e0e0e0;
		border-bottom: 2rpx solid #e0e0e0;
		display: flex;
		justify-content: space-between;
		padding: 20rpx 30rpx;
		align-items: center;
		text-align: center;
		color: #999;
		font-size: 28rpx;

		view {
			width: 30%;
		}
	}

	.lookContent {
		margin: 20rpx 0rpx;

		.one {
			.a-row {
				border-bottom: 2rpx solid #e0e0e0;
				padding: 10rpx 6rpx 10rpx 0;
				display: flex;
				justify-content: space-between;
				align-items: center;

				.share {
					text-align: center;
					display: flex;
					flex-direction: column;
					justify-content: center;
					align-items: center;

				}

				view {
					width: 30%;
					text-align: center;
				}

				.figure {
					font-size: 26rpx;
					color: #1a1a1a;
				}
			}
		}

		.two {
			.a-row {
				border-bottom: 2rpx solid #e0e0e0;
				padding: 10rpx 6rpx 10rpx 0;
				display: flex;
				justify-content: space-between;
				align-items: center;

				.share {
					text-align: center;
					display: flex;
					flex-direction: column;
					justify-content: center;
					align-items: center;

				}

				view {
					width: 30%;
					text-align: center;
				}

				.figure {
					font-size: 26rpx;
					color: #1a1a1a;
				}
			}
		}
	}
</style>