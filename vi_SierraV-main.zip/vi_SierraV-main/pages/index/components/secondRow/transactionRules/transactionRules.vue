<!-- 关于我们 -->
<template>
	<view>
		<view class="college-bg">
			<image src="@/static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">{{about.title}}</view>
			<view class=""></view>
		</view>
		<view class="college-content">
			<!-- <rich-text :nodes="about.content"></rich-text> -->
			<view class="" v-html="about.content"></view>

			<u-divider></u-divider>



		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				about: ''
			};
		},
		methods: {
			home() {
				uni.switchTab({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/index/index'
				});
			},
			//关于我们
			async about_us() {
				let list = await this.$http.get('api/article/info', {
					type: 19
				})
				this.about = list.data.data[0]
				// console.log(list.data.data[0], '交易规则');
			},
		},
		mounted() {
			this.about_us()
		},
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 80rpx;
				background-image: linear-gradient(to right, #FFB044, #FF2D30);
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		padding: 40rpx;
		font-size: 28rpx;

	}
</style>
