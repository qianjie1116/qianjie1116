<!-- 学院 -->
<template>
	<view>
		<view class="college-bg">
			<image src="../../../../static/zuojiantou.png" mode="" @tap="home()"></image>
			<view class="college-text">Đại học</view>
			<view class=""></view>
		</view>
		<view class="college-content" @click="circuit()">
			<view class="circuit">
				<!-- <image src="../../../../static/xueyaun.png" mode=""></image> -->
				<text>Đường dây 1</text>
			</view>
			<view class="right-arrow">
				<!-- <image src="../../../../static/jiantou.png" mode=""></image> -->
			</view>
		</view>
		<u-divider></u-divider>




	</view>
</template>

<script>
	export default {
		data() {
			return {

			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			circuit() {
				uni.$u.toast('Học viện Thân Vạn Hồng Nguyên, tạm thời chỉ mở cửa cho người sử dụng giao dịch đầy một năm');
				setTimeout(() => {
					uni.switchTab({
						url: '/pages/index/index',
					});
				}, 2000)
			}

		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 80rpx;
				background-image: linear-gradient(to right, #FFB044, #FF2D30);
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 30rpx 30rpx 0;

		.circuit {
			display: flex;
			flex-direction: row;
			justify-content: flex-end;
			align-items: center;

			image {
				width: 100rpx;
				height: 100rpx;
				margin-right: 20rpx;
			}
		}


		.right-arrow {
			image {
				width: 10rpx;
				height: 20rpx;
			}
		}
	}
</style>