<template>
	<view style="overflow: hidden;">
		<!-- 头部 -->
		<view class="head-background">
			<!-- 搜索栏 -->
			<view class="nav-slot">
				<!-- <view @tap="customer()" style="width: 50rpx;height: 50rpx;">
					<image style="width: 50rpx;height: 50rpx;" src="../../static/kefu.png" mode=""></image>
				</view> -->
				<view class="jump-search" @tap="searchFor()">
					<image src="../../static/sousuo.png" mode=""></image>
				</view>
			</view>
		</view>
		<!-- 第三排 -->
		<view class="third-row">
			<!-- 		<view class="new-shares" @tap="marketQuotations()">
				<image src="../../static/shouye/gupiao.png" mode=""></image>
				<text class="">股票</text>
			</view>
			<view class="new-shares" @tap="fund()">
				<image src="../../static/shouye/jijin.png" mode=""></image>
				<text class="">基金</text>
			</view>
			<view class="new-shares" @tap="college()">
				<image src="../../static/shouye/xuexi.png" mode=""></image>
				<text class="">学院</text>
			</view> -->
			<!-- 开户 -->
			<!-- <view class="new-shares" @tap="openAccount()">
				<image src="../../static/shouye/kaihu.png" mode=""></image>
				<text class="">tài khoản</text>
			</view> -->
			<!-- ETF -->
			<navigator class="new-shares" url="components/fund/fund">
				<image src="../../static/shouye/ETF.png" mode=""></image>
				<text>ETF</text>
			</navigator>

			<!-- 交易 -->
			<view class="new-shares" @tap="state()">
				<image src="../../static/shouye/jiaoyi.png" mode=""></image>
				<text>Giao dịch</text>
			</view>

			<!-- 新股申购 -->
			<view class="new-shares" @tap="ancestor()">
				<image src="../../static/shouye/caigou.png" mode=""></image>
				<text>IPO</text>
			</view>
			<!-- 交易规则 -->
			<view class="new-shares" @tap="transactionRules()">
				<image src="../../static/shouye/guize.png" mode=""></image>
				<text>Dịch vụ</text>
			</view>
			<!-- 客服 -->
			<view class="new-shares" @tap="customer()">
				<image src="../../static/shouye/kefu.png" mode=""></image>
				<text class=""> CSKH </text>
			</view>


			<!-- 		<view class="new-shares" @tap="newDebt()">
				<image src="../../static/shouye/shengou.png" mode=""></image>
				<text>新债申购</text>
			</view> -->

			<!-- <view class="new-shares" @tap="purchase()">
				<image src="../../static/shouye/VIP.png" mode=""></image>
				<text>VIP抢筹</text>
			</view> -->
			<!-- <view class="new-shares" @tap="scramble()">
				<image src="../../static/shouye/qiangchou.png" mode=""></image>
				<text>phân bổ</text>
			</view>

			<view class="new-shares" @tap="stopResumeTrading()">
				<image src="../../static/shouye/tingfupai.png" mode=""></image>
				<text>dừng trả lời</text>
			</view>
			<view class="new-shares" @tap="dragonTiger()">
				<image src="../../static/shouye/longhu.png" mode=""></image>
				<text>xếp hạng</text>
			</view>

			<view class="new-shares" @tap="tradingShares()">
				<image src="../../static/shouye/shida.png" mode=""></image>
				<text>Sợi nóng</text>
			</view>
			<view class="new-shares" @tap="dailyLimit()">
				<image src="../../static/shouye/zhangting.png" mode=""></image>
				<text>Tăng giá</text>
			</view> -->


		</view>
		<!-- 第四排  折线-->
		<!-- 	<view class="fourth-row">
			<polylineRegion></polylineRegion>
		</view> -->
		<!-- 		<view class="shanghais">
			<view class="deeps">沪深</view>
			<view class="upper">上涨{{distribution.up_count}}</view>
			<view class="rise">
				<image src="../../static/zuo.png" mode=""></image>
			</view>
			<view class="below">
				<image src="../../static/you.png" mode=""></image>
			</view>
			<view class="fall">{{distribution.down_count}}下跌</view>
		</view> -->
		<!-- 图片 -->
		<!-- <view class="tupian">
			<swiper circular autoplay>
				<swiper-item v-for="item in rotation" :key="item.id">
					<image :src="item.url"></image>
				</swiper-item>
			</swiper>
		</view> -->
		<!-- K线 -->
		<u-tabs lineColor="#121327" :list="list2" :activeStyle="{color: '#121327',}"></u-tabs>
		<view @click="link_etf">
			
			<view class="charts-box" >
				<qiun-data-charts 
				      type="area"
				      :opts="opts"
				      :chartData="chartData"
				      :optsWatch="false"
				      background="rgba(51,51,51,1)"
				      :animation="false"
				      :tooltipShow="false"
				      :tapLegend="false"
				      :ontap="false"
				      :onmouse="false"
				    />
			</view>
			<view style="background: #333333;margin: 0 20rpx;color: #e9952f;padding-left: 30rpx;height: 160rpx;" >
				<view class="information">
					<view class="help">
						<!-- <image src="/static/jijin/1.png" mode=""></image> -->
						<image src="/static/chuanggai/new-logo.png" mode=""></image>
						<view class="">{{list[0].name}}</view>
					</view>
					<view class="increase">
						<view class="help">
							<image src="/static/jijin/zhang.png" mode=""></image>
							<view class=""> {{list[0].syl}}
							</view>
						</view>
					</view>
				</view>
				<view class="information" style="font-size: 28rpx;padding-right: 20rpx;">
					<view class="help">
						<view class="" style="color: #fff;">{{list[0].gz==1?'Nhận lãi hàng ngày':'Nhận lãi từ thứ hai đến thứ sáu'}}</view>
					</view>
					<view class="help">
						<view class="" style="color: #fff;">{{toThousandFilter(list[0].min_price)}}₫</view>
					</view>
					
				</view>
				
			</view>
		</view>
		
		<!-- <view style="margin-top: 30rpx;" url="components/fund/fund">
			<u-tabs lineColor="#121327" :list="list2" :activeStyle="{color: '#121327',}"></u-tabs>
			<scroll-view scroll-x="true"  class="scrollview-box">
				<view class="stock-fund" v-for="(item,index) in list" v-if="index<=4" @click="link_etf">
					<view class="information">
						<view class="help">
							<image src="/static/jijin/1.png" mode=""></image>
							<view class="">{{item.name}}</view>
						</view>
				
					</view>
					<view class="increase">
						<view class="help">
							<image src="/static/jijin/2.png" mode=""></image>
							<view class=""> {{item.syl}}
							</view>
						</view>
						
					</view>
					<view class="last">
						<view class="help">
							{{item.gz==1?'Nhận lãi hàng ngày':'Nhận lãi từ thứ hai đến thứ sáu'}}
						</view>
						<view class="detailed">
							{{item.min_price}}
						</view>
					</view>
					
				</view>
				
			</scroll-view>
		</view> -->

		<!-- 滚动通知 -->
		<!-- 		<view class="headline">
			<image src="../../static/toutiao.png" mode=""></image>
			<u-notice-bar icon='' bgColor="#fef4db" color="#ed6a0c" :text="textNotice"></u-notice-bar>
		</view> -->
		<view style="width: 100%;height: 10rpx;background: #F4F4F4;"></view>

		<!-- <view  class="up-and-down-list">
			<u-divider></u-divider>
			<view class="range">
				<view class="share-certificate">Mã</view>
				<view class="up-to-date">
					<view>Lần cuối</view>
					<view>%Thđổi</view>
					<view>Th.đổi</view>
				</view>
			</view>
			<u-divider></u-divider>
			<view class="shujuk" v-for="(item,index) in list_data" :key="index" @tap="productDetails(item.gid)">
				<view class="share-certificate">
					<h6>{{item.name}}</h6>
					<view class="area" v-if="item.locate=='深'">
						<view class="deep">{{item.locate}}</view>
						<view class="deep-number">{{item.code}}</view>
					</view>
					<view class="area" v-if="item.locate=='北'">
						<view class="north">{{item.locate}}</view>
						<view class="north-number">{{item.code}}</view>
					</view>
					<view class="area" v-if="item.locate=='沪'">
						<view class="shanghai">{{item.locate}}</view>
						<view class="shanghai-number">{{item.code}}</view>
					</view>
				</view>
				<view class="up-to-date">
					<view class="current_price" :style="item.rate>0?'color:#16A139':'color:#FE0101'">{{item.current_price}}</view>
					<view class="rate" :style="item.rate>0?'color:#16A139':'color:#FE0101'">{{item.rate}}%</view>
					<view class="forehead">{{item.rate_num}}</view>
				</view>
			</view>
		</view> -->

		<!-- 底部选项卡 -->
		<view class="">
			<u-tabs lineColor="#121327" :list="list1" :activeStyle="{color: '#121327',}"></u-tabs>
			<view v-if="current == 0">
				<view class="finance-economics">
					<view class="important" v-for="i in news"
						@click="to_skip('/pages/index/components/newsDetail',1,i.title,i.id)">
						<view class="">
						</view>
						<view class="">
							<view>{{i.title}}</view>
							<view class="time">{{i.created_at}}</view>
						</view>
					</view>
				</view>
			</view>
			<view v-if="current == 1">
				<view class="finance-economics">
					<view class="important" v-for="i in news"
						@click="to_skip('/pages/index/components/newsDetail',1,i.title,i.id)">
						<view>{{i.title}}</view>
						<view class="time">{{i.created_at}}</view>
					</view>
				</view>
			</view>
			<view v-if="current == 2">
				<view class="finance-economics">
					<view class="important" v-for="i in news"
						@click="to_skip('/pages/index/components/newsDetail',1,i.title,i.id)">
						<view>{{i.title}}</view>
						<view class="time">{{i.created_at}}</view>
					</view>
				</view>
			</view>
			<view v-if="current == 3">
				<view class="finance-economics">
					<view class="important" v-for="i in news"
						@click="to_skip('/pages/index/components/newsDetail',1,i.title,i.id)">
						<view>{{i.title}}</view>
						<view class="time">{{i.created_at}}</view>
					</view>
				</view>
			</view>
			<view v-if="current == 4">
				<view class="finance-economics">
					<view class="important" v-for="i in news"
						@click="to_skip('/pages/index/components/newsDetail',1,i.title,i.id)">
						<view>{{i.title}}</view>
						<view class="time">{{i.created_at}}</view>
					</view>
				</view>
			</view>
			<view v-if="current == 5">
				<view class="finance-economics">
					<view class="important" v-for="i in news"
						@click="to_skip('/pages/index/components/newsDetail',1,i.title,i.id)">
						<view>{{i.title}}</view>
						<view class="time">{{i.created_at}}</view>
					</view>
				</view>
			</view>
			<view v-if="current == 6">
				<view class="finance-economics">
					<view class="important" v-for="i in news"
						@click="to_skip('/pages/index/components/newsDetail',1,i.title,i.id)">
						<view>{{i.title}}</view>
						<view class="time">{{i.created_at}}</view>
					</view>
				</view>
			</view>
		</view>

		<!-- 弹窗组件 -->
		<lerugeupdate ref="update" :downloadUrl="update.url" :updateDesc="update.title" :force="true" />
	</view>
</template>

<script>
	import polylineRegion from "./components/polylineRegion/polylineRegion.vue"
	import {
		TYPES
	} from '../../consts/index.js'
	export default {
		components: {
			polylineRegion,
		},
		data() {
			return {
				swiperList: ['integral', 'kefu-ermai', 'coupon', 'gift', 'scan', 'pause-circle', 'wifi', 'email', 'list'],
				downloadUrl: '',
				updateDesc: "",
				// urlway: '',
				// //是否更新
				updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				update: '',
				closeOnClickOverlay: false,
				text1: '央行、银保监会：支持发放住房租赁经营性贷款',
				textNotice: '',
				current: 0,
				list1: TYPES,
				news: "",
				newsimg: '',
				distribution: '',
				picturePath: '',
				type: TYPES[0].type,
				list_data: [],
				rotation: [{
						id: 1,
						url: '../../static/chuanggai/lunbo.jpg'
					},

				],
				list: [],
				list2: [{
					name: "Vốn tối ưu"
				}],
				chartData: {},
				//这里的 opts 是图表类型 type="area" 的全部配置参数，您可以将此配置复制到 config-ucharts.js 文件中下标为 ['area'] 的节点中来覆盖全局默认参数。实际应用过程中 opts 只需传入与全局默认参数中不一致的【某一个属性】即可实现同类型的图表显示不同的样式，达到页面简洁的需求。
				opts: {
					timing: "easeOut",
					duration: 1000,
					rotate: false,
					rotateLock: false,
					color: ["#30c47a", "#91CB74", "#FAC858", "#EE6666", "#73C0DE", "#3CA272", "#FC8452", "#9A60B4",
						"#ea7ccc"
					],
					padding: [15, 15, 0, 15],
					fontSize: 13,
					fontColor: "#ffffff",
					dataLabel: true,
					dataPointShape: false,
					dataPointShapeType: "solid",
					touchMoveLimit: 60,
					enableScroll: false,
					enableMarkLine: false,
					legend: {
						show: false,
						position: "bottom",
						float: "center",
						padding: 5,
						margin: 5,
						backgroundColor: "rgba(0,0,0,0)",
						borderColor: "rgba(0,0,0,0)",
						borderWidth: 0,
						fontSize: 13,
						fontColor: "#666666",
						lineHeight: 11,
						hiddenColor: "#CECECE",
						itemGap: 10
					},
					xAxis: {
						disableGrid: true,
						disabled: false,
						axisLine: true,
						axisLineColor: "#CCCCCC",
						calibration: false,
						fontColor: "#333333",
						fontSize: 13,
						lineHeight: 20,
						marginTop: 0,
						rotateLabel: false,
						rotateAngle: 45,
						itemCount: 5,
						boundaryGap: "center",
						splitNumber: 5,
						gridColor: "#CCCCCC",
						gridType: "solid",
						dashLength: 4,
						gridEval: 1,
						scrollShow: false,
						scrollAlign: "left",
						scrollColor: "#A6A6A6",
						scrollBackgroundColor: "#EFEBEF",
						title: "",
						titleFontSize: 13,
						titleOffsetY: 0,
						titleOffsetX: 0,
						titleFontColor: "#666666",
						format: ""
					},
					yAxis: {
						gridType: "dash",
						dashLength: 2,
						disabled: true,
						disableGrid: false,
						splitNumber: 5,
						gridColor: "#CCCCCC",
						padding: 10,
						showTitle: false,
						data: []
					},
					extra: {
						area: {
							type: "straight",
							opacity: 0.2,
							addLine: true,
							width: 2,
							gradient: false,
							activeType: "hollow"
						},
						tooltip: {
							showBox: true,
							showArrow: true,
							showCategory: false,
							borderWidth: 0,
							borderRadius: 0,
							borderColor: "#000000",
							borderOpacity: 0.7,
							bgColor: "#000000",
							bgOpacity: 0.7,
							gridType: "solid",
							dashLength: 4,
							gridColor: "#CCCCCC",
							boxPadding: 3,
							fontSize: 13,
							lineHeight: 20,
							fontColor: "#FFFFFF",
							legendShow: true,
							legendShape: "auto",
							splitLine: true,
							horizentalLine: false,
							xAxisLabel: false,
							yAxisLabel: false,
							labelBgColor: "#FFFFFF",
							labelBgOpacity: 0.7,
							labelFontColor: "#666666"
						},
						markLine: {
							type: "solid",
							dashLength: 4,
							data: []
						},
					}
				}
			}
		},

		methods: {
			toThousandFilter(num) {
			  return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			link_etf() {
				uni.navigateTo({
					url: "/pages/index/components/fund/fund"
				})
			},
			// 检测更新
			// clickUpdate(url) {
			// 	// let path = window.location.protocol + '//' + url
			// 	// location.href = url
			// 	uni.navigateTo({
			// 		// url: `/components/Update/Update?url=${url}`
			// 		url: '/pages/Update/Update' + `?url=${url}`
			// 	})
			// 	console.log('抛出去', url);
			// },
			//底部选项卡
			Kline(item, type) {
				this.current = item.index;
				this.type = item.type
				this.gain_views()
			},
			//个人中心
			personal() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},

			//跳转行情
			marketQuotations() {
				uni.switchTab({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/marketQuotations/marketQuotations'
				});
			},
			//邮箱跳转
			youxiang() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			//搜索
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},
			//学院
			college() {
				uni.navigateTo({
					url: '/pages/index/components/college/college'
				});
			},
			//客服
			customer() {
				uni.navigateTo({
					url: '/pages/index/components/customer/customer'
				});
			},
			//开户
			openAccount() {
				uni.navigateTo({
					url: '/pages/index/components/openAccount/openAccount'
				});
			},
			//基金
			fund() {
				uni.navigateTo({
					url: '/pages/index/components/fund/fund'
				});
			},
			//申购
			state() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/newShares?index=0'
				});
			},
			//新债
			// newDebt() {
			// 	uni.navigateTo({
			// 		url: '/pages/index/components/newShares/newShares?index=2'
			// 	});
			// },
			// 大宗交易
			ancestor() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/newShares?index=2'
				});
			},
			//vip抢筹
			purchase() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/newShares?index=3'
				});
			},
			//新股抢筹
			scramble() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/newShares?index=1'
				});
			},
			//龙虎榜
			dragonTiger() {
				uni.navigateTo({
					url: '/pages/index/components/secondRow/dragonTiger/dragonTiger'
				});
			},
			//每日停复牌
			stopResumeTrading() {
				uni.navigateTo({
					url: '/pages/index/components/secondRow/stopResumeTrading/stopResumeTrading'
				});
			},
			//十大成交股
			tradingShares() {
				uni.navigateTo({
					url: '/pages/index/components/secondRow/tradingShares/tradingShares'
				});
			},
			//每日涨停
			dailyLimit() {
				uni.navigateTo({
					url: '/pages/index/components/secondRow/dailyLimit/dailyLimit'
				});
			},
			//交易规则
			transactionRules() {
				uni.navigateTo({
					url: '/pages/index/components/secondRow/transactionRules/transactionRules'
				});
			},
			//新闻详情
			newsDetail() {
				uni.navigateTo({
					url: '/pages/index/components/newsDetail'
				});
			},

			//数据请求
			// async login_liufu() {
			// 	try {
			// 		uni.removeStorageSync('url');
			// 	} catch (e) {}
			// 	let list = await this.$http.get(
			// 		'https://sm8-x8ax6-b574-u99hy-w4uv-dgm4-s-p-c.oss-cn-hongkong.aliyuncs.com/sotck-S1GT9GYprH0PVgMLwapC0nYzLAoDa0bd.txt', {
			// 			// language: this.$i18n.locale
			// 		})
			// 	// 接口域名
			// 	console.log(list.data, '首页接口位置')
			// 	uni.setStorageSync('url', list.data);
			// },
			is_token() {
				let token = uni.getStorageSync('token') || '';
				if (!token) {
					try {
						uni.clearStorageSync();
					} catch (e) {
						// error
					}
					uni.showLoading({
						title: 'vui lòng đăng nhập trước',
						duration: 1000,
					})
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/logon/logon/logon'
						});
					}, 1000)
				} else {

				}
			},
			// 首页
			// async gain_home() {
			// 	let list = await this.$http.get('api/app/home', {
			// 		// language: this.$i18n.locale
			// 	})
			// 	// this.list = list.data.data.switchGoods.data
			// 	// console.log(list.data.data, '数据位置');
			// 	// uni.hideLoading();
			// 	// uni.stopPullDownRefresh();
			// },
			changeIndicatorDots(e) {
				this.indicatorDots = !this.indicatorDots
			},
			changeAutoplay(e) {
				this.autoplay = !this.autoplay
			},
			intervalChange(e) {
				this.interval = e.target.value
			},
			durationChange(e) {
				this.duration = e.target.value
			},
			//版本更新
			async versionUpdate() {
				let list = await this.$http.get('api/version/detail', {})
				this.update = list.data.data
				// console.log(list.data.data, '推送的版本');
				let version = list.data.data.version
				//如果获取不到版本号，就默认版本号为2.1  
				let old_version = uni.getStorageSync('version') || 1.0
				// console.log(old_version, '当前版本');
				if (old_version < version) {
					this.updateFlag = true
					this.$refs.update.upgrade()
					// console.log(111111111111);
					uni.setStorageSync('version', version)
				}
				// console.log(list.data.data, '版本更新');
			},
			async stock_list() {
				let list_stock = await this.$http.get('api/goods/updownlist', {
					page: 1,
					limit: 20,
				})
				console.log(list_stock)
				this.list_data = list_stock.data
			},
			//新闻
			async gain_views() {
				let list = await this.$http.get('api/article/list', {
					type: this.type,
				})
				// console.log(this.list1[index].type, '新闻列表')
				this.news = list.data.data
				// uni.hideLoading();
				// uni.stopPullDownRefresh();

			},
			//新闻图片
			// async newsPictures() {
			// 	let list = await this.$http.get('api/announce/default_image', {
			// 	})
			// 	this.newsimg = list.data.data
			// },


			//公告
			// async announcement() {
			// 	let list = await this.$http.get('api/app/article', {
			// 		type: 18,
			// 	})
			// 	this.textNotice = list.data.data[0].title
			// 	// console.log(list.data.data[0].content, '99999999');
			// },
			//新闻跳转携带参数
			to_skip(url, type, title, id) {
				if (type == 1) {
					uni.navigateTo({
						url: url + `?title=${title}&id=${id}`
					});
				} else if (type == 2) {
					uni.switchTab({
						url: url
					});
				}
			},

			//沪深港通涨跌分布		
			async fluctuation() {
				let list = await this.$http.get('api/stock-api/base-shszhk-distribution', {})
				this.distribution = list.data.data
			},
			async getlist() {
				var list = await this.$http.get('api/jijin/list')
				console.log("基金列表", list);
				this.list = list.data.jj_list
				setTimeout(() => {
				  //模拟服务器返回数据，如果数据格式和标准格式不同，需自行按下面的格式拼接
				  let res = {
				      categories: ["2018","2019","2020","2021","2022","2023","2023","2023","2023","2023"],
				      series: [
				        {
				          name:list.data.jj_list[0].name,
				          data: [11,12,12,12,12.5,13,14.2,14.7,15,16]
				        }
				      ]
				    };
				  this.chartData = JSON.parse(JSON.stringify(res));
				}, 500);
			},
			
			// K线首页
			// async homeKLine() {
			// 	let list = await this.$http.get('api/kline/index', {})
			// 	console.log(list.data.data, '99999999');
			// },
		},
		 
		async mounted() {
			this.versionUpdate()
			uni.startPullDownRefresh();
			this.is_token()
			this.fluctuation()

		},
		async onShow() {
			// await this.login_liufu()
			// this.gain_home()
			this.is_token()
			this.gain_views()
			this.stock_list()
			// this.announcement()
			this.versionUpdate()
			this.getlist()
			// this.newsPictures()
		},

		async onPullDownRefresh() {
			uni.showLoading({
				title: 'Đang tải',
			});
			// await this.login_liufu()
			// this.gain_home()
			this.is_token()
			this.gain_views()
			// this.announcement()
		}

	}
</script>

<style lang="scss">
	/deep/uni-swiper {
		height: 300rpx !important;
	}

	/deep/.tupian uni-image {
		height: 300rpx !important;
	}

	
	.charts-box{
		height: 200rpx;
		margin-left: 20rpx;
		margin-right: 20rpx;
		margin-top: 20rpx;
	}
	.scrollview-box {
		white-space: nowrap;
		/* 滚动必须加的属性 */
		width: 100%;
		padding: 20rpx 20rpx 20rpx 20rpx;
	}

	.head-background {
		background-image: url('../../static/chuanggai/bj.png');
		width: 100%;
		height: 234rpx;
		background-size: 100%;
		margin: 0 auto;
		z-index: -1;
		padding: 20rpx 0 0;

		// 搜索栏
		.nav-slot {
			display: flex;
			justify-content: flex-end;
			align-items: center;
			padding: 30rpx;

			.personalCenter {
				height: 54rpx;
				width: 54rpx;
				margin-top: 10rpx;
			}

			.jump-search {
				.code {
					margin: 0 20rpx;
					color: #fff;
					font-size: 26rpx;
				}


			}

			image {
				width: 40rpx;
				height: 40rpx;
				margin-top: 10rpx;
			}
		}

		.swiper {
			height: 720rpx;
		}

		.grid-text {
			font-size: 14px;
			color: #909399;
			padding: 10rpx 0 20rpx 0rpx;
			/* #ifndef APP-PLUS */
			box-sizing: border-box;
			/* #endif */
		}

	}

	//第二排
	// .second-row {
	// 	display: flex;
	// 	justify-content: space-between;
	// 	align-items: center;
	// 	padding: 0 60rpx;
	// 	color: #000;
	// 	margin-top: -5px;
	// 	background: #fff;
	// 	border-radius: 20rpx 20rpx 0 0;

	// 	.twoRow-sorting {
	// 		display: flex;
	// 		flex-direction: column;
	// 		justify-content: center;
	// 		align-items: center;
	// 		font-size: 26rpx;

	// 		image {
	// 			width: 66rpx;
	// 			height: 66rpx;
	// 			// border-radius: 50%;
	// 			margin: 10rpx 0;
	// 		}
	// 	}
	// }

	.third-row {
		// padding: 30rpx;
		// box-shadow: 0 2rpx 2rpx 0 #b1b1b1;
		background: #fff;
		margin-top: -10rpx;
		border-radius: 20rpx;
		// margin: -100rpx 30rpx 0rpx;
		display: flex;
		justify-content: space-between;
		flex-wrap: wrap;
		align-items: center;
		// webkit-box-shadow: 0 0.02rem 0.05rem 0 rgb(0 0 0 / 10%);

		// 第三排 
		.new-shares {
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			width: 20%;
			margin: 20rpx 0rpx;
			font-size: 26rpx;
			color: #929295;

			image {
				width: 60rpx;
				height: 60rpx;
				margin: 10rpx 0;
			}
		}
	}

	// 第四排
	.fourth-row {
		margin: 20rpx 20rpx 0;
		// box-shadow: 0 2rpx 2rpx 0 #b1b1b1;
		border: 1rpx solid #e0e0e0;
		background: #fff;
		border-radius: 20rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 20rpx 20rpx 0;

		.among {
			background: #888888;
			color: #FEFEFE;
			border-radius: 4rpx;
			padding: 2rpx;
		}
	}

	.shanghais {
		margin: 0rpx 30rpx;
		display: flex;
		justify-content: flex-start;
		align-items: center;

		.deeps {
			font-weight: 800;
			font-size: 30rpx;
			margin-right: 10rpx;
		}

		.upper {
			color: #121327;
			margin-right: 10rpx;
			font-size: 24rpx;
		}

		.fall {
			color: #16A139;
			margin-right: 10rpx;
			font-size: 24rpx;
		}

		.rise {
			width: 17%;
			margin: 0 0 20rpx 20rpx;

			image {
				width: 100%;
				height: 10rpx;
			}

		}

		.below {
			width: 23%;
			margin: 0 20rpx 20rpx 0rpx;

			image {
				width: 100%;
				height: 10rpx;
			}

		}
	}

	.tupian {
		image {
			height: 200rpx;
			width: 100%;
			border-radius: 20rpx;
		}

		margin:30rpx;
		background: #fff;
	}

	.headline {
		margin: 6rpx 30rpx;
		border-radius: 20rpx;
		background: #fef4db;
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 6rpx 20rpx;

		image {
			width: 80rpx;
			height: 30rpx;
		}
	}

	//去掉选项卡下面的滚动条  (仅pc端会出现)
	/deep/.u-tabs ::-webkit-scrollbar {
		width: 0;
		height: 0;
		color: transparent;
		// display: none;
	}

	.finance-economics {
		padding: 30rpx 30rpx;
		// margin: 0 0 30rpx;
		
		.important-news {
			display: flex;
			justify-content: space-between;
			align-items: center;
			border-bottom: 2rpx solid #ececec;
			padding: 20rpx 0;

			image {
				width: 200rpx !important;
				height: 120rpx !important;
				margin: 0 20rpx;
			}

			h3 {
				font-size: 26rpx;
				color: #333;
				// width: 68%;
			}

			.time {
				color: #999;
				margin-top: 10rpx;
				font-size: 24rpx;
			}
		}

		.important {
			border-bottom: 4rpx solid #ececec;
			padding:20rpx 0;
			font-size: 28rpx;
			// background-color: #bee0ff;
			background: rgba(138, 130, 231, 0.3);
			border-radius: 10rpx;
			padding-left: 10px;
			padding-right: 10px;	
			
			.time {
				color: #999;
				margin-top: 10rpx;
				font-size: 24rpx;
			}

		}
	}

	.up-and-down-list {
		.range {
			display: flex;
			justify-content: space-around;
			align-items: center;
			padding: 0 10rpx;

			.share-certificate {
				width: 30%;
				font-size: 28rpx;
			}

			.up-to-date {
				width: 60%;
				display: flex;
				justify-content: space-between;
				align-items: center;
				font-size: 28rpx;
			}
		}

		.shujuk {
			display: flex;
			justify-content: space-around;
			align-items: center;
			padding: 0 10rpx;

			.share-certificate {
				width: 30%;
				margin: 20rpx 0;

				h6 {
					color: #333;
					font-size: 28rpx;
					font-weight: 500;
				}

				.area {
					display: flex;
					justify-content: flex-start;
					align-items: center;
				}

				//深
				.deep {
					width: 30rpx;
					height: 30rpx;
					background: #3b4fde;
					border-radius: 0.4rpx;
					text-align: center;
					line-height: 30rpx;
					color: #fff;
					font-size: 24rpx;
					display: inline-block;
				}

				.deep-number {
					display: inline-block;
					padding: 0 0.04rem;
					background: rgba(59, 79, 222, .1);
					border-radius: 10rpx;
					color: #3b4fde;
					font-size: 24rpx;
					vertical-align: middle;
				}

				//北
				.north {
					width: 30rpx;
					height: 30rpx;
					background: #ea6248;
					border-radius: 0.4rpx;
					text-align: center;
					line-height: 30rpx;
					color: #fff;
					font-size: 24rpx;
					display: inline-block;
				}

				.north-number {
					display: inline-block;
					padding: 0 0.04rem;
					border-radius: 10rpx;
					font-size: 24rpx;
					vertical-align: middle;
					color: #ea6248;
					background: rgba(234, 98, 72, .1);
				}

				//沪
				.shanghai {
					width: 30rpx;
					height: 30rpx;
					background: #aa3bde;
					border-radius: 0.4rpx;
					text-align: center;
					line-height: 30rpx;
					color: #fff;
					font-size: 24rpx;
					display: inline-block;
				}

				.shanghai-number {
					display: inline-block;
					padding: 0 0.04rem;
					border-radius: 10rpx;
					font-size: 24rpx;
					vertical-align: middle;
					color: #aa3bde;
					background: rgba(170, 59, 222, .1);
				}
			}

			.up-to-date {
				width: 60%;
				display: flex;
				justify-content: space-between;
				align-items: center;
				color: #16A139;
				font-size: 28rpx;

				.current_price {
					text-align: left;
					width: 33%;
				}

				.rate {
					text-align: left;
					width: 33%;
				}


				.forehead {
					// background: #09965f;
					display: inline-block;
					width: 100rpx;
					height: 50rpxx;
					line-height: 50rpx;
					border-radius: 10rpx;
					color: #000;
					text-align: right;
				}
			}
		}

	}

	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 80rpx;
				background-image: linear-gradient(to right, #FFB044, #FF2D30);

		.account {
			display: flex;
			justify-content: space-between;
			align-items: center;
			text-align: center;

			image {
				width: 20rpx;
				height: 40rpx;

			}

			.college-text {
				// width: 97%;
				color: #fff;
				font-weight: 800;
				font-size: 36rpx;
			}
		}
	}

	.tile {
		color: #333;
		font-size: 30rpx;
		font-weight: 500;
		margin: 10rpx 20rpx;
		font-weight: 700;
	}

	.boxk {
		color: rgb(153, 153, 153);
		margin: 0px 20rpx;
		font-size: 24rpx;
	}

	.stock-fund {
		margin: 20rpx 20rpx;
		background-color: rgb(255, 255, 255);
		padding: 40rpx 20rpx;
		display: inline-block;
		white-space: nowrap;
		margin-right: 50rpx;
	}

	.information {
		display: flex;
		justify-content: space-between;
		align-items: center;

		.help {
			display: flex;
			justify-content: space-between;
			align-items: center;

			view {
				font-weight: bold;
			}

			image {
				width: 30rpx;
				height: 30rpx;
				margin-right: 10rpx;
				margin-bottom: 6px;
			}
		}

		.detailed {
			display: flex;
			justify-content: space-between;
			align-items: center;

			image {
				width: 15rpx;
				height: 30rpx;
				margin-left: 10rpx;
			}
		}
	}

	.increase {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin: 20rpx 0;
		padding-right: 20rpx;
		.help {
			display: flex;
			justify-content: space-between;
			align-items: center;

			view {
				font-weight: bold;
				color: #16A139;
				font-size: 28rpx;
			}

			image {
				width: 36rpx;
				height: 36rpx;
				margin-right: 10rpx;
			}
		}

		.detailed {
			image {
				width: 15rpx;
				height: 30rpx;
				margin-left: 10rpx;
			}
		}
	}

	.last {
		display: flex;
		justify-content: space-between;
		align-items: center;

		.help {
			color: #999999;
			font-size: 24rpx;
		}

		.detailed {
			color: #999999;
			font-size: 24rpx;
		}
	}
</style>