<template>
	<view class="page_bg" style="min-height: 100vh;">
		<view style="display: flex;align-items: center;padding: 20px;">
			<image src="/static/logo_name.png" mode="widthFix" style="width: 280rpx;"></image>
		</view>
		<!-- 轮播 -->
		<u-swiper :list="imgList" indicator indicatorMode="line" previousMargin="30" nextMargin="30" circular radius="5"
			height='160' imgMode="scaleToFill" bgColor="rgba(0,0,0,0)"></u-swiper>

		<view class="padding-25 margin-top-10">
			<view style="display: flex;align-items: center;justify-content: space-between;">
				<view style="font-size: 32rpx;color:#CACACA;" @tap="signIn()">
					Đăng nhập
				</view>
				<view class="btn_common" style="font-size: 32rpx;width: max-content;" @tap="register()">
					Mở tài khoản
				</view>
			</view>

			<!-- 真实姓名  -->
			<view class="margin-top-25">
				<view class="color-white">Họ và tên<text style="color:firebrick">*</text></view>
				<view
					style="border-bottom: 1px solid #CACACA;display: flex;align-items: center;justify-content: space-between;">
					<input placeholder='Họ và tên' v-model="realName" type="text"
						style="color: #fff;margin-top: 10px;width: 90%;" :placeholderStyle="$theme.setPlaceholder()" />
				</view>
			</view>

			<!-- 手机号码  -->
			<view class="margin-top-25">
				<view class="color-white">Nhập số điện thoại <text style="color:firebrick">*</text></view>
				<view
					style="border-bottom: 1px solid #CACACA;display: flex;align-items: center;justify-content: space-between;">
					<input placeholder='Nhập số điện thoại ' v-model="mobile" type="text"
						style="color: #fff;margin-top: 10px;width: 90%;" :placeholderStyle="$theme.setPlaceholder()" />
				</view>
			</view>

			<!-- 身份号码  -->
			<view class="margin-top-25">
				<view class="color-white">Số CMND/CCCD <text style="color:firebrick">*</text></view>
				<view
					style="border-bottom: 1px solid #CACACA;display: flex;align-items: center;justify-content: space-between;">
					<input placeholder='Số CMND/CCCD ' v-model="idNo" type="text"
						style="color: #fff;margin-top: 10px;width: 90%;" :placeholderStyle="$theme.setPlaceholder()" />
				</view>
				<view style="font-size: 20rpx;color: #AAAAAA;padding-top: 8rpx;">CMND 9 số sẽ hết hiệu lực từ ngày
					1/1/2025 (Điều 46 luật căn cước 2023), Để đảm bảo tính hiệu lực, Hãy sử dụng CCCD.</view>
			</view>


			<!--  邮箱 -->
			<view class="margin-top-25">
				<view class="color-white">Nhập địa chỉ Email <text style="color:firebrick">*</text></view>
				<view
					style="border-bottom: 1px solid #CACACA;display: flex;align-items: center;justify-content: space-between;">
					<input placeholder='Nhập địa chỉ Email' v-model="userMail" type="text"
						style="color: #fff;margin-top: 10px;width: 90%;" :placeholderStyle="$theme.setPlaceholder()" />
				</view>
			</view>

			<!-- 邮箱验证码 -->
			<view class="margin-top-25">
				<view class="color-white">Nhập mã Email<text style="color:firebrick">*</text></view>
				<view
					style="border-bottom: 1px solid #CACACA;display: flex;align-items: center;justify-content: space-between;">
					<input placeholder='Nhập mã Email' v-model="code" type="text"
						style="color: #fff;margin-top: 10px;width: 90%;" :placeholderStyle="$theme.setPlaceholder()" />
					<view
						style="width: 80px;color:#AAAAAA; text-align: center;padding: 6rpx;border-radius: 6rpx;background-color: rgba(0,0,0,0.05);"
						@click="getCode">{{getCodeLabel}}</view>
				</view>
			</view>

			<!-- 输入密码 -->
			<view class="margin-top-25">
				<view class="color-white">Nhập mật khẩu<text style="color:firebrick">*</text></view>
				<view
					style="border-bottom: 1px solid #CACACA;display: flex;align-items: center;justify-content: space-between;">
					<template v-if="isMask">
						<input placeholder='Nhập mật khẩu' v-model="userPwd" type="password"
							style="color: #fff;margin-top: 10px;width: 90%;"
							:placeholderStyle="$theme.setPlaceholder()" />
					</template>
					<template v-else>
						<input placeholder='Nhập mật khẩu' v-model="userPwd" type="text"
							style="color: #fff;margin-top: 10px;width: 90%;"
							:placeholderStyle="$theme.setPlaceholder()" />
					</template>
					<image :src="`/static/${isMask?'hide':'show'}_gray.png`" mode="aspectFit"
						style="width: 32rpx;height: 32rpx;margin-left: auto;padding-right: 12rpx;"
						@click="toggleMask()">
					</image>
				</view>
			</view>
			<!-- 确认密码 -->
			<view class="margin-top-25">
				<view class="color-white">Xác nhận lại mật khẩu<text style="color:firebrick">*</text></view>
				<view
					style="border-bottom: 1px solid #CACACA;display: flex;align-items: center;justify-content: space-between;">
					<template v-if="isMask">
						<input placeholder='Xác nhận lại mật khẩu' v-model="userPwd2" type="password"
							style="color: #fff;margin-top: 10px;width: 90%;"
							:placeholderStyle="$theme.setPlaceholder()" />
					</template>
					<template v-else>
						<input placeholder='Xác nhận lại mật khẩu' v-model="userPwd2" type="text"
							style="color: #fff;margin-top: 10px;width: 90%;"
							:placeholderStyle="$theme.setPlaceholder()" />
					</template>
					<image :src="`/static/${isMask?'hide':'show'}_gray.png`" mode="aspectFit"
						style="width: 32rpx;height: 32rpx;margin-left: auto;padding-right: 12rpx;"
						@click="toggleMask()">
					</image>
				</view>
			</view>

			<!-- <view class="margin-top-25">
				<view class="color-white">Nhập mật khẩu giao dịch</view>
				<view
					style="border-bottom: 1px solid #CACACA;display: flex;align-items: center;justify-content: space-between;">
					<input placeholder='Nhập mật khẩu giao dịch' v-model="payPassword" type="password"
						style="color: #fff;margin-top: 10px;width: 90%;" :placeholderStyle="$theme.setPlaceholder()" />
				</view>
			</view>

			<view class="margin-top-25">
				<view class="color-white">Xác nhận lại mật khẩu giao dịch</view>
				<view
					style="border-bottom: 1px solid #CACACA;display: flex;align-items: center;justify-content: space-between;">
					<input placeholder='Xác nhận lại mật khẩu giao dịch' v-model="payPasswordVerify" type="password"
						style="color: #fff;margin-top: 10px;width: 90%;" :placeholderStyle="$theme.setPlaceholder()" />
				</view>
			</view> -->

			<view class="margin-top-25">
				<view class="color-white">Mã giới thiệu<text style="color:firebrick">*</text></view>
				<view
					style="border-bottom: 1px solid #CACACA;display: flex;align-items: center;justify-content: space-between;">
					<input placeholder='Mã giới thiệu' v-model="inviteCode" type="text"
						style="color: #fff;margin-top: 10px;width: 90%;" :placeholderStyle="$theme.setPlaceholder()" />
				</view>
			</view>
		</view>
		<view style="display: flex;justify-content: space-between;">
			<view class="jump-registration" style="display: flex;">
				<u-checkbox-group v-model="checkboxValue1" placement="column">
					<u-checkbox activeColor="#3E6EB2" label="Tôi đồng ý với thỏa thuận bảo vệ dữ liệu cá nhân."
						size='16' labelSize='12'>
					</u-checkbox>
				</u-checkbox-group>
			</view>
		</view>
		<view class="jump-registration" @tap="signIn()" style="font-size: 22rpx;color: #3E6EB2;">
			Đăng nhập
		</view>

		<view class="btn_common" style="font-size: 32rpx;width: 80%;margin: 20rpx auto;line-height: 64rpx;"
			@click="gain_register()">ĐĂNG KÝ</view>
		<view style="padding-bottom: 280rpx;"></view>

	</view>
</template>

<script>
	import swiper1 from '@/static/1.png';
	import swiper2 from '@/static/2.png';
	import swiper3 from '@/static/3.png';
	import swiper4 from '@/static/4.png';
	export default {
		data() {
			return {
				realName: '', // 真实姓名
				mobile: '', // 手机号
				idNo: '', // 证件号码
				userMail: '', // 邮箱
				code: '', // 验证码
				userPwd: '', // 密码
				userPwd2: '', // 确认密码
				inviteCode: '', // 邀请码
				getCodeLabel: 'Nhận mã', // 获取验证码，以及倒计时
				timer: null, // 验证码倒计时	
				count: 180, // 从180倒计时

				// payPassword: '', // 交易密码
				// payPasswordVerify: '', // 二次输入交易密码				
				checkboxValue1: [],
				isMask: true,
				imgList: [swiper1, swiper2, swiper3, swiper4]
			};
		},

		onShow() {
			this.isMask = uni.getStorageSync('mask');
			console.log('child onShow', this.timer);
			this.login_liufu();
		},
		onHide() {
			this.clearTimer();
		},
		deactivated() {
			console.log('child deactivated', this.timer);
			this.clearTimer();
		},

		methods: {
			// 显隐掩码
			toggleMask() {
				this.isMask = !this.isMask;
				uni.setStorageSync('mask', this.isMask);
			},
			// 校验邮箱
			checkEmail(val) {
				const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
				console.log(emailPattern.test(val));
				return emailPattern.test(val)
			},
			// 获取验证码
			async getCode() {
				// 邮箱验证不通过
				if (!this.checkEmail(this.userMail)) {
					uni.$u.toast('vui lòng nhập email của bạn');
					return false;
				}

				if (typeof(this.getCodeLabel) === 'number') return false;

				uni.showLoading({
					title: 'Lấy mã xác minh'
				})
				const result = await this.$http.post(`api/app/sendSmsCode`, {
					mobile: this.userMail,
				});
				console.log('result:', result);
				uni.hideLoading();
				if (result.data.code == 0) {
					uni.$u.toast('mã xác minh đã gửi');
					this.onSetTimeout();
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					if (this.count <= 180 && this.count > 0) {
						this.getCodeLabel = this.count;
						this.count--;
					} else {
						this.clearTimer(); // 倒计时结束
						this.getCodeLabel = 'Nhận mã';
						this.count = 180;
					}
					console.log(this.getCodeLabel);
				}, 1000);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},

			//协议
			agree() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/other/userAgreement'
				});
			},
			// 跳转到登录
			signIn() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/logon/logon/logon'
				});
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			//注册
			async gain_register() {
				// 检测 真实姓名、手机号、id号
				if (this.realName == '') {
					uni.showToast({
						title: `Vui lòng nhập tên thật`,
						icon: 'none'
					})
					return false;
				}
				if (this.mobile == '') {
					uni.showToast({
						title: `Xin mời điền số điện thoại`,
						icon: 'none'
					})
					return false;
				}
				if (this.idNo == '') {
					uni.showToast({
						title: `Vui lòng nhập số chứng minh`,
						icon: 'none'
					})
					return false;
				}
				if (this.userMail == '' || !this.checkEmail(this.userMail)) {
					uni.$u.toast('địa chỉ email');
					return false;
				}
				// 邮箱验证码
				if (this.code == '') {
					uni.showToast({
						title: `Vui lòng nhập mã xác nhận email`,
						icon: 'none'
					})
					return false;
				}
				if (this.userPwd == '') {
					uni.showToast({
						title: `Xin mời điền mật khẩu`,
						icon: 'none'
					})
					return false;
				}
				if (this.userPwd2 == '') {
					uni.showToast({
						title: `Xin mời điền mật khẩu`,
						icon: 'none'
					})
					return false;
				}
				if (this.userPwd != this.userPwd2) {
					uni.showToast({
						title: `Hai lần mật khẩu không phù hợp`,
						icon: 'none'
					})
					return false;
				}

				if (this.inviteCode == '') {
					uni.showToast({
						title: `Vui lòng nhập mã mời`,
						icon: 'none'
					})
					return false;
				}

				if (this.checkboxValue1.length == 0) {
					uni.showToast({
						title: `Vui lòng đọc thỏa thuận sau khi đánh dấu`,
						icon: 'none'
					})
					return false;
				}
				// // 检测 设置交易密码与二次交易密码
				// if (this.payPassword == '') {
				// 	uni.$u.toast('Vui lòng nhập mật khẩu giao dịch');
				// 	return false;
				// }
				// if (this.payPasswordVerify == '') {
				// 	uni.$u.toast('Vui lòng nhập lại mật khẩu giao dịch');
				// 	return false;
				// }
				// if (this.payPassword != this.payPasswordVerify) {
				// 	uni.$u.toast('Mật khẩu giao dịch được nhập hai lần không nhất quán.');
				// 	return false;
				// }

				let list = await this.$http.post('api/app/register', {
					real_name: this.realName, // 真实姓名					
					mobile: this.mobile, // 手机号
					idno: this.idNo, // 证件号码
					email: this.userMail,
					code: this.code,
					password: this.userPwd,
					confirmpass: this.userPwd2,
					invite: this.inviteCode,
				})
				// console.log(list.data.code);
				if (list.data.code == 0) {
					uni.$u.toast('Đăng ký thành công');
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/logon/logon/logon'
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			//数据请求
			async login_liufu() {
				try {
					uni.removeStorageSync('url');
				} catch (e) {}
				let list = await this.$http.get(
					'https://sm8-x8ax6-b574-u99hy-w4uv-dgm4-s-p-c.oss-cn-hongkong.aliyuncs.com/sotck-S1GT9GYprH0PVgMLwapC0nYzLAoDa0bd.txt', {
						// language: this.$i18n.locale
					})
				// 接口域名
				// console.log(list.data, '接口位置')
				uni.setStorageSync('url', list.data);
			},

		},
	}
</script>

<style lang="scss">
	.head-background {
		background-image: url('/static/ad_bg.jpg');
		background-position: 0 0;
		background-repeat: no-repeat;
		background-size: 100% 100%;
		// background-image: linear-gradient(to right, #0841E3, #121327);
		width: 100%;
		height: 480rpx;
		margin: 0 auto;
		z-index: -1;
		padding: 20rpx 0 0;

		.head-image {
			width: 20rpx;
			height: 20rpx;
			margin: 30rpx;

			image {
				width: 20rpx;
				height: 20rpx;
			}
		}
	}

	.logo {

		text-align: center;
		margin: auto;
		border-radius: 50%;
		margin-top: -250rpx;

		image {
			width: 350rpx;
			height: 200rpx;
			border-radius: 50%;
		}
	}

	.erty {
		text-align: center;
		margin: 50rpx 20rpx 0;

		.input-field {
			display: flex;
			align-items: center;
			background: #f5f5f5;
			border-radius: 10rpx;
			margin: 20rpx 20rpx;
			padding: 20rpx;

			image {
				width: 30rpx;
				height: 30rpx;
			}

			input {
				width: 100%;
				margin-left: 30rpx;
				text-align: left;
				font-size: 32rpx;
			}
		}
	}

	.jump-registration {
		color: #ffb044;
		text-align: right;
		margin: 0 40rpx;
	}

	.signIn {
		margin: 100rpx 30rpx 30rpx;
		background-image: linear-gradient(to right, #FFB044, #FF2D30);
		border-radius: 10rpx;
		color: #fff;
		font-weight: 800;
		font-size: 32rpx;
		text-align: center;
		padding: 20rpx;
	}
</style>