<template>
	<view>
		<view class="flex flex-b padding-20 padding-top-20" style="padding-top: 48rpx;color: #fff;padding-bottom: 0;">
			<image src="/static/logo_name.png" mode="widthFix" style="width: 130px;height: 70px;"></image>
			<image src="/static/search.png" mode="widthFix" style="width: 20px;height: 20px;"
				@click="$u.route({url:'/pages/searchFor/searchFor'});"></image>
		</view>

		<!-- <view class="flex flex-wrap  margin-10 gap10">
			<view style="background-color: #333333;padding: 20px;flex: 1 0 10%;" class="radius10 text-center"
				v-for="(item,index) in list_zhishu">
				<view :class="item.rate<0?'red':'green'" class="font-size-18">{{toThousandFilter1(item.current_price)}}
				</view>
				<view class="flex gap5 font-size-12 justify-center">
					<view class="color-white">{{item.name}} </view>
					<view :class="item.rate<0?'red':'green'">
						{{item.rate_num?item.rate_num:'--'}}({{item.rate?item.rate:'--'}}%)
					</view>
				</view>
			</view>
		</view> -->
		<view class="padding-10" style="margin:24rpx 0;background-image: url(/static/top_bg.png);
		background-repeat: no-repeat;background-position: 0 0;background-size: 100% 100%; ">
			<!-- <image src="/static/banner.jpg" style="width: 100%;border-radius: 10px;" mode="widthFix"></image> -->
			<scroll-view :scroll-x="true" style="white-space: nowrap;padding: 0 10px 0 10px;" @touchmove.stop>
				<block v-for="(item,index) in list_zhishu" :key="index">
					<view
						style="width: 240rpx;display: inline-block; padding:10px;margin-right: 20px;border-radius: 12rpx;background-color: #333333;">
						<view style="color:#fff;">{{item.name}}</view>
						<image :src="`/static/line_${item.rate>0?'rise':'fall'}.png`" mode="aspectFit"
							style="width: 210rpx;height: 72rpx;"></image>
						<view style="font-size: 28rpx;" :style="$theme.setStockRiseFall(item.rate>0)">
							{{item.current_price}}
						</view>
						<view style="font-size: 24rpx;" :style="$theme.setStockRiseFall(item.rate>0)">
							{{item.rate_num}} ({{item.rate}}%)
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;padding-top: 16rpx;">
							<view style="border-radius: 12rpx;background-color: #FF606A;width: 30%;height: 6rpx;">
							</view>
							<view
								style="border-radius: 12rpx;background-color: #FDD355;width: 20%;height: 6rpx;margin:0 6rpx;">
							</view>
							<view style="border-radius: 12rpx;background-color: #1AC5A8;width: 50%;height: 6rpx;">
							</view>
						</view>
					</view>
				</block>
			</scroll-view>
		</view>

		<view style="display: flex;align-items: center;justify-content: space-between;padding:24rpx 36rpx;">
			<block v-for="(item,index) in tabs" :key="index">
				<view :class="top_index==index?'tops_select':'tops'" @click="top_click(index)">{{item}}</view>
			</block>
		</view>

		<view class="up-and-down-list" style="color: #fff;">
			<view class="range">
				<view class="share-certificate">Mã CK</view>
				<view class="up-to-date">
					<view>Giá TT</view>
					<view>+/-%</view>
					<view>Tỷ lệ</view>
				</view>
			</view>
			<view class="shujuk text-center" v-for="(item,index) in list_data" :key="index"
				@tap="productDetails(item.sym)">
				<view class="share-certificate">
					<h6>{{item.name}}</h6>

				</view>
				<view class="up-to-date">
					<view class="current_price" :style="$theme.setStockRiseFall(item.rate>0)">
						{{toThousandFilter(item.current_price)}}
					</view>
					<view class="rate text-center" :style="$theme.setStockRiseFall(item.rate>0)">{{item.rate}}%
					</view>
					<view class="forehead" :style="$theme.setStockRiseFall(item.rate>0)">{{(item.rate_num*1)}}
					</view>
				</view>
			</view>
		</view>
	</view>

	</view>
</template>

<script>
	export default {

		data() {
			return {
				//是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				closeOnClickOverlay: false,
				Inv: 0,
				current: 0,
				list: ['VN30', 'VNI', 'HNX', 'UPC'],
				six: '',
				rise: '',
				fall: '',
				exchange: '',
				status: 'loadmore',
				pager: {
					page: 1,
					limit: 20
				},
				timerId: null,
				list_data: [],
				list_zhishu: [],
				codes: [],

				top_index: 0
			}
		},

		computed: {
			tabs() {
				return [`HOSE`, `VN30`, `HNX`, `HNX30`, `UPCOM`]
			}
		},

		mounted() {
			// this.marketQuotations()
			// this.topSix()
			this.versionUpdate()
			this.is_token()

		},
		onShow() {
			if (!this.$util.checkToken()) return false;
			this.marketQuotations();
			this.versionUpdate();
			this.is_token();
		},

		onUnload() {
			console.log('行情结束1');
			uni.closeSocket({

			})
			// clearInterval(this.timerId);
		},
		onHide() {
			console.log('行情结束2');
			uni.closeSocket({

			})
			// clearInterval(this.timerId);
		},
		onReachBottom() {
			this.status = 'loading';
			// this.pager.page++;
			// this.marketQuotations()
		},
		//下拉刷新
		onPullDownRefresh() {

			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.dataUpdate()
			uni.stopPullDownRefresh()
		},



		methods: {
			toThousandFilter1(num) {
				return (+num || 0).toFixed(2).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			//搜索
			searchFor() {
				uni.navigateTo({
					url: '/pages/searchFor/searchFor'
				});
			},


			//产品详情
			productDetails(gid) {
				uni.navigateTo({
					url: '/pages/marketQuotations/productDetails' +
						`?gid=${gid}`
				});
			},
			top_click(index) {
				this.top_index = index
				this.marketQuotations()
			},
			//前6
			async topSix() {
				let list = await this.$http.get('api/goods/updownlistsix', {})
				this.six = list.data.data.zhang
				// console.log(this.six, '六');
			},
			//涨跌
			hose_type(top_index){
				if(top_index==0){
					 return 'hose'; 
				}else if(top_index==1){
					return 'VN30'; 
				}else if(top_index==2){
					 return 'hnx';
				}else if(top_index==3){
					 return 'HNX30'; 
				}else if(top_index==4){
					  return 'upcom';
				}
				return null;
			},
			async marketQuotations() {
				 const marketType = this.hose_type(this.top_index);
				let list = await this.$http.get('api/goods/updownlist', {
					page: this.pager.page,
					limit: this.pager.limit,
					top_index: this.top_index,
					 type: marketType
				})
				// if(this.pager.page>1){
				// 	this.list_data.push(list.data.goods)
				// 	this.codes=[...this.codes,...list.data.codes]
				// }else{

				// 应客户需求， 此处改为只显示前30条数据 /by 2024.06.06
				if (list && list.data && list.data.goods) {
					console.log("指数", list.data.goods);
					const temp = Object.values(list.data.goods);
					console.log("指数", temp);
					if (temp.length <= 0) {
						this.list_data = [];
					} else {
						this.list_data = temp.length <= 30 ? temp : temp.slice(0, 30);
					}
				}


				// this.list_data = list.data.goods
				this.list_zhishu = list.data.zhishu
				this.codes = list.data.codes
				// }
				console.log("指数", list.data.goods);
				this.socket()
				//涨
				// if (this.pager.page > 1) {
				// 	this.rise = [...this.rise, ...list.data.data.zhang]
				// } else {
				// 	this.rise = list.data.data.zhang
				// }
				// if (list.data.data.zhang.length < this.pager.limit) {
				// 	this.status = 'nomore'
				// }
				// //跌		
				// if (this.pager.page > 1) {
				// 	this.fall = [...this.fall, ...list.data.data.die]
				// } else {
				// 	this.fall = list.data.data.die
				// }
				// if (list.data.data.die.length < this.pager.limit) {
				// 	this.status = 'nomore'
				// }
				// //上证指数
				// this.exchange = list.data.data.zhishu
				// console.log(this.exchange, '上涨指数');
				//大于后端刷新
			},
			socket() {
				var that = this;
				uni.onSocketClose(function(res) {
					console.log('WebSocket 已关闭！');
				});

				uni.connectSocket({
					url: this.$http.WsUrl,
					success(res) {
						console.log("连接成功");
					},
					fail() {
						console.log("连接失败");
					}
				});
				console.log("codes", that.codes.join(","))
				uni.onSocketOpen(function(res) {
					console.log('WebSocket连接已打开！');
					uni.sendSocketMessage({
						data: that.codes.join(",")
					});

				});
				uni.onSocketMessage(function(res) {
					// console.log('收到服务器内容：' + );
					var arr = JSON.parse(res.data);
					// console.log('收到服务器内容：' + arr);
					if (arr[0] == "VNINDEX" && arr[0] && arr[19]) {
						// console.log('收到服务器内容：' + arr[19]);
						that.list_zhishu[0].current_price = arr[1]
						that.list_zhishu[0].rate = arr[19]
					} else if (arr[0] == "VN30" && arr[1] && arr[19]) {
						// console.log('收到服务器内容：' + arr[19]);
						that.list_zhishu[1].current_price = arr[1]
						that.list_zhishu[1].rate = arr[19]
					} else if (arr[0] == "HNXIndex" && arr[2] && arr[19]) {
						// console.log('收到服务器内容：' + arr[19]);
						that.list_zhishu[2].current_price = arr[1]
						that.list_zhishu[2].rate = arr[19]
					} else if (arr[0] == "HNXUpcomIndex" && arr[3] && arr[19]) {
						// console.log('收到服务器内容：' + arr[19]);
						that.list_zhishu[3].current_price = arr[1]
						that.list_zhishu[3].rate = arr[19]
					} else {

						if (arr[41] * 1 > 0 && that.list_data[arr[0]]) {
							// console.log('goods：' + arr[52]);
							that.list_data[arr[0]]['current_price'] = arr[41]
							that.list_data[arr[0]]['rate'] = arr[52]
						}

					}
				});
				uni.onSocketError(function(res) {
					console.log('WebSocket连接打开失败，请检查！');
					uni.showToast({
						icon: 'none',
						title: 'Mạng chậm'
					})
				});
			},
			removeDuplicateObj(arr) {
				let obj = {}
				arr = arr.reduce((newArr, next) => {
					obj[next.gid ?? next.sn] ?
						'' :
						(obj[next.gid ?? next.gid] = true && newArr.push(next))
					return newArr
				}, [])
				return arr
			},

			async dataUpdate() {
				let list = await this.$http.get('api/goods/updownlist', {
					page: 1,
					limit: 100,
				})
				//涨
				this.rise = this.removeDuplicateObj([...this.rise, ...list.data.data.zhang])
				//跌		
				this.fall = this.removeDuplicateObj([...this.fall, ...list.data.data.die])
				//上证指数 
				this.exchange = list.data.data.zhishu
				// console.log(this.exchange, '上涨指数');
				//大于后端刷新
			},

			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			async versionUpdate() {
				let list = await this.$http.get('api/version/detail', {})
				this.update = list.data.data
				let version = list.data.data.version
				let old_version = uni.getStorageSync('version') || 1.0
				// console.log(old_version, '当前版本111111111111111');
				if (old_version < version) {
					this.updateFlag = true
					this.$refs.update.upgrade()
					uni.setStorageSync('version', version)
				}
				// console.log(list.data.data, '版本更新');
			},

		},
	}
</script>

<style lang="scss">
	.tops_select {
		background-image: linear-gradient(90deg, #3E6EB2, #26397B);
		padding: 6px 12rpx;
		border-radius: 5px;
		font-size: 16px;
		color: #FFF;
	}

	.tops {
		border: 1px #3E6EB2 solid;
		padding: 6px 12rpx;
		border-radius: 5px;
		font-size: 16px;
		color: #3E6EB2;
	}



	//涨跌榜
	.up-and-down-list {
		.range {
			display: flex;
			justify-content: space-around;
			align-items: center;
			padding: 0 20rpx;
			font-weight: 700;

			.share-certificate {
				width: 30%;
				font-size: 28rpx;
			}

			.up-to-date {
				width: 60%;
				display: flex;
				justify-content: space-between;
				align-items: center;
				font-size: 28rpx;
			}
		}

		.shujuk {
			display: flex;
			justify-content: space-around;
			align-items: center;
			padding: 0 30rpx;
			color: #fff;

			.share-certificate {
				width: 30%;
				margin: 20rpx 0;
				color: #fff;

				h6 {
					color: #fff;
					font-size: 28rpx;
					font-weight: 500;
					text-align: left;
				}

				.area {
					display: flex;
					justify-content: flex-start;
					align-items: center;
				}

				//深
				.deep {
					width: 30rpx;
					height: 30rpx;
					background: #3b4fde;
					border-radius: 0.4rpx;
					text-align: center;
					line-height: 30rpx;
					color: #fff;
					font-size: 24rpx;
					display: inline-block;
				}

				.deep-number {
					display: inline-block;
					padding: 0 0.04rem;
					background: rgba(59, 79, 222, .1);
					border-radius: 10rpx;
					color: #3b4fde;
					font-size: 24rpx;
					vertical-align: middle;
				}

				//北
				.north {
					width: 30rpx;
					height: 30rpx;
					background: #ea6248;
					border-radius: 0.4rpx;
					text-align: center;
					line-height: 30rpx;
					color: #fff;
					font-size: 24rpx;
					display: inline-block;
				}

				.north-number {
					display: inline-block;
					padding: 0 0.04rem;
					border-radius: 10rpx;
					font-size: 24rpx;
					vertical-align: middle;
					color: #ea6248;
					background: rgba(234, 98, 72, .1);
				}

				//沪
				.shanghai {
					width: 30rpx;
					height: 30rpx;
					background: #aa3bde;
					border-radius: 0.4rpx;
					text-align: center;
					line-height: 30rpx;
					color: #fff;
					font-size: 24rpx;
					display: inline-block;
				}

				.shanghai-number {
					display: inline-block;
					padding: 0 0.04rem;
					border-radius: 10rpx;
					font-size: 24rpx;
					vertical-align: middle;
					color: #aa3bde;
					background: rgba(170, 59, 222, .1);
				}
			}

			.up-to-date {
				width: 60%;
				display: flex;
				justify-content: space-between;
				align-items: center;
				color: #1cdd49;
				font-size: 28rpx;

				.current_price {
					text-align: left;
					width: 33%;
				}

				.rate {
					text-align: center;
					width: 33%;
				}


				.forehead {
					// background: #09965f;
					display: inline-block;
					width: 100rpx;
					height: 50rpxx;
					line-height: 50rpx;
					border-radius: 10rpx;
					color: #000;
					text-align: right;
				}
			}
		}
	}
</style>