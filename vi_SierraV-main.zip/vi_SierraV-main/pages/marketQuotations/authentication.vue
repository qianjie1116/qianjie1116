<template>
	<view style="">
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 24rpx;height: 24rpx;" @tap="goBack()">
			</image>
			<view style="flex:1;text-align: center;color: #fff;font-size: 32rpx;font-weight: 500;">
				Xác thực thông tin
			</view>
		</view>

		<view style="padding:24rpx;font-size: 24rpx;color: #AAA;">Quý khách vui lòng thực hiện đầy đủ các bước theo
			hướng dẫn dưới đây để xác thực thông tin cá nhân </view>

		<view class="college-content" style="background-color: #242424;border-radius: 0;margin-top: 24rpx;">
			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Họ và Tên
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Họ và Tên</view>
			</view>
			<view class="input_wrapper">
				<input placeholder="Vui lòng nhập Họ và Tên" type="text" v-model="value1"
					:placeholderStyle="$theme.setPlaceholder()"></input>
			</view>

			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Số CCCD/CMND / Hộ chiếu
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Số CCCD/CMND / Hộ chiếu</view>
			</view>
			<view class="input_wrapper">
				<input placeholder="Vui lòng nhập số Căn cước công dân" type="text" v-model="value2"
					:placeholderStyle="$theme.setPlaceholder()"></input>
			</view>
		</view>

		<view style="display: flex;align-items: center;padding:24rpx;">
			<view style="flex:0 0 50%">
				<view style="font-size: 14px;font-weight: 800;color:#fff;">
					Mặt trước
				</view>
				<image :src="!obverseUrl?`/static/purchase/zheng.png`:obverseUrl" @click="selectImg('obverse')"
					mode="widthFix" style="margin: 10px 0;width:90%;height: auto;"></image>
			</view>

			<view style="flex:0 0 50%">
				<view style="font-size: 14px;font-weight: 800;color:#fff;">
					Mặt sau
				</view>
				<image :src="!reverseUrl?`/static/purchase/fan.png`:reverseUrl" @click="selectImg('reverse')"
					mode="widthFix" style="margin: 10px 0;width:90%;height: auto;"></image>
			</view>
		</view>

		<!-- 凭证 -->
		<view class="bold" style="color:#FFF;padding: 20px;">Chụp/ Tải ảnh chữ ký</view>
		<view style="display: flex;align-items: center;justify-content: center;background-color: #242424;border-radius: 12rpx;
			padding:12rpx;margin:12rpx 24rpx;">
			<image :src="!qianmingUrl?`/static/auth_name.png`:qianmingUrl" @click="selectImg('qianming')"
				mode="widthFix" style="margin: 10px 0;width:90%;height: auto;"></image>
		</view>

		<!-- 身份证 -->
		<view class="certification-content" style="background-color: transparent;">
			<view class="bottom-content" style="background-color: transparent;">
				<view class="">
					<view class="submit" v-if="userinfo.is_check!=1" @click="gain_aouonym()">Đăng ký</view>
					<view class="submit" v-if="userinfo.is_check==1">Đăng ký</view>
				</view>
			</view>
		</view>
		<!-- <view class="upload" style="margin-top: 30px;color: #fff;">Lưu ý khi tải căn cước công dân</view> -->
		<!-- <view class="notes-documents" style="margin-top: 30px;">
					<view class="careful">
						<view>
							<image src="../../static/purchase/biaozhun01.png" mode=""></image>
						</view>
						<view class="standard">
							<u-icon name="checkmark-circle-fill" color="#4db872"></u-icon>
							Tiêu chuẩn
						</view>
					</view>
					<view class="careful">
						<view>
							<image src="../../static/purchase/biaozhun02.png" mode=""></image>
						</view>
						<view class="standard">
							<u-icon name="close-circle-fill" color="#ee6560"></u-icon>
							Mất khung
						</view>
					</view>

					<view class="careful">
						<view>
							<image src="../../static/purchase/biaozhun03.png" mode=""></image>
						</view>
						<view class="standard">
							<u-icon name="close-circle-fill" color="#ee6560"></u-icon>
							Ảnh mờ
						</view>
					</view>

					<view class="careful">
						<view>
							<image src="../../static/purchase/biaozhun04.png" mode=""></image>
						</view>
						<view class="standard">
							<u-icon name="close-circle-fill" color="#ee6560"></u-icon>
							Chói sáng
						</view>
					</view>
				</view> -->
		<!-- </view> -->


		<!-- <view style="color: #AAA;padding:24rpx;font-size: 28rpx;line-height: 1.6;">
			<view style="line-height: 2.8;font-size: 28rpx;">Điều kiện tải lên</view>
			<view>1.Nội dung ảnh chụp chân thật, rõ nét, không được chỉnh sửa.</view>
			<view>2.Số CCCD và tên rõ ràng, hỗ trợ JPG/JPEG/PNG。</view>
			<view>3.CMND hoặc CCCD phải còn hạn ít nhất 6 tháng và không bị mờ số . Có thể
				sử dụng hình ảnh CMND hoặc CCCD để tải lên .</view>
			<view>4.Đảm bảo đường truyền tốt.</view>
		</view> -->
	</view>
</template>


<script>
	import md5 from 'js-md5'
	export default {

		data() {
			return {
				obverseUrl: '', // 正面
				reverseUrl: '', // 反面
				qianmingUrl: '', // 签名
				//
				value1: '',
				value2: '',
				userinfo: {},
				//倒计时
				second: Math.round(Math.random() * 6),
				timer: null,
			};
		},
		onShow() {
			if (!this.$util.checkToken()) return false;
			this.userInfo();
		},
		methods: {
			// 根据当前平台，执行回退方式
			goBack() {
				/*#ifdef APP-PLUS*/
				uni.navigateBack({
					delta: 1
				});
				/*#endif*/

				/*#ifdef H5*/
				history.back();
				/*#endif*/
			},

			// 点击上传
			async selectImg(name) {
				const result = await uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
				});
				console.log('result:', result);
				const imageFile = result[1].tempFiles[0];
				console.log('imageFile:', imageFile);

				if (name == "obverse") {
					this.upimg("obverse", imageFile.path)
				} else if (name == "reverse") {
					this.upimg("reverse", imageFile.path)
				} else if (name == "qianming") {
					this.upimg("qianming", imageFile.path)
				}
			},
			// 上传图片
			async upimg(type, tempFilePath) {
				uni.showLoading({
					title: "Đang gửi, vui lòng đợi..."
				})
				let Request = "Qwd3N5yp"
				let time = parseInt(new Date().getTime() / 1000)
				let str_url = ("/api/app/upload").toLowerCase()

				let mdd = md5("XPFXMedS" + Request + str_url + time);

				const result = await uni.uploadFile({
					url: this.$http.BaseUrl + '/api/app/upload?t=' + time + "&sign=" + mdd,
					filePath: tempFilePath,
					name: 'file',
				});

				console.log('result:', result);
				uni.hideLoading();
				if (result[1].statusCode == 200) {
					const temp = JSON.parse(result[1].data);
					console.log('temp:', temp);
					if (type == 'obverse') {
						this.obverseUrl = temp[0].url;
					} else if (type == "reverse") {
						this.reverseUrl = temp[0].url;
					} else if (type == "qianming") {
						this.qianmingUrl = temp[0].url;
					}
				}
			},

			// // 插件上传身份证
			// // 上传
			// async upimg(type, tempFilePath) {
			// 	uni.showLoading({
			// 		title: "Đang gửi, vui lòng đợi..."
			// 	})
			// 	let Request = "Qwd3N5yp"
			// 	let time = parseInt(new Date().getTime() / 1000)
			// 	let str_url = ("/api/app/upload").toLowerCase()


			// 	let mdd = md5("XPFXMedS" + Request + str_url + time)

			// 	uni.uploadFile({
			// 		url: this.$http.BaseUrl + '/api/app/upload?t=' + time + "&sign=" + mdd, // 仅为示例，非真实的接口地址
			// 		filePath: tempFilePath,
			// 		name: 'file',

			// 		success: (res) => {
			// 			uni.hideLoading()
			// 			var data = JSON.parse(res.data);
			// 			// this.is_url = res.data
			// 			console.log(1111, data)
			// 			if (type == 1) {
			// 				this.formData.obverseUrl = data[0].url;
			// 			} else {
			// 				this.formData.reverseUrl = data[0].url;

			// 			}

			// 		},
			// 		error: (res) => {
			// 			uni.hideLoading()
			// 			console.log(3333, res)
			// 		},
			// 	});
			// },

			// 认证
			async gain_aouonym() {
				uni.showLoading({
					title: "Đang gửi, vui lòng đợi...",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/user/real-auth1', {
					real_name: this.value1,
					idno: this.value2,
					front_image: this.obverseUrl,
					back_image: this.reverseUrl,
					qianming: this.qianmingUrl, // 签名
				})

				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/index/index'
						});
						uni.hideLoading();
					}, 1000)
				} else if (list.data.code == 1) {
					uni.$u.toast(list.data.message);

				}

			},
			async userInfo() {
				let userinfo = await this.$http.get('api/user/fastInfo', {})
				this.value1 = userinfo.data.data.real_name
				this.value2 = userinfo.data.data.idno
				this.userinfo = userinfo.data.data
				this.obverseUrl = userinfo.data.data.front_image
				this.reverseUrl = userinfo.data.data.back_image
				this.qianmingUrl = userinfo.data.data.qianming,
					// console.log(userinfo.data.data, '1111111111111');
					uni.hideLoading();
			},
		},
	};
</script>

<style lang="scss">
	/deep/.u-input {
		background: #f5f5f5;
		font-size: 28rpx;
	}

	/deep/ .uni-input-input {
		font-size: 30rpx;
	}

	.college-bg {
		padding: 48rpx 24rpx 24rpx 24rpx;
		background-color: #363636;
		margin-bottom: 24rpx;
		display: flex;
		align-items: center;
	}

	.college-content {
		margin: 30rpx 0;
		padding: 10rpx 30rpx;
	}

	.identity-card {
		margin: -50rpx auto 0;
		background: #fff;
		border-radius: 20rpx 20rpx 0 0;
		padding: 30rpx;


		.choice {
			color: #000;
			font-weight: 600;
			margin: 30rpx 0 10rpx;
			font-size: 28rpx;
		}

		input {
			background: #f5f5f5;
			padding: 20rpx;
			border-radius: 10rpx;
		}
	}

	.certification-content {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;



		.bottom-content {
			margin-top: 30rpx;
			background: #f9f9f9;
			width: 100%;
			height: 100%;

			.submit {
				text-align: center;
				background-image: linear-gradient(90deg, #3E6EB2, #26397B);
				color: #fdfdfd;
				padding: 20rpx 0;
				width: 92%;
				border-radius: 20rpx;
				margin: 30rpx;
			}

			.upload {
				margin: 30rpx;
				font-weight: 600;
				// font-size: 30rpx;
				font-size: 28rpx;
			}

			.ask {
				margin: 10rpx 30rpx;
				font-size: 28rpx;
			}

			.requirement {
				margin: 10rpx 30rpx;
				color: #8b8b8b;
				font-size: 28rpx;
			}

			.notes-documents {
				display: flex;
				justify-content: space-around;
				align-items: center;
				text-align: center;

				.careful {
					// width: 80%;
					height: 200rpx;

					image {
						width: 150rpx;
						height: 120rpx;
					}

					.standard {
						display: flex;
						justify-content: center;
						align-items: center;
						font-size: 28rpx;
						color: #8b8b8b;

						.u-icon {
							margin-right: 10rpx;
						}
					}
				}
			}
		}
	}
</style>