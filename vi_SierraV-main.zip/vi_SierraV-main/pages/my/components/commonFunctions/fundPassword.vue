<!-- 资金密码 -->
<template>
	<view>
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 24rpx;height: 24rpx;" @tap="goBack()">
			</image>
			<view style="flex:1;text-align: center;color: #fff;font-size: 32rpx;font-weight: 500;">Mật khẩu giao dịch
			</view>
		</view>
		<view class="college-content" style="background-color: #242424;border-radius: 0;margin-top: 24rpx;">
			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Vui lòng nhập mật khẩu cũ
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Vui lòng nhập mật khẩu cũ</view>
			</view>
			<view class="input_wrapper">
				<input placeholder="Vui lòng nhập mật khẩu cũ" maxlength="6" :password="isMask" v-model="value1"
					:placeholderStyle="$theme.setPlaceholder()"></input>
				<image :src="`/static/${isMask?'hide':'show'}_gray.png`" mode="aspectFit"
					style="width: 32rpx;height: 32rpx;margin-left: auto;padding-right: 12rpx;" @click="toggleMask()">
				</image>
			</view>

			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Vui lòng nhập mật khẩu
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Vui lòng nhập mật khẩu</view>
			</view>
			<view class="input_wrapper">
				<input placeholder="Vui lòng nhập mật khẩu" :password="isMask" maxlength="6" v-model="value2"
					:placeholderStyle="$theme.setPlaceholder()"></input>
				<image :src="`/static/${isMask?'hide':'show'}_gray.png`" mode="aspectFit"
					style="width: 32rpx;height: 32rpx;margin-left: auto;padding-right: 12rpx;" @click="toggleMask()">
				</image>
			</view>

			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Vui lòng nhập lại mật khẩu
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Vui lòng nhập lại mật khẩu</view>
			</view>
			<view class="input_wrapper">
				<input placeholder="Vui lòng nhập lại mật khẩu" :password="isMask" maxlength="6" v-model="value3"
					:placeholderStyle="$theme.setPlaceholder()"></input>
				<image :src="`/static/${isMask?'hide':'show'}_gray.png`" mode="aspectFit"
					style="width: 32rpx;height: 32rpx;margin-left: auto;padding-right: 12rpx;" @click="toggleMask()">
				</image>
			</view>
		</view>

		<view class="btn_common" style="font-size: 32rpx;width: 80%;margin: 20rpx auto;line-height: 64rpx;"
			@click="transactionPassword()">
			Xác nhận
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isMask: null,
				value1: '',
				value2: "",
				value3: "",
			};
		},
		onShow() {
			this.isMask = uni.getStorageSync('mask');
		},
		methods: {
			// 显隐掩码
			toggleMask() {
				this.isMask = !this.isMask;
				uni.setStorageSync('mask', this.isMask);
			},
			// 根据当前平台，执行回退方式
			goBack() {
				/*#ifdef APP-PLUS*/
				uni.navigateBack({
					delta: 1
				});
				/*#endif*/

				/*#ifdef H5*/
				history.back();
				/*#endif*/
			},
			//修改交易密码
			async transactionPassword() {
				if (this.value1 == '' || this.value2 == '' || this.value3 == '') {
					uni.showToast({
						title: `Vui lòng nhập mật khẩu`,
						icon: 'none'
					})
					return false;
				}

				let list = await this.$http.post('api/user/updatePayPassword', {
					oldpass: this.value1,
					newpass: this.value2,
					confirmpass: this.value3,
				})
				if (list.data.code == 0) {
					uni.$u.toast('Sửa đổi thành công');
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/my/my'
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
		}
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 48rpx 24rpx 24rpx 24rpx;
		background-color: #363636;
		margin-bottom: 24rpx;
		display: flex;
		align-items: center;
	}

	.college-content {
		margin-top: -30rpx;
		border-radius: 30rpx 30rpx 0 0;
		padding: 30rpx;

		.cipher {
			padding: 20rpx;
			margin: 30rpx 0;
			background: #f5f5f5;
			border-radius: 10rpx;

		}

	}

	/deep/.uni-input-placeholder {
		color: #C0C4CC;
		font-size: 28rpx;
	}

	.purchase {
		background-image: linear-gradient(to right, #FFB044, #FF2D30);
		margin: 60rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
	}
</style>