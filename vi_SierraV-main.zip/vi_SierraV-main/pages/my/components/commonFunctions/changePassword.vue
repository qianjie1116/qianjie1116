<!-- 修改登陆密码 -->
<template>
	<view>
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 24rpx;height: 24rpx;" @tap="goBack()">
			</image>
			<view style="flex:1;text-align: center;color: #fff;font-size: 32rpx;font-weight: 500;">Thay đổi mật khẩu
			</view>
		</view>
		<view class="college-content" style="background-color: #242424;border-radius: 0;margin-top: 24rpx;">
			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Vui lòng nhập mật khẩu cũ
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Vui lòng nhập mật khẩu cũ</view>
			</view>
			<view class="input_wrapper">
				<template v-if="isMask">
					<input placeholder="Vui lòng nhập mật khẩu cũ" type="password" v-model="value"
						:placeholderStyle="$theme.setPlaceholder()"></input>
				</template>
				<template v-else>
					<input placeholder="Vui lòng nhập mật khẩu cũ" type="text" v-model="value"
						:placeholderStyle="$theme.setPlaceholder()"></input>
				</template>
				<image :src="`/static/${isMask?'hide':'show'}_gray.png`" mode="aspectFit"
					style="width: 32rpx;height: 32rpx;margin-left: auto;padding-right: 12rpx;" @click="toggleMask()">
				</image>
			</view>

			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Vui lòng nhập mật khẩu
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Vui lòng nhập mật khẩu</view>
			</view>
			<view class="input_wrapper">
				<template v-if="isMask">
					<input placeholder="Vui lòng nhập mật khẩu" type="password" v-model="value2"
						:placeholderStyle="$theme.setPlaceholder()"></input>
				</template>
				<template v-else>
					<input placeholder="Vui lòng nhập mật khẩu" type="text" v-model="value2"
						:placeholderStyle="$theme.setPlaceholder()"></input>
				</template>
				<image :src="`/static/${isMask?'hide':'show'}_gray.png`" mode="aspectFit"
					style="width: 32rpx;height: 32rpx;margin-left: auto;padding-right: 12rpx;" @click="toggleMask()">
				</image>
			</view>

			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Vui lòng nhập lại mật khẩu
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Vui lòng nhập lại mật khẩu</view>
			</view>
			<view class="input_wrapper">
				<template v-if="isMask">
					<input placeholder="Vui lòng nhập lại mật khẩu" type="password" v-model="value3"
						:placeholderStyle="$theme.setPlaceholder()"></input>
				</template>
				<template v-else>
					<input placeholder="Vui lòng nhập lại mật khẩu" type="text" v-model="value3"
						:placeholderStyle="$theme.setPlaceholder()"></input>
				</template>
				<image :src="`/static/${isMask?'hide':'show'}_gray.png`" mode="aspectFit"
					style="width: 32rpx;height: 32rpx;margin-left: auto;padding-right: 12rpx;" @click="toggleMask()">
				</image>
			</view>
		</view>

		<view class="btn_common" style="font-size: 32rpx;width: 80%;margin: 20rpx auto;line-height: 64rpx;"
			@click="changePassword">
			Xác nhận
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isMask: null,
				value: "",
				value2: "",
				value3: "",
			};
		},
		onShow() {
			this.isMask = uni.getStorageSync('mask');
		},
		methods: {
			// 显隐掩码
			toggleMask() {
				this.isMask = !this.isMask;
				uni.setStorageSync('mask', this.isMask);
			},

			// 根据当前平台，执行回退方式
			goBack() {
				/*#ifdef APP-PLUS*/
				uni.navigateBack({
					delta: 1
				});
				/*#endif*/

				/*#ifdef H5*/
				history.back();
				/*#endif*/
			},
			//修改登录密码
			async changePassword() {
				let list = await this.$http.post('api/user/updateLoginPassword', {
					oldpass: this.value,
					newpass: this.value2,
					confirmpass: this.value3,
				})
				if (list.data.code == 0) {
					uni.$u.toast('Sửa đổi thành công');
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/my/my'
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
		},
		// 开局就调用请求
		// mounted() {
		// 	this.changePassword()
		// },
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 48rpx 24rpx 24rpx 24rpx;
		background-color: #363636;
		margin-bottom: 24rpx;
		display: flex;
		align-items: center;
	}

	.college-content {
		margin-top: -30rpx;
		border-radius: 30rpx 30rpx 0 0;
		padding: 30rpx;
	}
</style>