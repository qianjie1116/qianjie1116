<!-- 资金明细 -->
<template>
	<view>
		<view style="padding: 48rpx 24rpx 0 24rpx;background-color: #363636;border-bottom: 1px solid #9F9DA0;
		margin-bottom: 24rpx;">
			<view style="display: flex;	align-items: center;">
				<image src="/static/arrow_left.png" mode="aspectFit" style="width: 24rpx;height: 24rpx;"
					@tap="goBack()">
				</image>
				<view style="flex:1;text-align: center;color: #fff;font-size: 32rpx;font-weight: 500;">Chi tiết dòng
					tiền
				</view>
			</view>
			<view style="display: flex;align-items: center;justify-content: space-around;margin-top: 12rpx;">
				<block v-for="(item,index) in tabs">
					<view style="font-weight: 700;font-size: 32rpx;" @click="changeTab(index)"
						:style="{color:current==index?'#6FAAFD':'#999999',borderBottom:`6rpx solid ${current==index?'#6FAAFD':'transparent'}`}">
						{{item}}
					</view>
				</block>
			</view>
		</view>

		<view class="college-content">
			<!-- <u-tabs lineColor="#fff" :current="current" :list="list1" @click="select"
				:activeStyle="{color: '#fff',fontWeight: 'bold',}" :inactiveStyle="{color: '#e9f2de'}"></u-tabs> -->
			<view v-if="current == 0">
				<template v-if="!fundDetails || fundDetails.length<=0">
					<view style="text-align: center;margin-top: 10vh;">
						<image src="/static/empty_data.png" mode="aspectFit" style="width: 480rpx;height: 480rpx;">
						</image>
					</view>
				</template>
				<template v-else>
					<view class="" v-for="(item,index) in fundDetails" :key="index">
						<view class="takeNotes"
							style="color: #fff;background-color: #363636;padding:12rpx;border-radius: 12rpx;line-height: 1.8;">
							<view class="display">
								<view class="business">
									<view class="recharge" style="color: #fff;">Số dư</view>
									<view class="money" style="color: #ea6248;"> {{item.after}} đ</view>
								</view>
								<view class="underReview" v-if="item.status==0">
									<u-icon name="clock" color='#d50000' size="12"></u-icon>Đang xem xét
								</view>
								<view class="underReview_b" v-if="item.status==1">
									<u-icon name="checkmark-circle" color='#5AC725' size="12"></u-icon>Nạp tiền thành
									công
								</view>
								<view class="underReview_c" v-if="item.status==2">
									<u-icon name="close-circle" color='#F9AE3D' size="12"></u-icon>Thất bại, liên hệ với
									khách hàng
								</view>
							</view>
							<view class="" style="margin: 10rpx 0;white-space: pre-wrap;">{{item.desc}}</view>
							<!-- <view class="order"> -->
							<view class=""> Số dư trước giao dịch:<text>{{toThousandFilter(item.before)}}</text> </view>

							<!-- </view> -->
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view>Thời gian:</view>
								<view>{{item.created_at}}</view>
							</view>
						</view>
					</view>
				</template>
			</view>
			<view v-if="current == 1">
				<template v-if="!rechargeRecord || rechargeRecord.length<=0">
					<view style="text-align: center;margin-top: 10vh;">
						<image src="/static/empty_data.png" mode="aspectFit" style="width: 480rpx;height: 480rpx;">
						</image>
					</view>
				</template>
				<template v-else>
					<view class="" v-for="(item,index) in rechargeRecord" :key="index">
						<view class="takeNotes"
							style="color: #fff;background-color: #363636;padding:12rpx;border-radius: 12rpx;line-height: 1.8;">
							<view class="display">
								<view class="business">
									<!-- <view class="corporate">{{item.desc_type}}</view> -->
									<view class="recharge" style="color: #fff;">Nạp tiền</view>
									<view class="money">{{item.money}} VND</view>
								</view>

								<view class="underReview" v-if="item.status==0">
									<u-icon name="clock" color='#d50000' size="12"></u-icon>Đang xem xét
								</view>
								<view class="underReview_b" v-if="item.status==1">
									<u-icon name="checkmark-circle" color='#5AC725' size="12"></u-icon>Nạp tiền thành
									công
								</view>
								<view class="underReview_c" v-if="item.status==2">
									<u-icon name="close-circle" color='#F9AE3D' size="12"></u-icon>Thất bại, liên hệ với
									khách hàng
								</view>
							</view>
							<view class="order" style="color: #fff;">
								<view class=""> Mã giao dịch:<text>{{item.order_sn}}</text> </view>
							</view>
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view>Thời gian:</view>
								<view>{{item.created_at}}</view>
							</view>
						</view>
					</view>
				</template>

			</view>
			<view v-if="current == 2">
				<template v-if="!withdrawalRecords || withdrawalRecords.length<=0">
					<view style="text-align: center;margin-top: 10vh;">
						<image src="/static/empty_data.png" mode="aspectFit" style="width: 480rpx;height: 480rpx;">
						</image>
					</view>
				</template>
				<template v-else>
					<view class="" v-for="(item,index) in withdrawalRecords" :key="index">
						<view class="takeNotes"
							style="color: #fff;background-color: #363636;padding:12rpx;border-radius: 12rpx;line-height: 1.8;">
							<view class="display">
								<view class="business">
									<!-- <view class="corporate">{{item.desc_type}}</view> -->
									<view class="recharge" style="color: #fff;">Rút tiền</view>
									<view class="money">{{toThousandFilter(item.money)}} VND</view>
								</view>

								<view class="underReview" v-if="item.status==0">
									<u-icon name="clock" color='#d50000' size="12"></u-icon>Đang xử lý
								</view>
								<view class="underReview_b" v-if="item.status==1">
									<u-icon name="checkmark-circle" color='#5AC725' size="12"></u-icon>Rút tiền thành
									công
								</view>
								<view class="underReview_c" v-if="item.status==2">
									<u-icon name="close-circle" color='#F9AE3D' size="12"></u-icon>Thất bại, liên hệ với
									khách hàng
								</view>
							</view>
							<view class="order" style="color: #fff;">
								<view class=""> Mã giao dịch:<text>{{item.order_sn}}</text> </view>
							</view>
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view>Thời gian:</view>
								<view>{{item.created_at}}</view>
							</view>
						</view>
					</view>
				</template>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				current: 0,
				fundDetails: [],
				rechargeRecord: [],
				withdrawalRecords: [],
			};
		},
		computed: {
			tabs() {
				return ['Chi tiết', 'Lịch sử nạp tiền', 'Lịch sử rút tiền']
			}
		},

		onLoad(item) {
			this.current = item.index || 0;
		},

		onShow() {
			if (this.current == 0) this.fund()
			if (this.current == 1) this.recharge()
			if (this.current == 2) this.withdrawal()
		},
		methods: {
			changeTab(val) {
				this.current = val;
				if (this.current == 0) this.fund()
				if (this.current == 1) this.recharge()
				if (this.current == 2) this.withdrawal()
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			// 根据当前平台，执行回退方式
			goBack() {
				/*#ifdef APP-PLUS*/
				uni.navigateBack({
					delta: 1
				});
				/*#endif*/

				/*#ifdef H5*/
				history.back();
				/*#endif*/
			},
			// select(item) {
			// 	// console.log(item);
			// 	this.current = item.index;
			// 	// console.log(this.current, '9989999999');
			// },
			// 资金明细
			async fund() {
				let list = await this.$http.get('api/user/finance', {})
				this.fundDetails = list.data.data
				console.log(this.fundDetails);
			},
			//充值记录
			async recharge() {
				let list = await this.$http.get('api/user/recharge', {

				})
				this.rechargeRecord = list.data.data
			},
			//提现记录
			async withdrawal() {
				let list = await this.$http.get('api/user/withdraw', {

				})
				this.withdrawalRecords = list.data.data
			},

		},

	}
</script>

<style lang="scss">
	.college-bg {
		padding: 48rpx 24rpx 24rpx 24rpx;
		background-color: #363636;
		margin-bottom: 24rpx;
		display: flex;
		align-items: center;
	}

	/deep/.u-tabs__wrapper__nav {
		justify-content: space-between;
		border-bottom: 1rpx solid #e0e0e0;
		padding: 0 30rpx;

	}

	.college-content {
		width: 100%;

		//选项卡一
		.fund {
			margin: 30rpx;

			.display {
				margin-top: 20rpx;
			}

			.time {
				color: #999;
				font-size: 24rpx;
			}

			.amount {
				color: #999;
				font-weight: 600;
				font-size: 30rpx;
				margin-top: 10rpx;
			}
		}

		//选项卡二
		.takeNotes {
			margin: 30rpx;
			padding: 20rpx 0;
			border-bottom: 2rpx solid #eeeeee;
			font-size: 26rpx;


			.business {
				display: flex;

				.corporate {
					background-color: #7266ba;
					color: #fff;
					border-radius: 4rpx;
					padding: 2rpx 10rpx;
					font-size: 24rpx;

				}

				.recharge {
					font-weight: 700;
					color: #000;
					margin: 0 20rpx 0 0;
				}

				.money {
					color: #BB1815;
					font-weight: 600;
				}

			}

			.underReview {
				display: flex;
				align-items: baseline;
				color: #d50000;
			}

			.underReview_b {
				display: flex;
				align-items: baseline;
				color: #5AC725;
			}

			.underReview_c {
				display: flex;
				align-items: baseline;
				color: #F9AE3D;
			}


			.order {
				margin-top: 10rpx;
				display: flex;
				font-size: 24rpx;
				color: #666;

				text {
					margin: 0 20rpx 0 10rpx;
				}
			}
		}
	}
</style>