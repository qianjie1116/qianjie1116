<!-- 关于我们 -->
<template>
	<view>
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 24rpx;height: 24rpx;" @tap="goBack()">
			</image>
			<view style="flex:1;text-align: center;color: #fff;font-size: 32rpx;font-weight: 500;">{{about.title}}
			</view>
		</view>
		<view class="college-content" style="color: #fff;">
			<!-- <rich-text :nodes="about.content"></rich-text> -->
			<view class="" v-html="about.content"></view>

			<u-divider></u-divider>



		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				about: ''
			};
		},
		methods: {
			// 根据当前平台，执行回退方式
			goBack() {
				/*#ifdef APP-PLUS*/
				uni.navigateBack({
					delta: 1
				});
				/*#endif*/

				/*#ifdef H5*/
				history.back();
				/*#endif*/
			},
			//关于我们
			async about_us() {
				let list = await this.$http.get('api/article/about-us', {
					// language: this.$i18n.locale
				})
				this.about = list.data.data
				// console.log(list.data.data, '关于我们');
			},
		},
		mounted() {
			this.about_us()
		},
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 48rpx 24rpx 24rpx 24rpx;
		background-color: #363636;
		margin-bottom: 24rpx;
		display: flex;
		align-items: center;
	}

	.college-content {
		padding: 40rpx;
		font-size: 28rpx;

	}
</style>