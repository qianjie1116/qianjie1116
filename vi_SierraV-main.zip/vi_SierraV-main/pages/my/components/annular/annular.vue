<template>
	<view class="charts-box">
		<qiun-data-charts type="arcbar" :opts="opts" :chartData="chartData" />

		<!-- {{totalZichan}} -->

	</view>
</template>

<script>
	export default {
		//通过props接收父组件中传过来的值,但渲染未生效,迫于无奈请求数据 
		// props: ['totalZichan'],

		data() {
			return {
				chartData: {},
				//您可以通过修改 config-ucharts.js 文件中下标为 ['arcbar'] 的节点来配置全局默认参数，如都是默认参数，此处可以不传 opts 。实际应用过程中 opts 只需传入与全局默认参数中不一致的【某一个属性】即可实现同类型的图表显示不同的样式，达到页面简洁的需求。
				opts: {
					color: ["#ea4445", ],
					padding: undefined,
					title: {
						//总资产金额
						name: '',
						fontSize: 24,
						color: "#ea4445"
					},
					subtitle: {
						name: "账户总资产",
						fontSize: 12,
						color: "#666666"
					},
					extra: {
						arcbar: {
							type: "circle",
							width: 12,
							backgroundColor: "#E9E9E9",
							startAngle: 1.5,
							endAngle: 0.25,
							gap: 2
						}
					}
				}
			};
		},
		mounted() {
			this.getServerData();
			this.gaint_info()
		},
		methods: {
			getServerData() {
				//模拟从服务器获取数据时的延时
				setTimeout(() => {
					//模拟服务器返回数据，如果数据格式和标准格式不同，需自行按下面的格式拼接
					let res = {
						series: [{
							name: "价格",
							color: "#ea4445",
							//环形进度条
							data: 1
						}]
					};
					this.chartData = JSON.parse(JSON.stringify(res));
				}, 500);
			},
			//用户信息
			// async gaint_info() {
			// 	let list = await this.$http.get('api/user/info', {
			// 		// language: this.$i18n.locale
			// 	})
			// 	this.opts.title.name = list.data.data.totalZichan
			// 	// console.log(list.data.data.money, '用户信息');

			// },
		},

	};
</script>

<style scoped>
	/* 请根据实际需求修改父元素尺寸，组件自动识别宽高 */
	.charts-box {
		width: 94%;
		height: 360rpx;
	}
</style>
