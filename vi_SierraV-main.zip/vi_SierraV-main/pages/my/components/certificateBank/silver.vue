<!-- 银转证 -->
<template style="background: #f0f0f0;">
	<view>
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 24rpx;height: 24rpx;" @tap="goBack()">
			</image>
			<view style="flex:1;">
				<view style="display: flex;align-items: center;justify-content: space-between;padding:0 80rpx;">
					<view style="text-align: center;color: #3E6EB2;font-size: 32rpx;font-weight: 500;">Nộp tiền
					</view>
					<view style="text-align: center;color: #fff;font-size: 32rpx;font-weight: 500;" @click="linkTo()">
						Rút tiền
					</view>
				</view>
			</view>
		</view>
		<!-- 
		<u-tabs lineColor="#121327" :list="list1" @click="strike"
			:activeStyle="{color: '#fff',background:'#121327',padding:'10px 20px',}"></u-tabs> -->

		<!-- <view class="inv-h-w">
			<block v-for="(item,index) in items" :key="index">
				<view :class="['inv-h',Inv== index?'inv-h-se':'']" @click="Inv=index">{{item}}</view>
			</block>

		</view> -->
		<view style="background-color: #242424;padding:12rpx 24rpx;">
			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Tài sản của tôi
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Tài sản của tôi</view>
			</view>
			<view style="border-radius: 20rpx;background-image: url(/static/position_card_bg.png);
		background-repeat: no-repeat;background-position: 0 0;background-size: 100% 100%;">
				<view style="display: flex;flex-direction: column;justify-content: space-between;">
					<view style="padding: 30rpx;0 24rpx 24rpx;">
						<view style="display: flex;align-items: center;">
							<view style="color: #fff;">Tổng tài sản (VND)</view>
							<image :src="`/static/mask_${isMask?'hide':'show'}.png`" mode="aspectFit"
								style="width: 32rpx;height: 32rpx;padding-left: 12rpx;" @click="toggleMask()">
							</image>
						</view>
						<view style="font-size: 48rpx;font-weight: 700;color: #fff;line-height: 2;">
							{{isMask?`******`: toThousandFilter(userInformation.totalZichan*1+userInformation.holdYingli*1)}}
						</view>
						<view style="display: flex;align-items: center;color: #fff;line-height: 1.4;">
							<view style="font-size: 24rpx;padding-right: 24rpx;">Tổng lãi lỗ</view>
							<view :style="{color:userInformation.holdYingli>0?'aqua':'red'}">
								{{isMask?`******`: toThousandFilter(userInformation.holdYingli)}}
							</view>
						</view>
						<view style="display: flex;align-items: center;color: #fff;line-height: 1.4;">
							<view style="font-size: 24rpx;padding-right: 24rpx;">Tổng giá trị thị trường</view>
							<view style="color: #fff;">{{isMask?`******`: toThousandFilter(userInformation.frozen)}}
							</view>
						</view>
						<view style="display: flex;align-items: center;color: #fff;line-height: 1.4;">
							<view style="font-size: 24rpx;padding-right: 24rpx;">Sức mua</view>
							<view style="color: #fff;">{{isMask?`******`: toThousandFilter(userInformation.money)}}
							</view>
						</view>
					</view>
				</view>
			</view>

			<view style="margin-bottom: 40rpx;"></view>
			<!-- 公司名称 显示后台设置的公户收款帐号-->
			<view style="color:#FFF;">Tên tài khoản</view>
			<view class="input_wrapper">
				<view>{{BankUser}}</view>
				<image src="/static/fuzhi2.png" mode="aspectFit" style="width: 48rpx;height: 48rpx;margin-left: auto;"
					@click="copy(BankUser)"></image>
			</view>

			<!-- 公司帐号 显示公户公司名称 -->
			<view style="color:#FFF;">Tài khoản thụ hưởng</view>
			<view class="input_wrapper">
				<view>{{BankName}}</view>
				<image src="/static/fuzhi2.png" mode="aspectFit" style="width: 48rpx;height: 48rpx;margin-left: auto;"
					@click="copy(BankName)"></image>
			</view>
			<!-- 汇款内容  空的栏位 -->
			<view style="color:#FFF;">Số tài khoản</view>
			<view class="input_wrapper">
				<view>{{BankNo}}</view>
				<image src="/static/fuzhi2.png" mode="aspectFit" style="width: 48rpx;height: 48rpx;margin-left: auto;" @click="copy(BankNo)">
				</image>
			</view>

			<!-- <view v-show="Inv == 0">
				<view class="collections">
					<view class="call">
						<view class="beneficiaryName">Tên</view>
						<view class="" style="color: #fff;">{{BankUser}}</view>
						<view class="duplicate" @click="copy(BankUser)">
							<image src="../../../../static/fuzhi2.png" mode="widthFix" style="width: 25px;">
						</view>
					</view>
				</view>
				<view class="xian"></view>
				<view class="make-collections">
					<view class="call">
						<view class="beneficiaryName">Ngân hàng</view>
						<view class="" style="color: #fff;">{{BankName}}</view>
						<view class="duplicate" @click="copy(BankName)">
							<image src="../../../../static/fuzhi2.png" mode="widthFix" style="width: 25px;">
						</view>
					</view>
				</view>
				<view class="xian"></view>

				<view class="make-collections">
					<view class="call">
						<view class="beneficiaryName">Tài khoản</view>
						<view class="" style="color: #fff;">{{BankNo}}</view>
						<view class="duplicate" @click="copy(BankNo)">
							<image src="../../../../static/fuzhi2.png" mode="widthFix" style="width: 25px;">
						</view>
					</view>
				</view>
				<view class="xian"></view> -->
			<!-- 密码 -->
			<!-- <view class="make-collections">
				<view class="call">
					<view class="beneficiaryName">Mật khẩu</view>
					<view class="beneficiaryinput">
						<u-input placeholder="Nhập mật khẩu" type="password" v-model="value3"></u-input>
					</view>
					<view class="duplicate" style="color: red; font-weight: 900;" @click="testVerify()">Kiểm tra</view>
				</view>
			</view> -->
			<!-- </view>
			<view v-show="Inv == 1">
				<view class="collections">
					<view class="call">
						<view class="beneficiaryName">Tên</view>
						<view class="">{{BankUser_2}}</view>
						<view class="duplicate" @click="copy(BankUser_2)">
							<image src="../../../../static/fuzhi2.png" mode="widthFix" style="width: 25px;">
						</view>
					</view>
				</view>
				<view class="xian"></view>
				<view class="make-collections">
					<view class="call">
						<view class="beneficiaryName">Ngân hàng</view>
						<view class="">{{BankName_2}}</view>
						<view class="duplicate" @click="copy(BankName_2)">
							<image src="../../../../static/fuzhi2.png" mode="widthFix" style="width: 25px;">
						</view>
					</view>
				</view>
				<view class="xian"></view>

				<view class="make-collections">
					<view class="call">
						<view class="beneficiaryName">Tài khoản</view>
						<view class="">{{BankNO_2}}</view>
						<view class="duplicate" @click="copy(BankNO_2)">
							<image src="../../../../static/fuzhi2.png" mode="widthFix" style="width: 25px;">
						</view>
					</view>
				</view>
				<view class="xian"></view> -->
			<!-- 密码 -->
			<!-- <view class="make-collections">
					<view class="call">
						<view class="beneficiaryName">Mật khẩu</view>
						<view class="beneficiaryinput">
							<u-input placeholder="Nhập mật khẩu" type="password" v-model="value4"></u-input>
						</view>
						<view class="duplicate" style="color: red; font-weight: 900;" @click="testVerify_2()">Kiểm tra
						</view>
					</view>
				</view>
			</view>

			<view class="xian"></view> -->

			<!-- 查看 -->
			<!-- <view class="make-collections">
				<view class="call">
					<view class="beneficiaryName">Hồ sơ nạp tiền</view>
					<view class="" style="color: #fff;"></view>
					<view class="duplicate" @tap="capitalDetails()">Xem thêm</view>
				</view>
			</view> -->
		</view>


		<view style="background-color: #242424;padding:12rpx 24rpx;margin-top: 24rpx;">
			<!-- 充值金额 -->
			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Số tiền nộp
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Số tiền nộp</view>
			</view>

			<view style="font-weight: 700;color: #FFF;font-size: 14px;">
				Lưu ý : Số tiền giao dịch tối thiểu là<text
					style="margin-left: 10rpx;color: firebrick;">{{toThousandFilter(userInformation.min_rprice)+`(VND)`}}
				</text>
			</view>

			<view class="input_wrapper">
				<image src="/static/icon_sub.png" mode="aspectFit"
					style="width: 48rpx;height: 48rpx;padding-right: 24rpx;" @click="handleSub()"></image>
				<input placeholder="Vui lòng nhập số tiền cần nộp" type="number" v-model="amount"
					:placeholderStyle="$theme.setPlaceholder()"></input>
				<image src="/static/icon_add.png" mode="aspectFit" style="width: 48rpx;height: 48rpx;margin-left: auto;"
					@click="handleAdd()"></image>
			</view>

			<view style="display: flex;align-items: flex-start;flex-wrap: wrap; margin: 30rpx 0;">
				<block v-for="(item,index) in amountList" :key="index">
					<view style="flex:0 0 33.33%;">
						<view
							style="border-radius: 8rpx;margin:10rpx;padding:8rpx 10rpx;line-height: 1.6;text-align: center;"
							:style="setStyle(curPos==index)" @click="quantity(item,index)">
							{{$util.formatNumber(item)}}
						</view>
					</view>
				</block>
			</view>

			<!-- <view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Tải lên chứng từ
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Tải lên chứng từ
				</view>
			</view> -->
			<!-- <view class="success">
				<view style="flex: 100%;border: #fff 1px solid;border-radius: 5px;">
					<u-upload :fileList="fileList6" @afterRead="afterRead" @delete="deletePic" name="6" multiple
						:maxCount="1" width="" height="300">

						<view class="" style="text-align: center;margin: 30rpx 0; font-size: 24rpx;color: #fff;">
							Nhấp vào Tải lên chứng từ chuyển khoản thành công
						</view>
						<view style="width: 100%;justify-content: center;display: flex;">
							<image src="/static/jiahao.png" mode="widthFix" style="width: 50px;margin: 110px;"></image>
						</view>
					</u-upload>
				</view>
			</view> -->

		</view>
		<!-- 		<view class="cash-withdrawal">
			<view class="withdrawal">通道密码</view>
			<view class="money">
				<input placeholder="请输入" type="password">
			</view>
		</view> -->


		<view class="btn_common" style="font-size: 32rpx;width: 80%;margin: 20rpx auto;line-height: 64rpx;"
			@click="to_recharge()">
			Xác nhận
		</view>

		<view style="padding:32rpx;color: #FFF;">
			<view style="border-bottom: 1px dashed #999;display: flex;align-items: center;padding-bottom: 12rpx;">
				<view style="margin-right: auto;">
					<image src="/static/error.svg" style="width: 48rpx;height: 48rpx;padding-right: 24rpx;">
					</image>
				</view>
				<view style="flex:1;">Thông tin giao dịch</view>
			</view>
			<view style="border-bottom: 1px dashed #999;padding: 20rpx;">
				Lưu ý : Để thực hiện nộp tiền giao dịch, quý khách vui lòng liên hệ Trung Tâm Tài Khoản để được
				hướng
				dẫn chi tiết.
			</view>
			<view style="border-bottom: 1px dashed #999;padding: 20rpx;">
				Thời gian giao dịch 9:00 đến 21:00 hàng ngày ( Trừ các ngày nghỉ, lễ, tết ) Vui lòng đọc kỹ điều
				khoản
				và thỏa thuận giao dịch. Vì chúng đặt ra nhằm bảo vệ quyền và nghĩa vụ pháp lý của quý khách,
				Cảm ơn bạn
				đã lựa chọn chúng tôi !
			</view>

			<view style="display: flex;align-items: center;padding-top: 24rpx;">
				<view style="margin-right: auto;">
					<image src="/static/error.svg" style="width: 48rpx;height: 48rpx;padding-right: 24rpx;">
					</image>
				</view>
				<view style="flex:1;">Sau khi chuyển khoản thành công quý khách vui lòng liên hệ CSKH để được hướng dẫn.
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import md5 from 'js-md5'
	import {
		pathToBase64
	} from '@/utils/js_sdk.js'
	export default {
		data() {
			return {
				isMask: true,
				customerService: 'Vui lòng liên hệ với dịch vụ khách hàng của bạn',
				amount: '',
				curPos: 0,
				shadow: '',
				shadow1: '',
				shadow2: '',
				shadow3: '',
				character: '',
				character1: '',
				character2: '',
				character3: '',
				fileList6: [],
				userInformation: "",
				queryFunction: '',
				value3: '',
				value4: "",
				// lookOver: "",
				BankUser: '',
				BankName: '',
				BankNo: '',
				BankUser_2: '',
				BankName_2: '',
				BankNO_2: '',
				current: 0,
				list1: [{
						name: '通道一'
					},
					{
						name: '通道二'
					},
				],
				Inv: 0,
				items: ['通道一', '通道二'],
				is_url: ""
			};
		},
		computed: {
			// 入金金额预置值
			amountList() {
				return [50000000, 100000000, 500000000];
			},
		},
		onLoad(option) {

		},
		onShow() {
			this.gaint_info()
			this.testVerify();
			this.isMask = uni.getStorageSync('mask');
		},
		methods: {
			linkTo() {
				uni.navigateTo({
					url: '/pages/my/components/certificateBank/prove',
				})
			},

			handleSub() {
				if (this.amount <= 0) {
					return false;
				}
				this.amount = this.amount * 1 - 1;
			},
			handleAdd() {
				this.amount = this.amount * 1 + 1;
			},

			// 显隐掩码
			toggleMask() {
				this.isMask = !this.isMask;
				uni.setStorageSync('mask', this.isMask);
			},
			setStyle(val) {
				return {
					backgroundColor: val ? '#3E6EB2' : '#666',
					color: val ? '#FFFFFF' : '#CCC',
					borderRadius: `8rpx`,
					// border: `1px solid #F88B8B1A`
				}
			},
			// 根据当前平台，执行回退方式
			goBack() {
				uni.switchTab({
					url: `/pages/index/index`
				})
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			//选项卡
			strike(item) {
				// console.log(item);
				this.current = item.index;
			},
			//选项卡
			changeTab(Inv) {
				that.navIdx = Inv;

			},
			home() {
				uni.switchTab({
					url: '/pages/my/my'
				});
			},
			//客服
			customer() {
				uni.navigateTo({
					url: '/pages/index/components/customer/customer'
				});
			},

			//充值记录
			capitalDetails() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/components/commonFunctions/capitalDetails?index=1'
				});
			},



			copy(value) {
				//提示模板
				if (value == '') {
					uni.$u.toast('Vui lòng xác nhận mật khẩu');
				} else {
					uni.setClipboardData({
						data: value, //要被复制的内容
						success: () => { //复制成功的回调函数
							// console.log(value);
							uni.showToast({
								title: 'Sao chép thành công',
								duration: 2000,
								icon: 'success'
							})
						}
					});
				}

			},
			quantity(val, index) {
				this.curPos = index;
				this.amount = val;
			},
			// 回调参数为包含columnIndex、value、values
			async to_recharge() {
				uni.showLoading({
					title: "Đang nạp tiền, vui lòng chờ trong giây lát...",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/app/recharge', {
					money: this.amount,
					type: 5,
					image: this.is_url,
					desc: this.value2,
				})

				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.value2 = '';
					this.amount = '';
					this.is_url = '';
					this.fileList6 = [];
					this.title = 'Thẻ ngân hàng',
						setTimeout(() => {
							uni.switchTab({
								url: '/pages/my/my'
							});
							uni.hideLoading();
						}, 2000)
				} else {
					uni.$u.toast(list.data.message);
					uni.hideLoading();
					// if (list.data.message === '充值金额错误') {
					// 	uni.$u.toast('请填写充值金额金额');
					// } else if (list.data.message === '您还未实名') {
					// 	uni.$u.toast('请先实名认证');
					// 	setTimeout(() => {
					// 		uni.navigateTo({
					// 			url: '/pages/index/components/openAccount/openAccount'
					// 		});
					// 		uni.hideLoading();
					// 	}, 2000)

					// } else if (list.data.message === '请先添加银行卡信息') {
					// 	uni.$u.toast('请先添加银行卡');
					// 	setTimeout(() => {
					// 		uni.navigateTo({
					// 			url: '/pages/my/components/bankCard/renewal'
					// 		});
					// 		uni.hideLoading();
					// 	}, 2000)
					// }
					// uni.$u.toast(list.data.message);
					// if (list.data.message != '您还未实名' || '请先添加银行卡信息') {

					// }
				}
			},

			//凭证
			deletePic(event) {
				this[`fileList${event.name}`].splice(event.index, 1)
			},
			// 新增图片
			async afterRead(event) {
				// 当设置 multiple 为 true 时, file 为数组格式，否则为对象格式
				console.log(111, event)
				let lists = [].concat(event.file)
				let fileListLen = this[`fileList${event.name}`].length
				lists.map((item) => {
					this[`fileList${event.name}`].push({
						...item,
					})
				})
				for (let i = 0; i < lists.length; i++) {
					const result = await this.uploadFilePromise(lists[i].url)
					let item = this[`fileList${event.name}`][fileListLen]
					this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
						status: 'success',
						message: '',
						url: result
					}))
					fileListLen++
				}
			},
			//个人信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data

			},
			uploadFilePromise(url) {
				let Request = "Qwd3N5yp"
				let time = parseInt(new Date().getTime() / 1000)
				let str_url = ("/api/app/upload").toLowerCase()
				let mdd = md5("XPFXMedS" + Request + str_url + time)
				uni.uploadFile({
					url: this.$http.BaseUrl + '/api/app/upload?t=' + time + "&sign=" + mdd, // 仅为示例，非真实的接口地址
					filePath: url,
					name: 'file',
					success: (res) => {
						uni.hideLoading()
						var data = JSON.parse(res.data);
						// this.is_url = res.data
						console.log(1111, data)
						this.is_url = data[0].url;
					},
					error: (res) => {
						uni.hideLoading()
						console.log(3333, res)
					},
				});

			},
			//显示银行信息
			async queryPassword() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.queryFunction = list.data.data.bank_card_info
				// console.log(this.queryFunction, '收款人银行');
			},
			//点击验证
			async testVerify() {

				let list = await this.$http.get('api/app/config', {
					// language: this.$i18n.locale
				})

				// uni.$u.toast('Mật khẩu đúng');
				this.BankUser = list.data.data[13].value
				this.BankName = list.data.data[12].value
				this.BankNo = list.data.data[9].value
				this.value3 = ''
				uni.hideLoading();


			},
			async testVerify_2() {
				uni.showLoading({
					title: "Đang truy vấn, vui lòng chờ một chút...",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.get('api/app/config', {
					// language: this.$i18n.locale
				})
				if (this.value4 === list.data.data[25].value) {
					console.log(this.value4);
					uni.$u.toast('Mật khẩu đúng');
					this.BankUser_2 = list.data.data[22].value
					this.BankName_2 = list.data.data[23].value
					this.BankNO_2 = list.data.data[24].value
					this.value4 = ''
					uni.hideLoading();
				} else {
					uni.hideLoading();
					uni.$u.toast('Vui lòng nhập mật khẩu chính xác');

				}
			},



		},



	}
</script>

<style lang="scss">
	.college-bg {
		padding: 48rpx 24rpx 24rpx 24rpx;
		background-color: #363636;
		margin-bottom: 24rpx;
		display: flex;
		align-items: center;
	}

	.xian {
		width: 100%;
		height: 2rpx;
		background: #e9e9e9;
	}

	/deep/.u-tabs {
		border-radius: 30rpx 30rpx 0 0 !important;
		margin-top: -30rpx !important;
		background: #fff;
	}

	/deep/.u-tabs__wrapper__nav {
		justify-content: space-around;
	}

	.collections {
		// border-radius: 30rpx 30rpx 0 0;
		// margin-top: -30rpx;
		// background: #180d2b;
		padding: 20rpx 30rpx;

		.call {
			display: flex;
			justify-content: space-between;
			align-items: center;
			// border-bottom: 2rpx solid #e0e0e0;
			padding: 20rpx 0;
			font-size: 26rpx;

			.beneficiaryName {
				color: #fff;
				font-weight: 700;
			}

			.duplicate {
				color: #fff;
				font-weight: 700;

			}
		}
	}

	.make-collections {
		// border-radius: 30rpx 30rpx 0 0;
		// margin-top: -30rpx;
		// background: #fff;
		padding: 20rpx 30rpx;

		.call {
			display: flex;
			justify-content: space-between;
			align-items: center;
			// border-bottom: 2rpx solid #e0e0e0;
			padding: 20rpx 0;
			font-size: 26rpx;

			.beneficiaryName {
				color: #fff;
				font-weight: 700;
			}

			.duplicate {
				color: #fff;
				font-weight: 700;

			}
		}
	}

	//充值金额
	.recharge {
		margin: 30rpx;
		font-size: 28rpx;

		.title {
			color: #fff;
		}

		.minimum {
			color: #fff;
			font-size: 26rpx;
			margin: 20rpx 0;

			text {
				color: #ffa1a1;
			}
		}

		input {
			background: #f5f5f5;
			border-radius: 10rpx;
			color: #000;
			padding: 30rpx 20rpx;
			font-size: 28rpx;
		}

		.select {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin: 30rpx 0;
			font-size: 28rpx;

			view {
				background: #333;
				color: #FFF;
				border-radius: 10rpx;
				width: 23%;
				text-align: center;
				padding: 20rpx 0;
			}

			// .shadow {
			// 	background-image: linear-gradient(to right, #FFB044, #FF2D30);
			// }
		}
	}


	.cash-withdrawal {

		padding: 30rpx;

		.withdrawal {
			color: #333;
		}

		.money {
			display: flex;
			justify-content: space-between;
			align-items: center;
			background: #f5f5f5;
			padding: 30rpx;
			margin: 20rpx 0;
			border-radius: 10rpx;

		}
	}

	.purchase {
		background-image: linear-gradient(to right, #FFB044, #FF2D30);
		margin: 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #fff;
		font-weight: 600;
		font-size: 30rpx;
	}

	.uploadVoucher {
		margin: 30rpx;
		color: #333;
		font-size: 28rpx;
	}

	.success {
		// width: 100%;
		height: 760rpx;
		margin: 30rpx;

		image {
			width: 100%;
			height: 100%;
		}

		/deep/.u-upload__wrap {
			width: 100% !important;
			height: 720rpx !important;
			flex-wrap: nowrap;
			flex: none;

			view {
				width: 100%;
			}
		}

		/deep/.u-upload__wrap__preview__image {
			height: 720rpx !important;
		}

		/deep/.u-upload__wrap__preview__image {
			width: 100% !important;
		}

		/deep/ .u-upload__deletable {
			width: 14px !important;
		}

		/deep/ .u-upload__success {
			width: 60rpx !important;
			border-right-color: transparent;
		}
	}

	.point-out {
		margin: 30rpx;
		color: #fff;
		font-size: 28rpx;

	}

	.beneficiaryinput {
		width: 65%;
		word-break: break-word; //文本超出 自动换行

		input {
			word-break: break-word; //文本超出 自动换行
			font-size: 26rpx;
			overflow: hidden;
			white-space: nowrap;
			text-overflow: ellipsis;
			text-align: left;
		}
	}

	.inv-h-w {
		background-color: #FFFFFF;
		display: flex;
		justify-content: space-between;
		align-items: center;
		border-radius: 30rpx 30rpx 0 0 !important;
		margin-top: -30rpx !important;
		padding: 30rpx 100rpx;

	}

	.inv-h {
		font-size: 28rpx;
		flex: 1;
		text-align: center;
		color: #666666;
		position: relative;

	}

	.inv-h-se {
		font-size: 28rpx;
		color: #fff;
		background: #121327;
		border-radius: 40rpx;
		padding: 10rpx 0;
	}

	.inv-h-se:after {
		content: '';
		position: absolute;
		bottom: -2rpx;
		top: auto;
		left: 42%;
		height: 6rpx;
		width: 44rpx;
		background-color: #4DB046;
		display: none;
	}
</style>