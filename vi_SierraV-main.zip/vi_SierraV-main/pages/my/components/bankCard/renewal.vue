<!-- 绑定银行卡 -->
<template>
	<view>
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 24rpx;height: 24rpx;" @tap="goBack()">
			</image>
			<view style="flex:1;text-align: center;color: #fff;font-size: 32rpx;font-weight: 500;">Liên kết thẻ ngân
				hàng</view>
		</view>
		<view class="college-content" style="background-color: #242424;border-radius: 0;margin-top: 24rpx;">
			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Họ tên
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Họ tên</view>
			</view>
			<view class="input_wrapper">
				<input placeholder="Vui lòng nhập" type="text" v-model="value"
					:placeholderStyle="$theme.setPlaceholder()"></input>
			</view>

			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Tên ngân hàng
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Tên ngân hàng</view>
			</view>
			<view class="input_wrapper">
				<input placeholder="Vui lòng nhập" type="text" v-model="value2"
					:placeholderStyle="$theme.setPlaceholder()"></input>
			</view>

			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Số tài khoản
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Số tài khoản</view>
			</view>
			<view class="input_wrapper">
				<input placeholder="Vui lòng nhập" type="text"  v-model="value4"
					:placeholderStyle="$theme.setPlaceholder()"></input>
			</view>
			
			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Mật khẩu giao dịch 
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Mật khẩu giao dịch </view>
			</view>
			<view class="input_wrapper">
				<input placeholder="Vui lòng nhập mật khẩu giao dịch" maxlength="6"  type="text" v-model="value5"
					:placeholderStyle="$theme.setPlaceholder()" style="width: 90%;"></input>
			</view>
			
			<!-- <view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Vui lòng nhập mật khẩu giao dịch
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Vui lòng nhập mật khẩu giao dịch</view>
			</view> -->
			<view class="input_wrapper">
				<input placeholder="Vui lòng xác nhận lại nhập mật khẩu giao dịch" type="text" maxlength="6" v-model="value6"
					:placeholderStyle="$theme.setPlaceholder()" style="width: 95%;"></input>
			</view>

		</view>

		<view class="btn_common" style="font-size: 32rpx;width: 80%;margin: 20rpx auto;line-height: 64rpx;"
			@click="replaceBank()">
			Xác nhận liên kết
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

				value: '',
				value2: '',
				value3: '',
				value4: '',
				value5: '',
				value6: '',

			};
		},
		methods: {
			// 根据当前平台，执行回退方式
			goBack() {
				/*#ifdef APP-PLUS*/
				uni.navigateBack({
					delta: 1
				});
				/*#endif*/

				/*#ifdef H5*/
				history.back();
				/*#endif*/
			},

			//跟换银行卡
			async replaceBank() {
				let list = await this.$http.post('api/user/bindBankCard', {
					//value2和value3反了
					//value2应该是bank_name  
					//value3应该是bank_sub_name
					realname: this.value,
					bank_name: this.value,
					bank_sub_name: this.value2,
					card_sn: this.value4,
					password: this.value5,
					pas_word2: this.value6,
				})
				if (list.data.code == 0) {
					uni.$u.toast('Thông tin thẻ gửi thành công');
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/my/my'
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}

			},
		},
		// mounted() {
		// 	this.replaceBank()
		// },
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 48rpx 24rpx 24rpx 24rpx;
		background-color: #363636;
		margin-bottom: 24rpx;
		display: flex;
		align-items: center;
	}

	.college-content {
		margin: 30rpx 0;
		padding: 10rpx 30rpx;
	}
</style>