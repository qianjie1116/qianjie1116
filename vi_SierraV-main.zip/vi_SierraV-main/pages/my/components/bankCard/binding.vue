<!-- 绑定银行卡 -->
<template>
	<view>
		<view class="college-bg">
			<image src="/static/arrow_left.png" mode="aspectFit" style="width: 24rpx;height: 24rpx;" @tap="goBack()">
			</image>
			<view style="flex:1;text-align: center;color: #fff;font-size: 32rpx;font-weight: 500;">Liên kết ngân hàng
			</view>
		</view>

		<view class="college-content" style="background-color: #242424;border-radius: 0;margin-top: 24rpx;">
			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Họ tên
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Họ tên</view>
			</view>
			<view class="input_wrapper">
				<view> {{!cardManagement?'':cardManagement.realname}}</view>
			</view>

			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Tên ngân hàng
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Tên ngân hàng</view>
			</view>
			<view class="input_wrapper">
				<view> {{!cardManagement?'':cardManagement.bank_sub_name}}</view>
			</view>

			<view style="position: relative; height: 40px; padding: 0px 10px; color: transparent; width: max-content;">
				Số tài khoản
				<view style="position: absolute; bottom: 10px; left: 0px; right: 0px; height: 8px; width: 100%; 
					background-image: linear-gradient(90deg, #3E6EB2, #26397B); border-radius: 8px;">
				</view>
				<view
					style="position: absolute; top: 8px; left: 0px; right: 0px; font-size: 16px; color: rgb(255, 255, 255); font-weight: 800; width: 100%; text-align: center;">
					Số tài khoản</view>
			</view>
			<view class="input_wrapper">
				<view> {{!cardManagement?'':cardManagement.card_sn}}</view>
			</view>
			
		</view>
		

		<!-- 		<view class="college-content">
			<view class="bank-name">
				<view class="">银行卡号: </view> <text> {{cardManagement.card_sn}}</text>
			</view>
		</view> -->
		<view class="btn_common" style="font-size: 32rpx;width: 80%;margin: 20rpx auto;line-height: 64rpx;"
			@tap='renewal()'>
			Nhấp để liên kết lại
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				cardManagement: null,
			};
		},
		methods: {
			// 根据当前平台，执行回退方式
			goBack() {
				/*#ifdef APP-PLUS*/
				uni.navigateBack({
					delta: 1
				});
				/*#endif*/

				/*#ifdef H5*/
				history.back();
				/*#endif*/
			},

			renewal() {
				uni.navigateTo({
					url: '/pages/my/components/bankCard/renewal'
				});
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
				this.cardManagement = list.data.data.bank_card_info
			},
		},
		onLoad(option) {
			this.gaint_info();


		},
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 48rpx 24rpx 24rpx 24rpx;
		background-color: #363636;
		margin-bottom: 24rpx;
		display: flex;
		align-items: center;
	}

	.college-content {
		margin: 30rpx 0;
		padding: 10rpx 30rpx;
	}
</style>