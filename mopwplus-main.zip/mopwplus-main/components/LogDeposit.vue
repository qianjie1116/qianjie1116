<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view class="line common_block" style="margin:0 10px 20px 10px;padding:10px;">
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">Withdraw</view>
					<view :style="{color:$util.THEME.PRIMARY}" style="flex:40%;font-size: 18px;font-weight: 700;">
						{{$util.formatNumber(item.money)}}
					</view>
					<view style="flex:20%;text-align: center;" :style="{color:$util.THEME.RISE}">
						{{item.desc_type}}
					</view>
				</view>

				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">Order Number:</view>
					<view style="flex:70%;" :style="{color:$util.THEME.TEXT}">
						{{item.order_sn}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">Date time:</view>
					<view style="flex:70%;" :style="{color:$util.THEME.TEXT}">
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">Reason for rejection:</view>
					<view style="flex:70%;" :style="{color:$util.THEME.TEXT}">
						{{item.reason}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:3%;">
						<image :src="item.icon" :style="$util.calcImageSize(12)"></image>
					</view>
					<view style="flex:97%;" :style="{color:item.color}">{{item.text}}</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogDeposit",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		mounted() {
			this.getList()
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_DEPOSIT, {})
				if (result.data.code == 0) {
					this.list = result.data.data
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		}
	}
</script>

<style>

</style>