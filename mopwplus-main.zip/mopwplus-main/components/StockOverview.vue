<template>
	<view class="top1 common_block">
		<view class="flex flex-b pd10">
			<view class="flex align-center">
				<image mode="aspectFit" :src="getlogo()" :style="$util.calcImageSize(50)" style="border-radius: 100%;">
				</image>
				<view class="margin-left-15">
					<view class="text-center bold">{{curInfo.name}}</view>
					<view class="hui1"> {{curInfo.ct_name}} {{curInfo.number_code}}</view>
				</view>
			</view>

			<view class="icon margin-right-10" style="width:20px;height: 20px;"
				:class="curInfo.is_collected==1?'yzx':'wzx'" @click="handleClickDelProduct(curInfo.gid)">
			</view>
		</view>
		<view class="flex mt10 pd10" v-if="curInfo">
			<view class="num-font font-size-24" :style="$util.calcStyleRiseFall(curInfo.rate>0)">
				{{$util.formatNumber(curInfo.current_price)}}
			</view>
			<view class="flex ">
				<span class="num-font margin-left-20" :style="$util.calcStyleRiseFall(curInfo.rate>0)">
					{{$util.formatNumber(curInfo.rate_num)}}
					{{curInfo.rate}}%
				</span>
			</view>
		</view>
		<view class="list1 flex flex-b" v-if="curInfo">
			<view class="flex flex-b item">
				<view class="t2">market price</view>
				<view class="t3">{{$util.formatNumber(curInfo.info.open)}} </view>
			</view>
			<view class="flex flex-b item">
				<view class="t2">high price</view>
				<view class="t3">{{$util.formatNumber(curInfo.info.high)}}
				</view>
			</view>
			<view class="flex flex-b item">
				<view class="t2">trading volume</view>
				<view class="t3">
					{{$util.formatNumber(curInfo.info.volume/10000)}}
				</view>
			</view>
			<view class="flex flex-b item">
				<view class="t2">The previous day's closing price</view>
				<view class="t3">{{$util.formatNumber(curInfo.info.prev_close)}}
				</view>
			</view>
			<view class="flex flex-b item">
				<view class="t2">low price</view>
				<view class="t3">{{$util.formatNumber(curInfo.info.low)}}</view>
			</view>
			<view class="flex flex-b item">
				<view class="t2">transaction amount</view>
				<view class="t3">
					{{$util.formatNumber(parseInt(curInfo.info.volume_valued/10000))}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "StockOverview",
		props: ['info'],
		data() {
			return {
				curInfo:this.info,
			};
		},
		mounted() {
			// console.log(this.info);
		},
		methods: {
			
		}
	}
</script>