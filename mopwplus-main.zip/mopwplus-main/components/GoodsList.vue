<template>
	<view class="common_block" style="padding-bottom: 6px;border-top-left-radius: 12px;border-top-right-radius: 12px;">
		<view
			style="padding:4px 10px;display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between; margin-left: 10px;">
			<view style="padding-left: 10px; font-size: 14px;" @click="click(0)" :style="{color:$util.THEME.TEXT}">NSE
				TOP</view>
			<view style="padding-left: 10px; font-size: 14px; padding-right: 16px;" @click="click(1)" :style="{color:$util.THEME.TEXT}">BSE
				TOP</view>
			<!-- <image mode="aspectFit" src="/static/stock_all.png" :style="$util.calcImageSize(16)"></image> -->
		</view>

		<EmptyData v-if="list && list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view @click="handleDetail(item.co_code)"
				style="display: flex;align-items: center;font-size: 16px;background-color: #F8F7FC;border-radius: 8px;margin:12px;padding: 6px 10px">
				<view style="display: inline-block;flex:44%;padding-left: 6px;" :style="{color:$util.THEME.TEXT}">
					{{item.co_name}}
				</view>
				<text style="display: inline-block;flex:25%;text-align: right;padding-right: 10px;"
					:style="$util.calcStyleRiseFall(item.per_chg>0)">{{$util.formatNumber(item.current_price*1)}}
				</text>
				<view
					style="border-radius: 3px;font-weight: 700; display: inline-block;flex:25%;text-align: right;margin-right: 10px;"
					:style="$util.calcStyleRiseFall(item.per_chg>0)">
					<view style="display: inline-block;padding-right:4px;">
						{{item.per_chg>0?'+':""}}{{(1*item.per_chg).toFixed(2)}}%
					</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "GoodsList",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
				current2: 0
			};
		},
		mounted() {
			this.getList();
		},
		methods: {
			click(item) {
				console.log('item', item);
				this.current2 = item
				this.getList()
			},
			// handleAllList() {
			// 	uni.navigateTo({
			// 		url: `${this.$util.PAGE_URL.STOCK_ALL}?type=0`,
			// 	})
			// },
			handleDetail(code) {
				let type = this.current2 + 1
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}&type=${type}`,
				})
			},
			async getList() {
				let list = await this.$http.post('api/goods/top2', {
					current: this.current2,
					limit: 99
				})
				this.list = list.data.data
				uni.hideLoading()
			},
		}
	}
</script>