<!-- 个人交易 交易信息 -->
<template>
	<view>
		<view class="common_block" style="padding: 10px;">
			<view style="display: flex;align-items: center;">
				<!-- <view style="flex:10%;font-size: 16px;font-weight: 700;" :style="{color:$util.THEME.TIP}">
					205-01-{{info.uid}}
				</view>
				<view class="hui font-size-10" style="flex:10%;">[CMA]{{info.real_name}}</view> -->
				<view style="flex:70%;font-size: 24px;font-weight: 700;" :style="{color:$util.THEME.TEXT_DARK}">
					₹{{$util.formatNumber(info.money)}}
				</view>
				<view class="common_btn btn_secondary" style="width: 20%;margin-top: 10px;transform: scale(0.85);"
					@click="handleDeposit">
					{{$lang.DEPOSIT}}
				</view>
			</view>
		</view>

		<view class="common_block" style="padding:10px;">
			<view
				style="line-height: 2;display: flex; align-items: center;padding: 0 2px;margin: 0 6px 6px 0;background-color: #F8F7FC;border-radius: 6px;">
				<view style="flex:50%;" :style="{color:$util.THEME.TIP}">{{$lang.TOTAL_BUY_AMOUNT}}</view>
				<view style="flex:50%;" :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(info.frozen)}}</view>
			</view>

			<view
				style="line-height: 2;display: flex; align-items: center;padding: 0 2px;margin: 0 6px 6px 0;background-color: #F8F7FC;border-radius: 6px;">
				<view style="flex:50%;" :style="{color:$util.THEME.TIP}">{{$lang.VALUATION_GAIN_LOSS}}</view>
				<view style="flex:50%;" :style="{color:$util.THEME.TEXT}">{{$util.formatNumber(info.holdYingli)}}</view>
			</view>

			<view
				style="line-height: 2;display: flex; align-items: center;padding: 0 2px;margin: 0 6px 6px 0;background-color: #F8F7FC;border-radius: 6px;">
				<view style="flex:50%;" :style="{color:$util.THEME.TIP}">{{$lang.VALUATION_GAIN_LOSS_AMOUNT}}</view>
				<view style="flex:50%;" :style="{color:$util.THEME.TEXT}">{{$util.formatNumber(info.guzhi)}}</view>
			</view>

			<view
				style="line-height: 2;display: flex; align-items: center;padding: 0 2px;margin: 0 6px 6px 0;background-color: #F8F7FC;border-radius: 6px;">
				<view style="flex:50%;" :style="{color:$util.THEME.TIP}">{{$lang.RATE_RESPONSE}}</view>
				<view style="flex:50%;" :style="{color:$util.THEME.TEXT}">{{info.huibao}}%</view>
			</view>

			<view
				style="line-height: 2;display: flex; align-items: center;padding: 0 2px;margin: 0 6px 6px 0;background-color: #F8F7FC;border-radius: 6px;">
				<view style="flex:50%;" :style="{color:$util.THEME.TIP}">{{$lang.AMOUNT_TOTAL}}</view>
				<view style="flex:50%;" :style="{color:$util.THEME.TEXT}">{{$util.formatNumber(info.totalZichan)}}
				</view>
			</view>

			<view
				style="line-height: 2;display: flex; align-items: center;padding: 0 2px;margin: 0 6px 0 0;background-color: #F8F7FC;border-radius: 6px;">
				<view style="flex:50%;" :style="{color:$util.THEME.TIP}">{{$lang.TOTAL_GAIN}}</view>
				<view style="flex:50%;" :style="$util.calcStyleRiseFall(info.totalYingli>0)">
					{{$util.formatNumber(info.totalYingli)}}</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "TradeInfo",
		props:['info'],
		data() {
			return {			};
		},
		mounted() {
		},
		methods: {
			handleDeposit() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_DEPOSIT
				});
			},
		}
	}
</script>