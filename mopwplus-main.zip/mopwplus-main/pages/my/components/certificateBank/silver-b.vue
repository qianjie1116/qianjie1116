<!-- 银转证 -->
<template>
	<view>
		<view class="college-bg">
			<view class="account">
				<view class="college-text">bank transfer certificate</view>
				<view class=""></view>
			</view>
			<!-- 	<view class="progress">¥ {{userInformation.money}}</view>
			<view class="vacancies">현재 사용 가능한 잔액</view> -->
		</view>
		<view class="content">
			To apply for a securities transfer deposit card number for securities transfer, please contact the online customer center.
		</view>
		<!-- <view class="content">
			温馨提醒您:您的银证转入存款卡号仅限当日您申请时段(30分钟内)使用,逾期失效,为保证您的资金安全以及第一时间供您进行交易使用,请您获取转入卡号后第一时间进行银证转入存款,其他时间不可擅自向该卡号转账,若违规转入对您造成任何损失均由您本人自行承担,若有任何疑问您可以随时联系在线客服咨询。
		</view> -->
		<view class="ermai">
			<view class=""></view>
			<!-- <view class="kefu" @tap="customer()">
				<u-icon name="kefu-ermai" color="#B9B9B9" size="28"></u-icon>
				<view class="kefu-text">在线客服</view>
			</view> -->

		</view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				userInformation: "",

			};
		},
		methods: {

			//选项卡
			strike(item) {
				// console.log(item);
				this.current = item.index;
			},
			//选项卡
			changeTab(Inv) {
				that.navIdx = Inv;

			},
			home() {
				uni.switchTab({
					url: this.$util.PAGE_URL.ACCOUNT_CENTER
				});
			},
			//客服
			customer() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.SERVICE
				});
				
			},

			//充值记录
			capitalDetails() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url:`${this.$util.PAGE_URL.ACCOUNT_TRADE_LOG}?index=1`
				});
			},
			//个人信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},

		},

		onLoad(option) {
			this.gaint_info()
		},
		mounted() {
			this.gaint_info()

		}
	}
</script>

<style lang="scss">
	page {
		background: #989898;
	}

	.college-bg {
		padding: 60rpx 30rpx 100rpx;
		// height: 280rpx;
		background: #989898;


		.account {
			display: flex;
			text-align: center;
			justify-content: space-between;
			align-items: center;

			image {
				width: 20rpx;
				height: 40rpx;

			}

			.college-text {

				color: #fff;
				font-weight: 800;
				font-size: 36rpx;
			}
		}

		.progress {
			text-align: center;
			font-size: 52rpx;
			color: #B9B9B9;
			// font-weight: 600;
			margin: 60rpx 0 10rpx;
		}

		.vacancies {
			text-align: center;
			color: #f47b78;
			font-size: 26rpx;
		}
	}

	.content {
		color: #B9B9B9;
		padding: 30rpx;
		font-size: 36rpx;
		font-weight: 600;
		letter-spacing: 0.1em;
	}

	.ermai {
		// display: flex;
		// justify-content: space-between;
		// padding: 30rpx 60rpx;
		position: fixed;
		right: 30rpx;
		bottom: 300rpx;
	}

	.kefu {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}

	/deep/.u-icon {
		background: #FEFEFE !important;
		border-radius: 50% !important;
		width: 80rpx !important;
		height: 80rpx !important;
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.kefu-text {
		color: #B25836;
		font-size: 24rpx;
		margin: 20rpx 0 0;
	}
</style>