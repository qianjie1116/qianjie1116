<!-- 主页 -->
<template>
	<view style="position: relative;">
		<view class="bg_home_header">
			<Header></Header>
		</view>
		<view style="position: absolute;top:60px;left: 50%;transform: translateX(-50%);">
			<image src="/static/home_banner.png" mode="widthFix" style="width: 343px;height: 164px;"></image>
		</view>
		<view style="">
			<view class="common_block">
				<ButtonGroup :btns="$util.BTNS_CONFIG_HOME" :col="22.22"></ButtonGroup>
			</view>
			<!-- 指数 -->
			<template v-if="list.length>0">
				<view style="display: flex;align-items: center;justify-content: space-between;margin:0 4px;">
					<block v-for="(item,index) in list" :key="index">
						<view :class="item.PERCCHANGE>0?'green':'red'"
							style="margin:4px;padding:4px;flex:33.33%;border-radius: 6px;text-align: center;">
							<!-- <view class="name" style="font-size: 11px;">{{item.indxnm}}</view> -->
							<view class="name" style="font-size: 11px;">{{item.name}}</view>
							<view class="price">{{item.pricecurrent}}</view>
							<view>
								<image :src="item.PERCCHANGE>0?'/static/lv.png':'/static/hong.png'" mode="aspectFit"
									style="width: 100px;height: 45px;"></image>
							</view>
							<view class="per">[{{item.PERCCHANGE}}%]</view>
						</view>
					</block>
				</view>
			</template>
			<GoodsList ref="goods"></GoodsList>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import GoodsList from '@/components/GoodsList.vue';
	export default {
		components: {
			Header,
			ButtonGroup,
			EmptyData,
			GoodsList,
		},
		data() {
			return {
				timer: null,
				page: 1,
				gp_index: 0,
				list: [],
				listTitles:['BANKEX','S&P BSE 100','Next 50'],
			}
		},

		onLoad() {		},

		onShow() {
			this.getDataList();
			this.startTimer();
			if (this.$refs.goods) {
				this.$refs.goods.getList();
			}
		},
		onHide() {
			clearInterval(this.timer);
		},

		// onReachBottom() {
		// 	this.page = this.page + 1;
		// 	this.$refs.goods.getList(this.page);
		// },
		onUnload() {
			uni.$off('onSuccess');
		},
		methods: {
			handleIPO() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.TRADE_IPO
				});
			},
			startTimer() {
				this.timer = setInterval(() => {
					// this.$refs.free.getList();
					this.getDataList();
					this.$refs.goods.getList();
				}, 3000);
			},
			// 指数数据
			async getDataList() {
				const result = await this.$http.post('api/goods/zhishu', {})
				if (result.data.code == 0) {
					this.list = result.data.data && result.data.data.length > 3 ? result.data.data.slice(0, 3) : result.data.data;
					// console.log(this.list);
				}
			},
			// 银转证
			async silver() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.SERVICE
				});
			},
		},
	}
</script>

<style>
	.green {
		background: #d8efff;
		color: #16a139;
	}

	.red {
		background: linear-gradient(180deg, rgba(253, 67, 49, .06), rgba(255, 120, 95, .06));
		color: #fd4331;
	}
</style>