<template>
	<view>
		<view class="header_wrapper_10">
			<Header></Header>
		</view>

		<view class="common_block" style="margin: 10px;padding-top: 10px;padding-bottom: 10px;">
			<!-- <view style="padding-left: 10px; font-size: 16px;" :style="{color:$util.THEME.TEXT}">fist</view> -->
			<view style="display: flex;align-items: center;padding:6px 10px;" :style="{color:$util.THEME.TIP}">
				<view style="flex:50%;">{{$lang.STOCK}}</view>
				<view style="flex:25%;text-align: right; padding-right: 16px;">{{$lang.RISE_FALL_AMOUNT}}</view>
				<view style="flex:20%;text-align: right; padding-right: 16px;">{{$lang.RISE_FALL_RATE}}</view>
				<view style="flex:5%;"></view>
			</view>
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view @click="productDetails(item.goods.code,item.id,item.goods.project_type_id)"
					style="display: flex;align-items: center;font-size: 16px;background-color: #F8F7FC;border-radius: 8px;margin:12px;padding: 6px 10px">
					<!-- <view style="flex:15%;font-weight: 900;padding-right: 16px;"
						:style="$util.calcStyleRiseFall(item.goods.rate>0)">{{item.goods.code}}</view> -->
					<view style="flex:50%;" :style="{color:$util.THEME.TEXT}">
						{{item.goods.name}}
					</view>
					<view style="flex:25%;text-align: right; padding-right: 16px;"
						:style="$util.calcStyleRiseFall(item.goods.rate>0)">
						{{$util.formatNumber(item.goods.current_price)}}
					</view>
					<view style="flex:20%;text-align: right; padding-right: 16px;"
						:style="$util.calcStyleRiseFall(item.goods.rate>0)">
						{{item.goods.rate>0?'+':''}}{{item.goods.rate}}%
					</view>
					<view style="flex:5%;">
						<image mode="aspectFit" src="/static/star.png" :style="$util.calcImageSize(12)"
							@click.stop="handleClickDelProduct(item.goods.gid)"></image>
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			Header,
			EmptyData,
		},
		data() {
			return {
				list: [],
				timer: null,
			}
		},
		onShow() {
			this.getList()
			this.startTimer()
		},
		onHide() {
			clearInterval(this.timer);
		},
		computed: {
			best() {
				return this.list.sort((a, b) => b.goods.rate - a.goods.rate).slice(0, 3);
			}
		},
		methods: {
			productDetails(code, id,type) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}&type=${type}`,
				});
			},
			//定时器
			startTimer() {
				this.timer = setInterval(() => {
					this.getList();
				}, 5000);
			},

			async getList() {
				if (this.list.length <= 0) {
					uni.showLoading({
						title: this.$lang.LOADING,
					})
				}
				const result = await this.$http.get(this.$http.API_URL.COLLECT_LIST, {});
				if (this.list.length <= 0 || result.data.code == 0) {
					uni.hideLoading();
				}
				this.list = result.data.data.list;
			},

			// 点击删除
			async handleClickDelProduct(gid) {
				const result = await this.$http.post(this.$http.API_URL.COLLECT_EDIT, {
					gid: gid,
				})
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					this.getList()
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		},
	}
</script>