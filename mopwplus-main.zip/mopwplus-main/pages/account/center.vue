<template>
	<view style="position: relative;">
		<view class="account_center_bg">
			<Header></Header>
		</view>

		<Profile :info="userInfo"></Profile>

		<view class="common_block" style="padding:20px 0;margin: 0 10px;">
			<view style="display: flex;align-items: center;justify-content:space-around;margin-top: 20px;">
				<view>
					<view :style="{color:$util.THEME.TEXT}">{{$lang.AMOUNT_TOTAL}}</view>
					<view style="font-size: 24px;font-weight: 500;" :style="{color:$util.THEME.TEXT_DARK}">
						{{$util.formatNumber(userInfo.totalZichan)}}
					</view>
				</view>
				<view>
					<view :style="{color:$util.THEME.TEXT}">{{$lang.AMOUNT_AVAILABLE}}</view>
					<view style="font-size: 24px;font-weight: 500;" :style="{color:$util.THEME.TEXT_DARK}">
						{{$util.formatNumber(userInfo.money)}}
					</view>
				</view>
			</view>
			<view style="display: flex;align-items: center;justify-content:space-around;margin-top: 20px;">
				<view class="common_btn btn_primary" :style="{color:$util.THEME.TEXT}" @click="handleDeposit()"
					style="margin:0 10px;width: 30vw;">Bank Deposit</view>
				<view class="common_btn btn_secondary" :style="{color:$util.THEME.PRIMARY}" @click="handleWithDraw()"
					style="margin:0 10px;width: 30vw;"> Withdrawal</view>
				<view class="common_btn btn_secondary" :style="{color:$util.THEME.PRIMARY}" @click="handleScore()"
					style=";margin:0 10px;width: 30vw;">Credit Score</view>
			</view>
		</view>

		<NavList :list="$util.funcListConfig(userInfo.is_check)" @action="handleClick"> </NavList>



		<template v-if="isShow">
			<view class="common_mask">
				<view class="common_block common_popup" style="min-height:35vh;margin:auto">
					<view class="popup_header">{{curConfig.title}}</view>
					<template v-if="current==2">
						<view class="common_input_wrapper">
							<image mode="aspectFit" src='/static/user.png' :style="$util.calcImageSize(20)"> </image>
							<input v-model="value1" :placeholder="curConfig.input1ph" type="text"></input>
						</view>
						<view class="common_input_wrapper">
							<image mode="aspectFit" src='/static/bank.png' :style="$util.calcImageSize(20)"> </image>
							<input v-model="value2" :placeholder="curConfig.input2ph" type="text"></input>
						</view>
						<view class="common_input_wrapper">
							<image mode="aspectFit" src='/static/card1.png' :style="$util.calcImageSize(20)"> </image>
							<input v-model="value3" :placeholder="curConfig.input3ph" type="text"></input>
						</view>
					</template>

					<template v-else>
						<view class="common_input_wrapper">
							<image mode="aspectFit" src='/static/password.png' :style="$util.calcImageSize(20)">
							</image>
							<input v-model="value1" :placeholder="curConfig.input1ph" type="password"></input>
						</view>
						<view class="common_input_wrapper">
							<image mode="aspectFit" src='/static/password.png' :style="$util.calcImageSize(20)">
							</image>
							<input v-model="value2" :placeholder="curConfig.input2ph" type="password"></input>
						</view>
					</template>

					<view style="display: flex;justify-content: space-evenly;margin-top: 60px;">
						<view class="common_btn btn_primary" style="flex:30%;margin:0px 30px;" @click="handleConfirm">
							{{$lang.CONFIRM}}
						</view>
						<view class="common_btn btn_secondary" style="flex:30%;margin:0px 30px;" @click="handleCancel">
							{{$lang.CANCEL}}
						</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import Profile from '@/components/Profile.vue';
	import NavList from '@/components/NavList.vue';
	export default {
		components: {
			Header,
			Profile,
			NavList,
		},
		data() {
			return {
				userInfo: {}, // 基本信息
				isShow: false, // 显示弹层
				value1: '', // 第一个输入框
				value2: '', // 第二个输入框
				value3: '', // 第三个输入框，绑卡所需
				current: -1, // 当前显示的弹层
				curConfig: {}, // 弹层中的配置
				cardInfo: {}, // 银行卡信息，显示绑卡信息，或变更绑卡信息
			}
		},
		onShow() {
			this.gaint_info()
			this.is_token()
		},
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: 'Loading',
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.gaint_info()
			uni.stopPullDownRefresh()
		},
		methods: {
			// 提款
			handleWithDraw() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_WITHDRAW
				})
			},
			// 储值
			handleDeposit() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_DEPOSIT
				})
			},
			// 贷款
			handleScore() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.ACCOUNT_CREDIT_SCORE
				})
			},
			// 功能列表，点击事件
			handleClick(val) {
				console.log('val:', val);
				this.current = this.$util.MODE_DIALOG.findIndex(item => item.url == val.url);
				console.log('index:', this.current);
				this.curConfig = {
					title: val.name,
					input1ph: this.current == 2 ? this.$lang.REAL_NAME : this.$lang.NEW_PWD,
					input2ph: this.current == 2 ? this.$lang.BANK_NAME : this.$lang.NEW_PWD2,
					input3ph: this.$lang.BANK_CARD,
					type: this.current == 2 ? 'text' : 'password',
				};
				this.isShow = true;

				// 如果是绑卡弹层，请求已绑卡信息
				if (this.current == 2 && this.cardInfo) {
					this.value1 = this.cardInfo.realname;
					this.value2 = this.cardInfo.bank_name;
					this.value3 = this.cardInfo.card_sn;
				}
			},
			handleCancel() {
				this.isShow = false;
				this.value1 = "";
				this.value2 = "";
				this.value3 = "";
			},
			async handleConfirm() {
				// 根据当前显示弹出，分别处理。其中，变更账户密码与支付密码逻辑相同
				const urls = [this.$http.API_URL.SIGNIN_PASSWORD,
					this.$http.API_URL.PAY_PASSWORD,
					this.$http.API_URL.BIND_BANK_CARD,
				];
				let tempData = {};
				if (this.current == 2) {
					tempData = {
						realname: this.value1,
						bank_name: this.value2,
						card_sn: this.value3,
					}
				} else {
					tempData = {
						newpass: this.value1,
						confirmpass: this.value2,
					};
				}
				let result = await this.$http.post(urls[this.current], tempData);
				if (result.data.code == 0) {
					uni.$u.toast(this.current == 2 ? 'Your bank card information has been successfully submitted.' :
						'It is changed.');
					this.isShow = false;
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(result.data.message);
				}
			},

			// manages() {
			// 	if (this.cardManagement) {
			// 		uni.navigateTo({
			// 			url: this.$util.PAGE_URL.ACCOUNT_BANK_CARD
			// 		});
			// 	} else {
			// 		uni.navigateTo({
			// 			//保留当前页面，跳转到应用内的某个页面
			// 			url: '/pages/my/components/bankCard/renewal'
			// 		});
			// 	}
			// },
			// //版本更新
			// Update() {
			// 	uni.navigateTo({
			// 		url: '/pages/my/components/other/versionUpdate'
			// 	});
			// },
			// //用户协议
			// userAgreement() {
			// 	uni.navigateTo({
			// 		url: '/pages/my/components/other/userAgreement'
			// 	});
			// },
			// //隐私协议
			// privacyAgreement() {
			// 	uni.navigateTo({
			// 		url: '/pages/my/components/other/privacyAgreement'
			// 	});
			// },

			// //关于我们
			// aboutUs() {
			// 	uni.navigateTo({
			// 		url: this.$util.PAGE_URL.ABOUT
			// 	});
			// },
			// //实名认证
			// notCertified() {
			// 	uni.navigateTo({
			// 		url: this.$util.PAGE_URL.ACCOUNT_AUTH
			// 	});
			// },


			//用户信息
			async gaint_info() {
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {
					// language: this.$i18n.locale
				})
				this.userInfo = result.data.data;
				// this.cardManagement = result.data.data.bank_card_info
			},

			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
		},


	}
</script>