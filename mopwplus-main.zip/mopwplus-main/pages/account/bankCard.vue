<!-- 绑定银行卡 -->
<template>
	<view>
		<view class="header_wrapper_10">
			<CustomHeader title="Add Banking Details" @action="handleBack()"></CustomHeader>
		</view>
		<view style="padding-top:3vh;margin:20px;">
			<view style="margin-left: 10px;" :style="{color:$util.THEME.TIP}">Bank Account Number:</view>
			<view class="common_input_wrapper" style="width:90%;height: 30px;line-height: 30px;margin-bottom: 20px;"
				:style="{color:$util.THEME.TEXT}">
				<template v-if="isRenewal">
					<input v-model="card_sn" type="number" placeholder="Enter Bank Account Number" :placeholderStyle="$util.setStylePlaceholder()"></input>
				</template>
				<template v-else>
					<view> {{info.card_sn}}</view>
				</template>
			</view>
			<template v-if="isRenewal">
				<view style="margin-left: 10px;" :style="{color:$util.THEME.TIP}">Re-Enter Bank Account Number:</view>
				<view class="common_input_wrapper"
					style="width:90%;height: 30px;line-height: 30px;margin-bottom: 20px;">
					<input v-model="card_sn2" type="number" placeholder="Re-Enter Bank Account Number" :placeholderStyle="$util.setStylePlaceholder()"></input>
				</view>
			</template>

			<view style="margin-left: 10px;" :style="{color:$util.THEME.TIP}">Bank Account Holder’s Name:</view>
			<view class="common_input_wrapper" style="width:90%;height: 30px;line-height: 30px;margin-bottom: 20px;">
				<template v-if="isRenewal">
					<input v-model="realname" type="text" placeholder="Enter Bank Account Holder’s Name" :placeholderStyle="$util.setStylePlaceholder()"></input>
				</template>
				<template v-else>
					<view> {{info.realname}}</view>
				</template>
			</view>
			<view style="margin-left: 10px;" :style="{color:$util.THEME.TIP}">IFSC Code:</view>
			<view class="common_input_wrapper" style="width:90%;height: 30px;line-height: 30px;margin-bottom: 20px;">
				<template v-if="isRenewal">
					<input v-model="ifcscode" type="text" placeholder="Enter your  IFSC Code" :placeholderStyle="$util.setStylePlaceholder()"></input>
				</template>
				<template v-else>
					<view> {{info.ifcscode}}</view>
				</template>
			</view>
			<view style="margin-left: 10px;" :style="{color:$util.THEME.TIP}">Bank Branch Name:</view>
			<view class="common_input_wrapper" style="width:90%;height: 30px;line-height: 30px;margin-bottom: 20px;">
				<template v-if="isRenewal">
					<input v-model="bank_sub_name" type="text" placeholder="Enter Bank Branch Name" :placeholderStyle="$util.setStylePlaceholder()"></input>
				</template>
				<template v-else>
					<view> {{info.bank_sub_name}}</view>
				</template>
			</view>
			<view style="margin-left: 10px;display: flex;align-items: center;margin-bottom: 20px;"
				:style="{color:$util.THEME.TIP}">
				<view style="flex:50%;">Account Type:</view>
				<view style="flex:50%;">
					<u-radio-group v-model="accountType" placement="row" @change="groupChange">
						<u-radio :customStyle="{marginRight: '20px'}" v-for="(item, index) in radioList" :key="index"
							:label="item.name" :name="item.name" @change="radioChange"
							:activeColor="$util.THEME.PRIMARY" labelSize="11px" :disabled="!isRenewal"
							:labelColor="item.name==accountType?'rgba(51, 51, 51, 1)':'rgba(102, 102, 102, 1)' ">
						</u-radio>
					</u-radio-group>
				</view>
			</view>

			<template v-if="isRenewal">
				<view style="display: flex;align-items: center;justify-content: space-around;"> 
					<view class="common_btn btn_primary" style="width:30%;"
						@click="handleBindBank()">Submit
					</view>
					<view class="common_btn btn_secondary" style="width:30%;" @click="handleCancel()">
						{{$lang.CANCEL}}
					</view>
				</view>
				<view style="margin:20px;" :style="{color:$util.THEME.TIP}">
					<view>
						<text>Standard Disclaimers:</text>
					</view>
					<view>
						In order to ensure the absolute security of your account and the accuracy of transaction
						processes, it is imperative that you provide your genuine and detailed information when filling
						out your banking details. We emphasize the seriousness of this matter, as any inaccuracies in
						the provided information may lead to severe financial losses, for which our company holds no
						responsibility. All withdrawals will strictly be processed to the account held in the name of
						the account holder, ensuring the safety and compliance of transactions.</view>
					<view style="margin-top: 10px;">
						Please treat this step with utmost seriousness, as errors in filling out this information may
						result in extremely serious consequences. Our company disclaims any responsibility for losses
						incurred due to inaccuracies in the information provided. To safeguard your interests, we
						strongly advise a thorough review and confirmation before submitting your banking details. If
						you have any doubts or concerns, please contact our customer service team promptly for
						assistance. This measure is implemented to provide the utmost security for your financial
						well-being, and we appreciate your understanding and cooperation. Rest assured, we are committed
						to ensuring the highest level of protection for your funds and personal information.</view>
				</view>
			</template>
			<template v-else>
				<view class="common_btn btn_primary" style="width:60%;margin: auto;" @click="renewal()">Change</view>
			</template>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				// type账户类型				
				info: {},
				isRenewal: false,
				card_sn: '', // 卡号
				card_sn2: '', // 卡号确认
				realname: '', // 开户人
				ifcscode: '', // IFCS COSE
				bank_sub_name: '', // 支行名
				accountType: 'Current', // 账户类型
				// 账户类型选项组
				radioList: [{
						name: 'Saving',
						disabled: false
					},
					{
						name: 'Current',
						disabled: false
					}
				],
				
			};
		},
		onLoad() {
			this.gaint_info()
		},
		methods: {
			groupChange(n) {
				console.log('groupChange', n);
			},
			radioChange(n) {
				console.log('radioChange', n);
			},
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			renewal() {
				this.isRenewal = true;
			},
			handleCancel() {
				this.isRenewal = false;
				this.gaint_info();
			},

			// 检查卡号二次输入值。
			checkForm() {
				if (this.card_sn !== this.card_sn2) {
					uni.$u.toast('Account number entered twice is inconsistent');
					return false;
				}
				return true;
			},

			//  绑卡
			handleBindBank() {
				if (this.checkForm()) {
					this.replaceBank();
				}
			},

			// 换绑银行卡
			async replaceBank() {
				const result = await this.$http.post(this.$http.API_URL.USER_BIND_CARD, {
					card_sn: this.card_sn, // 卡号
					realname: this.realname, // 开户人
					ifcscode: this.ifcscode, // IFCS COSE
					bank_sub_name:this.bank_sub_name, // 支行名
					type:this.accountType, // 账户类型
				})
				if (result.data.code == 0) {
					uni.$u.toast('Your bank card information has been successfully submitted.');
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			//用户信息
			async gaint_info() {
				const result = await this.$http.get('api/user/info', {})
				console.log(result);
				if (result.data.code == 0) {
					if (!result.data.data.real_name) {
						uni.navigateTo({
							url: this.$util.PAGE_URL.ACCOUNT_AUTH,
						})
					}
					if (!result.data.data.bank_card_info) {
						this.isRenewal = true;
					} else {
						this.info = result.data.data.bank_card_info;
						this.accountType = this.info.type;
					}
				}
			},
		},
	}
</script>