<template>
	<view class="page">
		<view>
			<view class="header flex flex-b" style="background-color: #fddc3c;">
				<view class="icon jiantou" @click="$u.route({type:'navigateBack'});"></view>
				<view class="header-center flex-1" style="color: #000;">REITs</view>
				<view class="icon ss" @click="$u.route({url:$util.PAGE_URL.SEARCH});"></view>
			</view>
		</view>

		<view class="flex margin-top-20 padding-10">
			<view :class="current==0?'top-a':'top'" class="flex-1" @click="sectionChange(0)">
				Introduce
			</view>
			<view :class="current==1?'top-a':'top'" class="flex-1" @click="sectionChange(1)">
				Market
			</view>
			<view :class="current==2?'top-a':'top'" class="flex-1" @click="sectionChange(2)">
				Order
			</view>
		</view>

		<view v-if="current==0" class="padding-20">
			<span>Real Estate Investment Trust (REIT) is an investment vehicle that allows individual investors to
				invest indirectly in real estate projects by purchasing fund shares. REITs are usually managed by a
				management company, which holds and operates a portfolio of real estate assets, including commercial
				real estate, residential real estate, etc.<br><br>

				Investors can capture the returns in the real estate market by purchasing shares or units in a REIT
				without having to buy or hold the property directly. REITs provide a relatively stable investment
				option, usually with high capital preservation and dividend returns.<br><br>

				In the Indian stock market, there are several key differences between buying REITs through an
				institutional account and using a regular stock trading account.<br><br>

				1. Access: Typically, Wealth Management Accounts are held by professional investment institutions or
				companies that manage assets, and they may have wider market access and faster market execution.
				Therefore, it may be more efficient and convenient to purchase REITs through institutional
				accounts.<br><br>

				2. Investment scale: Wealth Management Accounts usually have a larger investment scale and can conduct
				larger transactions. This gives Wealth Management Accounts greater purchasing power and a greater likelihood
				of receiving more favorable trading conditions.<br><br>

				3. Investment purpose: Wealth Management Accounts typically conduct transactions based on more complex
				investment strategies and objectives, including hedging, arbitrage, etc. In contrast, ordinary stock
				trading accounts may be more biased towards long-term investment and value investment.
				<br><br>
				It should be noted that, generally speaking, ordinary investors can purchase REITs through ordinary
				stock trading accounts, but they may need to face some restrictions or conditions, such as minimum
				purchase quantities, transaction fees, etc. Therefore, when choosing which account to purchase REITs
				through, you need to consider your investment purposes, fund size, and market access needs.</span>
		</view>
		<view style="background-color: #fddc3c;justify-content: center;width: 90%;margin-left: 5%;"
			class="radius30 padding-top-20 margin-top-10" v-for="(item,index) in list" @click="buy(index)"
			v-if="current==1">
			<view class="bg-white padding-20" style="height: 100%;border-radius: 0 0px 14px 14px;">
				<view class="flex width100">
					<view class="align-center flex">
						{{item.name}}
					</view>
					<view style="background-color: #8fc2ed;padding:2px 5px;margin-left: auto;" class="radius10">
						<view class="bg-white radius10 hui2"
							style="padding:2px 10px;box-shadow: rgba(99, 99, 99, 0.2) 0px 2px 8px 0px;">Buy</view>
					</view>
				</view>

				<view class="flex width100 margin-top-10">
					<view class="align-center flex font-size-22 bold" style="color: #008000;">
						{{item.syl}}%
					</view>
					<view style="padding:2px 5px;margin-left: auto;color: #489CE5;"
						class="radius10 font-size-18 bold align-center flex">{{item.zhouqi}}Day
					</view>
				</view>

				<view class="flex width100">
					<view class="align-center flex hui1">
						highest return
					</view>
					<view class="align-center flex hui1 left-auto" style="padding:2px 5px;">to give
					</view>
				</view>
			</view>

		</view>

		<view class="overlay" v-if="item_show" @click="item_show=false"></view>
		<view
			style="position: fixed;width: 90%;margin-left: 5%;border-radius: 20px;background-color: #489CE5;bottom: 5%;z-index: 9999;"
			v-if="item_show">
			<view class="color-white  padding-10 flex ">
				<view class="text-center justify-center width100 font-size-16">Experience level</view>

				<u-icon name="/static/market/close.png" size="24" @click="item_show=false"></u-icon>
			</view>

			<view class="bg-white padding-10">
				<view>{{goods_buy.name}}</view>
				<view style="color: #E82D28;" class="bold margin-top-10">{{goods_buy.syl}}%</view>
				<view class="flex margin-top-10"
					style="background-color: #fff;border-radiu;height: 40px;border-radius: 5px;border: 1px #dadbde solid;"
					@click="show=true">
					<view class="flex-1 margin-left-5">{{zhouqi}}</view>
					<view class="margin-right-5">{{syl}}</view>
					<view class="margin-right-5">
						<image src="/static/xiajiantou.png" mode="widthFix" style="width: 10px;"></image>
					</view>
				</view>
				<view class="margin-top-10">
					<u-input type="number" placeholder="Please enter the purchase amount" v-model="price"></u-input>
				</view>
				<view class="margin-top-10 hui1 font-size-12">
					Available purchase balance
					<text style="color: #E82D28; margin-left: 10px;">
						{{$util.formatNumber(userinfo.money)}}
					</text>
				</view>
				<view @click="confirm()" class="padding-10 text-center radius40 margin-top-10 color-white"
					style="background-color: #489CE5;width: 90%;margin-left: 5%;">Buy</view>
			</view>
			<!-- <view  class="text-center padding-20" style="background-color: #fff;border-radius: 0 0 20px 20px;">
				
				<view style="width: 100%;background-color: #3779CD;" class="padding-10 radius10 color-white font-size-16" v-if="Inv==0" @tap="productDetails(info.goods_info.number_code)">구입하다</view>
				
			</view> -->
		</view>

		<view v-if="current==2" style="background-color: #fddc3c;width: 90%;margin-left: 5%;"
			class="radius30 padding-top-20 margin-top-10 justify-center" v-for="(item,index) in order_list">
			<view class="bg-white padding-20" style="height: 100%;border-radius: 0 0px 14px 14px;">
				<u-cell-group>
					<u-cell icon="order" :title="item.goodname" :value="item.zhouqi+' Day'"></u-cell>
					<u-cell title="purchase amount" :value="toThousandFilter(item.price)"></u-cell>
					<u-cell title="period" :value="item.zhouqi+' Day'"></u-cell>
					<u-cell title="Purchase date" :value="item.cretime"></u-cell>
					<u-cell title="deadline" :value="item.endtime"></u-cell>
					<u-cell title="Transaction ID" :value="item.ordersn"></u-cell>

					<u-cell title="Margin (leverage)" :value="item.ganggan"></u-cell>

					<u-cell title="rate of return %" :value="item.fudul"></u-cell>


					<u-cell style="font-weight: 700;" v-if="item.status==1">

						<u-button color="#6db0ea" @click="sell(item.id)" slot="value">sell</u-button>
					</u-cell>

				</u-cell-group>
			</view>
		</view>
		<u-picker :show="show" :columns="columns" keyName="val" cancelText="Cancel" confirmText="Confirm"
			@confirm="confirm1" @cancel="show=false"></u-picker>
	</view>


</template>

<script>
	export default {
		data() {
			return {
				zhouqi: "",
				syl: "",
				show: false,
				type: 0,
				// huobi:"ERC20-USDT",
				columns: [],
				item_show: false,
				ganggan: 1,
				actions: [{
					name: '1',
					index: 1
				}],
				top_list: [{
						name: 'event'
					},
					{
						name: 'Purchase history'
					}

				],
				current: 0,
				top_hg: 80,
				show_js: false,
				title: "",
				content: "",
				show_buy: false,
				list: [],
				jijin_name: '',
				goods_buy: [],
				price: '',
				order_list: [],
				xiangqing_show: false,
				xq_list: [],
				userinfo: "",
				item: []
			};
		},
		onShow() {
			this.getlist()
			this.userInfo()
		},
		methods: {
			confirm(e) {
				console.log('confirm', e)
				this.show = false
				this.huobi = e.value[0]
				if (e.indexs[0] == 2) {
					this.type = 1
				} else {
					this.type = 0
				}
			},
			confirm1(e) {
				console.log('confirm', e)
				this.show=false
				this.zhouqi=e.value[0].zhouqi;
				this.syl=e.value[0].syl;
				
			
			},
			async sell(id) {
				uni.showLoading({
					title: this.$t('index.tkjxz'),
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				uni.showModal({
					content: "Are you sure you want to sell?",
					cancelText: "cancellation",
					confirmText: "check",
					success: (res) => {
						if (res.confirm) {
							this._sell(id)
						} else {
							console.log('cancel') //点击取消之后执行的代码
						}
					}

				})

			},
			async _sell(id) {
				var list = await this.$http.get('api/jijin/sell', {
					id: id,
				})
				uni.hideLoading()
				if (list.data.code == 1) {

					uni.$u.toast(list.data.message);
				} else {
					uni.$u.toast(list.data.message);
					this.getlist()
				}
			},
			toThousandFilter(num) {
				return (+num || 0).toFixed(0).replace(/\d{1,3}(?=(\d{3})+(\.\d*)?$)/g, '$&.')
			},
			Select(e) {
				console.log(e);
				this.ganggan = e.index
				// this.columns = this.detailedData.ganggan
				// console.log(this.title, '99999');
			},
			//实名认证
			async userInfo() {
				let list = await this.$http.get('api/user/fastInfo', {})
				this.userinfo = list.data.data
				if (list.data.code == 1) {
					uni.reLaunch({
						url: this.$util.PAGE_URL.ACCOUNT_SIGNIN
					})
				}
				this.actions = list.data.data.ganggan
			},
			async xiangqing(id) {

				var list = await this.$http.post('api/jijin/info', {
					id: id,

				})

				console.log(list)
				this.xq_list = list.data
				this.xiangqing_show = true
			},
			async buy(index) {

				console.log('index', index);
				this.item_show = true;
				// this.item=data;
				this.columns = [this.list[index].zq_fd]
				this.jijin_name = this.list[index].name
				this.show_buy = true
				this.goods_buy = this.list[index]

				this.zhouqi = this.list[index].zq_fd[0].zhouqi
				this.syl = this.list[index].zq_fd[0].syl
				var list = await this.$http.get('api/jijin/buy', {
					id: this.list[index].id

				})
				console.log(list)

			},
			jieshao(index) {
				console.log(index);
				this.content = this.list[index].content
				this.show_js = true
			},
			confirm() {
				console.log(this.goods_buy);
				var price = this.price
				this.show_buy = false
				uni.showLoading({

				})
				if (!price || price == '') {
					console.log(price);
					// uni.showToast({
					// 	icon:'none',
					// 	title:'请输入金额'
					// })
					uni.$u.toast('Please enter the amount.');
				}


				this.buy_goods(price)
			},
			async buy_goods(price) {

				var list = await this.$http.post('api/jijin/buy', {
					id: this.goods_buy.id,
					price: price,
					ganggan: this.ganggan,
					zhouqi: this.zhouqi,
					fudu: this.syl,
				})
				uni.hideLoading()
				this.item_show = false
				if (list.data.code == 1) {
					this.show_buy = false
					uni.$u.toast(list.data.message);
				} else {
					uni.$u.toast("purchase successfully");
					this.getlist()
				}

			},
			close() {
				this.show_buy = false
				// console.log('close');
			},
			async getlist() {
				var list = await this.$http.get('api/jijin/list')
				console.log("Fund List", list);
				this.list = list.data.jj_list
				this.order_list = list.data.order
			},
			sectionChange(index) {
				console.log(index)
				this.current = index;
				this.getlist()
			},

			home() {
				uni.switchTab({
					url: this.$util.PAGE_URL.HOME
				});
			},
			async fundDetails(i) {
				console.log(i)
				let list = await this.$http.get('api/peizi/index', {
					index: i
				})
				uni.navigateTo({
					url: this.$util.PAGE_URL.SERVICE
				})
				// let list = await this.$http.get('api/app/config', {})
				// window.open(list, '_blank');
			}

		}
	}
</script>

<style lang="scss">
	uni-view,
	uni-text {
		box-sizing: border-box;
	}

	page {
		background-color: #F3F4F8;
	}

	.page {
		padding: 50px 0 0;
	}

	.header {
		height: 60px;
		background: #489ce5;
		box-shadow: 0px 1px 4px 0px rgba(0, 0, 0, .1);
		padding: 20px 16px;
		width: 100vw;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.header-left {
			position: absolute;
			top: 18px;
			left: 16px;
			width: 10px;
			height: 18px;
		}

		.header-center {
			font-size: 16px;
			font-weight: 700;
			color: #fff;
			text-align: center;
		}
	}

	.top-a {
		background-color: #fddd43;
		height: 28px;
		line-height: 28px;
		text-align: center;
		color: #000;
		width: 70px;
		margin: 5px;
	}

	.top {
		background-color: #fff;
		color: #000;
		height: 28px;
		line-height: 28px;
		width: 70px;
		text-align: center;
		border: 1px #b6b6b6 solid;
		margin: 5px;
	}

	/* 遮罩层 */
	.overlay {

		position: fixed;
		/* Stay in place */
		top: 0;
		left: 0;
		width: 100%;
		/* Full width */
		height: 100%;
		/* Full height */
		z-index: 999;
		/* Sit on top */
		background-color: rgba(0, 0, 0, 0.5);
		/* Black background with opacity */
		cursor: pointer;
		/* Add a pointer on hover */
	}
</style>