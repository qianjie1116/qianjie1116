<template>
  <div
    class="container page"
    style="background-color: #1c1e23; min-height: 100vh"
  >
    <van-nav-bar :title="this.lottery.desc" class="nav-bar">
      <template #left>
        <van-icon name="arrow-left" color="#fff" @click="back()" />
      </template>
      <!--      <template #right>-->
      <!--        <div class="right">切换任务</div>-->
      <!--      </template>-->
    </van-nav-bar>

    <div
      style="
        display: flex;
        align-items: center;
        background-color: #1b1b1b;
        padding: 4px 16px;
      "
    >
      <div style="">
        <img
          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACQAAAAdCAYAAADCdc79AAACx0lEQVRYhb2XS2hTQRSGv8TroyoiAQWxvhBqob4gFqsNCi5EceNrUbBSkNIqbrSuFNdKFyoujaAoWlGjoCsLolYFtRhF6UIp6KbVjQuJj2qb3MipE5iee0snbdIfLtz/zJkz/507c85MJP/6AhPADKADqAG2AP1Fh4q3jKDRgIM7NgI9wC6gCtjq2HMl0AasD7QAXsDihqPAWeWZdei5CngLTDF8M/DUdih2hqYBqRAxglzAEkSDJUbQRTpZPV5B8jUfgT2BFnfcDPF8OB5Bx4AnwNJAS3F4D+xWPRaSTrYXSGGXVch6B6YrZ5neQ8BOh2H3mR3nguPAKeVXRbyl1zNbtnNYaWlRD1wyEQ8Cj63op4EmYIVlOyk2maF3wOoSSLFnKAJ8A2JW+3Lgk8UTwDOLZ4D50RKJCcNMZbur+HOg1+JzJKeJoF8hwSaKPNCoYqwxSdTGVcU3iSC/DIIEd4AzynZC8ZTiNRMpHS4QAUOW3zqg0uKypn5avLLcggaBN8pWrdq/WHxuuQURcgKYrfhv633qZAiap/iA4nYyzk6GoLji9laXxLzA4plyC2pT+ahHJcdFsm4s3h81WbUcqA/Z9ucU13npQzRkkZUKOjN/tWpbAfsVf+Hl4TOwrAyCYorrE4MU9bUW/wvcivo+Tb7PgO9DiZ+9vs938zT4Pt0q/mXF70fiLRkvlx+uuHJI32BuEYWjqNQjOQ8dBuoC3z827gGLzRrNKG/5VbXK1i6DeTlfxqUPuD3KENfM4mwLtIyNHyEetSFF9XpFXWtaXrysW2mVI6x0SAKzAq3uWAI8Ut5/gAMF4g251/oOc2VJjXanckBzyK7eEUu0DhZINJuDIp6+bI66bI7zIX1cYnUq3hhLtI6YMddfpnEE6AYuWplYNsRYkFPidmAb8Aq4oTt4Q/8X9Xggv/AlcMVcj7ocgzwwTxDAP8eWD5N5Dy1DAAAAAElFTkSuQmCC"
          style="width: 28px; height: 24px"
        />
      </div>
      <div style="margin-left: auto">
        <img
          src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAK8AAAAnCAYAAAB5cRjAAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA4RpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDcuMS1jMDAwIDc5LjljY2M0ZGU5MywgMjAyMi8wMy8xNC0xNDowNzoyMiAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDo2MTQ0MTFlYS1kZGQ2LTdiNGUtYmQ1Yy00MWQ2YWFjMjMyMGMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NTZFMjZDNTY3MjBGMTFFRTgyNDU4RUI1MTdDODRBOUUiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NTZFMjZDNTU3MjBGMTFFRTgyNDU4RUI1MTdDODRBOUUiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIDIzLjMgKFdpbmRvd3MpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6YjQ0NDM1ZmItN2RhMi1iMzQzLWJiMjktOWQ4ZWMyMDMyMTkzIiBzdFJlZjpkb2N1bWVudElEPSJhZG9iZTpkb2NpZDpwaG90b3Nob3A6OTQxYjYwZjYtYmI1ZC0xODQ1LWJhMzUtOGM4NDk0ZjMyYzYzIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+zYLamwAAB0FJREFUeNrsXVlsVFUY/ltqO6ULLV1oS4dOKaWU1lrKUlEwgGxBlkiKEmNiTPTJxLjFiBqixhh8MD75QPTBxKSJcUmAugQUBUQsskMBW6CttCyFSitq2hrF852ZO7Yw59y5t+feubTnS/5M2zvc5Zzv/Of7lxnibhzYTB5AMrNPmOVF+X5f6N9EwmTSGKkYYHaC2WvMtiW4dNGEEKnGCI6/zuwBPTcaJkhkVsNsC7M6N8gbFyJumuD4cmbr9LxoWOTUG/EuXKhQQtwAs5f1XGjYwDSnyZvNLFeiW99mNlbPg4YNjHGSvKnMJkmOv8isRM+Bhl04Rd7EEDHjBMcRnK3Ww6/hNfIaAZooGMSxDW483B9//kUXL1/hr6oxMPA3P3f3td6YTR6ujXtwCji3k+f3Inn9zFIEx5JDOtenYtJgIJEIp1paqf7TLfxVPXF6+Ll37d0fs8nDtXEPqvBD42H6vGFHeEHi3CrPrxqqU2VZzHIkx+Fxi+2e/NjJFtqzr5H6+vqG/L26qpJqa6ooNeX2jv1AmnPtHXS+4wKNG5dGhQV5VOyfSImJd9j2nCDffffOpdnVFbccf+e9D6i4qIjWrlzCf++6cpVa29tp7uzq22K8VJJ3rEmA9iCzFXZP/u2en+jIsRP8Zwy4v7CAfr9+nU43n+F/x+tj69daJvDPR5po9959pu8bPMlOAF6v8cDBIX/Dc2VmZNCaFUsoK3OcZ0mERWAHzz/1hCfImxAK0EQyZCqzF+yevO38BT6RPp+PEWgZ5U/437nPr51JexoP8uPbv9trmWDpaSmcmCL09ffTxUuXHJ187CgGceElC/NzqZ/JoR/3H+LX3vLlDnp03RrbHtgtyMbRy543EMowRAL07yZmSXZPjkkEFi+YN4S4PK3BJhQEbv+1g2952HqteKmykgA3GbFAIHh6JwDNDikErFy+eMi9BPwFVP9ZA7/+0ZPNEbd+L8HJnckp8uYzk7HlVRM5Ya7dQp5PRDIQeOqUEu69Oi92Kd1ir3R3hz20E2g938k1PLxWpOdbOK+W69b9Bw/bJu/xplNcR480DJe86SHyivAQMyXLMT9P3nCWlBR0/P0DA0oHCFoamJiX68gEdFwILsyK8tLIz812Gjw7FrDVXcXAtZ4ebpGDuss8w2D8PFrImxjKHIgKEeXMnlV1o07rTpHWhlcEeZzKZPT2Xuev2eMzhe+ZkJvNn3/A5sKUZRvwfJBbbgduontyg7xmhQg04iCfqyTCMDwPUj83a14DLWeDuVwEO6pw6GgTf60sL3N8ocg8anpasK+pg0ki0fMPJ8gytCo88HCIbCVgUyHD7JJXVogAsTcyUxbhlJYUc/J+9c2uiFE30l04jrSSqsmF18VEIsMxbUqANEZGwDae5IUI6NyFKm8S2ws8Kwj6/kcf012VFVQSKGTBVA+dOdcW9hbIh6rKAHyxfWc4w+FGigrXNLuOXW+FfLiXy7xukddnkjmAzn3GiRutW7UsnM9FVmFwQl91Ir9h+/fSDIBKJPmCGUSUm0W7hpEpSE+1R16MmVHgcRLYAa0AEm84O6UV8saT/KM8aIHcpErn3hIdMq90//y7eRn4XHtnOKuQk5XJ86GqgEqeIRdWLl3g+IT7C/Lp9C/NdLatI+JEwiMbO0tWZobFMUs01aG5OdnKniWaSuXNQZtb5IXOTZYcfwUZJacnG1F/1fRSR7btHbv3cSKBuOvXrnJFLkwuCg7Z0RNNVF1ZdktWA8UJYFrZVMv3g53IDR0KEtrBcIPraMmLhhvZEq0jRflcGZDnRCcVcqIqt3PoQQSDyIUaxHWrlwBkRWMRtvWtX++k1csXhQmM6p7hzWruLFcyfki3wYOrXJixqvxFQ95kE52LvoXn3LhZDDy2UFWlWvT5Nh46FtaDSMktWzTf9SYYlLcvd13lAenmD+v5Vt/T2xsuLKBsrCKLgoWP8Xukbk3E8xkSAnJjJARshs6NlxD7LRL3NcQURtONKEpH84tRQaudNZPmzKiMSfMLrmkEpLgfQ+NiMd0zp0apppdhXu2MIb+D5Lczef0kbxxHp1jAqw9n1nQDDwuJAI+uOvlvNyCFeQWyMbGaWTBDeWmx5SqmjLzjTXTuUmbeXppRBjUazmcWogneVJE3yUTnYh/boKdw9EK1pLCaBhSR1+hbEOVz8fc3SfxFIq6seqsrf7hd+yMJVj+XFqmJJtYyiwSBGL7hRua/n2RWpSmg4bWADf25sswxlt/jsQwgvOJBjeqVygqVVVi9ttuNM04jbtBXnILI00lc3oUOrmdWpNe8hhcwWDZMInlfwtOauBpeJC/SYpmS982iYKujhoanyIvsgd9EF79E4o/7aGjEjLw5JC9WLCIPV9E0Ri3+jTeRC8DDepw0PIhTIG+yyZsq9DhpeAw3mG2EXPiNgp+CAP6J8MZ3KdirG23nGM45mr7tPIXE1ciRhljPLb4S9DgF/wOerf8JMADoKWHjV3mQ9wAAAABJRU5ErkJggg=="
          style="width: 92px; height: 20px"
        />
      </div>
    </div>

    <!-- <div style="padding: 20px; padding-bottom: 100px">
      <van-tabs animated sticky line-width="100px" :swipeable="true">
        <van-tab title="MY 베팅">
          <div style="padding:20px;">
            111
          </div>
        </van-tab>
        <van-tab title="최근 퀴즈">
          <div style="padding:20px;">
            111
          </div>
        </van-tab>

        <van-tab title="추이 차트">
          <div style="padding:20px;">
            111
          </div>
        </van-tab>
      </van-tabs>
    </div> -->

    <div class="record" style="background-color: #1b1b1b">
      <div class="period">
        <van-image class="cover" :src="this.lottery.ico">
          <template v-slot:loading>
            <van-loading type="spinner" />
          </template>
        </van-image>
        <span class="period-number" style="color: #fff">{{
          this.lottery.now_expect
        }}</span>
        <div class="next-number">
          <span style="color: #fff">{{ this.lottery.next_expect }}</span>
          <van-count-down :time="time" @finish="check()" />
        </div>
      </div>
      <div
        class="linear-gradient"
        style="
          background: linear-gradient(
            to right,
            rgba(126, 86, 120, 0),
            rgb(230, 195, 161),
            rgba(126, 86, 120, 0)
          );
        "
      ></div>
      <div class="recent">
        <div class="kuaisan-ball left">
          <!-- <span class="num">{{ shanzi_1 }}</span>
          <span class="num">{{ shanzi_2 }}</span>
          <span class="num">{{ shanzi_3 }}</span> -->
          <!-- <span class="res-des middle" style="color: #fff">{{ this.sum }}</span> -->
          <!-- <span class="res-des middle" style="color: #fff; width: 20%">{{
            this.size
          }}</span>
          <span class="res-des middle" style="color: #fff; width: 20%">{{
            this.double
          }}</span> -->
          <span class="res-des middle" style="color: #fff; width: 20%"
            >{{ temp1[this.lottery.opencode[0] - 1] }}
            <!-- {{ this.lottery.opencode[0] }} -->
          </span>
          <span class="res-des middle" style="color: #fff; width: 20%"
            >{{ temp1[this.lottery.opencode[1] - 1] }}
            <!-- {{ this.lottery.opencode[1] }} -->
          </span>

          <!-- {{ temp1[this.double+1] }} -->
        </div>
        <van-icon
          name="arrow-down"
          :class="{ up: active, down: !active }"
          color="#FFF"
          @click="active ? (active = false) : (active = true)"
        />
      </div>
    </div>
    <div class="history_popup"></div>
    <div class="wrapper" style="background-color: #1b1b1b">
      <div class="options-bar">
        <div class="game">
          <div class="tips">
            <p class="odds" style="color: #ffcc99">
              【{{ this.lottery.desc }}】
            </p>
            <div class="play-tip">
              <van-icon name="more-o" color="#FFCC99" />
              <span
                class="span-text"
                style="color: #ffcc99"
                @click="$router.push({ path: '/GameRecord' })"
                >미션 기록</span
              >
              <van-popup class="mask" get-container="body" v-model="playgame">
                <div class="play-type-tip">
                  <div class="title">게임 규칙</div>
                  <div class="wrapper">
                    <div class="item">
                      <van-icon name="info-o" />
                      <div class="content">
                        <p class="content-title">게임 기술</p>
                        <p class="content-detail">
                          옵션 양식에서 번호를 선택하고 베팅 값을 입력하세요
                        </p>
                      </div>
                    </div>
                    <div class="item">
                      <van-icon name="comment-o" />
                      <div class="content">
                        <p class="content-title">승리 설명</p>
                        <p class="content-detail">
                          세 장의 복권 총 가치는 11-18 큰 값이고, 총 가치는 3-10
                          작은 값입니다.
                        </p>
                      </div>
                    </div>
                    <div class="item">
                      <van-icon name="description" />
                      <div class="content">
                        <p class="content-title">예를 들어, 베팅.</p>
                        <p class="content-detail">
                          베팅 계획: 소규모 복권 번호: 123, 즉 소형 및 중형
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </van-popup>
            </div>
          </div>
          <div
            class="linear-gradient"
            style="
              background: linear-gradient(
                to right,
                rgba(126, 86, 120, 0),
                rgb(230, 195, 161),
                rgba(126, 86, 120, 0)
              );
            "
          ></div>
          <div class="sumValueTwoSides">
            <div
              class="rectangle large"
              :class="{ active: choose[v.type] }"
              v-for="(v, key) in lottery_peilv_list"
              :key="key"
              @click="choosePlay(v.type, v.name)"
            >
              <div class="wrapper">
                <div class="content">
                  <p class="name-text large">{{ v.name }}</p>
                  <!-- <p class="odd-text large">{{v.proportion}}</p> -->
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="bottom-bar" style="background-color: #1b1b1b !important">
        <div class="bar" style="background-color: #1b1b1b !important">
          <div class="left">
            <div
              class="item"
              @click="shopping ? (shopping = false) : (shopping = true)"
            >
              <van-icon name="cart-o" class="jixuanico" color="#FFF" />
              <span class="text" style="color: #ffcc99">배팅</span>
            </div>
            <div class="line"></div>
          </div>
          <div class="mid">
            <span class="text" style="color: #999; font-size: 10px"
              >배팅 수:</span
            >
            <span class="text num" style="color: #ffcc99; font-size: 12px">{{
              Math.trunc(this.userInfo.money)
            }}</span>
            <span class="text" style="color: #ffcc99"></span>
          </div>
          <div class="right" @click="jiesuan()">완료</div>
        </div>
        <div
          class="wrapper"
          :class="{ active: shopping }"
          style="background-color: #1b1b1b"
        >
          <div class="item">
            <span class="label" style="color: #fff">현재 선택:</span>
            <div class="bet-number">{{ this.shopchoose }}</div>
            <van-icon
              name="arrow-down"
              :class="{ up: !shopping, down: shopping }"
              @click="shopping ? (shopping = false) : (shopping = true)"
            />
          </div>
          <div class="item">
            <span class="label" style="color: #fff">배팅 수:</span>
            <div class="amount-wrapper">
              <van-field
                v-model="money"
                type="digit"
                placeholder="금액을 입력해 주세요"
              />
              <span class="label" style="color: #fff"></span>
            </div>
          </div>
          <!-- <div class="item">
            <div class="part">
              <span style="color: #fff">총</span>
              <span class="number" style="color: #ffcc99">{{
                this.formData.length
              }}</span>
              <span style="color: #fff">주의</span>
            </div>
            <div class="part">
              <span style="color: #fff">총계</span>
              <span class="number" style="color: #ffcc99">{{
                Math.trunc(this.formData.length * this.money)
              }}</span>
              <span style="color: #fff"></span>
            </div>
          </div> -->
        </div>
      </div>
      <van-popup v-model="jiesuanpage" get-container="body">
        <div
          class="confirm-order-modal"
          style="background-color: #1b1b1b !important"
        >
          <div class="head van-hairline--bottom">
            <p class="text">작업 목록</p>
          </div>
          <ui class="list">
            <li
              v-for="(v, key) in formData"
              :key="key"
              class="lise-item van-hairline--bottom"
            >
              <div class="main">
                <p class="bet-name">{{ v.name }}</p>
                <p class="detail-text">
                  1 Attention X{{ money }}₩={{ money }}₩
                </p>
              </div>
              <van-icon @click="clearChooes(v.type)" name="close" />
            </li>
          </ui>
          <div class="sub-bar">
            <van-button
              class="item cancel-btn"
              type="default"
              @click="allClear()"
              style="background-color: transparent; font-size: 13px"
              >취소</van-button
            >
            <van-button
              class="item sub-btn"
              style="background-color: transparent; font-size: 13px"
              type="default"
              @click="doSub"
              >투표 확인</van-button
            >
          </div>
        </div>
      </van-popup>
      <van-popup v-model="active" position="top" :style="{ height: '70%' }">
        <van-pull-refresh
          v-model="isLoading"
          @refresh="onRefresh"
          success-text="Success"
          style="background-color: #f0f0f0"
        >
          <template #pulling> 새로 고치려면 아래로 스크롤하세요 </template>
          <template #loosing> 새로 고치려면 아래로 스크롤하세요 </template>
          <template #loading> 로딩 중 </template>

          <div class="wrapper" style="background-color: #1b1b1b !important">
            <div class="item">
              <div class="left font-weight" style="color: #aaa">주기 수</div>
              <div class="right font-weight" style="color: #aaa">번역</div>
            </div>
            <div class="item" v-for="(v, key) in lottery_list" :key="key">
              <div
                class="left font-weight"
                style="
                  color: #ccc;
                  width: max-content;
                  padding-left: 24px;
                  padding-right: 40px;
                  font-size: 14px;
                "
              >
                {{ v.expect }}
              </div>
              <div class="right font-weight">
                <div class="kuaisan-ball left">
                  <!-- <span class="num">
                    {{ v.opencode[0] }}
                  </span>
                  <span class="num">
                    {{ v.opencode[1] }}
                  </span>
                  <span class="num">
                    {{ v.opencode[2] }}
                  </span> -->
                  <!-- <van-image class="res-img" :src="'img/lottery/shaizi/' + v.opencode[0] + '.png'">
                            <template v-slot:loading>
                              <van-loading type="spinner"/>
                            </template>
                          </van-image> -->

                  <!-- <van-image class="res-img" :src="'img/lottery/shaizi/' + v.opencode[1] + '.png'">
                            <template v-slot:loading>
                              <van-loading type="spinner"/>
                            </template>
                          </van-image> -->
                  <!-- <van-image class="res-img" :src="'img/lottery/shaizi/' + v.opencode[2] + '.png'">
                            <template v-slot:loading>
                              <van-loading type="spinner"/>
                            </template>
                          </van-image> -->
                  <!-- <span class="res-des middle" style="color: #fff">{{
                    v.opencode[0] + v.opencode[1] + v.opencode[2]
                  }}</span> -->

                  <span
                    class="res-des middle"
                    style="
                      color: #fff;
                      width: max-content;
                      padding-right: 12px;
                      min-width: 60px;
                    "
                    >{{ temp1[v.opencode[0] - 1] }}
                  </span>
                  <!-- {{(v.opencode[0] + v.opencode[1] + v.opencode[2]) >= 11 && (v.opencode[0] + v.opencode[1] + v.opencode[2]) &lt;= 18 ? "장미" : "캔디"}} -->
                  <span
                    class="res-des middle"
                    style="color: #fff; width: max-content; min-width: 80px"
                    >{{ temp1[v.opencode[1] - 1] }}
                    <!-- {{ v.opencode[1] }} -->
                    <!-- {{
                      (v.opencode[0] + v.opencode[1] + v.opencode[2]) % 2 === 0
                        ? "요트"
                        : "비행기"
                    }} -->
                  </span>
                </div>
              </div>
            </div>
          </div>
        </van-pull-refresh>
      </van-popup>
    </div>
  </div>
</template>

<script>
var time;
var count = 0;
export default {
  data() {
    return {
      jiesuanpage: false,
      choose: {
        A: false,
        B: false,
        C: false,
        D: false,
        3: false,
        4: false,
        5: false,
        6: false,
        7: false,
        8: false,
        9: false,
        10: false,
        11: false,
        12: false,
        13: false,
        14: false,
        15: false,
        16: false,
        17: false,
        18: false,
      },
      playgame: false,
      shopping: false,
      isLoading: false,
      play: {},
      lottery_peilv_list: {},
      lottery_list: {},
      active: false,
      userInfo: {},
      lottery: {},
      shanzi_1: "0",
      shanzi_2: "0",
      shanzi_3: "0",
      sum: 0,
      size: "",
      double: "",
      time: 0,
      shopchoose: "선택되지 않음",
      gameitem: "",
      formData: [],
      money: "",
      temp1: [`복`, `록`, `수`, `희`],
    };
  },
  methods: {
    back() {
      return window.history.back();
    },
    doSub() {
      if (this.money === "0") {
        this.$toast("금액이 틀렸습니다!");
        return false;
      }
      if (this.formData.length === 0) {
        this.$toast("C 숫자를 선택하세요!");
        return false;
      } else if (this.money === "") {
        this.$toast("금액을 입력해 주세요!");
        return false;
      } else {
        if (this.userInfo.money - this.money * this.formData.length < 0) {
          this.$toast(
            "잔액이 부족합니다. 충전을 위해 고객 서비스에 문의해 주세요!"
          );
          return false;
        } else {
          this.$http({
            method: "post",
            data: {
              item: this.gameitem,
              money: this.money,
              lid: this.lottery.id,
              mid: this.userInfo.id,
              expect: this.lottery.now_expect,
            },
            url: "game_place_order",
          }).then((res) => {
            if (res.code === 200) {
              this.$toast(res.msg);
              this.allClear();
              this.getUserInfo();
            } else if (res.code === 401) {
              this.$toast(res.msg);
            }
          });
          return true;
        }
      }
    },
    allClear() {
      for (var i = 0; i < this.formData.length; i++) {
        this.choose[this.formData[i]["type"]] = false;
      }
      this.formData.length = 0;
      this.money = "";
      this.shopchoose = "선택되지 않음";
      this.gameitem = "";
      this.shopping = false;
      this.jiesuanpage = false;
    },
    jiesuan() {
      if (this.formData.length === 0) {
        this.$toast("개의 숫자를 선택하세요!");
        return false;
      } else if (this.money === "") {
        this.$toast("금액을 입력해 주세요!");
        return false;
      } else {
        this.doSub();
        // this.jiesuanpage
        //   ? (this.jiesuanpage = false)
        //   : (this.jiesuanpage = true);
      }
    },
    clearChooes(type) {
      for (var i = 0; i < this.formData.length; i++) {
        if (type === this.formData[i]["type"]) {
          this.formData.splice(i, 1);
          this.choose[type] = false;
        }
      }
      if (this.formData.length >= 1) {
        for (var j = 0; j < this.formData.length; j++) {
          if (j === 0) {
            this.shopchoose = this.formData[j]["name"];
            this.gameitem = this.formData[j]["type"];
          } else {
            this.shopchoose += "," + this.formData[j]["name"];
            this.gameitem += "," + this.formData[j]["type"];
          }
        }
      } else {
        this.shopchoose = "선택되지 않음";
        this.gameitem = "";
        this.shopping = false;
      }
      if (this.formData.length === 0) {
        this.jiesuanpage = false;
      }
    },
    choosePlay(type, name) {
      if (this.choose[type] === true) {
        this.choose[type] = false;
        for (var i = 0; i < this.formData.length; i++) {
          if (type === this.formData[i]["type"]) {
            this.formData.splice(i, 1);
          }
        }
      } else if (this.choose[type] === false) {
        this.formData.push({ name: name, type: type });
        this.choose[type] = true;
      }
      if (this.formData.length === 1) {
        this.shopping = true;
      }
      if (this.formData.length >= 1) {
        for (var j = 0; j < this.formData.length; j++) {
          if (j === 0) {
            this.shopchoose = this.formData[j]["name"];
            this.gameitem = this.formData[j]["type"];
          } else {
            this.shopchoose += "," + this.formData[j]["name"];
            this.gameitem += "," + this.formData[j]["type"];
          }
        }
      } else {
        this.shopchoose = "선택되지 않음";
        this.gameitem = "";
        this.shopping = false;
      }
    },
    check() {
      if (!localStorage.getItem("token")) {
        this.$router.push({ path: "/Login" });
      } else {
        time = window.setInterval(() => {
          setTimeout(() => {
            this.getUserInfo();
            this.getLotteryInfo();
            this.getLotteryList();
            count++;
            if (count > 5) {
              clearInterval(time);
              count = 0;
            }
          }, 0);
        }, 300);
      }
    },
    onRefresh() {
      setTimeout(() => {
        this.$toast("성공");
        this.getLotteryList();
        this.isLoading = false;
      }, 200);
    },
    getUserInfo() {
      this.$http({
        method: "get",
        url: "user_info",
      }).then((res) => {
        if (res.code === 200) {
          this.userInfo = res.data;
        } else if (res.code === 401) {
          this.$toast(res.msg);
        }
      });
    },
    getLotteryPeilv() {
      this.$http({
        method: "get",
        data: { id: this.$route.query.id },
        url: "lottery_get_peilv",
      }).then((res) => {
        if (res.code === 200) {
          console.log(`lottery_peilv_list:`, res.data);
          this.lottery_peilv_list = res.data;
          // this.lottery_peilv_list.forEach((item) => {
          //   // 장미, 캔디, 비행기, 요트
          //   item.name = item.name
          //     .replace("大", "장미")
          //     .replace("小", "캔디")
          //     .replace("单", "비행기")
          //     .replace("双", "요트");
          //   item.type = item.type
          //     .replace("大", "장미")
          //     .replace("小", "캔디")
          //     .replace("单", "비행기")
          //     .replace("双", "요트");
          // });
          this.lottery_peilv_list.splice(4, this.lottery_peilv_list.length - 1);
        } else if (res.code === 401) {
          this.$toast(res.msg);
        }
      });
    },
    getLotteryList() {
      this.$http({
        method: "get",
        data: { key: this.$route.query.key },
        url: "lottery_get_one_list",
      }).then((res) => {
        if (res.code === 200) {
          this.lottery_list = res.data;
          console.log("lottery_list===??===>", this.lottery_list);
          this.getLotteryPeilv();
        } else if (res.code === 401) {
          this.$toast(res.msg);
        }
      });
    },
    getLotteryInfo() {
      this.$http({
        method: "get",
        data: { key: this.$route.query.key },
        url: "lottery_get_info",
      }).then((res) => {
        if (res.code === 200) {
          if (
            parseFloat(this.userInfo.money) < parseFloat(res.data.condition)
          ) {
            this.$toast("이 작업을 요청하려면 관리자에게 연락해 주세요");
            this.$router.push({ path: "/Home" });
            return false;
          }
          this.lottery = res.data;
          console.log(`!!!`, this.lottery);
          this.lottery.desc = this.lottery.desc.replace("分钟", "분");
          this.time = res.data.second * 1000;

          if (this.time / 1000 === 59) {
            this.$toast("로또 당첨 성공：" + this.lottery.now_expect);
          }
          if (res.data?.opencode) {
            this.shanzi_1 = res.data?.opencode[0];
            this.shanzi_2 = res.data?.opencode[1];
            this.shanzi_3 = res.data?.opencode[2];
            this.sum =
              res.data?.opencode[0] +
              res.data?.opencode[1] +
              res.data?.opencode[2];
          }

          if (this.sum >= 11 && this.sum <= 18) {
            this.size = "복";
          } else if (this.sum >= 3 && this.sum <= 10) {
            this.size = "록";
          }
          if (this.sum % 2 === 0) {
            this.double = "수";
          } else {
            this.double = "희";
          }
        } else if (res.code === 401) {
          this.$toast(res.msg);
        }
      });
    },
  },
  created() {
    if (!localStorage.getItem("token")) {
      this.$router.push({ path: "/Login" });
    } else {
      this.getUserInfo();
      this.getLotteryInfo();
      this.getLotteryList();
    }
  },
  destroyed() {
    clearInterval(time);
  },
};
</script>

<style lang="less" scoped>
::v-deep .van-tabs__nav {
  background-color: transparent !important;
}
::v-deep .van-tab__text {
  color: #ffcc99;
  font-size: 28px;
}
::v-deep .van-tabs__line {
  background-color: #ffcc99 !important;
}

::v-deep .van-popup {
  background-color: #1b1b1b;
}

@import "../../assets/css/base.css";
.nav-bar .right {
  padding-left: 8px;
  padding-right: 8px;
  color: #fff;
  font-size: 28px;
  border-radius: 10px;
  border: 2px solid #fff;
  line-height: 60px;
}
.record {
  padding-left: 20px;
  padding-right: 20px;
  background-color: transparent;
  box-shadow: 0 2px 2px 0 #cacaca;
  z-index: 1;
}
.record .period {
  display: flex;
  align-items: center;
  padding: 20px 0;
}
.record .period .cover {
  width: 60px;
  height: 60px;
  -o-object-fit: cover;
  object-fit: cover;
}
.record .period .period-number {
  flex: 1;
  margin-left: 20px;
  margin-right: 10px;
  height: 50px;
  line-height: 50px;
  font-size: 35px;
  font-weight: 700;
  color: #000;
}
.van-count-down {
  color: #ff253f;
  font-size: 45px;
  margin-top: 10px;
  float: right;
}
.linear-gradient {
  width: 100%;
  height: 2px;
}
.record .recent {
  display: flex;
  align-items: center;
  height: 110px;
}
.kuaisan-ball .left {
  justify-content: flex-start;
}
.kuaisan-ball .num {
  font-size: 45px;
  color: #ffcc99;
  padding-right: 20px;
  font-weight: 700;
}
.kuaisan-ball {
  flex: 1;
  display: flex;
  align-items: center;
}

.kuaisan-ball .res-img {
  width: 70px;
  height: 70px;
  margin-right: 30px;
}
.kuaisan-ball .res-des {
  font-weight: 700;
  text-align: center;
  color: #000;
}
.kuaisan-ball .res-des.middle {
  width: 15%;
  font-size: 35px;
}
.van-icon {
  font-size: 40px;
}
.down {
  transition: all 0.5s;
}
.up {
  transform: rotate(180deg);
  transition: all 0.5s;
}
.wrapper {
  position: relative;
  flex: 1;
  overflow: hidden;
}
.options-bar {
  display: flex;
  align-items: center;
  height: calc(100% - 80px);
}
.options-bar .game {
  flex: 1;
  height: 100%;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}
.options-bar .game .tips {
  display: flex;
  align-items: center;
  height: 100px;
  padding: 0 20px;
}
.options-bar .game .tips .odds {
  flex: 1;
  font-size: 35px;
  font-weight: 500;
  color: #ff253f;
}
.options-bar .game .tips .play-tip {
  display: flex;
  align-items: center;
  height: 100%;
}
::v-deep .van-icon-more-o {
  color: #ff253f;
  font-size: 50px;
}
.options-bar .game .tips .play-tip .span-text {
  margin-left: 10px;
  font-size: 35px;
  font-weight: bolder;
  color: #ff253f;
}
.linear-gradient {
  width: 100%;
  height: 2px;
}
.sumValueTwoSides {
  display: flex;
  padding: 30px 0;
  flex-direction: row;
  align-items: center;
  justify-content: flex-start;
  flex-wrap: wrap;
}
.rectangle {
  overflow: hidden;
}
.rectangle.large {
  margin: 0 0 30px 4%;
  width: 20%;
  border-radius: 10px;
}
.rectangle .wrapper {
  position: relative;
  padding: 0 10px;
  background: #fff;
}
.rectangle .wrapper .content {
  position: absolute;
  display: flex;
  top: 0;
  left: 0;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 100%;
  height: 100%;
}
.rectangle.large .wrapper {
  padding-bottom: 100%;
}
.rectangle .wrapper .content .name-text.large {
  font-size: 45px;
}
.rectangle .wrapper .content .name-text {
  color: #7d7c7c;
  font-weight: bolder;
}
.rectangle .wrapper .content .odd-text.large {
  font-size: 25px;
  margin-top: -30px;
}
.rectangle .wrapper .content .odd-text {
  text-align: center;
  color: #ff253f;
}
.bottom-bar {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 0;
  height: 100px;
  z-index: 2;
}
.bottom-bar .bar .left,
.bottom-bar .bar {
  display: flex;
  flex-direction: row;
  align-items: center;
}
.bottom-bar .bar {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 100px;
  background-color: #fff;
  box-shadow: 0 0 20px 0 #cacaca;
  z-index: 2;
}
.bottom-bar .bar .left,
.bottom-bar .bar {
  display: flex;
  flex-direction: row;
  align-items: center;
}
.bottom-bar .bar .left .item {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  width: 180px;
  font-size: 20px;
}
.bottom-bar .bar .left .item .text {
  font-size: 22px;
  color: #7d7c7c;
}
.jixuanico {
  font-size: 45px;
}
.bottom-bar .bar .left .line {
  width: 2px;
  height: 50px;
  background: #dadada;
}
.bottom-bar .bar .mid {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: flex-end;
}
.bottom-bar .bar .mid .text {
  font-size: 16px;
  font-weight: 500;
  color: #333;
}
.bottom-bar .bar .mid .text.num {
  margin: 0 15px;
  color: #ff253f;
}
.bottom-bar .bar .right {
  padding: 0 25px;
  margin: 0 30px;
  color: #fff;
  background: linear-gradient(270deg, #e6c3a1, #7e5678);
  font-size: 20px;
  font-weight: 500;
  height: 60px;
  line-height: 60px;
  border-radius: 50px;
}
.rectangle.active .wrapper {
  background-color: #ff253f !important;
}

::v-deep .van-pull-refresh__track .van-pull-refresh__head * {
  color: #000000;
  font-size: 35px;
}
::v-deep .van-popup {
  position: absolute;
}
::v-deep .van-overlay {
  position: absolute;
  background-color: rgb(70 67 67 / 70%);
}
::v-deep .van-popup--top {
  top: -1px;
}
.wrapper .item {
  display: flex;
  flex-direction: row;
  align-items: center;
  padding: 10px 0;
}
.wrapper .item .left {
  width: 40%;
  font-size: 30px;
  text-align: center;
  font-weight: 500;
  color: #000;
}
.font-weight {
  font-weight: 700 !important;
}
.wrapper .item .right {
  flex: 1;
  display: flex;
  font-size: 30px;
  justify-content: center;
  overflow: hidden;
  color: #000;
}
.wrapper .item .kuaisan-ball .left {
  justify-content: flex-start;
}
.wrapper .item .kuaisan-ball {
  margin-left: 20px;
  flex: 1;
  display: flex;
  align-items: center;
}
.wrapper .item .kuaisan-ball .res-img {
  width: 50px;
  height: 50px;
  margin-right: 20px;
}
.wrapper .item .kuaisan-ball .res-des {
  font-weight: 700;
  text-align: center;
  color: #000;
}
.wrapper .item .kuaisan-ball .res-des.middle {
  width: 15%;
  font-size: 35px;
}
.play-type-tip {
  position: unset;
  margin: auto;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: 650px;
  height: 700px;
  max-height: 50%;
  z-index: 10;
  border-radius: 30px;
  overflow: hidden;
  background-color: #fff;
  color: #000;
}
.play-type-tip .title {
  line-height: 90px;
  background: linear-gradient(90deg, #775fd9, #ffcc99);
  text-align: center;
  color: #fff;
  font-size: 35px;
  font-weight: 500;
}
.mask {
  background-color: rgb(0 0 0 / 0%);
  animation-duration: 0.35s;
}
.play-type-tip .wrapper {
  height: calc(100% - 10px);
  background-color: transparent;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}
.play-type-tip .wrapper .item {
  padding: 40px 50px;
  display: flex;
  align-items: flex-start;
}
.play-type-tip .wrapper .item .van-icon {
  color: #e6c3a1;
  font-size: 60px;
}
.play-type-tip .wrapper .item .content .content-title {
  margin-top: 22px;
  font-size: 35px;
  font-weight: 500;
  color: #000;
  line-height: 0px;
}
.play-type-tip .wrapper .item .content .content-detail {
  margin-top: 5px;
  font-size: 22px;
  color: #000;
  line-height: 30px;
}
.play-type-tip .wrapper .item .content {
  flex: 1;
  margin-left: 30px;
}
.rectangle .wrapper {
  background-color: transparent !important;
  border: 1px solid #ffcc99;
}
.rectangle.active .wrapper {
  background-color: transparent !important;
}
.rectangle.active .wrapper .name-text,
.rectangle.active .wrapper .odd-text {
  color: #ffcc99 !important;
}
.bottom-bar .wrapper {
  position: absolute;
  top: 10px;
  left: 0;
  right: 0;
  padding: 20px 20px 10px 20px;
  height: 230px;
  background-color: #fff;
  z-index: 1;
  box-shadow: 0 0 10px 0 #cacaca;
  transition: transform 0.3s cubic-bezier(0.21, 1.02, 0.55, 1.01);
}
.bottom-bar .wrapper.active {
  transform: translateY(-100%);
}
.bottom-bar .wrapper .item {
  position: relative;
  display: flex;
  flex-direction: row;
  align-items: center;
  height: 65px;
}
.bottom-bar .wrapper .item .label {
  font-size: 30px;
  line-height: 30px;
  color: #000;
}
.bottom-bar .wrapper .item .bet-number {
  flex: 1;
  margin: 0 16px;
  overflow: auto;
  white-space: nowrap;
  -webkit-overflow-scrolling: touch;
  color: #ffcc99 !important;
  font-size: 30px;
  font-weight: 500;
  height: 40px;
  line-height: 40px;
}
.bottom-bar .wrapper .item .amount-wrapper {
  flex: 1;
  display: flex;
  flex-direction: row;
  align-items: center;
}
.van-cell {
  font-size: 30px;
  line-height: 50px;
}
.bottom-bar .wrapper .item .part {
  margin-right: 20px;
}
.bottom-bar .wrapper .item .part span {
  font-size: 30px;
  vertical-align: center;
  color: #000;
}
.bottom-bar .wrapper .item .part .number {
  margin: 0 5px;
  color: #ff253f;
  font-weight: 500;
}
::v-deep .van-field__control {
  color: #ff253f;
}
.confirm-order-modal {
  position: unset;
  display: flex;
  flex-direction: column;
  margin: auto;
  padding: 0 20px 30px;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  width: 610px;
  height: 680px;
  max-height: 50%;
  z-index: 10;
  background-color: #fff;
  border-radius: 30px;
}
.confirm-order-modal .head {
  position: relative;
  height: 80px;
}
.confirm-order-modal .head .text {
  padding: 0 20px;
  height: 30px;
  line-height: 10px;
  text-align: center;
  font-size: 35px;
  font-weight: 500;
  color: #7e5678;
}
::v-deep .confirm-order-modal .van-hairline--bottom::after {
  border-bottom-width: 2px;
}
.van-popup--center {
  border-radius: 30px;
}
.confirm-order-modal .list {
  flex: 1;
  padding: 0 10px;
  overflow-y: auto;
  -webkit-overflow-scrolling: touch;
}
.confirm-order-modal .list .lise-item {
  display: flex;
  flex-direction: row;
  align-items: center;
  padding: 10px 0;
}
.confirm-order-modal .list .lise-item .main {
  flex: 1;
  overflow: hidden;
}
.confirm-order-modal .list .lise-item .main .bet-name {
  color: #ff253f;
  font-size: 35px;
  font-weight: 500;
  line-height: 0px;
  word-wrap: break-word;
  word-break: break-all;
}
.confirm-order-modal .list .lise-item .main .detail-text {
  line-height: 0px;
  font-size: 25px;
  color: #979799;
}
.confirm-order-modal .list .lise-item {
  color: #ff253f;
}
.confirm-order-modal .sub-bar {
  display: flex;
  align-items: center;
  margin-top: 30px;
  justify-content: space-around;
}
.confirm-order-modal .sub-bar .item {
  min-width: 40%;
  height: 80px;
  text-align: center;
  box-sizing: border-box;
  border-radius: 50px;
  font-size: 35px;
  font-weight: 500;
}
.confirm-order-modal .sub-bar .item.cancel-btn {
  border: 2px solid #979799;
  color: #979799;
  background-color: #fff;
}
.confirm-order-modal .sub-bar .item.sub-btn {
  // background: linear-gradient(270deg, #e6c3a1, #7e5678);
  background-color: transparent !important;
  color: #ffcc99;
  border: 1px solid #ffcc99;
}
.next-number span {
  font-size: 35px;
  font-weight: 700;
  color: #000;
  float: right;
}
</style>
