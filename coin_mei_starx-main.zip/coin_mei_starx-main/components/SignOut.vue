<template>
	<view class="common_btn"
		style="margin:40rpx auto; width: 80%;background-color: #F8F8FA;border-radius: 24rpx;border:none;color:#999999;"
		@click="handleSignOut()">
		{{$lang.BTN_SIGN_OUT}}
	</view>
</template>

<script>
	export default {
		name: 'SignOut',
		methods: {
			// 登出
			handleSignOut() {
				try {
					let version = uni.getStorageSync('version')
					uni.removeStorageSync('token');
					uni.setStorageSync('version', version);
				} catch (e) {
					// error
				}
				uni.showToast({
					title: this.$lang.TIP_SIGN_OUT_SUCCESS,
					icon: 'none'
				});
				setTimeout(() => {
					uni.navigateTo({
						url: this.$CONSTANTS.ACCOUNT_ACCESS
					});
					this.$router.go(0)
				}, 500)
			}
		}
	}
</script>

<style>
</style>