<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view
				style="background-color: #FFFFFF; padding:20rpx 30rpx;border-radius: 28rpx;line-height: 1.8;margin:0 20rpx 20rpx 20rpx;">
				<view style="text-align: right;" :style="{color:$theme.RISE}">
					{{item.desc_type}}
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view :style="{color:$theme.LOG_LABEL}">
						{{$lang.LOG_TRADE_DW}}[{{$lang.CURRENCY_UNIT}}]
					</view>
					<view :style="{color:$theme.PRIMARY}" style="font-size: 18px;">
						{{$util.formatMoney(item.money)}}
					</view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.LOG_TRADE_ORDER_SN}}</view>
					<view :style="{color:$theme.LOG_LABEL}">
						{{item.order_sn}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.LOG_TRADE_CREATE_TIME}}</view>
					<view :style="{color:$theme.LOG_LABEL}">
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view :style="{color:$theme.LOG_LABEL}">{{$lang.LOG_TRADE_DW_DESC}}</view>
					<view :style="{color:$theme.LOG_LABEL}">
						{{item.reason}}
					</view>
				</view>
				<!-- <view style="display: flex;align-items: center;justify-content: space-between;">
					<view style="flex:6%;">
						<image :src="item.icon" :style="$theme.setImageSize(24)"></image>
					</view>
					<text style="flex:97%;white-space:pre-wrap;" :style="{color:item.color}">{{item.text}}</text>
				</view> -->
			</view>
		</block>
	</view>
</template>

<script>

	export default {
		name: "LogDeposit",

		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList()
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.get(`api/user/recharge`);
				this.list = result || [];
			},
		}
	}
</script>

<style>

</style>