<template>
	<view>
		<template v-if="logo && logo != '' && $util.isImageUrl(logo)">
			<image :src="setLogo" mode="aspectFit" :style="$theme.setImageSize(size)" style="border-radius:100%;">
			</image>
		</template>
		<template v-else>
			<view class="logo"
				:style="{backgroundColor:$theme.PRIMARY,lineHeight:size+`rpx`,...$theme.setImageSize(size)}">
				{{setLogo}}
			</view>
		</template>
	</view>
</template>

<script>
	export default {
		name: "CustomLogo",
		props: {
			logo: {
				type: String,
				default: '',
			},
			// 股票名字，用于切出第一个字符作为LOGO
			name: {
				type: String,
				default: '',
			},
			size: {
				type: Number,
				default: 60
			}
		},
		computed: {
			setLogo() {
				// console.log(`logo:`, this.logo);
				if (this.logo && this.logo != '' && this.$util.isImageUrl(this.logo)) {
					return this.$util.setLogo(this.logo);
				} else {
					return this.name && this.name.length > 0 ? this.name[0] : '';
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	.logo {
		text-align: center;
		color: #FFFFFF;
		border-radius: 100%;
		font-size: 18px;
		text-transform: uppercase;
	}
</style>