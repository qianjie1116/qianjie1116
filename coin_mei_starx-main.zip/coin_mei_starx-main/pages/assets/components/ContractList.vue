<template>
	<view>
		<view style="display: flex;align-items: center;justify-content: center;">
			<view class="common_card_bg card_bg_5" style="width: 640rpx;background-color: #FFFFFF;">
				<CardItemPrimary :info="info" :labels="cardLabels"></CardItemPrimary>
			</view>
		</view>

		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view class="common_block" style="border-radius: 24rpx;" @tap="linkContract()">
					<!-- <view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
						<view :style="{color:$theme.LOG_LABEL}">
							{{$lang.FLOW_AMOUNT_AFTER}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{item.after}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
						<view :style="{color:$theme.LOG_LABEL}">
							{{$lang.FLOW_AMOUNT_BEFORE}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{item.before}}
						</view>
					</view> -->

					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
						<view :style="{color:$theme.LOG_LABEL}">
							{{$lang.FLOW_AMOUNT}}
						</view>
						<view style="font-size: 32rpx;" :style="{color:$theme.PRIMARY}">
							{{item.money}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
						<view :style="{color:$theme.LOG_LABEL}">
							{{$lang.FLOW_CT}}
						</view>
						<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
							{{item.created_at}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.FLOW_DESC}}</view>
					</view>
					<view style="display: flex;align-items: center;">
						<view style="flex:30%;"></view>
						<text :style="{color:$theme.LOG_VALUE}"
							style="white-space:pre-wrap;text-align: right;">{{item.desc}}</text>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import CardItemPrimary from '@/components/card/CardItemPrimary.vue';
	export default {
		name: 'ContractList',
		components: {
			CardItemPrimary,
		},
		props: {
			list: {
				type: Array,
				default: []
			},
			info: {
				type: Object,
				default: {}
			},
		},
		data() {
			return {
				cardData: {}, // 资产卡
			}
		},
		computed: {
			cardLabels() {
				return [this.$lang.CARD_ASSETS_TOTAL,
					this.$lang.CARD_ASSETS_AVAIL,
					this.$lang.CARD_ASSETS_FREEZE
				]
			},
		},
		methods: {
			linkContract() {
				uni.navigateTo({
					url: this.$CONSTANTS.ASSETS_CONTRACT,
				})
			}
		}
	}
</script>

<style>
</style>