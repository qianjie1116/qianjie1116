<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<header class="header" style="background-color: #FFFFFF;">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text style="color:#121212;">{{$lang.TRADE_BLOCK_TITLE}}</text>
			</view>
			<view class="right" @click="linkRecord()">
				<image src="/static/icon_record.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view>
		</header>
		
		<view>
			<view class="flex" style=" justify-content: space-between;padding: 20px 20px;">
				<view style="background-color: #6e42ff;color: #fff; padding: 8px 20px;border-radius: 10px;">{{$lang.PINZHONG}}</view>
				<view style="background-color: #6e42ff;color: #fff; padding: 8px 20px;border-radius: 10px;" @click="chicang()">{{$lang.CONTRACT_RECORD_HOLD}}</view>
				<view style="background-color: #6e42ff;color: #fff; padding: 8px 20px;border-radius: 10px;" @click="lishi()">{{$lang.CONTRACT_RECORD_HISTORY}}</view>
			</view>
		</view>

		<view style="padding-bottom: 200rpx;">
			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view class="common_block"
						style="padding:20rpx 30rpx;border-radius: 8rpx;line-height: 1.6;margin:0 20rpx 20rpx 20rpx;">
						<view style="display: flex;align-items: center;">
							<view style="flex:0 0 6%">
								<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
							</view>
							<view style="flex:94%;">
								<view style="display: flex;align-items: center;">
									<view style="padding-left: 20rpx;font-size: 28rpx;font-weight: 700;color:#121212;">
										{{item.name}}
										<!-- <text style="font-size: 20rpx;padding:20rpx;color:#999;">
											{{item.code}}</text> -->
									</view>
									<view style="margin-left: auto;">
										<view :style="setStyleBuy()" @click="showModal(item)">
											{{$lang.BTN_BUY}}
										</view>
									</view>
								</view>
							</view>
						</view>

						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color: #666666;font-size: 24rpx;">{{$lang.TRADE_BLOCK_PRICE}}</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.PRIMARY}">
								{{$util.formatNumber(item.price)}}
							</view>
						</view>

						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="color: #666666;font-size: 24rpx;">
								{{$lang.TRADE_BLOCK_RATE}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.rate,2)}}%
							</view>
						</view>

						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="color: #666666;font-size: 24rpx;">
								{{$lang.TRADE_BLOCK_MIN_QTY}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.min_num}}
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="color: #666666;font-size: 24rpx;">
								{{$lang.TRADE_BLOCK_MAX_QTY}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.max_num}}
							</view>
						</view>
					</view>
				</block>
			</template>
		</view>
		<template v-if="isShow">
			<view class="common_mask" @click="handleClose()"></view>
			<view class="common_popup" style="min-height:35vh;margin:auto">
				<view class="popup_header" style="background-color: #6d41ff;">
					{{detail.name}}
					<image src="/static/close.png" mode="aspectFit" :style="$theme.setImageSize(40)"
						style="position: absolute;top:50%;right: 30px;transform: translateY(-50%);"
						@click="handleClose()">
					</image>
				</view>
				<view style="padding-bottom: 30rpx;">
					<view
						style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;margin-top: 10px;">
						<text :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_BLOCK_BUY_AMOUNT}}</text>
						<text :style="{color:$theme.PRIMARY}">
							{{$util.formatNumber(detail.price) }}</text>
					</view>
					<view class="common_input_wrapper"
						style="padding-left: 20px;margin:30rpx 40rpx;background-color: transparent;border:1px solid #EEE;">
						<input v-model="amount" :placeholder="$lang.TRADE_BLOCK_TIP_BUY_COUNT" type="number"
							style="width: 80%;" :placeholder-style="$theme.setPlaceholder()"></input>
					</view>

					<!-- 杠杆默认有一个数组，当数组大于1，视为开启杠杆功能 -->
					<!-- <template v-if="leverList.length>1">
						<view style="padding-left: 30px;font-size: 14px;font-weight: 800;margin-top: 20px;"
							:style="{color:$theme.LOG_LABEL}">
							{{$lang.LEVER}}
						</view>
			
						<view style="display: flex;align-items: center;flex-wrap: wrap;margin-left: 30rpx;">
							<block v-for="(item,index) in leverList" :key="index">
								<view
									style="border-radius: 8rpx;width:12%;margin:10rpx;padding:6rpx 10rpx;line-height: 1.6;text-align: center;"
									:style="setStyle(curLever==item)" @click="chgangeLever(item)">
									{{item}}
								</view>
							</block>
						</view>
					</template> -->

					<view
						style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-between;padding:20rpx 50rpx;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_BLOCK_BUY_TOTAL_AMOUNT}}</view>
						<view :style="{color:$theme.PRIMARY}">
							{{$util.formatNumber(buyAmount) }}
						</view>
					</view>

					<!-- <view class="common_input_wrapper" style="margin:30rpx 40rpx;padding-left: 20px;">
						<input v-model="password" :placeholder="$lang.TRADE_BLOCK_TIP_BUY_PWD" type="password"
							:placeholder-style="$theme.setPlaceholder()"></input>
					</view>
			
					<view style="display: flex;align-items: center;justify-content: flex-end;padding:20rpx 50rpx;"
						:style="{color:$theme.LOG_LABEL}">
						<view style="padding-right: 10px;">{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}:</view>
						<view :style="{color: $theme.SECOND}">{{available +` ` + $lang.CURRENCY_UNIT}}</view>
					</view> -->

					<view class="common_btn" @tap.stop="handleConfirm()"
						style="margin:60rpx auto;width: 80%;background-color: #1C1C1C;color:#FFF;">
						{{$lang.BTN_BUY}}
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>

	export default {

		data() {
			return {
				isAnimat: false, // 页面动画
				list: [],
				isShow: false, // 是否显示弹层
				detail: {}, // 单条数据详情
				amount: "", // 金额
				password: '', // 支付密码
				leverList: [], // 杠杆值数组
				curLever: 1, // 当前杠杆值
			}
		},
		computed: {
			// 金额计算
			buyAmount() {
				return this.detail.price * this.amount / this.curLever;
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.isShow = false;
			this.getList();
			uni.stopPullDownRefresh();
		},
		methods: {
			showModal(val) {
				this.isShow = true;
				this.detail = val;
			},
			// 关闭弹层
			handleClose(val) {
				console.log('val:', val);
				this.isShow = false;
				// this.changeTab(val);
			},
			chicang(){
				uni.navigateTo({
					url:'/pages/trade/block/chicang'
				})
			},
			lishi(){
				uni.navigateTo({
					url:'/pages/trade/block/lishi'
				})
			},
			linkRecord() {
				uni.navigateTo({
					url: this.$CONSTANTS.TRADE_BLOCK_RECORD
				})
			},

			setStyle(val) {
				return {
					backgroundColor: val ? this.$theme.SECOND : 'transparent',
					color: val ? '#FFFFFF' : '#A8A8A8',
					borderRadius: `16rpx`,
					// border: `1px solid ${val? this.$theme.PRIMARY:'#F1F1F1'}`
				}
			},
			setStyleBuy() {
				return {
					backgroundColor: this.$theme.PRIMARY,
					color: '#FFFFFF',
					borderRadius: `8rpx`,
					// minWidth: `60rpx`,
					padding: `4rpx 16rpx`,
					fontSize: `22rpx`,
					textAlign: `center`
				}
			},
			// 选择杠杆
			chgangeLever(val) {
				this.curLever = val;
			},

			handleConfirm() {
				if (this.checkForm()) {
					this.buy();
				}
			},
			checkForm() {
				if (this.amount == '') {
					uni.$u.toast(this.$lang.TRADE_BLOCK_TIP_BUY_COUNT);
					return false;
				}
				// if (this.password == '') {
				// 	uni.$u.toast(this.$lang.TRADE_BLOCK_TIP_BUY_PWD);
				// 	return false;
				// }
				return true;
			},
			async buy() {
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT
				});
				const result = await this.$http.post(`api/goods-bigbill/doOrder`, {
					id: this.detail.id,
					num: this.amount,
					pay_pass: this.password,
					ganggan: this.curLever,
				});
				if (!result) return false;
				this.handleClose();
				setTimeout(() => {
					this.getList(); // 1为购买成功，通知父组件刷新
				}, 1000);
			},

			// 产品列表
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-bigbill/list`);
				if (!result) return false;
				console.log(result);
				// 过滤掉不合格数据，当前以【gid】字段来判定。
				const temp = result.filter(item => item.gid && item.gid > 0);
				this.list = !temp || temp.length <= 0 ? [] : temp.map(item => {
					return {
						logo: item.goods.logo,
						name: item.goods.name,
						code: item.goods.code,
						id: item.id,
						price: item.price,
						rate_num: item.goods.rate_num,
						rate: item.goods.rate,
						min_num: item.min_num,
						max_num: item.max_num,
					}
				});
			},
		},
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>