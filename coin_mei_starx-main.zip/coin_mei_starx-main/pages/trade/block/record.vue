<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<header class="header" style="background-color: #FFFFFF;">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text style="color:#121212;">{{$lang.TRADE_BLOCK_ORDER_TITLE}}</text>
			</view>
		</header>
		<view style="padding-bottom: 200rpx;padding-top: 48rpx;">
			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view class="common_block"
						style=" padding:20rpx 30rpx;border-radius: 8rpx;line-height: 1.6;margin:0 20rpx 20rpx 20rpx;">
						<view style="display: flex;align-items: center;">
							<view style="flex:0 0 6%">
								<CustomLogo :logo="item.goods.logo" :name="item.goods.name"></CustomLogo>
							</view>
							<view style="flex:94%;">
								<view style="display: flex;align-items: center;">
									<view style="padding-left: 20rpx;font-size: 28rpx;font-weight: 700;color:#121212;">
										{{item.goods.name}}
										<text style="font-size: 20rpx;padding:20rpx;color:#999;">
											{{item.goods.code}}</text>
									</view>
									<!-- <view :style="{color:transStatus2(item.admin_status)}" style="font-size: 15px;margin-left: auto;">
										{{transStatus(item.admin_status)}}
									</view> -->
								</view>
							</view>
						</view>

						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color: #666666;font-size: 24rpx;">{{$lang.TRADE_BLOCK_LOG_PRICE}}</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.PRIMARY}">
								{{$util.formatCoin(item.price)}}
							</view>
						</view>

						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="color: #666666;font-size: 24rpx;">
								{{$lang.TRADE_BLOCK_LOG_NUM}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatCoin(item.apply_amount)}}
							</view>
						</view>

						<!-- <view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="color: #666666;font-size: 24rpx;">
								{{$lang.TRADE_BLOCK_LOG_LEVER}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.double}}
							</view>
						</view> -->
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="color: #666666;font-size: 24rpx;">
								{{$lang.TRADE_BLOCK_LOG_AMOUNT}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatCoin(item.amount*1+item.buy_fee*1)}}
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="color: #666666;font-size: 24rpx;">
								{{$lang.TRADE_DAY_TONGGUOSHULIANG}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatCoin(item.success)}}
							</view>
						</view>
						
						
						
						<!-- <view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="color: #666666;font-size: 24rpx;">
								{{$lang.TRADE_BLOCK_LOG_TRADE_AMOUNT}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatCoin(item.cj_num||0)}}
							</view>
						</view> -->

						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="color: #666666;font-size: 24rpx;">
								{{$lang.TRADE_BLOCK_LOG_CREATE_TIME}}
							</view>
							<view style="font-size: 24rpx;padding-left: 24rpx;color:#333333;">
								{{item.created_at}}
							</view>
						</view>
					</view>
				</block>
			</template>
		</view>
	</view>
</template>

<script>
	export default {
		components: {},
		data() {
			return {
				isAnimat: false, // 页面动画
				list: [],
			}
		},
		onShow() {
			this.isAnimat = true;
			this.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.isShow = false;
			this.getList();
			uni.stopPullDownRefresh();
		},
		methods: {
			// 记录
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-bigbill/user-order-log`);
				if (!result) return false;
				this.list = result;
				console.log(this.list);
			},
			// transStatus(admin_status){
			// 			if(admin_status==0){
			// 				return this.$lang.TRSNFER_RECORD_REVIEW
			// 			}else if (admin_status==1){
			// 			return this.$lang.TRANSFER_RECORD_PASS
			// 			}
						
			// 		},
			// 		transStatus2(admin_status){
			// 					if(admin_status==0){
									
			// 						return this.statusColor = 'red'
			// 					}else if (admin_status==1){
									
			// 						return this.statusColor = "gray"
			// 					}
			// 				},
		}
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 20rpx 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>