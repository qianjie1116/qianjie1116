<template>
	<view>
		<view style="display: flex;align-items: center;padding:0 36rpx 0 36rpx;">
			<view style="width: 8rpx;height: 28rpx;" :style="{backgroundColor:$theme.PRIMARY}"></view>
			<view style="font-size: 28rpx;font-weight: 700;padding-left: 40rpx;">
				{{$lang.COPY_DETAIL_WEEK_PL}}
			</view>
		</view>

		<view style="display: flex;align-items: center;justify-content: center;padding-bottom: 36rpx;">
			<canvas canvas-id="week" id="week" class="charts"></canvas>
		</view>
	</view>
</template>

<script>
	import uCharts from '@/common/u-charts.js';
	import {
		columnChartWeek
	} from '@/common/customUChart.js';
	let uChartsInstance = {};
	export default {
		// 每周盈亏 正负柱(细) 持仓盈亏，平仓盈亏 Hold And Sell
		name: 'ChartWeekProfitLoss',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				cWidth: 0,
				cHeight: 0,
				chart: null, // uchart实例化
				pixelRatio: 1, // 设备像素比
				minValue: 0,
			}
		},
		computed: {
			// 周盈亏
			weekData() {
				console.log(`week:`, this.list);
				const temp = this.list.map(item => {
					return {
						timestamp: item.time * 1000,
						hold: item.total_week_dayshouyi * 1, // 持有
						close: item.total_week_zhoupingcang * 1, // 平仓
						week: item.year_week.slice(5),
					}
				});

				let tempCategories = []; // 存储时轴
				let tempSeries = []; // 存储数据
				let seriesHold = [];
				let seriesCloss = [];
				// 决定时轴显示及空字符间隙
				const divisor = parseInt(temp.length / 10);
				console.log(`divisor:`, divisor);
				const tempSort = temp.sort((a, b) => a.timestamp - b.timestamp);
				console.log(`tempSort:`, tempSort);
				tempSort.forEach((item, index) => {
					if (divisor > 0) {
						if (index % divisor === 0) {
							tempCategories.push(index % divisor === 0 ? item.week : '');
							seriesHold.push(item.hold > 0 ? item.hold : 0);
							seriesCloss.push(item.close < 0 ? item.close : 0);
						}
					} else {
						tempCategories.push(index % divisor === 0 ? item.week : '');
						seriesHold.push(item.hold > 0 ? item.hold : 0);
						seriesCloss.push(item.close < 0 ? item.close : 0);
					}
				})

				this.minValue = Math.min(...seriesHold) > Math.min(...seriesCloss) ?
					Math.min(...seriesCloss) : Math.min(...seriesHold);

				console.log(this.minValue);
				return {
					categories: tempCategories,
					series: [{
						name: 'Profit',
						data: seriesHold,
						color: this.$theme.RISE
					}, {
						name: 'Loss',
						data: seriesCloss,
						color: this.$theme.FALL
					}],
				}
			}
		},
		created() {
			//这里的 750 对应 css .charts 的 width
			this.cWidth = uni.upx2px(740);
			//这里的 500 对应 css .charts 的 height
			this.cHeight = uni.upx2px(500);
		},
		mounted() {
			setTimeout(() => {
				this.genCharts();
			}, 1000);
		},
		methods: {
			genCharts() {
				const ctx = uni.createCanvasContext("week", this);
				this.chart = new uCharts(columnChartWeek(ctx, this.weekData,
					this.cWidth,
					this.cHeight, this.minValue))
			},
		}
	}
</script>

<style lang="scss" scoped>
	.charts {
		width: 740upx;
		height: 500upx;
	}
</style>