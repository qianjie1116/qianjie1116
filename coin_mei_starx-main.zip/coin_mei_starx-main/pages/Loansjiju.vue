<template>
	<view>
		<header class="flex padding-20" style="background-color: #FFFFFF;justify-content: space-between;">
			<view class="left" @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="flex-1 text-center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.SECOND}" class="font-size-16">
					{{$lang.LOANSJILU_DKJL}}
				</text>
			</view>
		</header>

		<block v-for="(item,index) in list" :key="index">
			<view style="padding: 10px;">
				<view class="flex">
					<view class="flex-1">
						{{$lang.LOANSJILU_ZT}}
					</view>
					<view style="color: #fc4136;">{{transStatus(item.status)}}</view>
				</view>
				<view class="flex">
					<view class="flex-1">
						{{$lang.LOANSJILU_SQJE}}
					</view>
					<view>{{item.money}}</view>
				</view>
				<view class="flex">
					<view class="flex-1">
						{{$lang.LOANSJILU_TYJE}}
					</view>
					<view>{{item.new_amount}}</view>
				</view>
				<view class="flex">
					<view class="flex-1">
						{{$lang.LOANSJILU_HKJE}}
					</view>
					<view>{{item.haikuan}}</view>
				</view>
				<view class="flex">
					<view class="flex-1">
						{{$lang.LOANSJILU_SQSJ}}
					</view>
					<view>{{item.updated_at}}</view>
				</view>
			</view>
			<view style="border-top: 1px #ccc solid;"></view>
		</block>



	</view>
</template>

<script>
	export default {
		components: {

		},
		data() {
			return {
				list: "",
			};
		},

		computed: {

		},
		onLoad() {},
		onShow() {
			this.getAccountuserinfo();
		},
		onReady() {},
		onHide() {},
		methods: {
			async getAccountuserinfo() {
				try {
					const result = await this.$http.get('api/app/daikuanlist');
					if (result && result) {
						console.log(result);
						this.list = result;
					}
				} catch (error) {
					console.error('获取数据失败', error);
				}
			},
			transStatus(status) {
				if (status == 0) {
					return this.$lang.LOANSJILU_SQZ
				} else if (status == 1) {

					return this.$lang.LOANSJILU_YTG
				} else if (status == 2) {

					return this.$lang.LOANSJILU_YHK
				} else if (status == 3) {

					return this.$lang.LOANSJILU_WTG
				}

			},



		}
	}
</script>

<style>
</style>