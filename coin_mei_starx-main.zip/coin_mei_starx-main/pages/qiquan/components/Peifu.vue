<template>
	<view>
		<view style="display: flex;align-items: center;padding:20rpx 40rpx;">
			<u-checkbox-group>
				<u-checkbox shape="circle" :activeColor="$theme.SECOND" :label="$lang.CONTRACT_RECORD_TIP_CUR_CONTRACT"
					v-model="isShowCurCoin" labelColor="#999" labelSize="24rpx" @change="filterCoin"
					:checked="isShowCurCoin" iconColor="#FFFFFF"></u-checkbox>
			</u-checkbox-group>

			<!-- <view class="common_btn" style="margin-left: auto;padding:8rpx 24rpx;font-size: 24rpx;">
				{{$lang.CONTRACT_HOLD_QUICK_CLOSE}}
			</view> -->
		</view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view class="common_block" style="border-radius: 16rpx;">
				
					<view class="flex flex-b margin-top-10">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.PEIFU_NAME}}</view>
						<view>{{item.goods_info.name}}</view>
					</view>
					
					<view class="flex flex-b margin-top-10">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.CONTRACT_HOLD_BUY_PRICE}}</view>
						<view >{{item.order_buy.bx_money}}</view>
					</view>
					
					
					<view class="flex flex-b margin-top-10">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.PEIFU_STATUS}}</view>
						<view :style="{color:item.order_buy.sy==1?'#00B45A':'#FF533B'}">{{item.order_buy.sy==1?$lang.Qiquan_ying:$lang.Qiquan_shu}}</view>
					</view>
					
					
					<view class="flex flex-b margin-top-10">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.CONTRACT_HOLD_BUY_PL}}</view>
						<view :style="{color:item.order_buy.sy==1?'#00B45A':'#FF533B'}">{{ item.order_buy.yingli?item.order_buy.yingli:-1*item.order_buy.amount}}</view>
					</view>
					
					<view class="flex flex-b margin-top-10">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.PEIFU_RETURN}}</view>
						<view>{{item.order_buy.bx_money}}</view>
					</view>
					
					<view class="flex flex-b margin-top-10">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.BAOXIAN_PRICE}}</view>
						<view>{{item.order_buy.bx_money}}</view>
					</view>
				
					<view style="display: flex;align-items: center;justify-content: space-between; line-height:2.4;">
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
							{{item.order_sn}}
						</view>
						<view style="font-size: 26rpx;" :style="{color:$theme.LOG_LABEL}">
							{{item.created_at}}
						</view>
					</view>

				</view>
			</block>
		</template>

		<template v-if="isShowProfitLoss">
			<ProfitLoss :info="infoData" @action="handleProfitLossClose"></ProfitLoss>
		</template>
		<template v-if="isShowClose">
			<CloseModal :info="infoData" @action="handleClose"></CloseModal>
		</template>
	</view>
</template>

<script>
	
	import ProfitLoss from './ProfitLoss.vue';
	import CloseModal from './CloseModal.vue';
	export default {
		name: 'HoldRecord',
		components: {
	
			ProfitLoss,
			CloseModal,
		},
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				isShowCurCoin: true, // 是否僅顯示當前coin
				// 傳入彈層的數據
				infoData: {},
				isShowProfitLoss: false, // 止盈止損彈層
				isShowClose: false, // 平倉彈層
			}
		},
		created() {},

		methods: {
			// 過濾出當前coin的數據
			filterCoin(e) {
				this.isShowCurCoin = e;
				// 通知父组件
				this.$emit('action', this.isShowCurCoin);
			},
			openProfitLossModal(val) {
				console.log(`pl:`, val);
				uni.hideTabBar(); // 隐藏tabBar
				this.isShowProfitLoss = true;
				this.infoData = val;
			},
			handleProfitLossClose(val) {
				this.isShowProfitLoss = false;
				uni.showTabBar(); // 显示tabBar
				// 通知父组件
				this.$emit('action', this.isShowCurCoin);
			},
			openCloseModal(val) {
				console.log(`close:`, val);
				uni.hideTabBar(); // 隐藏tabBar
				this.isShowClose = true;
				this.infoData = val;
			},

			handleClose(val) {
				this.isShowClose = false;
				uni.showTabBar(); // 显示tabBar
				// 通知父组件
				this.$emit('action', this.isShowCurCoin);
			},

			setStyle(val) {
				const temp = val == 1 ? this.$theme.RISE : this.$theme.FALL;
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(temp, 20),
					color: temp,
				}
			},
		}
	}
</script>

<style>
</style>