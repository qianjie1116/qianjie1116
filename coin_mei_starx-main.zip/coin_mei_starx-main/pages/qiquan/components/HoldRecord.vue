<template>
	<view>
		<view style="display: flex;align-items: center;padding:20rpx 40rpx;">
			<u-checkbox-group>
				<u-checkbox shape="circle" :activeColor="$theme.SECOND" :label="$lang.CONTRACT_RECORD_TIP_CUR_CONTRACT"
					v-model="isShowCurCoin" labelColor="#999" labelSize="24rpx" @change="filterCoin"
					:checked="isShowCurCoin" iconColor="#FFFFFF"></u-checkbox>
			</u-checkbox-group>

			<!-- <view class="common_btn" style="margin-left: auto;padding:8rpx 24rpx;font-size: 24rpx;">
				{{$lang.CONTRACT_HOLD_QUICK_CLOSE}}
			</view> -->
		</view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view class="common_block" style="border-radius: 16rpx;">
					<view style="display: flex;align-items: center;">
						<view style="padding-right: 10rpx;font-size: 28rpx;" :style="{color:$theme.SECOND}">
							{{item.goods_info.name}}
						</view>
						
						<view
							style="background-color: #F3F3F3;font-size: 22rpx;border-radius: 8rpx;padding:6rpx 16rpx;margin:0 20rpx;"
							:style="{color:item.order_buy.sy==1?'#00B45A':'#FF533B'}">
							{{item.order_buy.sy==1?$lang.Qiquan_ying:$lang.Qiquan_shu}}
						</view>
						<view style="margin-left: auto;">
							<view class="common_tag" :style="setStyle(item.direct)">
								{{item.direct == 1 ? $lang.Qiquan_zhang : $lang.Qiquan_die}}
							</view>
						</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between;margin-top: 20rpx;line-height: 1.4;">
						<view style="flex:33.33%">
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
								{{$lang.CONTRACT_HOLD_BUY_PRICE}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">{{item.order_buy.price}}</view>
						</view>
						<view style="flex:33.33%;text-align: center;">
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
								{{$lang.Qiquan_Amount1}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">{{item.order_buy.amount}}</view>
						</view>
						<view style="flex:33.33%;margin-left:auto;text-align: right;">
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
								{{$lang.CONTRACT_HOLD_BUY_TOTAL}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">{{item.order_buy.user_pay}}</view>
						</view>
					</view>

					<view
						style="display: flex;align-items: center;justify-content: space-between;margin-top: 20rpx;line-height: 1.4;">
						<view style="flex:33.33%">
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
								{{$lang.Qiquan_endprice}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">{{item.order_buy.end_price}}</view>
						</view>
						<!-- <view style="flex:33.33%;text-align: center;">
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
								{{$lang.CONTRACT_HOLD_BUY_FEE}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">{{item.order_buy.buy_fee}}</view>
						</view> -->
						<view style="flex:33.33%;text-align: center;">
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
								{{$lang.BAOXIAN}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:item.bx==1?'#00B45A':'#FF533B'}" >{{item.bx==1?"ON":'OFF'}}</view>
						</view>
						
						<view style="flex:33.33%;margin-left:auto;text-align: right;">
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
								{{$lang.CONTRACT_HOLD_BUY_PL}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:item.order_buy.sy==1?'#00B45A':'#FF533B'}">
								{{ item.order_buy.yingli?item.order_buy.yingli:-1*item.order_buy.amount}}
							</view>
						</view>
					</view>
					
					
					<view v-if="item.bx==1"
						style="display: flex;align-items: center;justify-content: space-between;margin-top: 20rpx;line-height: 1.4;">
						<view style="flex:33.33%">
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
								{{$lang.BAOXIAN_PRICE}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">{{item.order_buy.bx_money}}</view>
						</view>
						<!-- <view style="flex:33.33%;text-align: center;">
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
								{{$lang.CONTRACT_HOLD_BUY_FEE}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">{{item.order_buy.buy_fee}}</view>
						</view> -->
						<view style="flex:33.33%;text-align: center;">
							<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
								{{$lang.BAOXIAN_STATUS}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:item.bx==1?'#00B45A':'#FF533B'}" >{{$lang.BAOXIAN_2}}</view>
						</view>
						
						<view style="flex:33.33%;margin-left:auto;text-align: right;">
							
						</view>
					</view>



					<view style="display: flex;align-items: center;justify-content: space-between; line-height:2.4;">
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
							{{item.order_sn}}
						</view>
						<view style="font-size: 26rpx;" :style="{color:$theme.LOG_LABEL}">
							{{item.created_at}}
						</view>
					</view>

				</view>
			</block>
		</template>

		<template v-if="isShowProfitLoss">
			<ProfitLoss :info="infoData" @action="handleProfitLossClose"></ProfitLoss>
		</template>
		<template v-if="isShowClose">
			<CloseModal :info="infoData" @action="handleClose"></CloseModal>
		</template>
	</view>
</template>

<script>
	
	import ProfitLoss from './ProfitLoss.vue';
	import CloseModal from './CloseModal.vue';
	export default {
		name: 'HoldRecord',
		components: {
	
			ProfitLoss,
			CloseModal,
		},
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				isShowCurCoin: true, // 是否僅顯示當前coin
				// 傳入彈層的數據
				infoData: {},
				isShowProfitLoss: false, // 止盈止損彈層
				isShowClose: false, // 平倉彈層
			}
		},
		created() {},

		methods: {
			// 過濾出當前coin的數據
			filterCoin(e) {
				this.isShowCurCoin = e;
				// 通知父组件
				this.$emit('action', this.isShowCurCoin);
			},
			openProfitLossModal(val) {
				console.log(`pl:`, val);
				uni.hideTabBar(); // 隐藏tabBar
				this.isShowProfitLoss = true;
				this.infoData = val;
			},
			handleProfitLossClose(val) {
				this.isShowProfitLoss = false;
				uni.showTabBar(); // 显示tabBar
				// 通知父组件
				this.$emit('action', this.isShowCurCoin);
			},
			openCloseModal(val) {
				console.log(`close:`, val);
				uni.hideTabBar(); // 隐藏tabBar
				this.isShowClose = true;
				this.infoData = val;
			},

			handleClose(val) {
				this.isShowClose = false;
				uni.showTabBar(); // 显示tabBar
				// 通知父组件
				this.$emit('action', this.isShowCurCoin);
			},

			setStyle(val) {
				const temp = val == 1 ? this.$theme.RISE : this.$theme.FALL;
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(temp, 20),
					color: temp,
				}
			},
		}
	}
</script>

<style>
</style>