<template>
	<view :class="isAnimat?'fade_in':'fade_out'">
		<header style="padding-top: 60rpx;border-bottom: 1px solid #E7E8ED;">
			<scroll-view :scroll-x="true" style="white-space: nowrap;width: 96%;padding:0 10px 0 10px;" @touchmove.stop>
				<view style="display: flex;margin:0 10rpx;">
					<block v-for="(item,index) in tabs" :key='index'>
						<view :style="setStyle(curTab ==index)" @click="changeTab(index)">
							{{item.value}}
						</view>
					</block>
				</view>
			</scroll-view>
		</header>

		<view :class="setClass">
			<!-- 检索 -->
			<view style="border:1px solid #25262A1A;border-radius: 16rpx;padding:12rpx 24rpx;margin:24rpx;">
				<view style="display: flex;align-items: center;">
					<view :style="{color:$theme.LOG_VALUE}">{{$lang.FILTER}}</view>
					<view style="padding:0 24rpx;" :style="{color:$theme.LOG_VALUE}">|</view>
					<input v-model="keyword" type="text" :placeholder="$lang.TRADE_COPY_SEARCH_TIP"
						:placeholder-style="$theme.setPlaceholder()"></input>
					<!-- <image src="/static/search.png" mode="aspectFit" :style="$theme.setImageSize(40)"></image> -->
				</view>
			</view>

			<!-- tab0 coin 包含 -->
			<template v-if="curTab==0">
				<view style="display: flex;justify-content: space-between;margin:0 10rpx;">
					<block v-for="(v,k) in sortTabs" :key='k'>
						<view :style="setStyleSort(curSort ==k)" @click="changeSort(k)">
							{{v}}
						</view>
					</block>
				</view>
			</template>

			<template v-if="!filterList || filterList.length<=0">
				<EmptyData></EmptyData>
			</template>
			<block v-for="(item,index) in filterList" :key="index">
				<view class="common_block"
					style="padding:10px;background-color: #FFFFFF;margin:20rpx;border-radius: 24rpx;"
					@click="linkDetail(item)">
					<view style="display: flex;align-items: center;">
						<view style="width: 80rpx;margin:auto 0;">
							<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
						</view>
						<view style="flex:1 0 40%;padding-left: 40rpx;">
							<view :style="{color:$theme.SECOND}" style="font-size: 32rpx;line-height: 1.6;">
								{{item.name}}
							</view>
							<template v-if="curTab==0">
								<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">24H:
									{{$util.formatNumber(item.vol,0)}}
								</view>
							</template>
						</view>
						<view style="margin-left: auto;">
							<view style="font-size: 32rpx;font-weight: 700;text-align: right;"
								:style="{color:$theme.SECOND}">
								{{$util.formatCoin(item.current_price)}}
							</view>
							<view style="font-size: 28rpx;text-align: right;"
								:style="$theme.setStockRiseFall(item.rate*1>0)">
								{{`${item.rate>0?'+':'-'} `+ ($util.formatNumber($util.formatMathABS(item.rate),2))}}%
							</view>
						</view>
					</view>
				</view>
			</block>

			<!-- <template v-if="curTab==2 && filterList && filterList.length<=10">
				<view style="border-radius: 44rpx;padding:20rpx 0;margin:40rpx auto;width: 80%;"
					:style="{backgroundColor:$theme.SECOND}">
					<view style="display: flex;align-items: center;justify-content: center;" @tap="changeTab(0)">
						<image src="/static/icon_add.png" mode="aspectFit" :style="$theme.setImageSize(40)"
							style="padding-right: 60rpx;"></image>
						<view :style="{color:'#FFFFFF'}">{{$lang.MARKET_INDEX_TIP_GO_COIN}}</view>
					</view>
				</view>
			</template> -->
		</view>
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	export default {
		components: {
			HeaderPrimary,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				curTab: 0, // 当前默认放在Coin
				curSort: 0, // 排序
				list: null, // 列表数据
				socket: null, // websocket
				isConnected: false, // 是否链接socket
				keyword: '', // 检索关键词
				listFutures: null, // 期货数据
			}
		},

		computed: {
			// tabs设置。
			tabs() {
				return [{
						key: 'coin',
						value: this.$lang.MARKET_INDEX_TAB_COIN
					},
					{
						key: 'forex',
						value: this.$lang.FOREX_TITLE
					},
					// {
					// 	key: 'futures',
					// 	value: this.$lang.FUTURES_TITLE
					// },
					// 如果是开放收藏，则对track一栏加上二级tab【coin、forex】等。避开多个ws同时启动
					// {
					// 	key: 'track',
					// 	value: this.$lang.MARKET_INDEX_TAB_TRACK
					// }, 
				]
			},
			// 切换tab的动效
			setClass() {
				return this.curTab % 2 === 0 ? 'right_in' : 'left_in'
			},
			// 排序
			sortTabs() {
				return [
					this.$lang.MARKET_INDEX_TAB_HOP,
					this.$lang.MARKET_INDEX_TAB_RISE,
					this.$lang.MARKET_INDEX_TAB_FALL,
				]
			},
			// 根据关键字，过滤数据
			filterList() {
				if (this.setList && this.setList.length > 0) {
					// 输入三个字符以上才检索
					if (this.keyword.length >= 1) {
						return this.setList.filter(item => item.name.includes(this.keyword) || item.name.toLowerCase().includes(this.keyword));
					} else {
						return this.setList;
					}
				} else {
					return []
				}
			},

			setList() {
				if (!this.list || Object.values(this.list).length <= 0) {
					return []
				}
				const temp = Object.values(this.list);
				if (this.curTab == 0) {
					if (this.curSort == 0) return temp;
					if (this.curSort == 1) {
						return temp.sort((a, b) => b.rate - a.rate);
					} else {
						return temp.sort((a, b) => a.rate - b.rate);
					}
				} else {
					let tempFutures;
					if (this.listFutures && Object.values(this.listFutures).length >= 0) {
						tempFutures = Object.values(this.listFutures);
					} else {
						tempFutures = [];
					}
					return [...tempFutures, ...temp];
				}
			}
		},

		onLoad(opt) {
			// 避免变动错位，使用遍历查找下标 url?tag=forex
			const temp = this.tabs.findIndex(item => item.key == opt.tag);
			this.curTab = temp > -1 ? temp : 0;
		},
		onShow() {
			if (this.socket) this.disconnect();
			this.changeTab(this.curTab);
			this.isAnimat = true;
		},
		onHide() {
			if (this.socket) this.disconnect();
			this.isAnimat = false;
		},
		deactivated() {
			if (this.socket) this.disconnect();
		},
		onUnload() {
			if (this.socket) this.disconnect();
		},
		// 下拉刷新
		onPullDownRefresh() {
			if (this.socket) this.disconnect();
			this.changeTab(this.curTab);
			uni.stopPullDownRefresh();
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
				if (this.socket) this.disconnect();
				this.list = null;
				this.getList();
				if (this.curTab > 0) {
					this.listFutures = null;
					this.getFutures();
				}
			},
			// 排序模式
			changeSort(val) {
				this.curSort = val;

			},
			// 跳转到详情
			linkDetail(val) {
				// coin forex track
				console.log(`val:`, val);
				const temp = this.tabs[this.curTab].key;
				if (temp == 'coin') {
					uni.reLaunch({
						url: this.$CONSTANTS.COIN_DETAIL + `?code=${val.locate}`
					});
				} else {
					uni.navigateTo({
						url: this.$CONSTANTS.FOREX_DETAIL + `?code=${val.locate}`
					})
				}
			},

			async getList() {
				let tempUrl = ''; // 处理api
				let tempData = {};
				const temp = this.tabs[this.curTab].key;
				// track
				if (temp == 'track') {
					tempUrl = `api/user/collect_list`;
				} else {
					tempUrl = `api/goods/list`
					tempData.gp_index = this.$CONSTANTS.GPINDEX[temp];
				}
				const result = await this.$http.post(tempUrl, tempData);
				if (!result) return false;
				console.log(`111result:`, result);
				// 数据处理成 Object类型，并统一字段
				// [pid,locate,logo,name,price,rate,vol,project_type_id]
				// if (this.curTab == 2) {
				// 	let tempObj = {};
				// 	result.list.forEach(item => {
				// 		tempObj[item.locate] = item;
				// 	})
				// 	this.list = tempObj;
				// } else {
				this.list = result;
				// }

				// if (this.curTab == 0) {

				// }
				// if (this.curTab == 1) {
				// let tempObj = {};
				// Object.values(result).forEach(item => {
				// 	tempObj[item.locate] = item;
				// 	// this.$set(this.list, item.locate, item);
				// })
				// this.list = tempObj;
				// // this.$set(this.list, item.locatek, item);
				console.log(`this.list:`, this.list);
				// }
				if (Object.values(this.list).length > 0) {
					console.log(Object.values(this.list).length)
					this.connect();
				}
			},

			async getFutures() {
				const result = await this.$http.post(`api/goods/list`, {
					gp_index: this.$CONSTANTS.GPINDEX['futures'],
				});
				if (!result) return false;
				console.log(`getFutures:`, result);
				this.listFutures = result;
			},

			// websocket 断线重连
			reconnectWebSocket() {
				// 连接中，并且非手动关闭
				if (this.isConnected) return;
				console.log(`reconnect!`, this.isConnected);
				this.socket = null;
				console.log(`reconnect! socket:`, this.socket);
				this.connect();
			},
			// websocket链接
			connect() {
				let tempURL = '';
				const temp = this.tabs[this.curTab].key;
				if (temp == 'coin') {
					tempURL = this.$http.WS_COIN_URL;
				} else {
					tempURL = this.$http.WS_Zonghe_URL;
				}
				console.log('tempURL', tempURL);
				//创建webSocket
				this.socket = uni.connectSocket({
					url: tempURL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('success', res);
					},
					fail: (res) => {
						console.log('fail', res);
					},
					complete: (res) => {
						console.log('complete', res);
					}
				})
				console.log('ws', this.socket);
				if (this.socket) {
					this.isConnected = true; // 已连接
					this.socket.onOpen((res) => {
						console.info("socket onOpen:", res)
					});
					this.socket.onClose((res) => {
						// code:1000(手动关闭) 1006(异常关闭) 
						console.log(`onClose:`, res);
						this.isConnected = false;
						if (res.code !== 1000) {
							this.reconnectWebSocket();
						}
					});

					this.socket.onError((err) => {
						console.log(`onError:`, err);
						this.isConnected = false;
						this.reconnectWebSocket();
					});
					// 接收websocket消息及处理
					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);
						// console.log(data);
						// ws价格>0，更新数据。
						if (this.curTab == 0) {
							if (this.list[data.market] && data.market && data.lastPrice > 0) {
								this.list[data.market].current_price = data.lastPrice;
								this.list[data.market].rate = data.rate || 0;
								this.list[data.market].vol = data.vol || 0;
							}
						} else {
							// console.log(`pid:`, this.list[data.pid]);
							if (this.list[data.pid] && data.pid && data.last > 0) {
								this.list[data.pid].current_price = data.last;
								this.list[data.pid].rate = data.pcp || 0;
							}
							if (this.listFutures[data.pid] && data.pid && data.last > 0) {
								this.listFutures[data.pid].current_price = data.last;
								this.listFutures[data.pid].rate = data.pcp || 0;
							}
						}
					});
				}
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
			},

			// 设置样式
			setStyle(val) {
				return {
					width: `120rpx`,
					padding: `12rpx 32rpx`,
					color: val ? this.$theme.SECOND : '#CBCBCB',
					textAlign: 'center',
					fontSize: `36rpx`,
					fontWeight: `700`,
					borderBottom: `4rpx solid ${val? this.$theme.SECOND :this.$theme.TRANSPARENT }`
				}
			},
			// 排序
			setStyleSort(val) {
				return {
					minWidth: `120rpx`,
					margin: '16rpx',
					padding: `12rpx 20rpx`,
					borderRadius: `16rpx`,
					textAlign: 'center',
					backgroundColor: val ? this.$theme.SECOND : '#FFFFFF',
					color: val ? '#FFFFFF' : this.$theme.SECOND,
					borderRadius: `44rpx`,
				}
			}
		},
	}
</script>