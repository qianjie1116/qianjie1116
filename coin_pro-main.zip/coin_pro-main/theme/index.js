import Vue from 'vue';
import * as constants from '@/common/constants.js';
import * as dark from './dark.js';
import * as light from './light.js';
import * as common from './common.js';


const themes = {
	'dark': dark,
	'light': light
};
// console.log(`themes:`, themes);

export const setTheme = (val) => {
	// console.log(`setTheme val:`, val);
	const temp = val ? constants.DARK : constants.LIGHT;
	uni.setStorageSync('theme', temp);
	// console.log(`themes[temp]:`, themes[temp]);
	Vue.prototype.$theme = Object.assign(Vue.prototype.$theme, {
		...common,
		...themes[temp]
	});
	// console.log(`Object.assign:`, Vue.prototype.$theme);
};

// 设置布局方案
export const setLayout = (val) => {
	return uni.getStorageSync('layout') === val;
};

// 页面主体容器 宽屏有个顶部固定余量，竖屏有个底部固定余量。宽屏需考虑两边留白
export const setStyleBody = () => {
	let temp = {};
	// 当前布局调整 小屏样式，紧凑样式，宽屏样式
	if (setLayout(constants.SMALL))
		temp.padding = `16px 16px 80px 16px`;
	if (setLayout(constants.MEDIUM))
		temp.padding = `80px 40px 20px 40px`;
	if (setLayout(constants.LARGE)) {
		temp.padding = `80px 0 20px 0`;
		temp.maxWidth = constants.WIDTH_PC + `px`;
		temp.margin = `0 auto`;
	}
	// console.log(temp)
	return temp;
};


// 页面通设 根据机制，在模板上使用，必须有一个变更值，才能重新计算样式。
export const setPageStyle = (val = true) => {
	// console.log(`setPageStyle val:`, val);
	return {
		width: Vue.prototype.$WINDOW_WIDTH + `px`,
		// height: temp.windowHeight + temp.windowBottom + `px`
		minHeight: Vue.prototype.$WINDOW_HIGHT + `px`,
		backgroundColor: Vue.prototype.$theme.BASIC_BG,
		color: Vue.prototype.$theme.BASIC_TXT,
	};
};



// 设置图片尺寸（自定义size）
export const setImageSize = (w = 24, h = 0) => {
	const _h = h > 0 ? h : w;
	return {
		width: `${w}px`,
		// 若为设置h值，则视为高=宽
		height: `${_h}px`,
	};
};

// 渐变设置
export const linerGradient = (deg, from, to) => {
	return {
		backgroundImage: `linear-gradient(${deg}deg, ${from} ,${to})`
	}
};

// 计算设计图上带有透明度的值输出为RGBA
export const convertRGBA = (hex, opacity) => {
	// console.log(hex);
	const r = parseInt(hex.slice(1, 3), 16);
	const g = parseInt(hex.slice(3, 5), 16);
	const b = parseInt(hex.slice(5, 7), 16);
	const a = opacity / 100;
	return `rgba(${r},${g},${b},${a})`;
};

// 设置input输入框， 背景及边框根据主题切换
export const setInputStyle = (val) => {
	return {
		backgroundColor: Vue.prototype.$theme.INPUT_BG,
		border: `1px solid ${Vue.prototype.$theme.INPUT_BORDER }`
	}
};

// 设置input的placeholder样式
export const setPlaceholder = (color = '', fontsize = '') => {
	return `color:${color == '' ?Vue.prototype.$theme.TXT_UNACT : color};font-size:${fontsize==''?10:fontsize}px`;
};

// 设置checkbox label 文字跟随主题
// export const setCheckboxLabel = () => {
// 	return val ? CHECKBOX_COLOR_LABEL_DARK :
// 		CHECKBOX_COLOR_LABEL_LIGHT
// };

/**
 * @function 涨跌值样式设置
 * @param {number} num 数值
 * @param {string} isbg 是否需要背景
 * @description 所有涨幅通用。[-1跌,0平,1涨]
 * @example
 * $theme.setRiseFall(0.111)
 * $theme.setRiseFall(-1.111,true)
 */
export const setRiseFall = (num, isbg = false) => {
	// 检查传入值的合法性
	num = !num || isNaN(num) ? 0 : Number(num);
	const temp = [
		Vue.prototype.$theme.FALL,
		Vue.prototype.$theme.FLAT,
		Vue.prototype.$theme.RISE,
	];
	const index = num == 0 ? 0 : num < 0 ? -1 : 1;
	return {
		color: temp[index + 1],
		backgroundColor: !isbg ? Vue.prototype.$theme.TRANSPARENT : convertRGBA(temp[index + 1], 20),
	}
};

// Coin Depth bg
export const depathAsksBG = (val, max, dir = 'right') => {
	const temp = convertRGBA(Vue.prototype.$theme.RISE, 20);
	// 當前最大值為100%,
	const tempVal = val / max * 100;
	// console.log(val, max, tempVal);
	const style = {
		...linerGradient(180, temp, temp),
		backgroundRepeat: 'no-repeat',
		backgroundPosition: `right 0`,
		backgroundSize: `${tempVal}% 100%`,
		width: '100%',
		minHeight: `100%`,
	}
	return style;
};
export const depathBidsBG = (val, max, dir = '0') => {
	const temp = convertRGBA(Vue.prototype.$theme.FALL, 20);
	// 當前最大值為100%,
	const tempVal = val / max * 100;
	// console.log(val, max, tempVal);
	const style = {
		...linerGradient(180, temp, temp),
		backgroundRepeat: 'no-repeat',
		backgroundPosition: `${dir} 0`,
		backgroundSize: `${tempVal}% 100%`,
		width: '100%',
		minHeight: `100%`,
	}
	return style;
};

// 定义颜色数组
export const colors = [
	common.PRIMARY,
	'#0ECB81',
	'#FF5722',
	'#3F51B5',
	'#9C27B0',
	'#2196F3',
	'#FFC107',
	'#4CAF50',
	'#E91E63',
	'#FF9600',
	'#935EBD',
	'#2196F3',
	'#E11D74',
	'#01C5C4',
];

// 随机一个颜色值作为无LOGO时的背景底色
export const randomBGColor = () => {
	// 随机选择一个颜色
	const randomIndex = Math.floor(Math.random() * colors.length);
	return convertRGBA(colors[randomIndex], 80)
}

// 状态的颜色值
export const colorStatus = [
	'#FF5722',
	'#0ECB81',
	'#E91E63'
];