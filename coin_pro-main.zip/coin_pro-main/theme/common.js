// common 无关主题，通用样式常量及处理函数

export const TRANSPARENT = 'transparent'; // 使用父级元素颜色
export const PRIMARY = `#6D41FF`;
// 宽屏 header 竖屏 footer 未激活的文字样式 。通用字色、icon色
export const TXT_UNACT = `#838B9C`;

export const TXT_WHITE = `#FFFFFF`;

// checkbox 边框及勾选
export const CHECKBOX_COLOR_ACTIVE = PRIMARY;