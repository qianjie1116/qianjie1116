// theme light

export const PRIMARY_BG = `#536FFF7A`;
export const PRIMARY_TXT = `#536FFF`;
export const SUCCESS_BG = `#102821`;
export const SUCCESS_TXT = `#2EBD85`;
export const ERROR_BG = `#35141D`;
export const ERROR_TXT = `#F6465D`;
export const WARNING_BG = `#A37200`;
export const WARNING_TXT = `#f9ae3d`;
export const INFO_BG = `#848E9C`;
export const INFO_TXT = `#B7BDC6`;


export const BASIC_BG = `#F8F8F8`;
export const BASIC_TXT = `#121212`;
// 按钮或card元素的边框。
export const BASIC_BORDER = `#EAECEF`;



export const HEADER_BG = `#FFFFFF`;
export const HEADER_BORDER = `#FFFFFFCF`;

export const BORDER_COLOR = `#474D57`;

export const INPUT_BG = 'transparent'; // input背景
export const INPUT_BORDER = '#6D41FF3A'; // input边框

export const RISE = `#2EBD85`; // 涨 字色
export const FALL = `#E33B54`; // 跌 字色
export const FLAT = `#888888`; // 平 字色

export const CHECKBOX_LABEL_COLOR = '#1f212d'; // checkbox 文字

export const CARD_BG = `#FFFFFFF0`; // 一些元素背景

//notify
export const NOTIFY_BG = CARD_BG; //