// theme dark

export const PRIMARY_BG = `#536FFF7A`;
export const PRIMARY_TXT = `#536FFF`;
export const SUCCESS_BG = `#102821`;
export const SUCCESS_TXT = `#2EBD85`;
export const ERROR_BG = `#F6465D70`;
export const ERROR_TXT = `#F6465D`;
export const WARNING_BG = `#A37200`;
export const WARNING_TXT = `#f9ae3d`;
export const INFO_BG = `#848E9C`;
export const INFO_TXT = `#B7BDC6`;



export const BASIC_BG = `#181E25`;
export const BASIC_TXT = `#FFFFFF`;
// 按钮或card元素的边框。
export const BASIC_BORDER = `#2B3139`;

export const HEADER_BG = `#1b1f2d`;
export const HEADER_BORDER = `#1b1f2d7A`;

export const BORDER_COLOR = `#B7BDC6`;

export const INPUT_BG = '#0a0c13'; // 暗色主题 input背景
export const INPUT_BORDER = '#1f212d'; // 暗色主题 input边框

export const RISE = `#0ECB81`; // 涨 字色
export const FALL = `#F6465D`; // 跌 字色
export const FLAT = `#888888`; // 平 字色

export const CHECKBOX_LABEL_COLOR = '#e9e9e9'; // checkbox 文字

export const CARD_BG = `#34393E`; // 一些元素背景

//notify
export const NOTIFY_BG = CARD_BG; //