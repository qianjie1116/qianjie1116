# coin_pro
Core platforms coin trade

## 该项目使用分支控制多版本

```
# branch
git checkout main
git checkout xinxin
git checkout brazil

## 命令
git checkout -b xinxin # 创建分支
git status # 查看状态
git add <file1> <file2>  # 指定你修改的文件
git commit -m "-c 说明"
git push origin xinxin # 推送到远程分支

分支合并  是将一个分支的更改引入到另一个分支的过程。
整合代码  ：将开发的功能整合到主代码库中，从而使得所有开发者都能使用最新的功能或修复。
git checkout main # 切换到需要接收更改的分支
git merge <要合并的分支名称> # 执行合并操作
合并之后的提交  ：合并操作通常会生成一个新的合并提交（merge commit），这意味着 Git 会创建一个新的提交记录以表明两个分支的结合。

不合并  意味着在某个分支上的更改不被合并到目标分支。这通常是在不同的开发需求下选择不将某些更改纳入主代码库时的决定。
```

- 说明：✅ 已完成、❎ 未完成、❓ 待确认、🟰 等等做、➕ 新增功能、➖ 非使用功能、✖ 移除功能


## 适配 PC、H5、APP

```
参考：
https://test.morgantrust.vip/
FOUYOAAA
123123

https://pc.prodtitle.online/#/home
账号：test01   密码123456
https://h5.prodtitle.online/#/home

svg在线处理支持一键调整viewbox
https://www.svgviewer.dev/

https://www.binance.com/en
https://www.btcaholic.com/#/contract
https://github.com/TradeClientUI/trade-ui/tree/15001edc0f702b997a7562ab90f793c8461b0133/src/components/tradingview
"lg‑RE" lg 是语言 (Language)  RE 是区域 (Region)。
https://en.wikipedia.org/wiki/List_of_tz_database_time_zones#List
https://tc39.es/proposal-intl-numberformat-v3/out/numberformat/proposed.html
https://jsdoc.app/

国旗.svg
https://flagicons.lipis.dev/

```

## TODO 
- ❎ RTL模式
- ✅ 明暗主题
- ✅ 多语言切换
- ✅ 响应式
- ✅ websocket通信

- ❓ `coin` 及 `contract` 的 `index` 页面添加强刷，解决页面谷歌翻译不更新问题。

# TODO KlineChart
 - `registerOverlay`,将`klineChartPro`中，所有绘图方式，改写为 js 函数。
- 维持原有对时间选择、柱形选择、技术指标选择。
- 技术指标设置、技术指标文字显隐、技术指标单个移除。
- 数据更新。
```
[ 磁铁 锁 覆盖物显隐 移除 ]
```

```可在自定义顶部导航，添加一个手机的图标，点击强制切换到app布局方案。设置页面最宽750px,两边留背景
toggleEnv() {
	uni.setStorageSync('env', true);
	this.isApp = uni.getStorageSync('env');
},
```

``` 交易所多种玩法规则
合约交易用的就是usdt，所以买入1个btc，会消耗对应的usdt
而币币交易买入一个btc，btc数量+1，usdt数量消耗赌赢的
合约交易是有杠杆的，大多数玩合约都是玩的杠杆
合约的买入计算逻辑:买入价*数量/杠杆
卖出计算逻辑：（平仓价 - 买入价）*数量*杠杆

做多/看涨卖出：（平仓价 - 买入价）*数量*杠杆
做空/看跌卖出：（买入价 - 平仓价）*数量*杠杆

比如我买入10个价值6w的btc，100倍杠杆买入，则计算为
6w*10/100=6000  也就是我6000usdt就能买入1个btc
合约里支付费用（不包含手续费）统称为保证金，不叫支付总额，或者买入总额，都是固定的叫法，保证金
如果这个AAA上涨1%，不玩杠杆的话，我获得的利润就是1%  1000*0.01=10USDT
如果玩杠杆，则计算是
（平仓价 - 买入价） × 合约数量*杠杆

1000*1%*1*100  我就会获得1000usdt
平仓是全卖，卖出则是卖持有的任意数量。

爆仓：也就是你的亏损>=保证金+你的余额，就会直接自动卖出，然后你的账户归为0
比如你花5000usdt买了AAA币种，你账户有3000USDT   如果AAA亏损达到了8000usdt以上，则会自动卖出，然后你的账户就会归为0

做多的止盈止损：就是你设置多少价格就自动卖出，叫止盈，设置多少价格止损卖出，叫止损，两者都可以单独设置
做空的止盈止损：由于做空卖出 = (买入价-平仓价)* 数量*杠杆  因此平仓价越低 挣得越多  所以止盈就是   设置一个低于买入价的 价格即止盈价格      设置一个大于 买入价的价格 即 设置 止损价格

 欧美心心   的
做多买入计算逻辑
保证金=1000/杠杆*数量

手续费
1000*数量*0.0005
卖出计算逻辑是
（平仓价 - 买入价）*数量
欧美心心的这个举例，欧美心心的这个也就是不管买那个币种，保证金都是一样的
我10倍杠杆买入  买入10个BTC
保证金就是   1000/10*10=1000usdt就可以买入10个BTC

手续费就是1000*10*0.005=10000*0.005=50

所以支付金额就是1050USDT

如果我买入的时候BTC价格是60000   我卖出的时候BTC涨到61000   则61000-60000=1000    1000*10=10000  我就可以获得10000盈利-50手续费+1000保证金=10950usdt

关于合约这一块，每一家都不一样的
A 普通玩法
保证金=买入金额*数量/杠杆
卖出盈亏=（平仓价-买入金额）*数量

B 爆仓玩法  高暴力高风险
保证金=买入金额*数量/杠杆
卖出盈亏=（平仓价-买入金额）*数量*杠杆

C 固定玩法 高暴力高风险
保证金=1000/杠杆*数量
卖出盈亏=（平仓价-买入金额）*数量

D 仓位玩法 高暴力高风险
保证金=账户资金*仓位百分比（交易金额/账户仓位）
卖出盈亏=（平仓价-买入金额）*数量*杠杆
```


# Theme
`根据机制，在模板上使用，必须有一个变更值，才能重新计算样式。`
```
// 每个页面或组件，优先获取缓存的主题，而后传入模板，触发响应更新。
:style="$theme.setPageStyle(isDark)"
```

## 计时器完整逻辑通用写法
```
data() {
	return {
		timer: null,
	};
},
onHide() {
	if (this.timer) this.clearTimer();
},
onUnload() {
	if (this.timer) this.clearTimer();
},
deactivated() {
	console.log('deactivated', this.timer);
	if (this.timer) this.clearTimer();
},
methods: {
	onSetTimeout() {
		this.timer = setInterval(() => {
			console.log("setInterval");
			this.genKLineData();
		}, 60000);
	},
	clearTimer() {
		if (this.timer) {
			clearInterval(this.timer);
			this.timer = null;
			console.log('clearTimer', this.timer);
		}
	},
}
```


### 驱动子组件强刷的方案 （不推荐）
```
// refreshChild() {
// 	this.isUpdate = false;
// 	this.$nextTick(() => {
// 		this.isUpdate = true;
// 	})
// },
```
# 所有提交表单行为，添加按钮锁
```js
data() { return { isBtnLock: false,// 按钮是否锁定	} },
handleSubmit() {
	if (!this.checkForm()) return false;
	// 如果按钮锁定，则不执行提交事件
	if (this.isBtnLock) return false;
	this.isBtnLock = true; // 锁住按钮
	this.signIn(); // 调用提交的异步函数
},
async signIn() {
	const result = await this.$http.post(`api/app/login`, {
		username: this.user,
		password: this.password,
	});
	console.log('result:', result);
	this.isBtnLock = false; // 解锁
	if (!result) return false;
},
```



# 通用组件
## CustomSvg
```html
<CustomSvg :color="$theme.PRIMARY" :path="$svg.close" />
```
## CopyrightVersion
- 版权信息 + 版本号。所有布局方案通用

## MenuMedium
- ✅ `medium`, 右入菜单。

## FmtNumber
- 格式化数值显示，兼容多汇率模式(手动添加)。

## MultiDisplayNumber （备用）
- 某些数量值、金额值按需判断独显还是多显

## MenuSmall
- `small`, 左入菜单。

## FooterLarge
- 仿照网站，放一些标题及超链接，比如`About Us`
- CopyrightVersion

# 页面

## Translate 语言选择
- 竖屏:跳转到该页面选择语言; 宽屏:使用浮层。

## SignIn 登入注册 

## Rule 所有规则
- 所有需要说明的规则。
```
// 建议接口。通知、公告、消息、规则、关于、隐私等。
api/article
{
	key:要获取什么内容。如传入spt，则视为获取SPT的规则。如传入withdraw则视为获取提现规则。
	locale:内容的语言版本。
}
```

## DeFi 挖矿
- 始终保留备份`index-copy.vue`文件。
- 欧美心心：迁移项目的DeFi玩法及规则过来。

## crypto/index
- 币、外汇、~~期货、合约、秒合约、期权、U本位、币本位~~

## stock/index 
- 各国股票的详情及购买

## 日内 day
- Trading、apply、Approval

## 大宗 block
- products、Record

## 新股 ipo
- products、apply、Approval
- 欧美心心:ieo(新股申购)。
- - 竖屏首图+数据遍历；双栏切换：产品和记录。
- - 横屏：首图居右，左侧使用数组第一个对象，否则使用一个简短说明之类的填充下。之后数据列表。

## VIP vip
- products、apply、Approval


## 持仓 （各家规则不同）
`如意大利是将所有持有和历史在position展示，并支持持有列表实时刷新`
- 使用ws实时，计算部分值。
- 持仓、平仓、买涨、买跌、盈亏额、盈亏率


## Account/index
与`Assets`相同模式
- overview:总览。url 没有 tag 时显示。竖屏下不显示该组件。
- ✅ help:帮助中心。直接渲染。
- password:登入密码、支付密码
- address:钱包地址管理。添加删除该在同一组件中处理。
- bankCard:银行卡管理。添加删除该在同一组件中处理。
- - 竖屏上下布局，否则左右布局。一半表单，一半显示每个卡的信息。
- Advanced:高级认证(实名认证)。判断是否初级认证，而后跳转。
- terms:服务条款。
- paper：白皮书。点击可直接下载 pdf

## Assets/index 资产管理
- recharge:充值
- withdraw:提现
- convert:闪兑。
- transfer:划转
<!-- - order:订单中心 tab[秒合约、币币交易、U 本位合约]
- record:资金明细 tab[资产明细、储值明细、提现明细] -->
- loan:贷款。保留index-copy
- 

- 组件化：充值记录、提现记录、闪兑记录、划转记录

- - - 订单中心(assets?key=tradeOrder) [秒合约、币币交易、U 本位] 当前委托、历史委托等。与交易下的相同。交易对搜索。
- - - 资产明细(assets?key=records) [资产明细、储值明细、提现明细]

## Download
- 仅可由 icon 点入页面。

## Home

### notify

- horn 滚动内容 查看更多
- 宽：近在 banner 之下。
- 竖：八个功能按钮之下。

### Coin List

- tabs:[Popular coins(热门币)、Foreign currency(外币)、International gold(国际黄金)]

``

# 参考项目的页面整理

## 首页 无需 token

### PC

- EXFT 精选：在我们的帮助下，学习怎样赚钱
- flex 3:image+标题+部分文字。三个点击皆跳转到帮助中心。
- 一些醒目文字 居右背景图
- 加密货币投资指南：icon+文字，居右背景图
- 您可以信赖加密货币交易所：列举六大重点。
- 四个账户等级：标准账户、进阶账户、专业账户、合作伙伴账户
- 立即赚取利益：提供快速充值按钮

## 行情：quotes

### PC

- tabs:[自选、秒合约、币币交易、U 本位合约]，列表包含正序、反序、末尾操作按钮。跳转到 trade?
- 找位置放个搜索。输入直接过滤符合项。前端过滤。
- 列表：收藏标识，币种，最新价，涨跌幅，操作

### H5

- 搜索：过滤当前列表
- tabs:[自选、秒合约、币币交易、U 本位合约]
- - 自选：一个编辑 cion，点击显示完全覆盖弹层，选中列表的币种，点击添加。
- - 如果是自选时空的，提供一个添加自选的按钮，点击跳转到(addOptional)页面
- - - 搜索过滤当前列表。[币种 icon、币种、当前价、涨跌幅、关注标识]

<!--

 U 本位合約（USDT Perpetual，USDT-Margined Perpetual）
 幣本位合約（Coin-Margined Perpetual）也被稱為反向合約（Inverse Perpetual）
 期權（Option）
 永续合约通常被简称为 perp
 U本位（USDT/USDC-Margined）：合约以稳定币USDT或USDC作为结算计价单位的合约。
 币本位（Coin-Margined）：以正在交易的加密货币作为结算计价单位，因加密货币本身价值可能变动，而影响实际的盈利或损失。
 
 “当前委托”的英文通常是“Open Orders”或者“Current Orders”。其简写可以是“OOs”或者“COs”。
 -->

```
 <input
      type="text"
      v-model="formattedValue"
      @input="formatInput"
      placeholder="请输入数字"
    />
	export default {
	  data() {
	    return {
	      value: '', // 原始输入值
	    };
	  },
	  computed: {
	    formattedValue: {
	      get() {
	        return this.value ? this.addThousandSeparator(this.value) : '';
	      },
	      set(newValue) {
	        this.value = newValue.replace(/,/g, ''); // 去掉千分符
	      },
	    },
	  },
	  methods: {
	    addThousandSeparator(num) {
			num = num.toString();
	      // 转换为数字，如果不是数字则返回空字符串
	      num = num.replace(/[^\d]/g, '');  // 只允许数字输入
	      const intPart = num.split('.')[0]; // 获取整数部分
	      const decimalPart = num.split('.')[1] ? '.' + num.split('.')[1] : ''; // 获取小数部分
	      // 添加千分符
	      const formattedIntPart = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
	      return formattedIntPart + decimalPart;
	    },
	    formatInput(event) {
	      // 获取输入的值，并更新数据属性
	      this.formattedValue = event.target.value;
	    },
	  },
	};

```



# Update Log 2024.08.03

- ✅ plugins/Alert:自定义 `Alert`，状态。非 APP 执行 `$alert`，APP 使用 `uni.showToast`。

# Update Log 2024.08.01

- 使用自定义顶部及底部导航
- 多语言
- 本地化日期时间
- 明暗主题 `进行中`

# Update Log 2024.07.28

- websocket 添加断线重连。
- cantrct :index 添加倒计时 分别是距离 8 点 16 点 24 点的倒计时

```
弹层无法遮蔽tabbar解决方案：
uni.hideTabBar(); // 隐藏tabBar
uni.showTabBar(); // 显示tabBar
```

# Update Log 2024.05.15

- uniapp 内置`scroll-view`不支持桌面端鼠标移动。

