// import enUS from './en-US.js';
// import zhTW from './zh-TW.js';
// import enGB from './en-GB.js';
// import enAU from './en-AU.js';
// import zhCN from './zh-CN.js';
// import frFR from './fr-FR.js';
// import thTH from './th-TH.js';
// import jaJP from './ja-JP.js';
// import koKR from './ko-KR.js';
// import trTR from './tr-TR.js';
// import arIL from './ar-IL.js';
// import viVN from './vi-VN.js';

import Vue from 'vue';
import VueI18n from 'vue-i18n';

Vue.use(VueI18n);

import {
	DEFAULT_LOCALE
} from '@/common/constants.js';



import enUS from './en-US.json';
import zhTW from './zh-TW.json';
import jaJP from './ja-JP.json';
import frFR from './fr-FR.json';
import arIL from './ar-IL.json';
import ptPT from './pt-PT.json';
import esES from './es-ES.json';
import ruRU from './ru-RU.json';
// 根据项目需求，注释不需要的语言包。
const messages = {
	'en-US': enUS, // 英语
	'zh-TW': zhTW,
	'ja-JP': jaJP,
	'fr-FR': frFR,
	'ar-IL': arIL,
	'pt-PT': ptPT,
	'es-ES': esES,
	'ru-RU': ruRU,
	
	// 'en-GB': enGB,
	// 'en-AU': enAU,
	// 'zh-CN': zhCN,
	// 'th-TH': thTH,
	// 'ko-KR': koKR,
	// 'tr-TR': trTR,
	// 'vi-VN': viVN,
};

const i18n = new VueI18n({
	// locale: uni.getLocale(), // 获取已设置的语言
	locale: uni.getStorageSync('locale'),
	fallbackLocale: DEFAULT_LOCALE,
	formatFallbackMessages: true,
	messages
});

export default i18n;


// const i18nConfig = {
// 	// locale: uni.getLocale(), // 获取已设置的语言
// 	locale: uni.getStorageSync('locale'),
// 	fallbackLocale: DEFAULT_LOCALE,
// 	formatFallbackMessages: true,
// 	messages
// }


// export default i18nConfig;