<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="layout==$C.MEDIUM">
			<HeaderMedium @action="toogleTheme" />
		</template>

		<template v-if="layout==$C.LARGE">
			<HeaderLarge @action="toogleTheme" @update="refresh" v-if="isUpdate" />
		</template>

		<view :style="$theme.setStyleBody(layout)">
			download
			放一些图片，文字，超链接
			<template v-if="layout==$C.MEDIUM"> </template>
			<template v-if="layout==$C.LARGE"> </template>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				layout: null, // 当前布局方案
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
				isUpdate: true, // 页面子组件强刷
			}
		},
		onShow() {
			console.log(`onShow:`);
			this.isAnimat = true;
			this.layout = uni.getStorageSync('layout');
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
		},
		onReady() {},
		onHide() {
			console.log(`onHide:`, this.isDark);
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.refreshChild();
			uni.stopPullDownRefresh();
		},
		methods: {
			// 此为驱动子组件强刷的方案。
			refreshChild() {
				this.isUpdate = false;
				this.$nextTick(() => {
					this.isUpdate = true;
				})
			},
			refresh(val) {
				this.refreshChild();
			},

			// 设置主题
			toogleTheme(val) {
				this.isDark = !this.isDark;
				console.log(`toggle:`, this.isDark);
				this.$theme.setTheme(this.isDark);
				// this.$emit('action', 1);
				this.refreshChild();
			},

			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
		},
	}
</script>

<style>
</style>