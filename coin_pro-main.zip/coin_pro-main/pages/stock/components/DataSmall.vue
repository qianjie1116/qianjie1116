<template>
	<view>
		<view style="font-size: 16px;padding-bottom: 6px;"> {{detail.name}} </view>
		<view style="display: flex;align-items: center;justify-content: space-between;
		padding-bottom: 4px; border-bottom: 1px solid #34393e;" :style="$theme.setRiseFall(detail.info.rate*1)">
			<view>{{$fmt.fmtCurrency(`${detail.info.lastPrice*1}`)}}</view>
			<view>{{$fmt.fmtNumber(detail.info.rate*1)}}%</view>
			<view>{{$fmt.fmtCurrency(`${detail.info.rate_num*1}`)}}</view>
		</view>
		<!-- 开，收，高，低 -->
		<view style="display: flex;align-items: center;justify-content: space-between;
			line-height: 1.4;padding-top: 4px;">
			<template v-if="detail.info.open">
				<view style="text-align: center;">
					<view style="font-size: 11px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('stock.open'))}}
					</view>
					<view>{{$fmt.fmtCurrency(`${detail.info.open*1}`,curLocale)}}</view>
				</view>
			</template>
			<template v-if="detail.info.high">
				<view style="text-align: center;">
					<view style="font-size: 11px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('stock.high'))}}
					</view>
					<view>{{$fmt.fmtCurrency(`${detail.info.high*1}`,curLocale)}}</view>
				</view>
			</template>
			<template v-if="detail.info.low">
				<view style="text-align: center;">
					<view style="font-size: 11px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('stock.low'))}}
					</view>
					<view>{{$fmt.fmtCurrency(`${detail.info.low*1}`,curLocale)}}</view>
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'DataSmall',
		props: {
			detail: {
				type: Object,
				default: {}
			}
		},
		computed: {
			// 根据当前股票详情，判断使用的语言代码，用于格式化金额
			curLocale() {
				if (!this.detail) return '';
				return this.detail.project_type_id == 6 ? 'it-IT' : '';
			}
		},
	}
</script>

<style>
</style>