<template>
	<view>
		kline 工具
		kline 图表
		kline 技术指标
	</view>
</template>

<script>
	export default {
		name: 'KlineSmall',
		props: {
			klienData: {
				type: Object,
				default: {}
			}
		},
		beforeMount() {
			console.log(this.klienData);
		},
	}
</script>

<style>
</style>