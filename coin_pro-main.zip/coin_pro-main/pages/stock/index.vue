<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.SMALL)">
			<HeaderSmall :dark="isDark" @update:dark="isDark = $event" :title="$fmt.fmtText($t('stock.detail'))" />
		</template>



		<view :style="$theme.setStyleBody()">
			<template v-if="detail">
				<template v-if="$theme.setLayout($C.SMALL)">
					<DataSmall :detail="detail" />

					<KlineSmall :klienData="klineData" />

				</template>
			</template>


			<template v-if="$theme.setLayout($C.SMALL)">
				<view class="btn_common" @click="showModal()" style="margin: 24px 0;line-height: 40px;">
					{{$fmt.fmtText($t('common.buy'))}}
				</view>
			</template>

			<template v-else>
				<view> 非 small 购买区域

					<view class="btn_common" @click="handleSubmit()" style="margin: 24px 0;line-height: 40px;">
						{{$fmt.fmtText($t('common.buy'))}}
					</view>
				</view>
			</template>
		</view>

		<!-- 仅限竖屏的购买弹层 -->
		<template v-if="$theme.setLayout($C.SMALL)">
			<template v-if="isShow">
				<view class="overlay" @click="handleClose()"></view>
				<view class="modal_wrapper bottom_in" style="background-color: #0a0c13;border-radius: 16px 16px 0 0;">
					<view style="width: 100%;height: 100%;">
						<view style="display: flex;align-items: center;padding:16px;">
							<view style="margin-left: auto;" @click="handleClose()">
								<CustomSvg :path="$svg.close" :color="$theme.PRIMARY"></CustomSvg>
							</view>
						</view>
						<view style="padding:16px;">
							<view style="font: 14px;font-weight: 700;">
								{{$fmt.fmtText($t('common.amount'))}}
							</view>
							<view class="input_wrapper" :style="$theme.setInputStyle(isDark)">
								<input v-model="quantity" type="number"
									:placeholder="$fmt.fmtText($t('common.enter')+ $t('common.amount'))"
									:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
							</view>
							<view
								style="display: flex;align-items: center;justify-content: space-between;padding-top: 8px;">
								<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
									{{$fmt.fmtText($t('stock.total'))}}
								</view>
								<MultiDisplayNumber :value="totalAmount" :config="setFmtConfig" />
							</view>
							<view style="display: flex;align-items: center;padding-top: 8px;">
								<view style="flex:auto; font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
									{{$fmt.fmtText($t('common.balance'))}}
								</view>
								<view style="margin-left: auto;padding-right: 8px;">
									<MultiDisplayNumber :value="balance" :config="setFmtConfig" />
								</view>
								<view style="margin-left: auto; font-size: 12px;"
									:style="{color:$theme.PRIMARY,borderBottom:`1px solid `+$theme.PRIMARY}"
									@click="$linkTo.linkAssets($C.KEY_RECHARGE)">
									{{$fmt.fmtText($t('assets.recharge'))}}
								</view>
							</view>
							<!-- 买多 -->
							<view class="btn_common" @click="handleSubmit()" style="margin: 24px 0;line-height: 40px;">
								{{$fmt.fmtText($t('common.buy'))}}
							</view>
							<!-- 卖空 -->
						</view>
					</view>
				</view>
			</template>
		</template>
	</view>
</template>

<script>
	import DataSmall from './components/DataSmall.vue';
	import KlineSmall from './components/KlineSmall.vue';
	export default {
		components: {
			DataSmall,
			KlineSmall,
		},
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
				symbol: '', // url?symbol= 详情 请求所需
				curKLine: 0, // 当前选中kline
				detail: null, // 详情
				isShow: false, // 是否显示购买弹层
				balance: '', // 账户余额
				quantity: '', // 购买股数
				config: null, // 获取配置

				klineData: null, // 图表数据
			}
		},
		computed: {
			// kline ws的url
			curWSURL() {

			},

			// 总额 = 单价*股数
			totalAmount() {
				if (this.detail && this.detail.current_price && this.quantity > 0) {
					console.log(this.detail.current_price * this.quantity)
					return this.detail.current_price * this.quantity;
				} else {
					return ''
				}
			},
			// 格式化配置，获取汇率
			setFmtConfig() {
				let temp;
				// 根据 config 接口返回，改变指定币种的汇率
				if (this.detail.project_type_id == 6) {
					temp = this.$fmt.prioritizeLocale(this.$fmt.fmtConfig(), 'it-IT');
				} else {
					temp = this.$fmt.prioritizeLocale(this.$fmt.fmtConfig(), 'en-US');
				}
				temp[`en-US`].rate = 1.3579;
				// temp[`en-US`].rate = this.config.get('eur_usd') || 1;
				return temp;
			},
		},
		onLoad(opt) {
			this.symbol = opt.symbol || this.symbol;
		},
		onShow() {
			if (!this.$linkTo.checkToken()) return false;
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
			console.log(this.symbol);
			this.getDetail();
			this.getConfig();
			this.getAccountInfo();
		},
		onReady() {},
		onHide() {
			console.log(`onHide:`, this.isDark);
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getDetail();
			this.getConfig();
			this.getAccountInfo()
			uni.stopPullDownRefresh();
		},
		deactivated() {},

		methods: {
			// // 此为驱动子组件强刷的方案。
			// refreshChild() {
			// 	this.isUpdate = false;
			// 	this.$nextTick(() => {
			// 		this.isUpdate = true;
			// 	})
			// },
			showModal() {
				this.isShow = true;
			},
			handleClose() {
				this.isShow = false;
				// console.log('close');
			},

			// 获取详情
			async getDetail() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.requestData')),
				});
				const result = await this.$http.post(`api/product/info`, {
					code: this.symbol,
					time_index: this.curKLine
				});
				if (!result) return false;
				if (result.length > 0) this.detail = result[0];
				console.log(`detail:`, this.detail);
				this.detail.info.open = 123;
				this.detail.info.high = 456;
				this.detail.info.low = 789;
			},

			// 购买
			async handleSubmit() {

			},

			// 获取账户信息
			async getAccountInfo() {
				const result = await this.$http.get(`api/user/fastInfo`);
				if (!result) return false;
				console.log(`getAccountInfo:`, result);
				this.balance = result.money || 0;
			},

			// 获取配置
			async getConfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				console.log(`getConfig:`, result);
				this.config = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				console.log(`getConfig:`, this.config);
			},
		},
	}
</script>

<style lang="scss" scoped>
	.modal_wrapper {
		width: 100vw;
		min-height: 40vh;
		background-color: transparent;
		position: fixed;
		bottom: 0;
		left: 0;
		right: 0;
		z-index: 13;
	}
</style>