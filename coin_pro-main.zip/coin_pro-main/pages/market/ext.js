import Vue from 'vue';
import i18n from '@/locales/index.js';
import * as constants from '@/common/constants.js';
import http from '@/common/http.js';
import * as fmt from '@/common/format.js';
import * as theme from '@/theme/index.js';

// tabs
export const tabs = () => {
	return [{
			key: constants.KEY_CRYPTO,
			value: fmt.fmtText(i18n.t('market.crypto')),
		},
		// {
		// 	key: constants.KEY_FOREX,
		// 	value: fmt.fmtText(i18n.t('market.forex')),
		// },
		// {
		// 	key: constants.KEY_FUTURE,
		// 	value: fmt.fmtText(i18n.t('market.future')),
		// }, 
		// {
		// 	key: constants.KEY_USSTOCK,
		// 	value: fmt.fmtText(i18n.t('market.usstock')),
		// }, {
		// 	key: constants.KEY_UKSTOCK,
		// 	value: fmt.fmtText(i18n.t('market.ukstock')),
		// }
	]
};