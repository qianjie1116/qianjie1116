<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<view :style="$theme.setStyleBody()">
			<!-- 宽竖通用 列表显示切换 -->
			<scroll-view :scroll-x="true" style="white-space: nowrap;width: 100%;padding:0;" @touchmove.stop>
				<view style="display: flex;margin:0 4px;">
					<block v-for="(v,k) in tabs" :key='k'>
						<view :style="setStyleTab(curTab==k)" @click="changeTab(k)">
							{{$fmt.fmtText( v.value,$C.FMT_METHOD_TC)}}
						</view>
					</block>
				</view>
			</scroll-view>
			<!-- 检索 -->

			<view class="input_wrapper" style="margin: 10px auto;">
				<view :style="{color:$theme.LOG_VALUE}">
					{{$fmt.fmtText($t('common.filter'),$C.FMT_METHOD_TC)}}
				</view>
				<view style="padding:0 8px;" :style="{color:$theme.LOG_VALUE}">|</view>
				<input v-model="keyword" type="text" :placeholder="$t('common.enter')+ $t('common.keywords')"
					:placeholder-style="$theme.setPlaceholder()" confirm-type="search"></input>
			</view>

			<!-- 宽竖通用 curTab 显示列。 -->
			<view :class="curTab%2===0?'right_in':'left_in'">
				<template v-if="!filterList || filterList.length<=0">
					<EmptyData />
				</template>
				<template v-else>
					<block v-for="(item,index) in filterList" :key="index">
						<view class="item" style="padding:12px 0;">
							<view style="display: flex;align-items: center;" @click="linkDetail(item)">
								<view style="margin-right: auto;">
									<CustomLogo :logo="item.logo" :name="item.name" :size="24" />
								</view>
								<view style="flex:0 0 10%;">
									<view style="font-size: 14px;padding-left: 10px;">
										{{item.name}}
									</view>
								</view>
								<view style="flex:1 1 auto;">
									<view style="font-size: 14px;font-weight: 500;text-align: center;">
										{{$fmt.fmtCrypto(`${item.current_price}`)}}
									</view>
								</view>
								<view style="margin-left: auto;">
									<view style="padding:8px;border-radius: 4px;min-width: 60px;text-align: center;"
										:style="$theme.setRiseFall(item.rate ,true)">
										{{`${item.rate>0?'+':'-'} `+ $fmt.fmtNumber (Math.abs(item.rate))}}%
									</view>
								</view>
								<template v-if="$theme.setLayout($C.LARGE)||$theme.setLayout($C.MEDIUM)">
									<view style="margin-left: auto;">
										<view class="btn_common" :class="isDark ? `btn_dark` : `btn_light`"
											@click.stop="hanldeBuy(item)">{{$t('common.buy')}}</view>
									</view>
								</template>
							</view>
						</view>
					</block>
				</template>
			</view>

			<template v-if="$theme.setLayout($C.SMALL)">
				<FooterSmall :dark="isDark" />
			</template>
		</view>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	export default {
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
				isUpdate: true, // 强刷
				tabs: ext.tabs(),
				curTab: 0, // 当前默认放在Coin
				keyword: '', // 过滤关键字
				list: null,
				wsClient: null, // ws实例
				isConnected: false, // ws是否连接
			}
		},

		computed: {
			setList() {
				return !this.list ? [] : Object.values(this.list);
			},
			// 根据关键字，过滤数据
			filterList() {
				if (!this.setList || this.setList.length <= 0) return [];
				// 输入三个字符以上才检索
				if (this.keyword.length >= 3) {
					return this.setList.filter(item =>
						item.code.toLowerCase().includes(this.keyword.toLowerCase()) ||
						item.name.toLowerCase().includes(this.keyword.toLowerCase()) ||
						item.locate.toLowerCase().includes(this.keyword.toLowerCase()));
				} else {
					return this.setList;
				}
			},
			// 当前显示列表的key
			curKey() {
				console.log(`curKey:`, this.curTab);
				console.log(`curKey:`, this.tabs[this.curTab].key);
				return this.tabs[this.curTab].key;
			},
			// 当前 ws url
			curURL() {
				if (this.curKey == this.$C.KEY_CRYPTO) return this.$http.WS_COIN_URL;
				return this.$http.WS_OTHER_URL;
			},
		},

		onLoad(opt) {
			this.curTab = Number(opt.type) || 0;
			this.keyword = opt.symbol || this.keyword;
		},
		onShow() {
			if (!this.$linkTo.checkToken()) return false;
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
			this.changeTab(this.curTab);
		},
		onHide() {
			this.isAnimat = false;
			if (this.wsClient) this.disconnect();
		},
		onUnload() {
			if (this.wsClient) this.disconnect();
		},
		onPullDownRefresh() {
			if (this.wsClient) this.disconnect();
			// this.refreshChild();
			uni.stopPullDownRefresh();
		},

		deactivated() {
			if (this.wsClient) this.disconnect();
		},

		methods: {
			// // 此为驱动子组件强刷的方案。
			// refreshChild() {
			// 	this.isUpdate = false;
			// 	this.$nextTick(() => {
			// 		this.isUpdate = true;
			// 	})
			// },

			// 在自选点击添加按钮，跳转到coin列表
			toCoin(val) {
				this.curTab = 1;
				this.changeTab(this.curTab);
			},

			changeTab(val) {
				this.curTab = val;
				this.getList();
			},
			// linkDetail 行点击
			linkDetail(val) {
				if (!this.$linkTo.checkToken()) return false;
				console.log(`val:`, val);
				console.log(val.locate);
				// 分为股票详情，和加密币详情
				if (this.$util.isUSDT(this.curKey)) {
					this.$linkTo.cryptoDetail(val.code);
				} else {
					this.$linkTo.stockDetail(val.locate);
				}
			},

			// buy按钮点击
			hanldeBuy(val) {
				this.linkDetail(val);
			},

			async getList() {
				uni.showLoading({
					title: this.$t('api.requestData'),
				});
				console.log(`curTab:`, this.curTab);
				const temp = this.tabs[this.curTab].key;
				console.log('gpIndex:', this.$C.GPINDEX[temp]);
				const result = await this.$http.post(`api/goods/list`, {
					page: 1,
					gp_index: this.$C.GPINDEX[temp]
				});
				console.log(`coin result:`, result);
				if (!result) return false;
				this.list = result;

				if (Object.values(this.list).length > 0) {
					if (this.wsClient) this.disconnect();
					// this.wsClient = new WebSocketTool(tempURL);
					console.log(`wsClient:`, this.curURL, this.wsClient);
					if (this.curTab == 0) this.initWebsocket();
				}
			},

			// websocket 断线重连
			reconnectWebSocket() {
				// 连接中，并且非手动关闭
				if (this.isConnected) return;
				console.log(`reconnect!`, this.isConnected);
				this.wsClient = null;
				console.log(`reconnect! socket:`, this.wsClient);
				this.initWebsocket();
			},

			// 关闭 websocket链接
			disconnect() {
				if (this.wsClient) {
					this.wsClient.close();
					this.wsClient = null;
					this.isConnected = false;
				}
			},

			//  websocket
			initWebsocket() {
				if (this.wsClient) this.disconnect();
				this.wsClient = uni.connectSocket({
					url: this.curURL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.info(`success res:`, res);
					},
					fail: (res) => {
						console.info(`fail res:`, res);
					}
				});

				console.log(`socket:`, this.wsClient);
				this.wsClient.onOpen((res) => {
					console.info("socket onOpen:", res);
					this.isConnected = true; // 已连接
					// if (this.messageHanlder) {
					// 	this.socket.onMessage(this.messageHanlder);
					// }
				});
				this.wsClient.onClose((res) => {
					// code:1000(手动关闭) 1006(异常关闭) 
					console.log(`onClose:`, res);
					this.isConnected = false;
					if (res.code !== 1000) {
						this.reconnectWebSocket();
					}
				});
				this.wsClient.onError((err) => {
					console.log(`onError:`, err);
					this.isConnected = false;
					this.reconnectWebSocket();
				});
				this.wsClient.onMessage((res) => {
					const data = JSON.parse(res.data);
					if (data.type == "ticker") {
						if (this.curTab == 0) {
							if (this.list[data.market] && data.market && data.lastPrice > 0) {
								// if (data.market == 'btcusdt') {
								// 	console.log(data.type, data);
								// }
								this.list[data.market].current_price = data.lastPrice;
								this.list[data.market].rate = data.rate || 0;
								this.list[data.market].vol = data.vol || 0;
							}
						} else {
							if (this.list[data.pid] && data.pid && data.last > 0) {
								this.list[data.pid].current_price = data.last;
								this.list[data.pid].rate = data.pcp || 0;
							}
							// if (this.listFutures[data.pid] && data.pid && data.last > 0) {
							// 	this.listFutures[data.pid].current_price = data.last;
							// 	this.listFutures[data.pid].rate = data.pcp || 0;
							// }
						}
					}
				});
			},

			setStyleTab(val) {
				return {
					width: `max-content`,
					padding: `6px 16px 6px 0`,
					color: val ? this.$theme.PRIMARY : '#838b9c',
					textAlign: 'center',
					fontSize: `18px`,
					fontWeight: `700`,
				}
			},
		},
	}
</script>

<style lang="scss" scoped>
	.input_wrapper {
		display: flex;
		flex-wrap: nowrap;
		align-items: center;
		box-shadow: none;
		border: 1px solid #536fff;
		height: 32px;
		background-color: transparent;
		border-radius: 3px;
		padding: 0 20px;

		input {
			width: 90%;
		}
	}
</style>