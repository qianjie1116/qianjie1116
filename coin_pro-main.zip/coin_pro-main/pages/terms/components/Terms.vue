<template>
	<view class="right_in">
		<view :class="$theme.setLayout($C.SMALL)?`second_small`:`second_medium`">
			<template v-if="!detail">
				<view style="text-align: center;" :style="{color:$theme.TXT_UNACT}">
					{{$fmt.fmtText($t('common.emptyData'))}}
				</view>
			</template>
			<template v-else>
				<view v-html="detail.content"></view>
			</template>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'Terms',
		props: {
			dark: {
				type: Boolean,
				default: true,
			}
		},
		data() {
			return {
				detail: null
			}
		},
		beforeMount() {
			this.getDetail();
		},
		methods: {
			async getDetail() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.requestData')),
				});
				const result = await this.$http.get(`api/article/privacy`);
				console.log('result:', result);
				if (!result) return false;
				this.detail = {
					title: result.title,
					content: result.content,
				}
			},
		}
	}
</script>

<style>
</style>