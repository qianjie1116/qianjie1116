<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.SMALL)">
			<HeaderSmall :dark="isDark" @update:dark="isDark = $event" :title="$t('account.terms')"> </HeaderSmall>
		</template>

		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<view :style="$theme.setStyleBody()">
			<Terms />
		</view>
	</view>
</template>

<script>
	import Terms from './components/Terms.vue';
	export default {
		components: {
			Terms
		},
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
				info: null
			}
		},
		onShow() {
			// if (!this.$linkTo.checkToken()) return false;
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
		},
		onReady() {},
		onHide() {
			console.log(`onHide:`, this.isDark);
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			uni.stopPullDownRefresh();
		},
		deactivated() {},
		methods: {}
	}
</script>

<style>
</style>