// 
import Vue from 'vue';
import * as constants from '@/common/constants.js';
import * as fmt from '@/common/format.js';
import {
	translate
} from '@/common/util.js';

// tabs
export const tabs = () => {
	return [{
		key: constants.KEY_CRYPTO_SPT,
		value: fmt.fmtText(translate('crypto.spt')),
	}, {
		key: constants.KEY_CRYPTO_CT,
		value: fmt.fmtText(translate('crypto.ct')),
	}, {
		key: constants.KEY_CRYPTO_PERP,
		value: fmt.fmtText(translate('crypto.perp')),
	}, {
		key: constants.KEY_CRYPTO_OPT,
		value: fmt.fmtText(translate('crypto.opt')),
	}, {
		key: constants.KEY_CRYPTO_USDT,
		value: fmt.fmtText(translate('crypto.usdt')),
	}, {
		key: constants.KEY_CRYPTO_CMT,
		value: fmt.fmtText(translate('crypto.cmt')),
	}, ]
};