<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.SMALL)">
			<HeaderSmall :dark="isDark" @update:dark="isDark = $event" :title="setTitle" />
		</template>

		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<view :style="$theme.setStyleBody()">
			<template v-if="!isHaveTag">
				<!-- S：顶部横向排列 -->
				<template v-if="$theme.setLayout($C.SMALL)">
					<view
						style="display: flex;align-items: center;justify-content: center;padding:16px;margin-bottom: 20px;"
						:style="{borderBottom:` 1px solid ${$theme.TXT_UNACT}`}">
						<block v-for="(v,k) in tabs" :key="k">
							<view class="tab_item" :style="{color:curTab==k? $theme.PRIMARY : $theme.TXT_UNACT}"
								@click="changeTab(k)">
								<text>{{v.value}}</text>
							</view>
						</block>
					</view>

					<view style="padding:0 20px 30px 20px;max-width: 800px;margin: auto;line-height: 1.4;">
						<template v-if="!info">
							<EmptyData></EmptyData>
						</template>
						<template v-else>
							<view style="text-align: center;color:#AAAAAA">
								<view v-html="info"></view>
							</view>
						</template>
					</view>
				</template>
			</template>

			<template v-if="$theme.setLayout($C.MEDIUM) || $theme.setLayout($C.LARGE)">
				<view
					style="max-width: 800px;margin: auto;margin-top: 24px;border-radius: 4px;display: grid; grid-auto-flow: column;row-gap: 10px;"
					:style="{border:` 1px solid ${$theme.TXT_UNACT}`}">
					<!-- M及L:左侧垂直排列 -->
					<view style="display: inline-block;padding:16px;">
						<block v-for="(v,k) in tabs" :key="k">
							<view style="display: flex;align-items: center;cursor: pointer;margin:16px 0;"
								:style="{color:curTab==k? $theme.PRIMARY : $theme.TXT_UNACT}" @click="changeTab(k)">
								<text
									style="font-size: 18px;font-weight: 700;">{{v.value+` `+$fmt.fmtText($t('header.rule'))}}</text>
								<image :src="`/static/arrow-right_${isDark?0:1}.svg`" mode="aspectFit"
									style="margin-left: auto;" :style="$theme.setImageSize(28)"></image>
							</view>
						</block>
					</view>

					<view
						style="display: inline-block;padding:0 20px 30px 20px;max-width: 800px;margin: auto;line-height: 1.4;"
						:style="{borderLeft:` 1px solid ${$theme.TXT_UNACT}`}">
						<template v-if="!info">
							<EmptyData></EmptyData>
						</template>
						<template v-else>
							<view
								style="text-align: center;font-size: 20px;font-weight: 900;line-height: 3;margin:0 auto;width: 80%;"
								:style="{borderBottom:` 1px solid ${$theme.TXT_UNACT}`}">
								{{setTitle}}
							</view>
							<view style="text-align: center;color:#AAAAAA;margin-top: 20px;">
								<view v-html="info"></view>
							</view>
						</template>
					</view>
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	export default {
		components: {},
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
				curTab: 0, // 
				info: null, // 
				curTag: '', // 当前url携带tag的值。
				tabs: ext.tabs(),
			}
		},
		computed: {
			setTitle() {
				return `${this.tabs[this.curTab].value} ` + this.$t('header.rule')
			},
			// 当前url是否携带tag
			isHaveTag() {
				// console.log()
				return this.curTag && this.curTag.length > 0;
			}
		},
		onLoad(opt) {
			this.curTag = opt.tag;
			// 在交易相关，借贷相关，充提兑转相关，会在url拼接 tag
			const temp = this.tabs.findIndex(item => opt.tag == item.key.toLowerCase());
			this.curTab = temp > 0 ? temp : this.curTab;
		},
		onShow() {
			if (!this.$linkTo.checkToken()) return false;
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
			this.changeTab(this.curTab);
			console.log(`tabs:`, this.tabs);
		},
		onReady() {},
		onHide() {
			console.log(`onHide:`, this.isDark);
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.changeTab(this.curTab);
			uni.stopPullDownRefresh();
		},
		deactivated() {},

		methods: {
			changeTab(val) {
				this.curTab = val;
				this.getData();
			},

			// 获取数据
			async getData() {
				uni.showLoading({
					title: this.$t('api.requestData'),
				});
				const result = await this.$http.get(`api/article/privacy`);
				console.log('result:', result);
				if (!result) return false;
				this.info = result.content;
			},
		},
	}
</script>

<style lang="scss" scoped>
	// .app_header {
	// 	padding: 24px 20px 10px 20px;
	// 	display: flex;
	// 	align-items: center;
	// 	border-bottom: 1px solid #34393e;

	// 	.left {
	// 		flex: 0 0 auto;
	// 	}

	// 	.right {
	// 		flex: 0 0 auto;
	// 	}

	// 	.center {
	// 		font-size: 32rpx;
	// 		font-weight: 500;
	// 		// padding-left: 40rpx;
	// 		flex: 1 1 auto;
	// 		text-align: center;
	// 	}
	// }

	.tab_item {
		font-size: 16px;
		font-weight: 700;
		text-align: center;
		min-width: 25%;
	}
</style>