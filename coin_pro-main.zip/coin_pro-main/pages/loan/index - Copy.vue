<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.SMALL)">
			<HeaderSmall :title="$t('header.loan')">
				<view style="padding-left: 10px;" :style="$theme.setImageSize(24)" @click="$linkTo.loanRecord()">
					<CustomSvg :color="$theme.PRIMARY" :path="$svg.record" />
				</view>
			</HeaderSmall>
		</template>

		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<view :style="$theme.setStyleBody()">
			<view class="second_medium">
				<view style="font: 14px;font-weight: 700;margin-top: 10px;">
					{{$fmt.fmtText($t('loan.goods'))}}
				</view>
				<view style="position: relative;">
					<view class="input_wrapper" :style="$theme.setInputStyle(isDark)" @click="handleShow()">
						<view style="flex:auto;height: 32px;line-height: 32px;font-size: 16px;">
							<template v-if="curGoods">
								{{$fmt.fmtNumber(curGoods.min)+` - `+$fmt.fmtNumber(curGoods.max)}}
							</template>
							<template v-else>
								<text style="font-size: 12px;"
									:style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('common.choose')+$t('header.loan')+` `+ $t('common.goods'))}}</text>
							</template>
						</view>
						<view style="margin-left: auto;">
							<view :style="$theme.setImageSize(16)">
								<CustomSvg :color="$theme.PRIMARY" :size="20" :path="$svg.arrowDown" />
							</view>
						</view>
					</view>
					<template v-if="showGoods">
						<view style="position: absolute;z-index: 9;left: 0;width: 100%; background-color: #0a0c13;">
							<block v-for="(v,k) in goodsList" :key="k">
								<view style="text-align: center;padding:10px 20px;" @click="chooseGoods(v)">
									{{$fmt.fmtNumber(v.min)+` - `+$fmt.fmtNumber(v.max)}}
								</view>
							</block>
						</view>
						<view class="overlay" @click.stop="hanldeClose()"> </view>
					</template>
				</view>

				<view style="font: 14px;font-weight: 700;margin-top: 24px;">
					{{$fmt.fmtText($t('loan.amount'))}}
				</view>
				<view class="input_wrapper" :style="$theme.setInputStyle(isDark)">
					<input v-model="amount" type="digit"
						:placeholder="$fmt.fmtText($t('common.enter')+$t('loan.amount'))"
						:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
				</view>

				<view style="display: flex;align-items: center;margin-top: 24px;">
					<view style="font: 14px;font-weight: 700;">{{$t('loan.detail')}}</view>
					<view style="margin-left: auto;cursor: pointer;" @click="$linkTo.rule($C.KEY_RULE_LOAN)">
						<view style="display: flex;align-items: center;">
							<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
								{{$fmt.fmtText($t('header.rule'))}}
							</view>
							<image :src="`/static/arrow_right_small.svg`" mode="aspectFit"
								:style="$theme.setImageSize(12)"></image>
						</view>
					</view>
				</view>

				<view
					style="margin-top:10px; padding:10px;border-top: 1px solid #666;border-bottom: 1px solid #666;line-height: 2;">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view>{{$fmt.fmtText($t('loan.cycle'))}}</view>
						<view>7</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view>{{$fmt.fmtText($t('loan.dailyRate'))}}</view>
						<view>0.16%</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view>{{$fmt.fmtText($t('loan.interest'))}}</view>
						<view>0 {{$t('common.unitUSDT')}}</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view>{{$fmt.fmtText($t('loan.method'))}}</view>
						<view>到期一次还本息</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view>{{$fmt.fmtText($t('loan.lending'))}}</view>
						<view>Binance</view>
					</view>
				</view>

				<view style="font: 14px;font-weight: 700;margin-top: 24px;margin-bottom: 8px;">
					{{$fmt.fmtText($t('recharge.upload'))}}
				</view>
				<view @click="selectImg()" style="display: flex;align-items: center;justify-content: center;padding: 24px;
					border-top: 1px solid #666;border-bottom: 1px solid #666;">
					<template v-if="!obverseUrl">
						<view
							style="margin:20rpx;width:220px;height:120px;display: flex;align-items: center;justify-content: center;flex-direction: column;">
							<image src="/static/icon_upload.png" mode="aspectFit" :style="$theme.setImageSize(96)">
							</image>
						</view>
					</template>
					<template v-else>
						<image :src="obverseUrl" style="margin:20rpx;width:220px;height:120px;">
						</image>
					</template>
				</view>

				<view class="btn_common" @click="handleSubmit()" style="margin: 24px 0;line-height: 40px;">
					{{$fmt.fmtText($t('common.submit'))}}
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		components: {},
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
				showGoods: false, // 显示借贷产品备选列表
				goodsList: null, // 产品备选列表
				curGoods: null, // 当前选中产品
				amount: '', // 借款金额
				obverseUrl: null, // 上传凭证
			}
		},
		computed: {
			setStyleBody() {
				let temp = {};
				// 当前布局调整 小屏样式，紧凑样式，宽屏样式
				if (this.$theme.setLayout(this.$C.SMALL))
					temp.padding = `0 0 80px 0`;
				else {
					temp.padding = `0 0 20px 0`;
					temp.maxWidth = `800px`;
					temp.margin = `0 auto`;
				}
				return temp;
			},
		},

		onShow() {
			if (!this.$linkTo.checkToken()) return false;
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
		},
		onHide() {
			console.log(`onHide:`, this.isDark);
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			uni.stopPullDownRefresh();
		},
		deactivated() {},

		methods: {
			handleShow() {
				this.getGoodsList();
			},
			hanldeClose() {
				this.showCoinList = false;
			},
			// coin選擇器確認事件
			chooseGoods(val) {
				console.log(`confirmMode e:`, val);
				// this.code = e.value[0].code;
				this.showGoods = false;
				this.curGoods = val;
			},

			// 点击上传
			async selectImg() {
				const result = await uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
				});
				console.log('result:', result);
				const imageFile = result[1].tempFiles[0];
				console.log('imageFile:', imageFile);
				const reultURL = await this.$http.uploadImage(imageFile.path);
				console.log(`resultURL:`, reultURL);
				if (!reultURL) return false;
				this.obverseUrl = reultURL;
				console.log(`obverseUrl:`, this.obverseUrl);
			},

			// 提交
			async handleSubmit() {
				if (!this.amount || this.amount <= 0) {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('common.amount')),
						icon: 'none'
					});
					return false;
				}
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.submiting')),
				});
				const result = await this.$http.post(`api/user/dk_shenqing`, {
					money: this.amount,
				});
				if (!result) return false;
				console.log(`result:`, result);
				uni.showToast({
					// title: result,
					icon: 'success'
				});
				setTimeout(() => {
					this.$linkTo.loanRecord();
				}, 1000);
			},

			// 获取产品列表
			async getGoodsList() {
				// const result = await this.$http.post(`api/xxxx`);
				// if (!result) return false;
				// console.log(result);
				const temp = [{
						"searchValue": null,
						"createBy": null,
						"createTime": "2023-08-09 11:12:06",
						"updateBy": null,
						"updateTime": "2023-08-25 03:04:02",
						"remark": null,
						"id": 6,
						"amountMin": 1000.000000,
						"amountMax": 100000.000000,
						"cycleType": 7,
						"repayType": 0,
						"status": 1,
						"odds": 0.160000,
						"repayOrg": "Binance",
						"isFreeze": "1"
					},
					{
						"searchValue": null,
						"createBy": null,
						"createTime": "2023-08-09 13:53:12",
						"updateBy": null,
						"updateTime": "2023-08-25 03:01:30",
						"remark": null,
						"id": 7,
						"amountMin": 1000.000000,
						"amountMax": 1000000.000000,
						"cycleType": 15,
						"repayType": 0,
						"status": 1,
						"odds": 0.142000,
						"repayOrg": "Binance",
						"isFreeze": null
					}
				];

				this.goodsList = temp.map(item => {
					return {
						min: item.amountMin,
						max: item.amountMax,
						id: item.id
					}
				});

				// 獲取數據之後，顯示選擇器
				this.showGoods = true;
				this.curGoods = this.getGoodsList[0];
			},
		},
	}
</script>

<style lang="scss" scoped>

</style>