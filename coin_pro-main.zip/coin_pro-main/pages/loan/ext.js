// loan
import Vue from 'vue';
import i18n from '@/locales/index.js';
import * as constants from '@/common/constants.js';
import * as fmt from '@/common/format.js';
import http from '@/common/http.js';
import * as icons from '@/icons/index.js';

// 页面说明组 产品优势
export const desc = () => {
	return [{
		title: i18n.t('loan.title0'),
		txt: i18n.t('loan.text0'),
		icon: icons.desc0,
	}, {
		title: i18n.t('loan.title1'),
		txt: i18n.t('loan.text1'),
		icon: icons.desc1,
	}, {
		title: i18n.t('loan.title2'),
		txt: i18n.t('loan.text2'),
		icon: icons.desc2,
	}, {
		title: i18n.t('loan.title3'),
		txt: i18n.t('loan.text3'),
		icon: icons.desc3,
	}]
};

// 页面step组
export const steps = () => {
	return [{
		key: i18n.t('loan.step1'),
		value: i18n.t('loan.step1Title'),
		icon: icons.step1,
	}, {
		key: i18n.t('loan.step2'),
		value: i18n.t('loan.step2Title'),
		icon: icons.step2,
	}, {
		key: i18n.t('loan.step3'),
		value: i18n.t('loan.step3Title'),
		icon: icons.step3,
	}, {
		key: i18n.t('loan.step4'),
		value: i18n.t('loan.step4Title'),
		icon: icons.step4,
	}]
};

// 页面问答组
export const qa = () => {
	return [{
		q: i18n.t('loan.q1'),
		a: i18n.t('loan.a1'),
	}, {
		q: i18n.t('loan.q2'),
		a: i18n.t('loan.a2'),
	}, {
		q: i18n.t('loan.q3'),
		a: i18n.t('loan.a3'),
	}, {
		q: i18n.t('loan.q4'),
		a: i18n.t('loan.a4'),
	}, {
		q: i18n.t('loan.q5'),
		a: i18n.t('loan.a5'),
	}]
};