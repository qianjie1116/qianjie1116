<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.SMALL)">
			<HeaderSmall :title="$t('header.loan')">
				<!-- <view style="padding-left: 10px;" :style="$theme.setImageSize(24)" @click="$linkTo.loanRecord()">
					<CustomSvg :color="$theme.PRIMARY" :path="$svg.record" />
				</view> -->
			</HeaderSmall>
		</template>

		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<view :style="$theme.setStyleBody()">
			<template v-if="$theme.setLayout($C.SMALL)">
				<view
					style="background-image: url(/static/img_defi.png);background-position: 0 0;background-repeat: no-repeat;background-size: 100% 100%;height: 150px;border-radius: 4px;">
				</view>

				<view
					style="padding:10px 0;display: flex;align-items: center;justify-content: space-between;flex-wrap: wrap; ">
					<block v-for="(v,k) in desc.slice(0,2)" :key="k">
						<view style="flex:0 0 100%;">
							<view style="display: flex;align-items: center;">
								<view style="padding-right: 20px;">
									<CustomSvg :color="$theme.PRIMARY" :size="60" :path="v.icon" />
								</view>
								<view>
									<view style="font-size: 16px;font-weight: 700;padding-bottom: 8px;">
										{{v.title}}
									</view>
									<view
										style="overflow: hidden;white-space: normal;word-wrap: break-word;padding-bottom: 12px;"
										:style="{color:$theme.TXT_UNACT}">{{v.txt}}</view>
								</view>
							</view>
						</view>
					</block>
				</view>

				<view style="display: flex;align-items: stretch;flex-wrap: wrap; padding-bottom: 12px;">
					<block v-for="(v,k) in desc" :key="k">
						<template v-if="k>1">
							<view style="flex:0 0 100%;">
								<view style="display: flex;align-items: center;justify-content: space-between;">
									<view style="font-size: 16px;font-weight: 700;padding-bottom: 8px;">
										{{v.title}}
									</view>
								</view>
								<view
									style="overflow: hidden;white-space: normal;word-wrap: break-word;padding-bottom: 12px;"
									:style="{color:$theme.TXT_UNACT}">{{v.txt}}</view>
							</view>
						</template>
					</block>
					<view style="flex:0 0 100%;">
						<view class="btn_common" @click="$util.linkCustomerService()"
							style="width: 94%; line-height: 40px;margin-left: 0;">
							<view style="display: flex;align-items: center;">
								<view style="font-size: 16px;font-weight: 700;" :style="{color:$theme.PRIMARY}">
									{{$fmt.fmtText($t('loan.goLoans'))}}
								</view>
								<view style="margin-left: auto;">
									<CustomSvg :color="$theme.PRIMARY" :size="24" :path="$svg.arrowRight" />
								</view>
							</view>
						</view>
					</view>
				</view>

				<view style="padding-top: 20px;font-size: 16px;font-weight: 700;"
					:style="{borderTop:`1px solid #AAAAAA9A`}">
					{{$fmt.fmtText($t('loan.how'))}}
				</view>

				<view
					style="display: flex;align-items: stretch;justify-content: space-between;padding:10px 0;flex-wrap: wrap; ">
					<block v-for="(v,k) in steps" :key="k">
						<view style="flex:0 0 100%;">
							<view style="display: flex;align-items: center;">
								<view style="padding-right: 24px;">
									<CustomSvg :color="$theme.PRIMARY" :size="32" :path="v.icon" />
								</view>
								<view>
									<view style="font-size: 14px;font-weight: 700;">{{v.key}}</view>
									<view style="padding-bottom: 12px;">{{v.value}} </view>
								</view>
							</view>
						</view>
					</block>
				</view>

				<view style="padding-top: 20px;font-size: 16px;font-weight: 700;"
					:style="{borderTop:`1px solid #AAAAAA9A`}">
					{{$fmt.fmtText($t('loan.faq'))}}
				</view>

				<block v-for="(v,k) in qa" :key="k">
					<view style="padding-top: 8px;" :style="{borderBottom:`1px solid #AAAAAA5A`}">
						<view>{{v.q}}</view>
						<view style="font-size: 12px;padding: 8px 0;" :style="{color:$theme.TXT_UNACT}">{{v.a}}</view>
					</view>
				</block>
			</template>
			<template v-if="!$theme.setLayout($C.SMALL)">
				<view style="display: flex;align-items: center;height: 150px;">
					<view style="flex: 0 0 60%;">
						<view style="padding:10px 0;display: flex;align-items: center;justify-content: space-between;">
							<block v-for="(v,k) in desc.slice(0,2)" :key="k">
								<view style="flex:0 0 50%">
									<view style="display: flex;align-items: center;">
										<view style="padding-right: 20px;">
											<CustomSvg :color="$theme.PRIMARY" :size="120" :path="v.icon" />
										</view>
										<view>
											<view style="font-size: 16px;font-weight: 700;padding-bottom: 8px;">
												{{v.title}}
											</view>
											<view style="overflow: hidden;white-space: normal;word-wrap: break-word;"
												:style="{color:$theme.TXT_UNACT}">{{v.txt}}</view>
										</view>
									</view>
								</view>
							</block>
						</view>
					</view>
					<view style="flex:0 0 40%">
						<view
							style="background-image: url(/static/img_defi.png);background-position: 0 0;background-repeat: no-repeat;background-size: 100% 100%;height: 150px;border-radius: 4px;margin-left: 20px;">
						</view>
					</view>
				</view>
				<view style="display: flex;align-items: stretch;padding: 14px 0;">
					<block v-for="(v,k) in desc" :key="k">
						<template v-if="k>1">
							<view style="flex:0 0 31%;">
								<view style="display: flex;align-items: center;justify-content: space-between;">
									<view style="font-size: 16px;font-weight: 700;padding-bottom: 8px;">
										{{v.title}}
									</view>
								</view>
								<view style="overflow: hidden;white-space: normal;word-wrap: break-word;"
									:style="{color:$theme.TXT_UNACT}">{{v.txt}}</view>
							</view>
						</template>
					</block>
					<view style="flex:0 0 33%;">
						<view class="btn_common" @click="$util.linkCustomerService()"
							style="width: 60%; line-height: 40px;">
							<view style="display: flex;align-items: center;">
								<view style="font-size: 16px;font-weight: 700;" :style="{color:$theme.PRIMARY}">
									{{$fmt.fmtText($t('loan.goLoans'))}}
								</view>
								<view style="margin-left: auto;">
									<CustomSvg :color="$theme.PRIMARY" :size="24" :path="$svg.arrowRight" />
								</view>
							</view>
						</view>
					</view>
				</view>

				<view style="padding-top: 20px;font-size: 16px;font-weight: 700;"
					:style="{borderTop:`1px solid #AAAAAA9A`}">
					{{$fmt.fmtText($t('loan.how'))}}
				</view>

				<view style="display: flex;align-items: stretch;justify-content: space-between;padding:20px;">
					<block v-for="(v,k) in steps" :key="k">
						<view style="flex:1;">
							<view style="display: flex;align-items: center;">
								<view style="font-size: 16px;font-weight: 700;">{{v.key}}</view>
								<view style="padding-left: 24px;">
									<CustomSvg :color="$theme.PRIMARY" :size="64" :path="v.icon" />
								</view>
							</view>
							<view style="padding-top: 8px;">{{v.value}}
							</view>
						</view>
					</block>
				</view>

				<view style="padding-top: 20px;font-size: 16px;font-weight: 700;"
					:style="{borderTop:`1px solid #AAAAAA9A`}">
					{{$fmt.fmtText($t('loan.faq'))}}
				</view>

				<block v-for="(v,k) in qa" :key="k">
					<view style="padding-top: 8px;" :style="{borderBottom:`1px solid #AAAAAA5A`}">
						<view>{{v.q}}</view>
						<view style="font-size: 12px;padding: 8px 0;" :style="{color:$theme.TXT_UNACT}">{{v.a}}</view>
					</view>
				</block>
			</template>
		</view>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	export default {
		components: {},
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
				desc: ext.desc(), // 优势
				steps: ext.steps(), // 步骤
				qa: ext.qa(), // Q&A
			}
		},
		computed: {
			setStyleBody() {
				let temp = {};
				// 当前布局调整 小屏样式，紧凑样式，宽屏样式
				if (this.$theme.setLayout(this.$C.SMALL))
					temp.padding = `0 0 80px 0`;
				else {
					temp.padding = `0 0 20px 0`;
					temp.maxWidth = `800px`;
					temp.margin = `0 auto`;
				}
				return temp;
			},
		},

		onShow() {
			if (!this.$linkTo.checkToken()) return false;
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
		},
		onHide() {
			console.log(`onHide:`, this.isDark);
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			uni.stopPullDownRefresh();
		},
		deactivated() {},

		methods: {
			handleShow() {
				this.getGoodsList();
			},
			hanldeClose() {
				this.showCoinList = false;
			},
			// coin選擇器確認事件
			chooseGoods(val) {
				console.log(`confirmMode e:`, val);
				// this.code = e.value[0].code;
				this.showGoods = false;
				this.curGoods = val;
			},

			// 点击上传
			async selectImg() {
				const result = await uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
				});
				console.log('result:', result);
				const imageFile = result[1].tempFiles[0];
				console.log('imageFile:', imageFile);
				const reultURL = await this.$http.uploadImage(imageFile.path);
				console.log(`resultURL:`, reultURL);
				if (!reultURL) return false;
				this.obverseUrl = reultURL;
				console.log(`obverseUrl:`, this.obverseUrl);
			},

			// 提交
			async handleSubmit() {
				if (!this.amount || this.amount <= 0) {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('common.amount')),
						icon: 'none'
					});
					return false;
				}
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.submiting')),
				});
				const result = await this.$http.post(`api/user/dk_shenqing`, {
					money: this.amount,
				});
				if (!result) return false;
				console.log(`result:`, result);
				uni.showToast({
					// title: result,
					icon: 'success'
				});
				setTimeout(() => {
					this.$linkTo.loanRecord();
				}, 1000);
			},

			// 获取产品列表
			async getGoodsList() {
				// const result = await this.$http.post(`api/xxxx`);
				// if (!result) return false;
				// console.log(result);
				const temp = [{
						"searchValue": null,
						"createBy": null,
						"createTime": "2023-08-09 11:12:06",
						"updateBy": null,
						"updateTime": "2023-08-25 03:04:02",
						"remark": null,
						"id": 6,
						"amountMin": 1000.000000,
						"amountMax": 100000.000000,
						"cycleType": 7,
						"repayType": 0,
						"status": 1,
						"odds": 0.160000,
						"repayOrg": "Binance",
						"isFreeze": "1"
					},
					{
						"searchValue": null,
						"createBy": null,
						"createTime": "2023-08-09 13:53:12",
						"updateBy": null,
						"updateTime": "2023-08-25 03:01:30",
						"remark": null,
						"id": 7,
						"amountMin": 1000.000000,
						"amountMax": 1000000.000000,
						"cycleType": 15,
						"repayType": 0,
						"status": 1,
						"odds": 0.142000,
						"repayOrg": "Binance",
						"isFreeze": null
					}
				];

				this.goodsList = temp.map(item => {
					return {
						min: item.amountMin,
						max: item.amountMax,
						id: item.id
					}
				});

				// 獲取數據之後，顯示選擇器
				this.showGoods = true;
				this.curGoods = this.getGoodsList[0];
			},
		},
	}
</script>

<style lang="scss" scoped>

</style>