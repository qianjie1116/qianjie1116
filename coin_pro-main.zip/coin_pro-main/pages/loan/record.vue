<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.SMALL)">
			<HeaderSmall :dark="isDark" @update:dark="isDark = $event"
				:title="$fmt.fmtText($t('header.loan')+` `+$t('common.record'))" />
		</template>
		<template v-else>
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<view :style="$theme.setStyleBody()">
			<view style="display: flex;align-items: center;line-height: 1.8;">
				<block v-for="(v,k) in tabs" :key="k">
					<view style="padding-right: 12px;">{{v}}</view>
				</block>
			</view>

			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(v,k) in list" :key="k">
					<!-- <template v-if="$theme.setLayout($C.SMALL)"> -->
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
						<view>{{v.ident}}</view>
						<view>{{$fmt.fmtNumber(v.money*1)}}</view>
						<view>{{v.created_at}}</view>
					</view>
					<!-- </template>
				<template v-if="$theme.setLayout($C.MEDIUM)">
					<view>紧凑 一行3字段</view>
				</template>
				<template v-if="$theme.setLayout($C.LARGE)">
					<view>宽屏 充值记录 完整展开一行一条数据</view>
					<view>单号 、 充值地址 、 币种、 金额、时间 、 状态</view>
				</template> -->
				</block>
			</template>
		</view>
	</view>
</template>

<script>
	export default {
		components: {},
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
				list: [],
			}
		},
		computed: {
			tabs() {
				return [`All`, `Unview`, `Approved`, `Reject`]
			},
			setStyleBody() {
				let temp = {};
				// 当前布局调整 小屏样式，紧凑样式，宽屏样式
				if (this.$theme.setLayout(this.$C.SMALL))
					temp.padding = `0 0 80px 0`;
				else {
					temp.padding = `0 0 20px 0`;
					temp.maxWidth = `800px`;
					temp.margin = `0 auto`;
				}
				return temp;
			},
		},

		onShow() {
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
			this.getRecord();
		},
		onReady() {},
		onHide() {
			console.log(`onHide:`, this.isDark);
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getRecord();
			uni.stopPullDownRefresh();
		},
		deactivated() {},

		methods: {
			async getRecord() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.requestData')),
				});
				const result = await this.$http.post(`api/user/dk_log`);
				if (!result) return false;
				console.log('result:', result);
				this.list = result;
			},
		},
	}
</script>