<template>
	<view style="display: flex;flex-direction: column;justify-content: space-between;align-items: center;"
		:style="setPageStyle(isDark)">
		<view>
			<view style="display: flex;align-items: center;justify-content: center;padding-top: 10vh;">
				<image src="@/assets/launch_logo.png" mode="widthFix" :style="$theme.setImageSize(150)"></image>
			</view>

			<view style="margin-top: 20px;text-align: center;font-weight: bold;font-size: 32px;"
				:style="{color:$theme.PRIMARY}">
				{{$APP_NAME}}
			</view>
		</view>


		<view>
			<!-- <view style="display: flex;align-items: center;justify-content: center;">
				<image src='/static/launch_logo.png' mode="widthFix" :style="$theme.setImageSize(100)">
				</image>
			</view> -->
			<view style="line-height: 3;font-size:18px;font-weight: normal;">{{$fmt.fmtText($t('common.platform'))}}
			</view>
		</view>

		<view :style="setProgress">
			<view style="position: relative;width: 100%;height: 21px;border-radius: 20px;"
				:style="{border:`1px solid ${$theme.BORDER_COLOR}`}">
				<view :style="setStyle"></view>
				<view
					style="position: absolute;left: 0;right: 0;width: 100%;height: 21px;line-height: 21px;text-align: center;"
					:style="{color:$theme.TXT_WHITE}">
					{{percentage+` %`}}
				</view>
			</view>
		</view>
		<view>
			<CopyrightVersion />

		</view>
	</view>

</template>

<script>
	export default {
		components: {},
		data() {
			return {
				layout: null, // 当前布局方案
				isDark: null, // 当前主题方案
				percentage: 1, // 进度条初始值
				timer: null,
			}
		},
		computed: {
			// 进度条容器宽度计算
			setProgress() {
				const temp = this.layout == this.$C.SMALL ? 80 :
					this.layout == this.$C.MEDIUM ? 60 : 40;

				console.log(`setProgress:`, temp);
				return {
					margin: `0 auto`,
					marginBottom: `4vh`,
					borderRadius: `20px`,
					backgroundColor: this.$theme.TRANSPARENT,
					width: temp + `%`,
				}
			},

			// 设置进度条递进样式
			setStyle() {
				// 根据当前主题，设置进度条渐变值。
				const _color = this.$theme.convertRGBA(this.$theme.PRIMARY, 100);
				const _progress = this.isDark ?
					this.$theme.linerGradient(90, _color, _color) :
					this.$theme.linerGradient(90, _color, _color);

				// 当前方向
				const _direction = 'left';
				const temp = {
					position: 'absolute',
					bottom: 0,
					[`${_direction}`]: 0, // 决定进度条的递进方向
					height: '21px',
					width: `${this.percentage}%`,
					..._progress,
					borderRadius: '20px',
				};
				// console.log('进度条递进完整样式:', temp);
				return temp;
			}
		},
		onShow() {
			this.layout = uni.getStorageSync('layout');
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
			console.log('onShow', this.timer);
			this.onSetTimeout();
		},
		onHide() {
			console.log('onHide', this.timer);
			this.clearTimer();
		},
		onUnload() {
			console.log('onUnload', this.timer);
			this.clearTimer();
		},

		methods: {
			setPageStyle(val) {
				return {
					color: this.$theme.BASIC_TXT,
					backgroundColor: this.$theme.BASIC_BG,
					width: `${this.$WINDOW_WIDTH}px`,
					minHeight: `100vh`,
				}
			},


			onSetTimeout() {
				this.timer = setInterval(() => {
					// console.log("setInterval");
					if (this.percentage < 100) {
						this.percentage++;
					} else {
						this.clearTimer();
						// 跳转到首页 缓一秒， 否则看不到进度条加满效果
						setTimeout(() => {
							this.$linkTo.home();
						}, 1500);
					}
					// console.log(this.percentage);
				}, 30);
			},
			clearTimer() {
				// clearTime
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},
		}

	}
</script>

<style lang="scss" scoped>
	// .launch {
	// 	width: 100%;
	// 	height: 100vh;
	// 	padding-top: 0;
	// 	// background-image: url('/static/launch_bg.png');
	// 	background-repeat: no-repeat;
	// 	background-position: 0 0;
	// 	background-size: cover;
	// 	background-image: linear-gradient(135deg, #F5F6FB, #F5F6FB);
	// 	position: relative;
	// }
</style>