<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.SMALL)">
			<HeaderSmall :dark="isDark" @update:dark="isDark = $event" :title="$t('header.defi')"> </HeaderSmall>
		</template>

		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>


		<view :style="$theme.setStyleBody()">
			<view :class="$theme.setLayout($C.SMALL)?`second_small`:`second_medium`">
				<view style="display: flex;align-items: center;padding: 20px 0 12px 0;">
					<block v-for="(v,k) in tabs" :key="k">
						<view style="padding-right: 12px;font-size: 16px;" @click="changeTab(k)">
							<text :style="{color:curTab==k?$theme.PRIMARY:$theme.TXT_UNACT,
								borderBottom:`1px dashed ${curTab==k?$theme.PRIMARY:$theme.TXT_UNACT}`}">
								{{v}}
							</text>
						</view>
					</block>
					<template v-if="$theme.setLayout($C.SMALL)">
						<view style="margin-left: auto;">
							<CustomSvg :color="$theme.PRIMARY" :path="$svg.refesh" @click="handleRefesh()" />
						</view>
					</template>
				</view>

				<!-- <template v-if="$theme.setLayout($C.SMALL)"> -->
				<block v-for="(item,index) in list" :key="index">
					<view style="padding: 18px 0;border-bottom: 1px Solid #ccc;line-height: 1.6;">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view style="font-size: 16px;">{{item.name}}</view>
							<view style="padding:4px 18px;border-radius: 22px;color:#FFF;"
								:style="{backgroundColor:curTab==0?$theme.RISE:$theme.FALL}" @click="modalShow(item)">
								{{$fmt.fmtText(curTab==0? $t('common.buy') : $t('common.sell'))}}
							</view>
						</view>
						<view :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('ctc.qty'))}} {{item.shuliang}}%
						</view>
						<view>
							<text style="font-size: 12px;padding-right: 12px;">
								{{$fmt.fmtText($t('ctc.rate'))}}</text>
							<text style="font-size: 16px;">{{item.bili}}%</text>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.TXT_UNACT}">
								{{$fmt.fmtText($t('ctc.tip1'))}}
							</view>
							<view :style="{color:$theme.LOG_VALUE}">
								{{$fmt.fmtCrypto(`${item.jiaoyicishu}`)}}
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$theme.TXT_UNACT}">
								{{$fmt.fmtText($t('ctc.min'))}}
							</view>
							<!-- Sell 是USD -->
							<view :style="{color:$theme.TXT_UNACT}">
								{{$fmt.fmtCrypto(`${item.xiane}`)}} {{$fmt.fmtText($t('common.unitUSDT'))}}
							</view>
						</view>
					</view>
				</block>
				<!-- </template>

			<template v-if="!$theme.setLayout($C.SMALL)">
				333
			</template> -->
			</view>
		</view>
		<!-- 购买的浮层 -->
		<template v-if="isShow">
			<ModalBuy :info="curInfo" :code="curTab" @action="closeModal" />
		</template>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	import ModalBuy from './components/ModalBuy.vue';
	export default {
		components: {
			ModalBuy
		},
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
				tabs: ext.tabs(),
				curTab: 0,
				list: null,
				isShow: false, // 是否显示浮层
				curInfo: null, // 选中数据
			}
		},
		onShow() {
			if (!this.$linkTo.checkToken()) return false;
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
			this.changeTab(this.curTab);
		},
		onReady() {},
		onHide() {
			console.log(`onHide:`, this.isDark);
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.changeTab(this.curTab);
			uni.stopPullDownRefresh();
		},
		deactivated() {},
		methods: {
			// 切换
			changeTab(val) {
				this.curTab = val;
				this.getList();
			},
			// 显示购买浮层
			modalShow(val) {
				this.isShow = true;
				this.curInfo = val;
			},
			// 关闭浮层
			closeModal(val) {
				this.isShow = false;
				this.curInfo = null;
				this.getList();
			},
			async getList() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.requestData')),
				});
				const result = await this.$http.post(`api/app/c2clist`, {
					type: this.curTab + 1,
				});
				if (!result) return false;
				console.log(result);
				this.list = result;
			},
		}
	}
</script>

<style>
</style>