<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.SMALL)">
			<HeaderSmall :dark="isDark" @update:dark="isDark = $event" :title="$t('header.defi')"> </HeaderSmall>
		</template>

		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>


		<view :style="$theme.setStyleBody()">
			<view :class="$theme.setLayout($C.SMALL)?`second_small`:`second_medium`">
				<view style="font-size: 20px;line-height: 1.6;">{{$fmt.fmtText($t('ctc.title'))}}</view>
				<view style="display: flex;align-items: center;padding: 12px 0;">
					<CustomLogo logo="" name="USDT" :size="32" />
					<view style="font-size: 14px;padding-left: 20px;" :style="{color:$theme.PRIMARY}">
						{{ $fmt.fmtText(code == 0 ? $t('common.buy') : $t('common.sell'))}}
						{{$t('common.unitUSDT')}}
					</view>
				</view>
				<template v-if="detail">
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 4px;">
						<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('ctc.rate'))}}</view>
						<view style="font-size: 16px;">
							${{$fmt.fmtCrypto(detail.huilv)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 4px;">
						<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('ctc.qty'))}}</view>
						<view style="font-size: 16px;">
							{{$fmt.fmtCrypto(detail.shuliang)}}
							<text style="font-size: 11px;"
								:style="{color:$theme.TXT_UNACT}">{{$t('common.unitUSDT')}}</text>
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 4px;">
						<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('ctc.total'))}}</view>
						<view style="font-size: 16px;">
							${{$fmt.fmtCrypto(detail.zongmoney)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('ctc.method'))}}</view>
						<view style="font-size: 16px;">
							{{detail.fukuan}}
						</view>
					</view>
				</template>
				<view style="display: flex; align-items: center;justify-content: space-between;padding: 12px 0;">
					<view class="btn_common" style="margin:0 auto; flex:1;padding:4px;margin-left: 0;line-height: 32px;"
						@click="$util.linkCustomerService()">
						{{ $fmt.fmtText($t('service.title'))}}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
				detail: null,
				code: '', // 当前是买还是卖
				id: '',
			}
		},
		onLoad(opt) {
			this.code = opt.tag || this.code;
			this.id = opt.id || this.id;
		},
		onShow() {
			if (!this.$linkTo.checkToken()) return false;
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
			this.getList();
		},
		onReady() {},
		onHide() {
			console.log(`onHide:`, this.isDark);
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.getList();
			uni.stopPullDownRefresh();
		},
		deactivated() {},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.requestData')),
				});
				const result = await this.$http.get(`api/app/c2corder`, {
					id: this.id,
				});
				if (!result) return false;
				console.log(result);
				this.detail = result;
			},
		}
	}
</script>

<style>
</style>