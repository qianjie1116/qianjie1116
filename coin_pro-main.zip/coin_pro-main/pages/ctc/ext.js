import Vue from 'vue';
import i18n from '@/locales/index.js';
import * as constants from '@/common/constants.js';
import * as fmt from '@/common/format.js';
import http from '@/common/http.js';

// 顶部tabs
export const tabs = () => {
	return [
		fmt.fmtText(i18n.t('common.buy')),
		fmt.fmtText(i18n.t('common.sell'))
	]
};