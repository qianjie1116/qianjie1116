<template>
	<view>
		<view class="overlay" style="background-color: rgba(0, 0, 0, 0.5);" @click="modalClose()"></view>
		<view :class="[$theme.setLayout($C.SMALL)?`modal_wrapper_bottom`:`modal_wrapper_center`,'bottom_in' ]"
			:style="{backgroundColor:$theme.BASIC_BG}">
			<view style="min-height: 30vh;padding:12px 12px 24px 12px;">
				<view style="display: flex;align-items: center;padding-bottom: 12px;">
					<view style="width: 24px;"></view>
					<view style="flex:1;text-align:center;">
						<text style="padding-bottom: 4px;" :style="{borderBottom:`1px solid ${$theme.PRIMARY}`}">
							{{setTitle}}
						</text>
					</view>
					<view style="margin-left: auto;">
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.close" @click="modalClose()" />
					</view>
				</view>

				<view style="font: 14px; margin-top: 8px;margin-bottom: 8px;">
					{{$fmt.fmtText($t('common.amount'))}}
				</view>
				<view class="input_wrapper" style="padding:0 12px;margin-top: 0;" :style="$theme.setInputStyle(dark)">
					<input v-model="amount" type="number"
						:placeholder="$fmt.fmtText($t('common.enter')+$t('common.amount'))"
						:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
					<view style="margin-left: auto;" :style="{color:$theme.PRIMARY}">
						USD
					</view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('ctc.min'))}}
					</view>
					<view>
						{{$fmt.fmtCrypto(`${$fmt.fmtNumber(info.xiane)}`)}}
						<text style="font-size: 11px;" :style="{color:$theme.TXT_UNACT}">
							{{$t('common.unitUSDT')}}</text>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('ctc.max'))}}
					</view>
					<view>
						{{$fmt.fmtCrypto(`${$fmt.fmtNumber(info.maxxiane)}`)}}
						<text style="font-size: 11px;" :style="{color:$theme.TXT_UNACT}">
							{{$t('common.unitUSDT')}}</text>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('common.balance'))}}
					</view>
					<view>
						{{$fmt.fmtCrypto(`${$fmt.fmtNumber(balance)}`)}}
						<text style="font-size: 11px;" :style="{color:$theme.TXT_UNACT}">
							{{$t('common.unitUSDT')}}</text>
					</view>
				</view>

				<view style="display: flex; align-items: center;justify-content: space-between;padding: 12px 0;">
					<view class="btn_common" style="margin:0 auto; flex:1;padding:4px;margin-left: 0;line-height: 32px;"
						@click="handleSubmit()">
						{{ $fmt.fmtText(code == 0 ? $t('common.buy') : $t('common.sell'))}}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'ModalBuy',
		props: {
			dark: {
				type: Boolean,
				default: true,
			},
			info: {
				type: Object,
				default: {}
			},
			code: {
				type: Number,
				default: 0
			}
		},
		data() {
			return {
				amount: '', // 输入值
				balance: '', // 余额
			}
		},
		computed: {
			setTitle() {
				const temp = this.code == 0 ? this.$t('common.buy') : this.$t('common.sell');
				return this.$fmt.fmtText(temp + ` ` + this.$t('common.detail'));
			}
		},
		beforeMount() {
			this.getAccount();
		},
		methods: {
			// 关闭浮层
			modalClose() {
				this.amount = '';
				this.$emit('action', 1);
			},
			async getAccount() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.requestData')),
				});
				const result = await this.$http.get(`api/user/fastInfo`);
				if (!result) return false;
				this.balance = result.money * 1 || this.balance;
			},
			// 购买
			async handleSubmit() {
				if (this.amount == '' || this.amount <= 0) {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('common.amount')),
						icon: 'none'
					});
					return false;
				}
				const result = await this.$http.post(`api/app/c2c`, {
					id: this.info.id,
					money: this.amount,
					type: this.code + 1,
				});
				if (!result) return false;
				console.log(`result:`, result);
				uni.showToast({
					title: result,
					icon: 'success'
				});
				setTimeout(() => {
					this.$linkTo.ctcOrder(this.code, this.info.id);
				}, 1000);
			},
		}
	}
</script>

<style>
</style>