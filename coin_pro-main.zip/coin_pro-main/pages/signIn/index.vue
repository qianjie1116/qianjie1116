<template>
	<view :class="[isAnimat?'fade_in':'fade_out',$theme.setLayout($C.SMALL)?'sign_bg_small':'']"
		:style="$theme.setPageStyle(isDark)">
		<header class="header_small">
			<template v-if="$theme.setLayout($C.SMALL)">
				<view>
					<CustomSvg :color="$theme.PRIMARY" :path="$svg.translate" @click="$linkTo.translate()" />
				</view>
				<view class="center"></view>
				<view class="right">
					<CustomSvg :color="$theme.PRIMARY" :path="$svg.close" @click="linkHome()" />
				</view>
			</template>
			<template v-else>
				<view class="center"></view>
				<view class="right">
					<CustomSvg :color="$theme.PRIMARY" :path="$svg.translate" @click="showTranslate()" />
				</view>
			</template>
		</header>

		<view class="sign_small">
			<view class="left_in">
				<view :class="$theme.setLayout($C.SMALL)?'':'sign_large'">
					<template v-if="!$theme.setLayout($C.SMALL)">
						<view style="flex:0 0 40%;">
							<image src="/static/img_signin.png" mode="widthFix"
								style="width: 96%;height: auto;padding-left: 20px;">
							</image>
						</view>
					</template>
					<view :style="{flex:$theme.setLayout($C.SMALL)?`0 0 60%`:`auto` }">
						<view style="padding:0 20px;">
							<view style="font-size: 32px;font-weight: 700;">
								{{signTitle}}
							</view>
							<view style="font-size: 48px;font-weight: 700;cursor: pointer;"
								:style="{color:$theme.PRIMARY}" @click="linkHome()">{{$APP_NAME}}</view>

							<!-- <view style="display: flex;align-items: center;margin-top: 40px;"> -->
							<!-- <view style="padding-right: 40px;font-size: 20px;
    font-weight: 700;cursor: pointer;color:#536fff;">{{$lang.SIGN_IN_ACCOUNT}} </view>
									<view style="font-size: 20px;
    font-weight: 700;cursor: pointer;">{{$lang.SIGN_IN_EMAIL}}</view> -->
							<!-- </view> -->

							<view style="margin-top: 24px;">
								<!-- 账号 -->
								<view style="font: 14px;font-weight: 700;margin-bottom: 8px;">
									{{$fmt.fmtText($t('sigin.account'))}}
								</view>
								<view class="input_wrapper" :style="$theme.setInputStyle(isDark)">
									<input v-model="user" type="text"
										:placeholder="$fmt.fmtText($t('common.enter')+ $t('sigin.account'))"
										:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
								</view>

								<!-- 密码 -->
								<view style="font: 14px;font-weight: 700;margin-top: 20px;margin-bottom: 8px;">
									{{$fmt.fmtText($t('sigin.pwd'))}}
								</view>
								<view class="input_wrapper" :style="$theme.setInputStyle(isDark)">
									<input v-model="password" :password="isMask"
										:placeholder="$fmt.fmtText($t('common.enter')+$t('sigin.pwd'))"
										:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>

									<view style="margin-left: auto;">
										<CustomSvg :color="$theme.PRIMARY" :size="18"
											:path="isMask?$svg.mask:$svg.unmask" @click="toggleMask()" />
									</view>
								</view>

								<template v-if="!isSignIn">
									<view style="font: 14px;font-weight: 700;margin-top: 20px;margin-bottom: 8px;">
										{{$fmt.fmtText($t('sigin.pwdConfirm'))}}
									</view>
									<view class="input_wrapper" :style="$theme.setInputStyle(isDark)">
										<input v-model="verifyPassword" :password="isMask"
											:placeholder="$fmt.fmtText($t('common.enter')+$t('sigin.pwdConfirm'))"
											:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>

										<view style="margin-left: auto;">
											<CustomSvg :color="$theme.PRIMARY" :size="18"
												:path="isMask?$svg.mask:$svg.unmask" @click="toggleMask()" />
										</view>
									</view>
									<view style="font: 14px;font-weight: 700;margin-top: 20px;margin-bottom: 8px;">
										{{$fmt.fmtText($t('sigin.invitation'))}}
									</view>
									<view class="input_wrapper" :style="$theme.setInputStyle(isDark)">
										<input v-model="inviteCode" type="text"
											:placeholder="$fmt.fmtText($t('common.enter')+ $t('sigin.invitation'))"
											:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
									</view>
									<!-- 隐私协议 -->
									<view
										style="display: flex;align-items: center;justify-content: center;margin-top: 10px;">
										<view>
											<u-checkbox-group>
												<u-checkbox shape="" :activeColor="$theme.CHECKBOX_COLOR_ACTIVE"
													:label="$fmt.fmtText($t('sigin.agree'))" v-model="isAgree"
													:labelColor="$theme.CHECKBOX_LABEL_COLOR" labelSize="12px"
													@change="changeAgree" :checked="isAgree"
													:iconColor="$theme.CHECKBOX_COLOR_ACTIVE"></u-checkbox>
											</u-checkbox-group>
										</view>
										<view>
											<text style="font-size:12px;margin-left: 8px;cursor: pointer;"
												:style="{color:$theme.PRIMARY}" @click="$linkTo.linkTerms()">
												{{$fmt.fmtText($t('sigin.termsOfUse'))}}
											</text>
											<text style="font-size:12px;margin-left: 8px;">
												{{$fmt.fmtText($t('sigin.agreeAnd'))}}
											</text>
											<text style="font-size:12px;margin-left: 8px;cursor: pointer;"
												:style="{color:$theme.PRIMARY}" @click="$linkTo.linkTerms()">
												{{$fmt.fmtText($t('sigin.privacy'))}}
											</text>
										</view>
									</view>
								</template>

								<!-- 记住密码，忘记密码 -->
								<template v-if="isSignIn">
									<view
										style="display: flex;align-items: center;justify-content: space-between;margin-top: 10px;">
										<u-checkbox-group>
											<!-- circle -->
											<u-checkbox shape="" :activeColor="$theme.CHECKBOX_COLOR_ACTIVE"
												:label="$fmt.fmtText($t('sigin.remember'))" v-model="isRemember"
												:labelColor="$theme.CHECKBOX_LABEL_COLOR" labelSize="12px"
												@change="changeRemember" :checked="isRemember"
												:iconColor="$theme.CHECKBOX_COLOR_ACTIVE"></u-checkbox>
										</u-checkbox-group>
										<view style="margin-left: auto;cursor: pointer;" :style="{color:$theme.PRIMARY}"
											@click="$util.linkCustomerService()">
											{{$fmt.fmtText($t('sigin.forgot'))}}
										</view>
									</view>
								</template>

								<view class="btn_common" :class="isDark ? `btn_dark` : `btn_light`"
									@click="handleSubmit()" style="margin: 20px 0;line-height:40px;">
									{{$fmt.fmtText($t(isSignIn? 'sigin.titleIn':'sigin.titleUp'))}}
								</view>

								<view style="display: flex;align-items: center;justify-content: center;">
									<view style="padding-right: 20px;">
										{{$fmt.fmtText($t(isSignIn? 'sigin.noAccount':'sigin.existAccount'))}}
									</view>
									<view @click="toggleTag()" :style="{color:$theme.PRIMARY}">
										{{$fmt.fmtText($t(isSignIn? 'sigin.titleUp':'sigin.titleIn')+` `+ $t('sigin.now'))}}
									</view>
								</view>
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>

		<!-- 语言选择弹层 LanguageLarge   -->
		<template v-if="showModal">
			<LanguageLarge :dark="isDark" @close="closeTranslate" />
		</template>
	</view>
</template>

<script>
	export default {
		components: {},
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
				showModal: false, // 是否显示语言选项组(宽屏使用)
				isMask: null, // 是否掩码
				tag: '', // url携带tag值
				isSignIn: true, // 是否为登入页面
				user: '', // 账号
				password: '', // 密码
				verifyPassword: '', // 确认密码
				inviteCode: '', // 默认为 url 携带code邀请码
				isRemember: true, // 记住密码
				isAgree: false, // 同意隐私协议
				isBtnLock: false, // 按钮是否锁定
			}
		},
		computed: {
			// 标题
			signTitle() {
				return this.$fmt.fmtText(this.$t('common.welcome') +
					this.$t(this.isSignIn ? 'sigin.titleIn' : 'sigin.titleUp') + ` `)
			},
		},
		onLoad(opt) {
			this.tag = opt.tag || this.tag;
			this.inviteCode = opt.code || this.inviteCode;
		},
		onShow() {
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
			this.isMask = uni.getStorageSync('masking'); // 当前掩码状态
			this.changeRemember(this.isRemember);
			this.user = uni.getStorageSync('user') || '';
			this.password = uni.getStorageSync('pwd') || '';
			// tag 中有值视为注册页
			this.isSinIn = !this.tag && this.tag.length <= 0;
			if (!this.isSignIn) this.changeAgree(this.isAgree);

		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 切换当前页面为登入还是注册
			toggleTag() {
				this.isSignIn = !this.isSignIn;
				// uni.setStorageSync('user', this.user);
				// uni.setStorageSync('pwd', this.password);
			},
			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
			// 勾选记住密码
			changeRemember(e) {
				this.isRemember = e;
			},
			// 勾选用户隐私协议
			changeAgree(e) {
				this.isAgree = e;
			},

			// 跳转到语言选择(窄屏)
			linkTranslate() {
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				this.$linkTo.translate();
			},

			// 跳转到首页 窄屏 关闭按钮 宽屏点击应用名称
			linkHome() {
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				this.$linkTo.home();
			},

			// 显示语言选项组
			showTranslate() {
				this.showModal = true;
			},
			closeTranslate(val) {
				console.log(`close val:`, val);
				this.showModal = false;
			},

			checkForm() {
				// check form
				if (this.user == '') {
					this.$util.showToast(this.$C.WARNING,
						this.$fmt.fmtText(this.$t('common.enter') + this.$t('sigin.account')));
					return false;
				}
				if (this.password == '') {
					this.$util.showToast(this.$C.WARNING,
						this.$fmt.fmtText(this.$t('common.enter') + this.$t('sigin.pwd')));
					return false;
				}
				if (!this.isSignIn && this.verifyPassword == '') {
					this.$util.showToast(this.$C.WARNING,
						this.$fmt.fmtText(this.$t('common.enter') + this.$t(
							'sigin.pwdConfirm')));
					return false;
				}
				if (!this.isSignIn && this.password != this.verifyPassword) {
					this.$util.showToast(this.$C.WARNING, this.$fmt.fmtText(this.$t('tip.towPwdDiff')));
					return false;
				}
				if (!this.isSignIn && this.inviteCode == '') {
					this.$util.showToast(this.$C.WARNING,
						this.$fmt.fmtText(this.$t('common.enter') + this.$t(
							'sigin.invitation')));
					return false;
				}
				if (!this.isSignIn && this.isAgree != true) {
					this.$util.showToast(this.$C.WARNING,
						this.$fmt.fmtText(this.$t('tip.checkAgree')));
					return false;
				}
				return true;
			},

			handleSubmit() {
				// 如果按钮锁定，则不执行提交事件
				console.log(`btnAct:`, this.isBtnLock);
				if (!this.checkForm()) return false;
				if (this.isBtnLock) return false;
				this.isBtnLock = true; // 锁住按钮
				if (this.isSignIn) this.signIn();
				else this.signUp();
			},

			// 登入提交
			async signIn() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.login')),
				});
				const result = await this.$http.post(`api/app/login`, {
					username: this.user,
					password: this.password,
				});
				console.log('result:', result);
				this.isBtnLock = false; // 解锁
				if (!result) return false;
				const token = result.token.access_token || '';
				uni.setStorageSync('token', token);
				uni.setStorageSync('user', this.user);
				uni.setStorageSync('pwd', this.password);
				this.$util.showToast(this.$C.SUCCESS,
					this.$fmt.fmtText(this.$t('sigin.titleIn') + ` ` + this.$t('common.success')));

				setTimeout(() => {
					this.$linkTo.home();
				}, 1000);
			},
			// 注册提交
			async signUp() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.register')),
				});
				const result = await this.$http.post(`api/app/register`, {
					mobile: this.user,
					password: this.password,
					confirmpass: this.verifyPassword,
					invite: this.invitation,
					code: 123456,
				});
				console.log('result:', result);
				this.isBtnLock = false; // 解锁
				if (!result) return false;
				this.$util.showToast('success',
					this.$fmt.fmtText(this.$t('sigin.titleUp') + ` ` + this.$t('common.success')));
				setTimeout(() => {
					this.isSignIn = true;
				}, 1000);
			}
		},
	}
</script>

<style lang="scss" scoped>
	/deep/.u-checkbox__icon-wrap {
		background-color: transparent !important;
	}
</style>