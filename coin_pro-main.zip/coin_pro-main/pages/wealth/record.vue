<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.SMALL)">
			<HeaderSmall :dark="isDark" @update:dark="isDark = $event"
				:title="$t('header.wealth')+` `+$t('common.record')" />
		</template>

		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<view :style="$theme.setStyleBody()">
			<template v-if="$theme.setLayout($C.SMALL)">
				Wealth Record
			</template>

			<template v-if="$theme.setLayout($C.MEDIUM) || $theme.setLayout($C.LARGE)">
				<view style="min-width: 800px;margin: auto;margin-top: 24px;">
					<view style="font-size: 32px;font-weight: 700;">
						{{$t('header.wealth')+` `+$t('common.record')}}
					</view>

					<view
						style="display: flex;align-items: center;justify-content: space-between; line-height:2.8;margin: 40px 0;padding:20px 40px;border-bottom: 1px solid #AAAAAA;border-top: 1px solid #AAAAAA;">
						<view style="text-align: center;">
							<view>{{$t('wealth.record.total')}}</view>
							<view>{{$fmt.fmtNumber(0.00)}}</view>
						</view>
						<view style="text-align: center;">
							<view>{{$t('wealth.record.eam')}}</view>
							<view>{{$fmt.fmtNumber(23.4040)}}</view>
						</view>
						<view style="text-align: center;">
							<view>{{$t('wealth.record.income')}}</view>
							<view>{{$fmt.fmtNumber(0)}}</view>
						</view>

						<view style="text-align: center;">
							<view>{{$t('wealth.record.held')}}</view>
							<view>{{$fmt.fmtNumber(0)}}</view>
						</view>
					</view>



					<view style="font-size: 24px;line-height: 2.8;">{{$t('wealth.record.bought')}}</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 2.8;">
						<view>{{$t('wealth.record.name')}}</view>
						<view>{{$t('wealth.record.daily')}}</view>
						<view>{{$t('wealth.record.invest')}}</view>
						<view>{{$t('wealth.record.revenue')}}</view>
						<view>{{$t('wealth.record.time')}}</view>
						<view>{{$t('wealth.record.state')}}</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
						<view>USDTSmart contract</view>
						<view>{{$fmt.fmtNumber(0.75)}}%</view>
						<view>{{$fmt.fmtNumber(500)}} USDT</view>
						<view>{{$fmt.fmtNumber(3.750000)}} USDT</view>
						<view>Daily settlement</view>
						<view>In position</view>
					</view>
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	export default {
		components: {},
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
			}
		},
		computed: {

		},

		onShow() {
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
		},
		onReady() {},
		onHide() {
			console.log(`onHide:`, this.isDark);
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			uni.stopPullDownRefresh();
		},
		deactivated() {},

		methods: {

		},
	}
</script>

<style>
</style>