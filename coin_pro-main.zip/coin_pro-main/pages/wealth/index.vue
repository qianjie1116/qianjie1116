<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.SMALL)">
			<HeaderSmall :dark="isDark" @update:dark="isDark = $event" :title="$t('header.wealth')" />
		</template>

		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<view :style="$theme.setStyleBody()">
			<template v-if="$theme.setLayout($C.SMALL)">
				WEALTH
			</template>

			<template v-if="$theme.setLayout($C.MEDIUM) || $theme.setLayout($C.LARGE)">
				<view> 一张大图，指定高度，完整宽度 </view>
				<view> 四个大图标 ,第四个(My investments 我的投资)

					<view class="btn_common" @click="$linkTo.wealthRecord()"
						style="background-color: #536fff;width: 20%;">
						{{$fmt.fmtText($t('common.record'))}}
					</view>
				</view>

				<!-- 产品列表 -->
				<view style="display: grid; grid-auto-flow: column;column-gap: 10px;">
					<view style="background-color: #1f212d;border-radius: 4px;padding:20px;">
						<view>USDT Smart Contract</view>

						<view style="display: flex;align-items: center;line-height: 3.2;">
							<image src="/static/logo.png" mode="aspectFit" style="padding-right: 40px;"
								:style="$theme.setImageSize(80)"></image>
							<view style="flex:1;">
								<view style="display: flex;align-items: center;">
									<view style="font-size: 24px;font-weight: 700;">0.75%</view>
									<view style="margin-left: auto;">
										<view class="btn_common" @click="handleSubmit()"
											style="background-color: #536fff;">
											{{$fmt.fmtText($t('common.submit'))}}
										</view>
									</view>
								</view>
								<view
									style="display: flex;align-items: center;justify-content: space-between; line-height: 1.6;">
									<view>
										<view style="font-size: 12px;">Initial investment amount</view>
										<view>{{$fmt.fmtNumber(50000) }} {{$t('common.unitUSDT')}}</view>
									</view>
									<view style="font-size: 12px;">|</view>
									<view>
										<view style="font-size: 12px;">Limited investment amount yield</view>
										<view> {{$fmt.fmtNumber(5000000) }} {{$t('common.unitUSDT')}}</view>
									</view>
									<view style="font-size: 12px;">|</view>
									<view>
										<view style="font-size: 12px;">Lockout days</view>
										<view>30</view>
									</view>
								</view>
							</view>
						</view>

						<!-- 进度条 -->
						<view style="display: flex;align-items: center;margin-top: 20px;">
							<view>Project Progress</view>
							<view></view>
							<view style="margin-left: auto;">33%</view>
						</view>
					</view>
					<view style="background-color: #1f212d;border-radius: 4px;padding:20px;">
						<view>USDT Smart Contract</view>

						<view style="display: flex;align-items: center;line-height: 3.2;">
							<image src="/static/logo.png" mode="aspectFit" style="padding-right: 40px;"
								:style="$theme.setImageSize(80)"></image>
							<view style="flex:1;">
								<view style="display: flex;align-items: center;">
									<view style="font-size: 24px;font-weight: 700;">0.75%</view>
									<view style="margin-left: auto;">
										<view class="btn_common" @click="handleSubmit()"
											style="background-color: #536fff;">
											{{$fmt.fmtText($t('common.submit'))}}
										</view>
									</view>
								</view>
								<view
									style="display: flex;align-items: center;justify-content: space-between; line-height: 1.6;">
									<view>
										<view style="font-size: 12px;">Initial investment amount</view>
										<view>{{$fmt.fmtNumber(50000) }} {{$t('common.unitUSDT')}}</view>
									</view>
									<view style="font-size: 12px;">|</view>
									<view>
										<view style="font-size: 12px;">Limited investment amount yield</view>
										<view> {{$fmt.fmtNumber(5000000) }} {{$t('common.unitUSDT')}}</view>
									</view>
									<view style="font-size: 12px;">|</view>
									<view style="font-size: 12px;">
										<view>Lockout days</view>
										<view>30</view>
									</view>
								</view>
							</view>
						</view>

						<!-- 进度条 -->
						<view style="display: flex;align-items: center;margin-top: 20px;">
							<view>Project Progress</view>
							<view></view>
							<view style="margin-left: auto;">33%</view>
						</view>
					</view>
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	export default {
		components: {},
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
			}
		},
		computed: {},

		onShow() {
			if (!this.$linkTo.checkToken()) return false;
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
		},
		onReady() {},
		onHide() {
			console.log(`onHide:`, this.isDark);
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			uni.stopPullDownRefresh();
		},
		deactivated() {},

		methods: {},
	}
</script>

<style>
</style>