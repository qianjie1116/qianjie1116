<template>
	<view class="right_in">
		<view :class="$theme.setLayout($C.SMALL)?`second_small`:`second_medium`">

			<view style="font: 14px;font-weight: 700;">
				<text :style="{color:$theme.PRIMARY,
				borderBottom:`1px dashed ${$theme.PRIMARY}`}" @click="toogleTransfer()">{{$fmt.fmtText(fmtInType.key )}}</text>
				<text style="padding-left: 4px;">
					{{$fmt.fmtText($t('transfer.account') + ` ` + $t('common.balance'))}}</text>
			</view>
			<view class="input_wrapper" :style="$theme.setInputStyle(dark)">
				<!-- <input v-model="inBalance" type="text" :placeholder-style="$theme.setPlaceholder()" style="flex:auto;" disabled></input> -->
				<view style="height: 32px;line-height: 32px;flex:auto;font-size: 16px;">
					{{$fmt.fmtCrypto(`${inBalance}`)}}
				</view>
				<view style="margin-left: auto;" :style="{color:$theme.TXT_UNACT}">
					{{$t('common.unitUSDT')}}
				</view>
			</view>

			<view style="font: 14px;font-weight: 700;padding-top: 12px;">
				<text :style="{color:$theme.PRIMARY,
				borderBottom:`1px dashed ${$theme.PRIMARY}`}" @click="toogleTransfer()">{{$fmt.fmtText(fmtOutType.key )}}</text>
				<text style="padding-left: 4px;">
					{{$fmt.fmtText($t('transfer.account') + ` ` + $t('common.balance'))}}</text>
			</view>
			<view class="input_wrapper" :style="$theme.setInputStyle(dark)">
				<!-- <input v-model="outBalance" type="text" :placeholder-style="$theme.setPlaceholder()" style="flex:auto;" disabled></input> -->
				<view style="height: 32px;line-height: 32px;flex:auto;font-size: 16px;">
					{{$fmt.fmtCrypto(`${outBalance}`)}}
				</view>
				<view style="margin-left: auto;" :style="{color:$theme.TXT_UNACT}">
					{{$t('common.unitUSDT')}}
				</view>
			</view>

			<view style="font: 14px;font-weight: 700;padding-top: 12px;">
				{{$fmt.fmtText($t('assets.transfer')+` `+ $t('common.amount'))}}
			</view>
			<view class="input_wrapper" :style="$theme.setInputStyle(dark)">
				<input v-model="amount" type="digit"
					:placeholder="$fmt.fmtText($t('common.enter')+ $t('common.amount'))"
					:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
				<view style="margin-left: auto;" :style="{color:$theme.TXT_UNACT}">
					{{$t('common.unitUSDT')}}
					<text style="padding-left: 12px;" :style="{color:$theme.PRIMARY}" @click="handleAll()">
						{{$fmt.fmtText($t('common.all'))}}</text>
				</view>
			</view>

			<view class="btn_common" @click="handleSubmit()" style="margin: 24px 0;line-height: 40px;">
				{{$fmt.fmtText($t('common.submit'))}}
			</view>

			<view style="font-size: 16px;font-weight: 700;line-height: 1.8;">
				{{$fmt.fmtText($t('assets.transfer')+` `+$t('common.record'))}}
			</view>

			<view style="display: flex;align-items: center;line-height: 1.8;">
				<block v-for="(v,k) in tabs" :key="k">
					<view style="padding-right: 12px;" @click="changeTab(k)">
						<text :style="{color:curTab==k?$theme.PRIMARY:$theme.TXT_UNACT,
							borderBottom:`1px dashed ${curTab==k?$theme.PRIMARY:$theme.TXT_UNACT}`}">
							{{$fmt.fmtText(v)}}
						</text>
					</view>
				</block>
				<view style="margin-left: auto;">
					<CustomSvg :color="$theme.PRIMARY" :path="$svg.refesh" @click="handleRefesh()" />
				</view>
			</view>

			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<template v-if="$theme.setLayout($C.SMALL)">
					<RecordSmall :list="fmtList" />
				</template>
				<template v-else>
					<RecordLarge :list="fmtList" />
				</template>
			</template>

		</view>
	</view>
</template>

<script>
	import * as ext from '../ext.js';
	import RecordLarge from './RecordLarge.vue';
	import RecordSmall from './RecordSmall.vue';
	export default {
		name: "Transfer",
		components: {
			RecordLarge,
			RecordSmall,
		},
		props: {
			dark: {
				type: Boolean,
				default: true,
			}
		},
		data() {
			return {
				inBalance: '', // 转入余额
				outBalance: '', // 转出余额
				amount: '', // 转出额
				inType: '', // 转入key
				outType: '', // 转出key
				isTransfer: false, // 是否点击切换
				list: null, // 底部列表
				tabs: ext.tabsRecharge(), // 列表类型过滤
				curTab: 0, // 当前显示
			}
		},
		computed: {
			fmtInType() {
				return ext.transferDir()[this.inType]
			},
			fmtOutType() {
				return ext.transferDir()[this.outType]
			},
			fmtList() {
				if (!this.list || this.list.length <= 0) return null;
				if (this.curTab == 0) return this.list;
				if (this.curTab > 0) {
					return this.list.filter(item => item.status == this.curTab - 1);
				}
			}
		},
		beforeMount() {
			this.inType = ext.transferDir().capital.key;
			this.outType = ext.transferDir().cantract.key;
			this.transferBalance();
			this.getRecord();
		},
		methods: {
			// 转入转出切换
			toogleTransfer() {
				if (this.isTransfer) {
					this.inType = ext.transferDir.capital.key;
					this.outType = ext.transferDir.cantract.key;
				} else {
					this.inType = ext.transferDir.cantract.key;
					this.outType = ext.transferDir.capital.key;
				}
				this.isTransfer = !this.isTransfer;
				this.transferBalance();
			},

			// 全额
			handleAll() {
				this.amount = this.inBalance;
			},
			// 切换
			changeTab(val) {
				this.curTab = val;
				this.getRecord();
			},
			// 宽屏列表数据刷新
			handleRefesh() {
				this.changeTab(this.curTab);
			},

			// 转换的余额，在每次变更时请求转入及转出的余额
			async transferBalance() {
				if (this.inType == 'capital') {
					const result = await ext.getAssets('USDT');
					this.inBalance = result;
					const resultOut = await ext.getAssets('USDT', 1);
					this.outBalance = resultOut;
				} else {
					const result = await ext.getAssets('USDT', 1);
					this.inBalance = result;
					const resultOut = await ext.getAssets('USDT');
					this.outBalance = resultOut;
				}
				console.log(this.inBalance, this.outBalance);
			},

			// 表单提交
			async handleSubmit() {
				if (!this.amount || this.amount <= 0) {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('common.amount')),
						icon: 'none'
					});
					return false;
				}
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.submiting')),
				});
				const result = await this.$http.post(`api/user/huazhuan`, {
					num: this.amount,
					coin: 'USDT',
					// 1代表转出是资金   2代表转入是资金
					type1: this.inType == 'capital' ? 2 : 1,
					type2: this.outType != 'cantract' ? 2 : 1,
				});
				if (!result) return false;
				console.log(`result:`, result);
				uni.showToast({
					title: result.message,
					icon: 'success'
				});
				setTimeout(() => {
					this.changeTab(this.curTab);
				}, 1000);
			},

			// 获取列表数据
			async getRecord() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.requestData')),
				});
				const result = await this.$http.get(`api/user/huazhuan_log`);
				if (!result) return false;
				console.log(`result:`, result);
				const temp = result.filter(item => item.num && item.num * 1 > 0)
				this.list = temp.map(item => {
					return {
						amount: item.num,
						sn: item.ordersn,
						ct: item.created_at,
						desc: item.fangxiang || ``,
						status: item.status,
					}
				});
			},
		}
	}
</script>

<style>
</style>