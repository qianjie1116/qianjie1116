<template>
	<view>Order</view>
</template>

<script>
	export default{
		name:'Order',
		props: {
			dark: {
				type: Boolean,
				default: true,
			}
		},
	}
</script>

<style>
</style>