<template>
	<view class="right_in">
		<!-- 当为small时， -->
		<view :class="$theme.setLayout($C.SMALL)?`second_small`:`second_medium`">
			<template v-if="$theme.setLayout($C.SMALL)">
				Record {{tag}}
			</template>
		</view>
		放 pages/account/flow 中的交易记录
		<view>横竖屏通用tabs[交易记录、充值记录、提现记录]</view>
		<view>RecordSmall</view>
		<view>RecordLarge</view>

		<RecordLargeRecharge :list="list" />

		<RecordLargeWithdraw :list="list" />

	</view>
</template>

<script>
	import RecordLargeRecharge from './recharge/RecordLarge.vue';
	import RecordSmallRecharge from './recharge/RecordSmall.vue';
	import RecordLargeWithdraw from './withdraw/RecordLarge.vue';
	import RecordSmallWithdraw from './withdraw/RecordSmall.vue';

	export default {
		name: 'Record',
		components: {
			RecordLargeRecharge,
			RecordSmallRecharge,
			RecordLargeWithdraw,
			RecordSmallWithdraw,

		},
		props: {
			dark: {
				type: Boolean,
				default: true
			},
			// 根据该传入值，决定页面当前角色
			tag: {
				type: String,
				default: ''
			}
		},
		data() {
			return {
				tabs: ext.recordTabs(),
				curTab: 1,
				list: null,
			}
		},
		computed: {
			// fmtList() {
			// 	if (!this.list || this.list.length <= 0) return null;
			// 	if (this.curTab == 0) return this.list;
			// 	if (this.curTab > 0) {
			// 		return this.list.filter(item => item.status == this.curTab - 1);
			// 	}
			// }
		},
		beforeMount() {
			console.log(`tag:`, this.tag);
			this.changeTab(this.curTab);
		},
		methods: {
			// 切换tab
			changeTab(val) {
				this.curTab = val;
				if (this.curTab == 1) this.getRecharge();
				if (this.curTab == 2) this.getWithdraw();
			},

			// 获取充值记录
			async getRecharge() {
				const result = await ext.getRecharge();
				const temp = result.filter(item => item.money && item.money * 1 > 0)
				this.list = temp.map(item => {
					return {
						amount: item.money,
						sn: item.order_sn,
						ct: item.created_at,
						desc: item.pay_channle || ``,
						status: item.status,
					}
				});
			},
			// 获取提现记录
			async getWithdraw() {
				const result = await ext.getWithdraw();
				const temp = result.filter(item => item.money && item.money * 1 > 0)
				this.list = temp.map(item => {
					return {
						id: item.id,
						token: item.pay_channle || ``,
						amount: item.money,
						fee: item.withfee,
						address: item.bankno,
						sn: item.order_sn,
						ct: item.created_at,
						desc: item.reason,
						status: item.status,
					}
				});
			},
		},
	}
</script>

<style>
</style>