<template>
	<view class="right_in">
		<view :class="$theme.setLayout($C.SMALL)?`second_small`:`second_medium`">
			<template v-if="$theme.setLayout($C.SMALL)">
				<view :style="setBG">
					<view style="padding: 40rpx 0 20rpx 40rpx;font-size: 28rpx;">
						{{$fmt.fmtText($t('common.balance'))}}({{curUnit}})
					</view>
					<view style="padding: 0 0 20rpx 40rpx;font-size: 40rpx;">{{$fmt.fmtNumber(available)}}
					</view>
				</view>
			</template>

			<template v-else>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view>
						<view style="font-size: 16px;">{{$fmt.fmtText($t('common.balance'))}}({{curUnit}}) </view>
						<view style="font-size: 36px;line-height: 1.6;">{{$fmt.fmtNumber(available)}} </view>
					</view>
					<view style="margin-left: auto;" @click="linkRecord()">
						<view style="display: flex;align-items: center;">
							<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
								{{$fmt.fmtText($t('common.record'))}}
							</view>
							<image :src="`/static/arrow_right_small.svg`" mode="aspectFit"
								:style="$theme.setImageSize(12)">
							</image>
						</view>
					</view>
				</view>
			</template>

			<view style="position: relative;">
				<view style="font: 14px;font-weight: 700;margin-top: 24px;">
					{{$fmt.fmtText($t('convert.amountFrom'))}}
				</view>
				<view class="input_wrapper" :style="$theme.setInputStyle(dark)">
					<template v-if="curMode==0">
						<input v-model="fromAmount" type="digit" :placeholder="$t('convert.amountFrom')"
							:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>

						<view style="margin-left: auto;">
							<view style="padding-right:10rpx;" :style="{color:$theme.PRIMARY}" @click="handleAll()">
								{{$fmt.fmtText($t('common.all'))}}
							</view>
						</view>
						<view style="margin-left: auto;" @click="handleShow()">
							<template v-if="curCoin">
								<view style="display: flex;align-items: center;">
									<view style="padding-right: 10px;">{{curCoin.unit}}</view>
									<CustomLogo :logo="curCoin.logo" :name="curCoin.label" :size="28" />
								</view>
							</template>
						</view>
					</template>

					<template v-else>
						<input v-model="fromAmount" type="digit" :placeholder="$t('convert.amountFrom')"
							:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
						<view style="margin-left: auto;">
							<view style="display: flex;align-items: center;padding-right: 20rpx;">
								<view style="padding-right: 20rpx;">{{usdtInfo.unit}}</view>
								<!-- <CustomLogo :logo="``" :name="usdtInfo.unit" :size="28" /> -->
							</view>
						</view>
					</template>
				</view>
				<template v-if="showCoinList">
					<view
						style="position: absolute;z-index: 9;right: 0; background-color: #0a0c13;max-height: 30vh;overflow-y: auto;">
						<block v-for="(v,k) in coinList" :key="k">
							<view style="text-align: center;padding:10px 20px;" @click="chooseCoin(v)">{{v.label}}
							</view>
						</block>
					</view>
					<view class="overlay" @click.stop="hanldeClose()"> </view>
				</template>
			</view>


			<view style="display: flex;align-items: center;justify-content: center;padding-top: 24px;">
				<view :style="$theme.setImageSize(48)" @click="toggleMode()">
					<CustomSvg :color="$theme.PRIMARY" :path="$svg.convert" :size="48" />
				</view>
			</view>

			<view style="font: 14px;font-weight: 700;margin-top: 10px;">
				{{$fmt.fmtText($t('convert.amountTo'))}}
			</view>
			<view class="input_wrapper" :style="$theme.setInputStyle(dark)">
				<view style="flex:auto;height: 32px;line-height: 32px;font-size: 16px;">
					{{$fmt.fmtNumber(toAmount,$decimal)}}</view>
				<view style="margin-left: auto;">
					<template v-if="curMode==0">
						<view style="display: flex;align-items: center;padding-right: 20rpx;">
							<view style="">{{toCoin.unit}}</view>
							<!-- <CustomLogo :logo="toCoin.logo" :name="toCoin.unit" :size="28" /> -->
						</view>
					</template>
					<template v-else>
						<view style="display: flex;align-items: center;padding-right: 20rpx;" @click="chooseCoin()">
							<view style="padding-right: 20rpx;">{{toCoin.unit}}</view>
							<CustomLogo :logo="toCoin.logo" :name="toCoin.unit" :size="28" />
						</view>
					</template>
				</view>
			</view>

			<view style="padding-top: 40rpx;" :style="{color:$theme.TXT_UNACT}">
				{{$fmt.fmtText($t('convert.rate'))}}
			</view>
			<template v-if="curRate>=0 && curCoin">
				<view style="text-align: right;">
					1{{curCoin.unit+` ≈ `+$fmt.fmtNumber(curRate) +` `+usdtInfo.unit}}
				</view>
			</template>

			<view class="btn_common" @click="handleSubmit()" style="margin: 24px 0;line-height: 40px;">
				{{$fmt.fmtText($t('common.submit'))}}
			</view>

			<!-- 			<view style="font-size: 16px;font-weight: 700;line-height: 1.8;">
				{{$fmt.fmtText($t('assets.convert')+` `+$t('common.record'))}}
			</view>

			<view style="display: flex;align-items: center;line-height: 1.8;">
				<block v-for="(v,k) in tabs" :key="k">
					<view style="padding-right: 12px;">{{$fmt.fmtText(v)}}</view>
				</block>
			</view>

			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(v,k) in list" :key="k">
					<template v-if="$theme.setLayout($C.SMALL)">
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
						<view>{{v.ident}}</view>
						<view>{{$fmt.fmtNumber(v.money*1)}}</view>
						<view>{{v.created_at}}</view>
					</view>
					</template>
				<template v-if="$theme.setLayout($C.MEDIUM)">
					<view>紧凑 一行3字段</view>
				</template>
				<template v-if="$theme.setLayout($C.LARGE)">
					<view>宽屏 充值记录 完整展开一行一条数据</view>
					<view>单号 、 充值地址 、 币种、 金额、时间 、 状态</view>
				</template>
				</block>
			</template> -->
		</view>
	</view>
</template>

<script>
	import * as ext from '../ext.js';
	export default {
		name: 'Convert',
		components: {},
		props: {
			dark: {
				type: Boolean,
				default: true,
			}
		},
		data() {
			return {
				showCoinList: false, // 是否显示选择浮层
				coinList: [],
				curCoin: null, // 当前选中币
				curMode: 0, // 当前模式[to usdt or from usdt]，0:转到USDT
				available: '', // 当前可用余额 
				fromAmount: '', // 转入的输入值
				curRate: 1, // 当前汇率
				// tabs: ext.tabsRecharge, // 列表类型过滤
				list: [], // 列表数据
				usdtInfo: {
					label: ``,
					code: ``,
					logo: ``,
					unit: `USDT`,
				},
			}
		},
		computed: {
			//  to coin
			toCoin() {
				return this.curMode == 1 && this.curCoin ? this.curCoin : this.usdtInfo
			},

			// 计算转出金额
			toAmount() {
				if (this.fromAmount == '' || this.fromAmount <= 0) return '';
				if (this.curMode == 0) {
					return this.fromAmount * this.curRate > 0 ? this.fromAmount * this.curRate : ''
				} else {
					return this.fromAmount / this.curRate > 0 ? this.fromAmount / this.curRate : ''
				}
			},

			// 当前余额 单位
			curUnit() {
				return this.curMode == 0 && this.curCoin ? this.curCoin.unit : this.usdtInfo.unit;
			},
			// 设置背景  to_usdt to_usdt
			setBG() {
				const temp = this.curMode == 0 ? `to` : `from`;
				return {
					backgroundImage: `url(/static/${temp}_usdt.png)`,
					backgroundPosition: '0 0',
					backgroundSize: `100% 100%`,
					color: '#FFFFFF',
					borderRadius: `8rpx`,
					width: `100%`,
					height: `120px`,
				}
			},
		},
		beforeMount() {
			this.getCoinList();
			// this.getRecord();
		},

		methods: {
			// 转入转出模式切换
			toggleMode() {
				console.log(`toggleMode`);
				this.curMode = this.curMode == 0 ? 1 : 0;
				// 重新获取资金中的可用余额
				this.getAccountAssets();
				this.fromAmount = '';
			},

			// from输入框的all
			handleAll() {
				this.fromAmount = this.available;
			},
			// 打开浮层
			handleShow() {
				this.showCoinList = true;
			},
			// 关闭下拉浮层
			hanldeClose() {
				this.showCoinList = false;
			},
			// 選擇一種coin
			chooseCoin(val) {
				console.log(val);
				this.curCoin = val;
				this.hanldeClose();
				this.getAccountAssets();
				this.getRate();
			},

			async getRecord() {
				uni.showLoading({
					title: this.$t('api.requestData'),
				})
				const result = await this.$http.post(`api/user/finance`, {
					type: 2
				});
				if (!result) return false;
				// console.log('result:', result);
				this.list = result.filter(item => item.type == 2 && item.option == 2 && item.money * 1 < 0)
			},

			// 获取汇率
			async getRate() {
				console.log(`getRate:`, this.curCoin);
				const result = await this.$http.post(`api/user/shandui_huilu`, {
					coin1: this.curCoin.unit,
					coin2: this.usdtInfo.unit,
				});
				if (!result) return false;
				console.log(`rate:`, result);
				this.curRate = result || 1;
			},
			// 提交
			async handleSubmit() {
				if (!this.fromAmount || this.fromAmount <= 0) {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('convert.amountFrom')),
						icon: 'none'
					});
					return false;
				}
				uni.showLoading({
					title: this.$t('api.submiting'),
				});
				const result = await this.$http.post(`api/user/shandui`, {
					coin1: this.curMode == 0 ? this.curCoin.unit : this.usdtInfo.unit,
					coin2: this.curMode == 0 ? this.usdtInfo.unit : this.curCoin.unit,
					money: this.fromAmount,
				});
				if (!result) return false;
				console.log('result:', result);
				uni.showToast({
					// title: result,
					icon: 'success'
				});
				setTimeout(() => {
					this.getRecord();
				}, 1000);
			},

			// 在切換coin時，需請求列表，製作coin選擇器數組
			async getCoinList() {
				uni.showLoading({
					title: this.$t('api.requestData'),
					icon: 'loading'
				});
				const result = await this.$http.get(`api/goods/list`);
				if (!result) return false;
				console.log(result);
				if (Object.values(result).length > 0) {
					this.coinList = Object.values(result).map(item => {
						return {
							label: item.name,
							code: item.code,
							logo: item.logo,
							unit: item.name.split('/')[0],
							price: item.current_price * 1,
						}
					});
					this.curCoin = this.coinList[0];
					this.getAccountAssets();
					this.getRate();
				}
			},

			// 获取账户 資產信息
			async getAccountAssets() {
				const result = await this.$http.post(`api/user/assets`, {
					type: 2,
					// coin to usdt 时，获取coin的余额，否则获取usdt余额
					name: this.curMode == 0 ? this.curCoin.code : this.usdtInfo.unit,
				});
				console.log(`assets:`, result);
				if (!result) return false;
				this.available = result.length > 0 ? result[0].money : '';
			},
		},

	}
</script>

<style lang="scss" scoped>
</style>