<template>
	<view class="left_in">
		<template v-if="$theme.setLayout($C.SMALL)">
			<header class="app_header">
				<view class="left"></view>
				<view class="center">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<block v-for="(item,index) in tabs" :key="index">
							<view :style="{color: curTab==index ? $theme.PRIMARY : $theme.TXT_UNACT}"
								@click="changeTab(index)">{{$fmt.fmtText(item)}}
							</view>
						</block>
					</view>
				</view>
				<view class="right"></view>
			</header>

			<view>
				<view style="border-bottom: 1px solid #343434;line-height: 3;">
					<view style="display: flex;align-items: center;">
						<!-- ({{$t('common.unitUSDT')}}) -->
						<view>{{tabs[curTab]}} </view>
						<image :src="`/static/${isMask?'show':'hide'}_dark.png`" mode="aspectFit"
							style="padding: 0 12px;" :style="$theme.setImageSize(16)" @click="toggleMask()">
						</image>
						<image :src="`/static/refesh.svg`" mode="aspectFit" style="padding: 0 12px;"
							:style="$theme.setImageSize(16)" @click="handleRefesh()">
						</image>
					</view>
					<view style="line-height: 1.6;font-size: 36px;font-weight: 700;">
						{{$fmt.fmtCurrency($fmt.fmtNumber(assetsAmount))}}
					</view>
				</view>
			</view>

			<!-- 操作按钮组 -->
			<view style="display: flex;align-items: center;padding: 20px 0; border-bottom: 1px solid #343434;">
				<block v-for="(v,k) in operList" :key="k">
					<view style="flex:0 0 20%;">
						<view style="display: flex;align-items: center;flex-direction: column;justify-content: center;"
							@click="operLink(v.key)">
							<image :src="`/static/top${k}.png`" mode="aspectFit" :style="$theme.setImageSize(40)">
							</image>
							<view style="padding-top: 6px;">{{$fmt.fmtText(v.name)}}</view>
						</view>
					</view>
				</block>
			</view>


			<!-- 通用的资产明细 list 理财和合约都只有一个元素 -->
			<view style="font-size: 36rpx;font-weight: 500;margin-top: 24px;">{{$fmt.fmtText($t('assets.detail'))}}
			</view>
			<block v-for="(item,index) in assetsList" :key="index">
				<view style="border-bottom: 1px solid #343434;padding:24rpx 0;">
					<view style="display: flex;align-items: center;padding:16rpx 0;">
						<CustomLogo :logo="``" :name="`USDT`" :size="28" />
						<view style="padding-left: 24rpx;">{{item.name}}</view>
					</view>
					<view style="display: flex;align-items: center;line-height: 2;">
						<view style="margin-right: auto;">
							<view style="font-size: 24rpx;" :style="{color:$theme.TXT_UNACT}">{{$t('assets.available')}}
							</view>
							<view>{{$fmt.fmtNumber(item.availbale)}}</view>
						</view>
						<view style="flex:1;">
							<view style="text-align: center;font-size: 24rpx;" :style="{color:$theme.TXT_UNACT}">
								{{$fmt.fmtText($t('assets.unavailale'))}}
							</view>
							<view style="text-align: center;">{{$fmt.fmtNumber(item.unavailbale)}}</view>
						</view>
						<view style="margin-left: auto;">
							<view style="text-align: right;font-size: 24rpx;" :style="{color:$theme.TXT_UNACT}">
								{{$fmt.fmtText($t('assets.equivalent'))}}({{$t('common.unitUSDT')}})
							</view>
							<view style="text-align: right;">{{$fmt.fmtNumber(item.equivalent)}}</view>
						</view>
					</view>
				</view>
			</block>
		</template>

		<!-- <view style="border-bottom: 1px solid #343434;line-height: 3;">
			<view>{{$lang.ASSET_OVERVIEW}} </view>
			<view style="text-align: right;">156,377,3131.22 {{$lang.UNIT_USDT}}</view>
		</view>

		<view style="border-bottom: 1px solid #343434;line-height: 3;">
			<view>{{$lang.ASSET_WEALTH}} </view>
			<view style="text-align: right;">377,3131.22 {{$lang.UNIT_USDT}}</view>
		</view>

		<view style="border-bottom: 1px solid #343434;line-height: 3;">
			<view>{{$lang.ASSET_CONTRACT}} </view>
			<view style="text-align: right;">3131.22 {{$lang.UNIT_USDT}}</view>
		</view> -->


		<template v-if="!$theme.setLayout($C.SMALL)">
			<view style="font-size: 14px;font-weight: 500;">{{$fmt.fmtText($t('assets.detail'))}}</view>
			<RecordLarge :list="list" />
		</template>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	import RecordLarge from '../account/components/RecordLarge.vue';
	export default {
		name: 'Overview',
		components: {
			RecordLarge
		},
		props: {
			dark: {
				type: Boolean,
				default: true,
			}
		},
		data() {
			return {
				isMask: null, // 是否掩码
				curTab: 0, //  small 当前tab
				assetsInfo: null, // 资产信息。
				list: null,
			}
		},
		computed: {
			tabs() {
				return [
					this.$t('assets.total'),
					this.$t('assets.wealth'),
					this.$t('assets.contract'),
				]
			},
			// 当前资产
			assetsAmount() {
				return !this.assetsInfo ? '' : this.assetsInfo.money
			},
			// 当前资产明细
			assetsList() {
				return [{
					name: `USDT`,
					availbale: 315350.74,
					unavailbale: 515350.74,
					// 此处需要 * 汇率
					equivalent: 515350.74 * 3.75
				}]
			},
			// 充提闪转贷
			operList() {
				return [{
					key: this.$C.KEY_RECHARGE,
					name: this.$t('assets.recharge'),
				}, {
					key: this.$C.KEY_WITHDRAW,
					name: this.$t('assets.withdraw'),
				}, {
					key: this.$C.KEY_CONVERT,
					name: this.$t('assets.convert'),
				}, {
					key: this.$C.KEY_TRANSFER,
					name: this.$t('assets.transfer'),
				}, {
					key: this.$C.KEY_RULE_LOAN,
					name: this.$t('header.loan'),
				}]
			},
			// 当前显示 我的资产(不含lan)，理财与合约(只显示transfer、loan)
			setOper() {
				return this.curTab == 0 ? this.operList.slice(0, -1) : this.operList.slice(3);
			},
		},
		beforeMount() {
			this.isMask = uni.getStorageSync('masking'); // 当前掩码状态
			this.getAssetsInfo();
			this.getAssetsList();
		},
		methods: {
			// 刷新
			handleRefesh() {
				// 重新获取当前tab的数据，或许还需强刷
				this.getAssetsInfo();
			},

			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
			operLink(val) {
				console.log(`operLink:`, val);
				this.$emit('action', val);
			},
			changeTab(val) {
				this.curTab = val;
			},

			// 获取账户 資產信息
			async getAssetsInfo() {
				const result = await this.$http.post(`api/user/assets`, {
					type: 1,
					// coin to usdt 时，获取coin的余额，否则获取usdt余额
					name: 'USDT',
				});
				console.log(`assets:`, result);
				if (!result) return false;
				this.assetsInfo = result[0];
			},

			async getAssetsList() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.requestData')),
				});
				const result = await this.$http.post(`api/user/assets`, {
					type: 2, // 2:assets 1:contract
					hide_money: this.isHideZero ? 1 : 0,
				});
				if (!result) return false;
				console.log(`assets:`, result);
				this.list = result;
			},
		}
	}
</script>

<style lang="scss" scoped>
	.app_header {
		padding: 20px 0 10px 0;
		display: flex;
		align-items: center;
		border-bottom: 1px solid #34393e;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			font-size: 16px;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1;
			text-align: center;
		}
	}
</style>