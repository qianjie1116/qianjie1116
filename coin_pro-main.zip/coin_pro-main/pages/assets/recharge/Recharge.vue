<template>
	<view class="right_in">
		<view :class="$theme.setLayout($C.SMALL)?`second_small`:`second_medium`">
			<!-- <view> 放一个资产卡。横屏N列数据排列。竖屏一行一数据</view> -->
			
			<view style="font: 14px;font-weight: 700;">
				{{$fmt.fmtText($t('recharge.amount'))}}
			</view>
			<view style="position: relative;">
				<view class="input_wrapper" :style="$theme.setInputStyle(dark)">
					<template v-if="curCoinType">
						<input v-model="amount" type="digit"
							:placeholder="$fmt.fmtText($t('common.min')+ $t('recharge.amount'))+` `+curCoinType.rmin"
							:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
						<view style="margin-left: auto;" @click="showModal()">
							<view :style="{color:$theme.PRIMARY}">
								{{curCoinType.key.toUpperCase()}}
							</view>
						</view>
					</template>
				</view>
				<template v-if="showCoinList">
					<view style="position: absolute;z-index: 9;right: 0; background-color: #0a0c13;">
						<block v-for="(v,k) in Object.values(cryptoOpt)" :key="k">
							<template v-if="k<=Object.values(cryptoOpt).length-2">
								<view style="text-align: center;padding:10px 20px;" @click="chooseCoin(v)">
									{{v.key.toUpperCase()}}
								</view>
							</template>
						</block>
					</view>
					<view class="overlay" @click.stop="closeModal()"> </view>
				</template>
			</view>

			<!-- 当前选择币种的地址 -->
			<view style="display: flex;align-items: center;margin-top: 24px;margin-bottom: 12px;">
				<view style="font: 14px;font-weight: 700;">
					{{ !curCoinType?``:curCoinType.key.toUpperCase()+` `}} {{$fmt.fmtText($t('common.address'))}}
				</view>
				<view style="margin-left: auto; font-size: 12px;" :style="{color:$theme.PRIMARY}" @tap="handleCopy()">
					{{$fmt.fmtText($t('common.copy'))}}
				</view>
			</view>

			<view style="word-break: break-word; font-size: 12px;line-height:1.4;padding-bottom: 6px;"
				:style="{color:$theme.TXT_WHITE,borderBottom:`1px solid ${$theme.PRIMARY}`}">
				{{ !curCoinType?``:curCoinType.address}}
			</view>

			<!-- 上传支付截图 -->
			<view style="font: 14px;font-weight: 700;margin-top: 24px;margin-bottom: 8px;">
				{{$fmt.fmtText($t('recharge.upload'))}}
			</view>

			<view style="display: flex;align-items: center;justify-content: center;padding: 14px 20px;">
				<template v-if="imgUrl">
					<canvas id="qrcode" canvas-id="qrcode" style="width: 200px;height: 210px;">
						<img :src="imgUrl" alt="" style="width: 200px;">
					</canvas>
				</template>
			</view>

			<view class="btn_common" @click="handleSubmit()" style="margin:0 0 24px 0;line-height: 40px;">
				{{$fmt.fmtText($t('common.submit'))}}
			</view>

			<view style="font-size: 16px;font-weight: 700;line-height: 1.8;">
				{{$fmt.fmtText($t('assets.recharge')+` `+$t('common.record'))}}
			</view>

			<view style="display: flex;align-items: center;line-height: 1.8;">
				<block v-for="(v,k) in tabs" :key="k">
					<view style="padding-right: 12px;" @click="changeTab(k)">
						<text :style="{color:curTab==k?$theme.PRIMARY:$theme.TXT_UNACT,
							borderBottom:`1px dashed ${curTab==k?$theme.PRIMARY:$theme.TXT_UNACT}`}">
							{{$fmt.fmtText(v)}}
						</text>
					</view>
				</block>
				<view style="margin-left: auto;">
					<CustomSvg :color="$theme.PRIMARY" :path="$svg.refesh" @click="handleRefesh()" />
				</view>
			</view>

			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<template v-if="$theme.setLayout($C.SMALL)">
					<RecordSmall :list="fmtList" />
				</template>
				<template v-else>
					<RecordLarge :list="fmtList" />
				</template>
			</template>
		</view>
	</view>
</template>

<script>
	import * as ext from '../ext.js';
	import RecordLarge from './RecordLarge.vue';
	import RecordSmall from './RecordSmall.vue';
	export default {
		name: 'Recharge',
		components: {
			RecordLarge,
			RecordSmall,
		},
		props: {
			dark: {
				type: Boolean,
				default: true,
			},
		},
		data() {
			return {
				amount: '', // 充值额
				showCoinList: false, // 是否显示选择浮层
				cryptoOpt: ext.cryptoOpt, // crypto 备选组
				curCoinType: null, // 当前选中币种
				list: null, // 列表数据
				tabs: ext.tabsRecharge(), // 列表类型过滤
				curTab: 0, // 当前显示
				imgUrl: null,
			}
		},
		computed: {
			fmtList() {
				if (!this.list || this.list.length <= 0) return null;
				if (this.curTab == 0) return this.list;
				if (this.curTab > 0) {
					return this.list.filter(item => item.status == this.curTab - 1);
				}
			}
		},
		beforeMount() {
			this.getCoinfg();
			this.getRecord();
		},
		methods: {
			// 打开浮层
			showModal() {
				this.showCoinList = true;
			},
			// 关闭下拉浮层
			closeModal() {
				this.showCoinList = false;
			},
			// 選擇一種coin
			chooseCoin(val) {
				console.log(val);
				this.curCoinType = val;
				this.closeModal();
				this.getCoinfg();
			},
			// 切换
			changeTab(val) {
				this.curTab = val;
				this.getRecord();
			},
			// 宽屏列表数据刷新
			handleRefesh() {
				this.changeTab(this.curTab);
			},

			// 获取充值记录
			async getRecord() {
				const result = await ext.getRecharge();
				const temp = result.filter(item => item.money && item.money * 1 > 0)
				this.list = temp.map(item => {
					return {
						amount: item.money,
						sn: item.order_sn,
						ct: item.created_at,
						desc: item.pay_channle || ``,
						status: item.status,
					}
				});
			},

			// 提交
			async handleSubmit() {
				if (!this.amount || this.amount <= 0) {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('recharge.amount')),
						icon: 'none'
					});
					return false;
				}
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.submiting')),
				});
				const result = await this.$http.post(`api/app/recharge`, {
					money: this.amount,
					type: this.curCoinType.key,
					image: '',
					desc: '',
				});
				if (!result) return false;
				console.log('result:', result);
				uni.showToast({
					title: this.$fmt.fmtText(this.$t('common.success')),
					icon: 'success'
				});
				this.amount = '';
				setTimeout(() => {
					this.getRecord();
				}, 1000);
			},

			// copy address
			async handleCopy() {
				const result = await uni.setClipboardData({
					data: this.curCoinType.address, //要被复制的内容
				});
				if (result[1].confirm) {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.copy') + this.$t('common.success')),
						duration: 2000,
						icon: 'success'
					})
				}
			},
			// 获取选中币的钱包地址及二维码
			async getCoinfg() {
				this.curCoinType = !this.curCoinType ? this.cryptoOpt[this.$C.KEY_ERC] : this.curCoinType;
				const result = await this.$http.post(`api/app/usdtpay`, {
					type: this.curCoinType.key
				});
				if (!result) return false;
				this.curCoinType.address = result.value;
				this.imgUrl = result.img;

			},
		}
	}
</script>

<style lang="scss" scoped>
</style>