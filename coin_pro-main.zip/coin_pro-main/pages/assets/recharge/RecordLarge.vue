<template>
	<view class="custom_table">
		<view class="table_header">
			<view class="table_row" :style="{color:$theme.TXT_UNACT}">
				<block v-for="(v,k) in Object.values(headers)" :key="k">
					<view class="table_cell" :style="{flex:`${v.flex}`,textAlign:v.align}"> {{v.text}} </view>
				</block>
			</view>
		</view>
		<view class="table_body" style="overflow-x: auto;">
			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<block v-for="(item,index) in list" :key="index">
				<view class="table_row" :style="{borderBottom:`1px solid ${$theme.TXT_UNACT}`}">
					<view class="table_cell" style="font-size: 11px;" :style="{
						color:setStatus(item.status).color,
					flex:`${headers.status.flex}`}">
						{{setStatus(item.status).text}}
					</view>
					<view class="table_cell" :style="{flex:`${headers.amount.flex}`}">
						{{$fmt.fmtCrypto(`${item.amount}`)}}
					</view>
					<view class="table_cell" style="font-size: 11px;"
						:style="{color:$theme.TXT_UNACT,flex:`${headers.sn.flex}`}">
						{{item.sn}}
					</view>
					<view class="table_cell" style="font-size: 11px;" :style="{color:$theme.TXT_UNACT,
					flex:`${headers.ct.flex}`}">
						{{item.ct}}
					</view>
					<view class="table_cell" style="font-size: 11px;" :style="{color:$theme.TXT_UNACT,
					flex:`${headers.desc.flex}`,textAlign:headers.desc.align}">
						{{item.desc.toUpperCase()}}
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import * as ext from '../ext.js';
	export default {
		name: 'RecordLarge',
		props: {
			list: {
				type: Array,
				default: []
			},
			// 根据code决定，某些列是否显示
			code: {
				type: String,
				default: ''
			}
		},
		data() {
			return {
				headers: ext.headersRecharge(),
			}
		},
		methods: {
			setStatus(val = 0) {
				return ext.fmtStatus()[val]
			}
		}
	}
</script>

<style>
</style>