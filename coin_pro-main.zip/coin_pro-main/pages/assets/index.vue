<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.SMALL)">
			<template v-if="curActive==0">
				<HeaderSmall :dark="isDark" @update:dark="isDark = $event" :title="setTitle" />
			</template>
			<template v-if="curTag !=''">
				<HeaderSmall :dark="isDark" @update:dark="isDark = $event" :title="setTitle" isLink @back="goBack">
					<view style="padding-left: 10px;">
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.rule" @click="showRule()" />
					</view>
				</HeaderSmall>
			</template>
		</template>

		<view :style="$theme.setStyleBody()">
			<template v-if="$theme.setLayout($C.MEDIUM) || $theme.setLayout($C.LARGE)">
				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 2.6;padding-bottom: 20px;">
					<block v-for="(item,index) in tabs" :key="index">
						<view class="sec_nav_item" :style="setStyleNav(curActive ==index)" @click="changeTab(index)">
							{{$fmt.fmtText(item.name)}}
						</view>
					</block>
				</view>
			</template>

			<template v-if="curActive==0">
				<template v-if="$theme.setLayout($C.SMALL)">
					<Overview :dark="isDark" @action="operLink" />
				</template>
				<template v-if="!$theme.setLayout($C.SMALL)">
					<!-- <AssetOper :dark="isDark" @action="handleOper" /> -->
					<view class="right_in">
						<view style="font-size: 24px;padding-top: 40px;padding-bottom: 10px;">
							{{$fmt.fmtText($t('assets.tip0'))}}
						</view>
						<view style="">{{$APP_NAME+$fmt.fmtText($t('assets.tip1'))}} </view>

						<view
							style="display: flex;align-items: center;justify-content: space-between;padding-top: 40px;">
							<view style="flex:0 0 32%;" @click="changeTab($C.KEY_RECHARGE)">
								<view
									style="padding: 10px 16px;   font-size: 14px;border-radius: 2px;   cursor: pointer;display: flex;align-items: center;height:100px;"
									:style="{color:$theme.TXT_UNACT, backgroundColor:$theme.INPUT_BORDER}">
									<image src="/static/top3.png" mode="aspectFit" :style="$theme.setImageSize(60)">
									</image>
									<view style="padding-left: 10px;">
										<view style="padding-bottom: 10px;" :style="{color:$theme.BASIC_TXT}">
											{{$fmt.fmtText($t('assets.recharge'))}}
										</view>
										<view style="font-size: 12px;line-height: 1.4;">
											{{$fmt.fmtText($t('tip.recharge'),$C.FMT_METHOD_SC)}}
										</view>

									</view>
								</view>
							</view>

							<view style="flex:0 0 32%;" @click="changeTab($C.KEY_WITHDRAW)">
								<view
									style="padding: 10px 16px;   font-size: 14px;border-radius: 2px;   cursor: pointer;display: flex;align-items: center;height:100px;"
									:style="{color:$theme.TXT_UNACT, backgroundColor:$theme.INPUT_BORDER}">
									<image src="/static/top2.png" mode="aspectFit" :style="$theme.setImageSize(60)">
									</image>
									<view style="padding-left: 10px;">
										<view style="padding-bottom: 10px;" :style="{color:$theme.BASIC_TXT}">
											{{$fmt.fmtText($t('assets.withdraw'))}}
										</view>
										<view style="font-size: 12px;line-height: 1.4;">
											{{$fmt.fmtText($t('tip.withdraw'),$C.FMT_METHOD_SC)}}
										</view>
									</view>
								</view>
							</view>

							<view style="flex:0 0 32%;" @click="changeTab($C.KEY_TRANSFER)">
								<view style="padding: 10px 16px;   font-size: 14px;
								border-radius: 2px;   cursor: pointer;display: flex;align-items: center;height:100px;"
									:style="{color:$theme.TXT_UNACT, backgroundColor:$theme.INPUT_BORDER}">
									<image src="/static/top3.png" mode="aspectFit" :style="$theme.setImageSize(60)">
									</image>
									<view style="padding-left: 10px;">
										<view style="padding-bottom: 10px;" :style="{color:$theme.BASIC_TXT}">
											{{$fmt.fmtText($t('assets.transfer'))}}
										</view>
										<view style="font-size: 12px;line-height: 1.4;">
											{{$fmt.fmtText($t('tip.transfer'),$C.FMT_METHOD_SC)}}
										</view>
									</view>
								</view>
							</view>
						</view>
					</view>
				</template>

				<template v-if="!$theme.setLayout($C.SMALL)">
					<view style="padding-bottom: 16px;"></view>
					<Overview :dark="isDark" @action="operLink" />
				</template>
			</template>

			<template v-if="curTag==$C.KEY_RECHARGE">
				<Recharge :dark="isDark" />
			</template>

			<template v-if="curTag==$C.KEY_WITHDRAW">
				<Withdraw :dark="isDark" />
			</template>

			<template v-if="curTag==$C.KEY_CONVERT">
				<Convert :dark="isDark" />
			</template>

			<template v-if="curTag==$C.KEY_TRANSFER">
				<Transfer :dark="isDark" />
			</template>

			<!-- <template v-if="curTag==$C.KEY_ORDER">
				<Order :dark="isDark" />
			</template> -->

			<!-- <template v-if="curTag==$C.KEY_RECORD">
				<Record :dark="isDark" :tag="curRecord" />
			</template> -->
		</view>

		<template v-if="$theme.setLayout($C.SMALL) && curActive==0">
			<FooterSmall :dark="isDark" />
		</template>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	import Overview from './Overview.vue';
	import Recharge from './recharge/Recharge.vue';
	import Withdraw from './withdraw/Withdraw.vue';
	import Convert from './convert/Convert.vue';
	import Transfer from './transfer/Transfer.vue';
	import Order from './Order.vue';
	import Record from './Record.vue';
	export default {
		components: {
			Overview,
			Recharge,
			Withdraw,
			Convert,
			Transfer,
			Order,
			Record
		},
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
				curActive: 0, // 当前项
				curTag: '',
				isRule: false, // 是否显示rule浮层
				// 紧凑及宽屏时，tab ，key为small屏时tag
				tabs: ext.tabsAssets(),
			}
		},
		computed: {
			// 当前标题
			setTitle() {
				return this.$fmt.fmtText(this.curActive == 0 ? this.$t('header.assets') : this.tabs[this.curActive].name);
			},
			// header small 动态更新title
			setHeader() {
				console.log(`tag:`, this.curTag);
				return this.curTag == this.$C.KEY_RECHARGE ||
					this.curTag == this.$C.KEY_WITHDRAW ||
					this.curTag == this.$C.KEY_CONVERT ||
					this.curTag == this.$C.KEY_TRANSFER;
			},
		},
		onLoad(opt) {
			console.log(`opt:`, opt);
			this.curTag = opt.tag || this.curTag;
			// this.curTitle = this.titles.get(this.curTag);
		},

		onShow() {
			if (!this.$linkTo.checkToken()) return false;
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
			// 
			if (this.curTag == '') {
				this.changeTab(this.curActive);
			} else {
				this.changeTab(this.curTag);
			}


		},
		onHide() {
			console.log(`onHide:`, this.isDark);
			this.isAnimat = false;
		},
		deactivated() {},
		onPullDownRefresh() {
			uni.stopPullDownRefresh();
		},
		methods: {
			// small 布局下，统一回退
			goBack(val) {
				this.curActive = 0;
				this.changeTab(this.curActive);
			},

			// small布局下，统一rule弹层。
			showRule() {
				this.isRule = true;
			},

			// 跳转
			operLink(val) {
				console.log(`index btnLinkTo:`, val);
				if (val == this.$C.KEY_RULE_LOAN) {
					console.log(`loan:`, val);
					uni.navigateTo({
						url: this.$linkTo.PAGES + this.$linkTo.LOAN
					})
					return false;
				}
				this.curActive = this.tabs.findIndex(item => item.key == val);
				this.curTag = val;
			},

			// 导航跳转
			changeTab(val) {
				if (typeof(val) === 'number') {
					this.curActive = val;
					console.log(`val:`, this.tabs[this.curActive]);
					this.curTag = this.tabs[this.curActive].key;
				} else {
					this.curActive = this.tabs.findIndex(item => item.key == val);
					this.curTag = this.tabs[this.curActive].key;
				}
			},
			handleOper(val) {
				console.log(`val:`, val);
				this.curActive = this.tabs.findIndex(item => item.key == val);
				this.changeTab(this.curActive);
			},

			// 导航激活样式
			setStyleNav(val) {
				return {
					color: val ? this.$theme.PRIMARY : this.$theme.TXT_UNACT,
					borderBottom: `1px solid  ${val?this.$theme.PRIMARY_TXT:this.$theme.TRANSPARENT}`,
				}
			}
		},
	}
</script>
<style lang="scss" scoped>
	.app_header {
		padding: 24px 20px 10px 20px;
		display: flex;
		align-items: center;
		border-bottom: 1px solid #34393e;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}

	.sec_nav_item {
		padding: 0 6px;
		text-align: center;
		cursor: pointer;
		border-bottom: 1px solid transparent;
	}

	.sec_nav_item:hover {
		color: #546BFF;
		border-bottom: 1px solid #546BFF;
	}
</style>