import Vue from 'vue';
import i18n from '@/locales/index.js';
import * as constants from '@/common/constants.js';
import * as fmt from '@/common/format.js';
import http from '@/common/http.js';

// assets tabs
export const tabsAssets = () => {
	return [{
			key: '',
			name: fmt.fmtText(i18n.t('assets.overview')),
		}, {
			key: constants.KEY_RECHARGE,
			name: fmt.fmtText(i18n.t('assets.recharge')),
		}, {
			key: constants.KEY_WITHDRAW,
			name: fmt.fmtText(i18n.t('assets.withdraw')),
		}, {
			key: constants.KEY_CONVERT,
			name: fmt.fmtText(i18n.t('assets.convert')),
		}, {
			key: constants.KEY_TRANSFER,
			name: fmt.fmtText(i18n.t('assets.transfer')),
		},
		// {
		// 	key: constants.KEY_RULE_LOAN,
		// 	name: fmt.fmtText(i18n.t('header.loan')),
		// }, 
		// {
		// 	key: constants.KEY_ORDER,
		// 	name: fmt.fmtText(i18n.t('assets.order')),
		// }, {
		// 	key: constants.KEY_RECORD,
		// 	name: fmt.fmtText(i18n.t('common.record')),
		// }
	]
};

// 提现最小额 手续费
export const cryptoOpt = {
	[constants.KEY_ERC]: {
		key: constants.KEY_ERC,
		wmin: 10,
		rmin: 1,
		fee: 0.05,
	},
	[constants.KEY_TRC]: {
		key: constants.KEY_TRC,
		wmin: 10,
		rmin: 1,
		fee: 0.05
	},
	[constants.KEY_BTC]: {
		key: constants.KEY_BTC,
		wmin: 0.001,
		rmin: 0.001,
		fee: 0.01
	},
	[constants.KEY_ETH]: {
		key: constants.KEY_ETH,
		wmin: 0.001,
		rmin: 0.01,
		fee: 0.01
	},
	[constants.KEY_TRX]: {
		key: constants.KEY_TRX,
		wmin: 100,
		fee: 0.05
	}
}

// 充值的tabs
export const tabsRecharge = () => {
	return [
		fmt.fmtText(i18n.t('assets.all')),
		fmt.fmtText(i18n.t('assets.review')),
		fmt.fmtText(i18n.t('assets.pass')),
		fmt.fmtText(i18n.t('assets.reject')),
	]
};

export const headers = () => {
	return {
		token: {
			flex: 1,
			text: fmt.fmtText(i18n.t('assets.token'))
		},
		money: {
			flex: 1,
			text: fmt.fmtText(i18n.t('assets.amount'))
		},
		freeze: {
			flex: 1,
			text: fmt.fmtText(i18n.t('assets.amount'))
		},
		total: {
			flex: 1,
			text: fmt.fmtText(i18n.t('assets.amount'))
		},
	}
};

// 状态
export const fmtStatus = () => {
	return [{
			color: '#FF5722',
			text: fmt.fmtText(i18n.t('assets.review'))
		},
		{
			color: '#0ECB81',
			text: fmt.fmtText(i18n.t('assets.pass')),
		},
		{
			color: '#E91E63',
			text: fmt.fmtText(i18n.t('assets.reject'))
		},
	]
};

// 充值记录
export const headersRecharge = () => {
	return {
		status: {
			flex: `0 0 60px`,
			text: fmt.fmtText(i18n.t('assets.status'))
		},
		amount: {
			flex: `0 0 160px`,
			text: fmt.fmtText(i18n.t('assets.amount'))
		},
		sn: {
			flex: `0 0 160px`,
			text: fmt.fmtText(i18n.t('assets.sn'))
		},
		ct: {
			flex: `0 0 120px`,
			text: fmt.fmtText(i18n.t('assets.ct'))
		},

		desc: {
			flex: `0 0 300px`,
			text: fmt.fmtText(i18n.t('assets.desc')),
			align: `right`,
		}
	}
};

// 提现记录
export const headersWithdraw = () => {
	return {
		status: {
			flex: `0 0 60px`,
			text: fmt.fmtText(i18n.t('assets.status'))
		},
		token: {
			flex: `0 0 100px`,
			text: fmt.fmtText(i18n.t('assets.token'))
		},
		amount: {
			flex: `0 0 100px`,
			text: fmt.fmtText(i18n.t('assets.amount'))
		},
		fee: {
			flex: `0 0 100px`,
			text: fmt.fmtText(i18n.t('assets.fee'))
		},
		address: {
			flex: `0 0 160px`,
			text: fmt.fmtText(i18n.t('common.address'))
		},
		sn: {
			flex: `0 0 120px`,
			text: fmt.fmtText(i18n.t('assets.sn'))
		},
		ct: {
			flex: `0 0 80px`,
			text: fmt.fmtText(i18n.t('assets.ct')),
		},
		action: {
			flex: `0 0 80px`,
			text: fmt.fmtText(i18n.t('common.action')),
			align: 'right',
		}
		// desc: {
		// 	flex: `0 0 300px`,
		// 	text: fmt.fmtText(i18n.t('assets.desc')),
		// 	align: `right`,
		// }
	}
};



// 存款提示
export const tipRecharge = () => {
	return [
		fmt.fmtText(i18n.t('recharge.tip0')),
		fmt.fmtText(i18n.t('recharge.tip1')),
		fmt.fmtText(i18n.t('recharge.tip2')),
		fmt.fmtText(i18n.t('recharge.tip3')),
		fmt.fmtText(i18n.t('recharge.tip4')),
	]
};

// 提款提示
export const tipWithdraw = () => {
	return [
		fmt.fmtText(i18n.t('withdraw.tip0')),
		fmt.fmtText(i18n.t('withdraw.tip1')),
		fmt.fmtText(i18n.t('withdraw.tip2')),
	]
};

// transfer
export const transferDir = () => {
	return {
		capital: {
			key: 'capital',
			text: fmt.fmtText(i18n.t('transfer.capital')),
		},
		cantract: {
			key: 'cantract',
			text: fmt.fmtText(i18n.t('transfer.cantract')),
		}
	}
};

// 获取config
export const getConfig = async () => {
	const result = await http.post(`api/app/config`);
	if (!result) return false;
	console.log(`result:`, result);
	const temp = result.reduce((map, item) => {
		map.set(item.key, item.value);
		return map;
	}, new Map());
	return temp;
};

// 获取资产信息
export const getAssets = async (code, type = 2) => {
	const temp = (code == constants.KEY_ERC || code == constants.KEY_TRC) ? 'USDT' : code.toUpperCase();

	const result = await http.post(`api/user/assets`, {
		type: type,
		name: temp
	});
	if (!result) return false;
	console.log(`result`, result);
	return result[0].money * 1 || 0;
};

// 获取record 充值记录
export const getRecharge = async () => {
	uni.showLoading({
		title: i18n.t('api.requestData'),
	});
	const result = await http.post(`api/user/recharge`, {
		type: 2
	});
	if (!result) return false;
	console.log(`record:`, result);
	return result;
};

// 获取 Withdraw 提现记录
export const getWithdraw = async () => {
	uni.showLoading({
		title: i18n.t('api.requestData'),
	});
	const result = await http.post(`api/user/withdraw`);
	if (!result) return false;
	console.log(`record:`, result);
	return result;
};



// export const getRecord = async () => {
// 	uni.showLoading({
// 		title: i18n.t('api.requestData'),
// 	});
// 	const result = await this.$http.post(`api/user/finance`, {
// 		type: 2
// 	});
// 	if (!result) return false;
// 	this.list = result.filter(item => item.type == 2 && item.option == 1 && item.money * 1 > 0)
// };

// // 选中图片上传
// export const selectImg = async () => {
// 	const result = await uni.chooseImage({
// 		count: 1,
// 		sizeType: ['compressed'],
// 		sourceType: ['album'],
// 	});
// 	console.log('result:', result);
// 	const imageFile = result[1].tempFiles[0];
// 	console.log('imageFile:', imageFile);
// 	const reultURL = await http.uploadImage(imageFile.path);
// 	console.log(`resultURL:`, reultURL);
// 	if (!reultURL) return false;
// 	return reultURL;
// };