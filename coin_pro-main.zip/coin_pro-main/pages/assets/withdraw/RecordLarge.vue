<template>
	<view class="custom_table">
		<view class="table_header">
			<view class="table_row" :style="{color:$theme.TXT_UNACT}">
				<block v-for="(v,k) in Object.values(headers)" :key="k">
					<view class="table_cell" :style="{flex:`${v.flex}`,textAlign:v.align}"> {{v.text}} </view>
				</block>
			</view>
		</view>
		<view class="table_body" style="overflow-x: auto;">
			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<block v-for="(item,index) in list" :key="index">
				<view class="table_row" :style="{borderBottom:`1px solid ${$theme.TXT_UNACT}`}">
					<view class="table_cell" style="font-size: 11px;" :style="{
						color:setStatus(item.status).color,
					flex:`${headers.status.flex}`}">
						{{setStatus(item.status).text}}
					</view>
					<view class="table_cell" :style="{flex:`${headers.token.flex}`}">
						{{item.token}}
					</view>
					<view class="table_cell" :style="{flex:`${headers.amount.flex}`}">
						{{$fmt.fmtCrypto(`${item.amount}`)}}
					</view>
					<view class="table_cell" :style="{flex:`${headers.fee.flex}`}">
						{{$fmt.fmtCrypto(`${item.fee}`)}}
					</view>
					<view class="table_cell"
						style="font-size: 11px;overflow: hidden;white-space: normal;word-wrap: break-word;"
						:style="{color:$theme.TXT_UNACT,flex:`${headers.address.flex}`}">
						{{item.address}}
					</view>
					<view class="table_cell" style="font-size: 11px;"
						:style="{color:$theme.TXT_UNACT,flex:`${headers.sn.flex}`}">
						{{item.sn}}
					</view>
					<view class="table_cell"
						style="font-size: 11px;overflow: hidden;white-space: normal;word-wrap: break-word;" :style="{color:$theme.TXT_UNACT,
					flex:`${headers.ct.flex}`}">
						{{item.ct}}
					</view>
					<!-- <view class="table_cell" style="font-size: 11px;" :style="{color:$theme.TXT_UNACT,
					flex:`${headers.desc.flex}`,textAlign:headers.desc.align}">
						{{item.desc.toUpperCase()}}
					</view> -->
					<view class="table_cell" :style="{ flex:`${headers.action.flex}`,textAlign:headers.action.align}">
						<template v-if="item.status==0">
							<view class="btn_common" style="margin-left: 0;line-height:24px;"
								:style="{backgroundColor:$theme.convertRGBA($theme.PRIMARY,20)}"
								@click="handleCancel(item)">
								{{$fmt.fmtText($t('common.cancel'))}}
							</view>
						</template>
						<template v-if="item.status==2">
							<view class="btn_common" style="margin-left: 0;line-height:24px;"
								:style="{backgroundColor:$theme.convertRGBA($theme.FALL,20)}"
								@click="$util.linkCustomerService()">
								{{$fmt.fmtText($t('service.title'))}}
							</view>
						</template>
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import * as ext from '../ext.js';
	export default {
		name: 'RecordLarge',
		props: {
			list: {
				type: Array,
				default: []
			},
			// 根据code决定，某些列是否显示
			code: {
				type: String,
				default: ''
			}
		},
		data() {
			return {
				headers: ext.headersWithdraw(),
			}
		},
		methods: {
			setStatus(val = 0) {
				return ext.fmtStatus()[val]
			},
			async handleCancel(val) {
				const result = await uni.showModal({
					title: this.$lang.WITHDRAW_MODAL_TITLE,
					cancelText: this.$lang.COMMON_CANCEL,
					confirmText: this.$lang.COMMON_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: this.$theme.MODAL_CANCEL,
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) this.cancelWithdraw(val.id);
			},
			async cancelWithdraw(id) {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.submiting')),
				});
				const result = await this.$http.post(`api/app/qx`, {
					id
				});
				if (!result) return false;
				uni.showToast({
					title: this.$fmt.fmtText(this.$t('common.success')),
					icon: 'success'
				});
				this.$emit('action', 1);
			},
		}
	}
</script>

<style>
</style>