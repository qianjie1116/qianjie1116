<template>
	<view style="padding-top: 14px;">
		<block v-for="(v,k) in list" :key="k">
			<view style="background-color: #1f212d;border-radius: 4px;padding:10px;margin-bottom: 14px;">
				<view style="display: flex;align-items: center;padding-bottom: 8px;">
					<view style="margin-left: auto;" :style="{color:setStatus(v.status).color}">
						{{setStatus(v.status).text}}
					</view>

				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{headers.amount.text}}
					</view>
					<view>{{$fmt.fmtCrypto(`${$fmt.fmtNumber(v.amount)}`)}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{headers.fee.text}}
					</view>
					<view>{{$fmt.fmtCrypto(`${$fmt.fmtNumber(v.fee)}`)}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{headers.address.text}}
					</view>
					<view
						style="font-size: 12px; width: 60%;text-align: right; overflow: hidden;white-space: normal;word-wrap: break-word;"
						:style="{color:$theme.TXT_UNACT}">{{v.address}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{headers.sn.text}}
					</view>
					<view :style="{color:$theme.TXT_UNACT}">{{v.sn}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{headers.ct.text}}
					</view>
					<view :style="{color:$theme.TXT_UNACT}">{{v.ct}}</view>
				</view>
				<!-- <view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
					{{headers.desc.text}}
				</view>
				<view style="text-align: right;">{{v.desc}}</view> -->
			</view>
		</block>
	</view>
</template>

<script>
	import * as ext from '../ext.js';
	export default {
		name: 'RecordSmall',
		props: {
			list: {
				type: Array,
				default: []
			},
			// 根据code决定，某些列是否显示
			code: {
				type: String,
				default: ''
			}
		},
		data() {
			return {
				headers: ext.headersWithdraw,
			}
		},
		methods: {
			setStatus(val = 0) {
				return ext.fmtStatus[val]
			}
		}
	}
</script>

<style>
</style>