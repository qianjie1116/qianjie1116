<template>
	<view class="left_in">
		<view :class="$theme.setLayout($C.SMALL)?`second_small`:`second_medium`">

			<view style="font: 14px;font-weight: 700;">
				{{$fmt.fmtText($t('withdraw.amount'))}}
			</view>
			<view style="position: relative;">
				<view class="input_wrapper" :style="$theme.setInputStyle(dark)">
					<template v-if="curCoinType">
						<input v-model="amount" type="digit"
							:placeholder="$fmt.fmtText($t('common.min')+ $t('withdraw.amount'))+` `+curCoinType.wmin"
							:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
						<view style="margin-left: auto;" @click="showModal()">
							<view :style="{color:$theme.PRIMARY}">
								{{curCoinType.key.toUpperCase()}}
							</view>
						</view>
					</template>
				</view>
				<template v-if="showCoinList">
					<view style="position: absolute;z-index: 9;right: 0; background-color: #0a0c13;">
						<block v-for="(v,k) in Object.values(cryptoOpt)" :key="k">
							<view style="text-align: center;padding:10px 20px;" @click="chooseCoin(v)">
								{{v.key.toUpperCase()}}
							</view>
						</block>
					</view>
					<view class="overlay" @click.stop="closeModal()"> </view>
				</template>
			</view>

			<!-- 当前选择币种的地址 -->
			<view style="display: flex;align-items: center;margin-top: 24px;margin-bottom: 12px;">
				<view style="font: 14px;font-weight: 700;">
					{{!curCoinType?``: curCoinType.key.toUpperCase()+` `}} {{$fmt.fmtText($t('common.address'))}}
				</view>
				<view style="margin-left: auto; font-size: 12px;" :style="{color:$theme.PRIMARY}" @tap="handleCopy()">
					{{$fmt.fmtText($t('common.copy'))}}
				</view>
			</view>

			<view
				style="border-bottom: 1px solid #AAAAAA;word-break: break-word; font-size: 12px;line-height:1.4;padding-bottom: 6px;"
				:style="{color:$theme.TXT_WHITE}">
				{{!curCoinType?``: curCoinType.address}}
			</view>

			<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
				<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
					{{$fmt.fmtText($t('common.balance'))}}
				</view>
				<view>{{$fmt.fmtCrypto(`${$fmt.fmtNumber(balance)}`)}}
					<text style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{fmtUnit}}</text>
				</view>
			</view>

			<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
				<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
					{{$fmt.fmtText($t('withdraw.fee'))}}
				</view>
				<view>{{$fmt.fmtCrypto(`${$fmt.fmtNumber(fee,$decimal)}`)}}
					<text style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{fmtUnit}}</text>
				</view>
			</view>

			<template v-if="$config.withdrawPwd">
				<view style="font: 14px;font-weight: 700;margin-top: 24px;">
					{{$fmt.fmtText($t('withdraw.password'))}}
				</view>
				<view class="input_wrapper" :style="$theme.setInputStyle(dark)">
					<input v-model="password" :password="isMask"
						:placeholder="$fmt.fmtText($t('common.enter')+ $t('withdraw.amount'))"
						:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
					<view style="margin-left: auto;padding-right: 10px;">
						<CustomSvg :color="$theme.PRIMARY" :size="18" :path="isMask?$svg.mask:$svg.unmask"
							@click="toggleMask()" />
					</view>
				</view>
			</template>

			<view class="btn_common" @click="handleSubmit()" style="margin: 24px 0;line-height: 40px;">
				{{$fmt.fmtText($t('common.submit'))}}
			</view>

			<view style="font-size: 16px;font-weight: 700;line-height: 1.8;">
				{{$fmt.fmtText($t('assets.withdraw')+` `+$t('common.record'))}}
			</view>

			<view style="display: flex;align-items: center;line-height: 1.8;">
				<block v-for="(v,k) in tabs" :key="k">
					<view style="padding-right: 12px;" @click="changeTab(k)">
						<text :style="{color:curTab==k?$theme.PRIMARY:$theme.TXT_UNACT,
							borderBottom:`1px dashed ${curTab==k?$theme.PRIMARY:$theme.TXT_UNACT}`}">
							{{$fmt.fmtText(v)}}
						</text>
					</view>
				</block>
				<view style="margin-left: auto;">
					<CustomSvg :color="$theme.PRIMARY" :path="$svg.refesh" @click="handleRefesh()" />
				</view>
			</view>

			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<template v-if="$theme.setLayout($C.SMALL)">
					<RecordSmall :list="fmtList" @action="handleCancel" />
				</template>
				<template v-else>
					<RecordLarge :list="fmtList" @action="handleCancel" />
				</template>
			</template>
		</view>
	</view>
</template>

<script>
	import * as ext from '../ext.js';
	import RecordLarge from './RecordLarge.vue';
	import RecordSmall from './RecordSmall.vue';
	export default {
		name: 'Withdraw',
		components: {
			RecordLarge,
			RecordSmall,
		},
		props: {
			dark: {
				type: Boolean,
				default: true,
			}
		},
		data() {
			return {
				isMask: null, // 是否掩码
				amount: '', // 提现额
				password: '', // 提现密码
				showCoinList: false, // 是否顯示 coin選擇器
				cryptoOpt: null, // crypto 备选组
				curCoinType: null, // 当前选中币种
				list: null, // 列表数据
				balance: '', // 余额
				tabs: ext.tabsRecharge(), // 列表类型过滤
				curTab: 0, // 当前显示
			}
		},
		computed: {
			curKey() {
				return this.curCoinType && this.curCoinType.key ? this.curCoinType.key : this.$C.KEY_ERC;
			},
			// 计算手续费
			fee() {
				if (!this.amount || this.amount * 1 <= 0) return 0;
				return this.$fmt.fmtNumber(this.amount * this.curCoinType.fee);
			},
			// 单位
			fmtUnit() {
				if (!this.curCoinType || this.curCoinType.key == this.$C.KEY_ERC ||
					this.curCoinType.key == this.$C.KEY_TRC)
					return this.$t('common.unitUSDT');
				else return this.curCoinType.key.toUpperCase();
			},
			fmtList() {
				if (!this.list || this.list.length <= 0) return null;
				if (this.curTab == 0) return this.list;
				if (this.curTab > 0) {
					return this.list.filter(item => item.status == this.curTab - 1);
				}
			}
		},
		beforeMount() {
			this.isMask = uni.getStorageSync('masking'); // 当前掩码状态
			this.getUserInfo();
			this.getRecord();
		},
		methods: {
			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
			// 打开浮层
			showModal() {
				this.showCoinList = true;
			},
			// 关闭下拉浮层
			closeModal() {
				this.showCoinList = false;
			},
			// 選擇一種coin
			chooseCoin(val) {
				console.log(val);
				this.curCoinType = val;
				this.closeModal();
				this.getUserInfo();
				this.getRecord();
			},
			// 切换
			changeTab(val) {
				this.curTab = val;
				this.getRecord();
			},
			// 宽屏列表数据刷新
			handleRefesh() {
				this.changeTab(this.curTab);
			},
			// 子组件提现撤销
			handleCancel(val) {
				this.getRecord();
			},

			// 从用户信息中获取绑定的钱包地址或银行卡信息
			async getUserInfo() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.requestData')),
				});
				const result = await this.$http.post(`api/user/fastinfo`);
				if (!result) return false;
				// console.log(`result:`, result);
				if (result.bank_card_info && result.bank_card_info.length > 0) {
					const temp = result.bank_card_info.reduce((acc, item) => {
						const fmtKey = item.huobi.split('-')[0].toLowerCase();
						const key = fmtKey;
						if (!acc[key]) acc[key] = [];
						acc[key] = {
							address: item.address
						};
						return acc;
					}, {});
					console.log(`temp:`, temp);
					this.cryptoOpt = this.$util.mergeObjects(ext.cryptoOpt, temp);
					this.curCoinType = this.cryptoOpt[this.curKey];
					console.log(`curCoinType:`, this.curCoinType);
					this.getAssets();
				}
			},

			// 获取当前crypto的余额
			async getAssets() {
				const result = await ext.getAssets(this.curCoinType.key);
				console.log(result);
				this.balance = result;
			},

			// 获取提现记录
			async getRecord() {
				const result = await ext.getWithdraw();
				const temp = result.filter(item => item.money && item.money * 1 > 0)
				this.list = temp.map(item => {
					return {
						id: item.id,
						token: item.pay_channle || ``,
						amount: item.money,
						fee: item.withfee,
						address: item.bankno,
						sn: item.order_sn,
						ct: item.created_at,
						desc: item.reason,
						status: item.status,
					}
				});
			},

			// 提交
			async handleSubmit() {
				if (!this.amount || this.amount <= 0) {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('withdraw.amount')),
						icon: 'none'
					});
					return false;
				}
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.submiting')),
				});
				const temp = Object.keys(this.cryptoOpt).findIndex(item => item === this.curCoinType.key);
				const result = await this.$http.post(`api/app/withdraw`, {
					amount: this.amount,
					type: temp + 1,
					address: this.curCoinType.address,
					remakes: '',
				});
				if (!result) return false;
				console.log('result:', result);
				uni.showToast({
					// title: result,
					icon: 'success'
				});
				setTimeout(() => {
					this.changeTab(this.curTab);
				}, 1000);
			},
			// copy address
			async handleCopy() {
				const result = await uni.setClipboardData({
					data: this.curCoinType.address, //要被复制的内容
				});
				if (result[1].confirm) {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.copy') + this.$t('common.success')),
						duration: 2000,
						icon: 'success'
					})
				}
			},
		},
	}
</script>

<style lang="scss" scoped>
</style>