<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.SMALL)">
			<header class="header_small">
				<view style="width: 24px;">
					<CustomSvg :color="$theme.PRIMARY" :path="$svg.arrowLeft" @click="$util.goBack()" />
				</view>
				<scroll-view :scroll-x="true" style="white-space: nowrap;width: 100%;padding:0;" @touchmove.stop>
					<view style="display: flex;margin:0 4px;">
						<block v-for="(v,k) in tabs" :key='k'>
							<view style="font-size: 14px;padding-right: 6px;" :style="{
									color:curTab==k?$theme.PRIMARY : $theme.TXT_UNACT
								}" @click="changeTab(k)">
								{{$fmt.fmtText( v.value)}}
							</view>
						</block>
					</view>
				</scroll-view>
			</header>
		</template>

		<view :style="setStyleBody">
			<template v-if="$theme.setLayout($C.SMALL)">
				<template v-if="detail">
					<view style="display: flex;align-items: center;">
						<view style="margin-right: auto;padding-right: 8px;">
							<CustomSvg :color="$theme.PRIMARY" :size="24" :path="$svg.menu" @click="showCryptos()" />
						</view>
						<view style="flex:1;">
							<view style="font-size: 16px;font-weight: 700;">{{detail.name}}</view>
							<view style="font-size: 12px;padding-top: 2px;" :style="{color:$theme.TXT_UNACT}">
								24H:{{$fmt.fmtCrypto(`${detail.info.vol}`)}}
							</view>
						</view>
						<view style="margin-left: auto;padding-right: 8px;">
							<CustomSvg :color="$theme.PRIMARY" :size="24" :path="$svg.kline" @click="showKline()" />
						</view>
						<view style="margin-left: auto;">
							<CustomSvg :color="$theme.PRIMARY" :size="20" :path="$svg.rule"
								@click="$linkTo.rule(curKey)" />
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;padding:8px 0;"
						:style="$theme.setRiseFall(detail.info.rate)">
						<view style="font-size: 16px;">
							{{$fmt.fmtCrypto(`${detail.info.lastPrice}`,(detail.shudian||$decimal)) }}
						</view>
						<view style="font-size: 16px;">
							{{$fmt.fmtCrypto(`${detail.info.rate_num}`,(detail.shudian||$decimal)) }}
						</view>
						<view style="font-size: 16px;">
							{{`${detail.info.rate>0?'+':'-'} `+ ($fmt.fmtNumber(Math.abs(detail.info.rate),2))}}%
						</view>
					</view>

					<template v-if="detail.info">
						<DataSmall :data="detail.info" />
					</template>
				</template>
			</template>


			<template v-if="!$theme.setLayout($C.SMALL)">
				<view style="width: 100%;">
					<view style="display: flex;margin:0 4px;padding-bottom: 8px;">
						<block v-for="(v,k) in tabs" :key='k'>
							<view style="font-size: 16px;padding-left: 12px;" :style="{
							color:curTab==k?$theme.PRIMARY : $theme.TXT_UNACT
						}" @click="changeTab(k)">
								{{$fmt.fmtText( v.value)}}
							</view>
						</block>
					</view>
				</view>
			</template>

			<view style="display: flex;align-items: stretch;width: 100%;" :style="{height:$theme.setLayout($C.SMALL)?``:`640px`, minHeight:$theme.setLayout($C.SMALL)?``:`640px`,
					borderTop:`1px solid ${$theme.TXT_UNACT}`}">
				<template v-if="!$theme.setLayout($C.SMALL)">
					<!-- 宽屏：Left 列表及搜索 -->
					<view style="width:20%;">
						<!-- 过滤检索 -->
						<view class="input_wrapper" style="padding:0 12px;margin-right: 4px;"
							:style="$theme.setInputStyle(isDark)">
							<view :style="{color:$theme.TXT_UNACT}">
								{{$fmt.fmtText($t('common.filter'),$C.FMT_METHOD_TC)}}
							</view>
							<view style="padding:0 6px;" :style="{color:$theme.TXT_UNACT}">|</view>
							<input v-model="keyword" type="text"
								:placeholder="$t('common.enter')+ $t('common.keywords')"
								:placeholder-style="$theme.setPlaceholder()" confirm-type="search"></input>
						</view>
						<!-- 列表  -->
						<view style="width: 100%;max-height: 92%;overflow-y: auto;padding-top: 4px;">
							<template v-if="!filterList || filterList.length<=0">
								<EmptyData />
							</template>
							<template v-else>
								<block v-for="(item,index) in filterList" :key="index">
									<view class="item" style="padding-top:6px;">
										<view style="display: flex;align-items: center;" @click="selectedCrypto(item)">
											<view style="margin-right: auto;">
												<CustomLogo :logo="item.logo" :name="item.name" :size="24" />
											</view>
											<view style="flex:0 0 10%;">
												<view style="font-size: 11px;padding-left: 10px;">
													{{item.name}}
												</view>
											</view>
											<view style="flex:1 0 auto;">
												<view style="font-size: 14px;font-weight: 500;text-align: center;">
													{{$fmt.fmtCrypto(`${item.current_price}`)}}
												</view>
											</view>
											<view style="margin-left: auto;">
												<view style="min-width: 60px;text-align: center;"
													:style="$theme.setRiseFall(item.rate)">
													{{`${item.rate>0?'+':'-'} `+ $fmt.fmtNumber (Math.abs(item.rate))}}%
												</view>
											</view>
										</view>
									</view>
								</block>
							</template>
						</view>


					</view>
					<!-- 宽屏：Center Detail  Kline  -->
					<view style="flex:auto;"
						:style="{border:`1px solid ${$theme.TXT_UNACT}`,borderBottom:`none`,borderTop:`none`}">
						<view style="padding:12px;">
							<template v-if="detail">
								<DataLarge :data="largeData" @action="linkRule" />
							</template>

							<view style="padding: 4px 0;" :style="{borderBottom:`1px solid ${$theme.TXT_UNACT}`}">
							</view>
							<template v-if="klineData">
								<KlineLarge ref="klineLarge" :list="klineData" @action="changeKline" />
							</template>
						</view>
					</view>
				</template>

				<!-- 宽屏：Right 买卖操作，最新买卖，最新交易 -->
				<view
					:style="{width:$theme.setLayout($C.SMALL)?`100%`:`24%`,marginLeft:$theme.setLayout($C.SMALL)?``: `4px`}">
					<!-- 买 卖 唯有Crypto 币币交易 需要 买卖oder切换 -->
					<template v-if="curKey == $C.KEY_CRYPTO_SPT">
						<view style="display: flex; align-items: center;justify-content: space-around;">
							<view class="btn_common" style="border:none;margin-left: 0;"
								:style="{color:!isSell?$theme.RISE:$theme.TXT_UNACT}"
								@click="changeTabOrder($C.KEY_CRYPTO_BUY)">
								<text
									:style="{borderBottom:`1px ${!isSell?`solid`:`dashed`} ${!isSell?$theme.RISE:$theme.TXT_UNACT}` }">
									{{$fmt.fmtText(tabOrder[0].value)}}
								</text>
							</view>
							<view class="btn_common" style="border:none;margin-left: 0;"
								:style="{color:isSell?$theme.FALL:$theme.TXT_UNACT}"
								@click="changeTabOrder($C.KEY_CRYPTO_SELL)">
								<text
									:style="{borderBottom:`1px ${isSell?`solid`:`dashed`} ${isSell?$theme.FALL:$theme.TXT_UNACT}`}">
									{{$fmt.fmtText(tabOrder[1].value)}}
								</text>
							</view>
						</view>
					</template>

					<!-- 市价、限价、限价输入框 -->
					<view style="display: flex;align-items: center;padding-top: 8px;">
						<view style="width: 40px;padding-right: 6px;" @click="isLimt=false">
							<text
								:style="{color:!isLimt?$theme.PRIMARY:$theme.TXT_UNACT,borderBottom:`1px dashed ${!isLimt?$theme.PRIMARY:$theme.TXT_UNACT}`}">
								{{$fmt.fmtText($t('crypto.market'))}}</text>
						</view>
						<view style="width: 40px;padding-right: 6px;" @click="isLimt=true">
							<text
								:style="{color:isLimt?$theme.PRIMARY:$theme.TXT_UNACT,borderBottom:`1px dashed ${isLimt?$theme.PRIMARY:$theme.TXT_UNACT}`}">
								{{$fmt.fmtText($t('crypto.limit'))}}</text>
						</view>
						<view style="flex:auto;">
							<view class="input_wrapper" style="padding:0 12px;margin-top: 0;"
								:style="$theme.setInputStyle(isDark)">
								<input v-model="price" type="digit"
									:placeholder="$fmt.fmtText($t('common.enter')+ $t('common.price'))"
									:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"
									:disabled="!isLimt"></input>
								<view style="margin-left: auto;">
									<view :style="{color:$theme.TXT_UNACT}">{{$t('common.unitUSDT')}}</view>
								</view>
							</view>
						</view>
					</view>
					<!-- 杠杆 根据tab判定，部分tab不显示杠杆一项  -->
					<template v-if="showLever">
						<Leverage :list="levers" @action="chooseLever" />
					</template>
					<!-- crypto输入框、lot输入框 。输入框根据当前tab判断显示。合约类是lot,否则是crypto  -->
					<view style="display: flex;align-items: center;padding-top: 8px;">
						<view style="padding-right: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('common.amount'))}}
						</view>
						<view style="flex:auto;">
							<view class="input_wrapper" style="padding:0 12px;margin-top: 0;"
								:style="$theme.setInputStyle(isDark)">
								<input v-model="amount" type="digit"
									:placeholder="$fmt.fmtText($t('common.enter')+ $t('common.amount'))"
									:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
								<view style="margin-left: auto;">
									<view :style="{color:$theme.TXT_UNACT}">{{amountUnit}}</view>
								</view>
							</view>
						</view>
					</view>

					<Percent :list="percents" @action="choosePercent" />

					<Balance :balance="balance" usdt :unit="isSell?this.detail.number_code: $t('common.unitUSDT')" />

					<view style="display: flex;align-items: center;padding-top: 8px;">
						<view style="padding-right: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('common.max'))}}
						</view>
						<view style="margin-left: auto;">
							<text>{{maxQTY}}</text>
							<text style="font-size: 12px;padding-left: 4px;"
								:style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText(amountUnit)}}</text>
						</view>
					</view>
					<view style="display: flex;align-items: center;padding-top: 8px;">
						<view style="padding-right: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('common.margin'))}}
						</view>
						<view style="margin-left: auto;">
							<text>{{marginAmount}}</text>
							<text style="font-size: 12px;padding-left: 4px;"
								:style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('common.unitUSDT'))}}</text>
						</view>
					</view>
					<template v-if="!isSPT">
						<view style="text-align: right;font-size: 11px;" :style="{color:$theme.TXT_UNACT}">
							1{{$fmt.fmtText($t('common.lot'))}}={{lot+$fmt.fmtText($t('common.unitUSDT'))}}
						</view>
					</template>
					<view style="padding-bottom: 4px;margin-bottom: 8px;"
						:style="{borderBottom:`1px solid ${$theme.TXT_UNACT}`}"></view>

					<!-- 币币交易，买卖单独显示，占一行 -->
					<view
						style="display: flex; align-items: center;justify-content: space-between;padding-bottom: 12px;">
						<template v-if="isSPT">
							<view class="btn_common"
								style="margin:0 auto; flex:1;border:none;padding:4px;margin-left: 0;line-height: 24px;"
								:style="{backgroundColor: isSell?$theme.FALL:$theme.RISE}"
								@click="handleSubmit($C.KEY_CRYPTO_BUY)">
								{{ isSell? $fmt.fmtText(tabOrder[1].value):$fmt.fmtText(tabOrder[0].value)}}
							</view>
						</template>
						<template v-else>
							<view class="btn_common"
								style="margin:0 auto; width:40%;border:none;padding:4px;margin-left: 0;line-height: 24px;"
								:style="{backgroundColor:$theme.RISE}" @click="handleSubmit($C.KEY_CRYPTO_BUY)">
								{{$fmt.fmtText(tabOrder[0].value)}}
							</view>
							<view class="btn_common"
								style="margin:0 auto; width: 40%;border:none;padding:4px;margin-right: 0;line-height: 24px;"
								:style="{backgroundColor:$theme.FALL}" @click="handleSubmit($C.KEY_CRYPTO_SELL)">
								{{$fmt.fmtText(tabOrder[1].value)}}
							</view>
						</template>
					</view>

					<view style="padding-bottom: 10px;">
						<!-- 买卖实时数据 横竖屏通用 设置不同宽度 -->
						<template v-if="depthData">
							<Depth :data="depthData" :width="$theme.setLayout($C.SMALL)?100:100"
								:code="detail?detail.number_code:''" />
						</template>
						<view style="margin: 8px 0;" :style="{borderBottom:`1px solid ${$theme.TXT_UNACT}`}">
						</view>
						<!-- 最新交易，横竖通用 竖屏默认5条数据 -->
						<template v-if="latestData">
							<Latest :data="latestData" :width="$theme.setLayout($C.SMALL)?100:100"
								:code="detail?detail.number_code:''" />
						</template>
					</view>
				</view>
			</view>

			<view :style="{borderBottom:`1px solid ${$theme.TXT_UNACT}`}"></view>
			<view style="display: flex;align-items: center;padding: 8px 0 4px 0;">
				<block v-for="(v,k) in footerTabs" :key="k">
					<view style="padding-right: 12px;font-size: 16px;" @click="changFooterTab(k)">
						<text :style="{color:curList==k?$theme.PRIMARY:$theme.TXT_UNACT,
								borderBottom:`1px dashed ${curList==k?$theme.PRIMARY:$theme.TXT_UNACT}`}">{{v.value}}
						</text>
					</view>
				</block>

				<view style="margin-left: auto;">
					<view style="display: flex;align-items: center;">
						<CustomSvg :color="$theme.PRIMARY" :path="isMask?$svg.mask:$svg.unmask" @click="toggleMask()" />
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.refesh" @click="handleRefesh()" />
					</view>
				</view>
			</view>

			<template v-if="curFooterKey==$C.KEY_CRYPTO_POSITION">
				<Position :dark="isDark" :list="positionData" @action="setPL" @close="handleClose" :balance="balance" />
			</template>

			<template v-if="curFooterKey==$C.KEY_CRYPTO_ORDER">
				<OrdersList :list="orderData" @action="updateList" />
			</template>

			<template v-if="curFooterKey==$C.KEY_CRYPTO_HISTORY">
				<History :list="historyData" :isspt="isSPT" />
			</template>
		</view>

		<!-- 竖屏侧入币列表 -->
		<template v-if="modalCryptos">
			<CryptoList :list="filterList" @action="chooseCrypto" />
		</template>

		<!-- 竖屏Kline -->
		<template v-if="modalKline">
			<view class="overlay" style="background-color: rgba(0, 0, 0, 0.5);" @click="modalKline=false"></view>
			<view class="modal_wrapper_bottom bottom_in" :style="{backgroundColor:$theme.BASIC_BG}">
				<view style="min-height: 75vh;padding:12px 12px 24px 12px;">
					<view style="display: flex;align-items: center;padding-bottom: 12px;">
						<view style="width: 24px;"></view>
						<view style="flex:1;text-align:center;">
							<text style="padding-bottom: 4px;" :style="{borderBottom:`1px solid ${$theme.PRIMARY}`}">
								{{setKlineModalTitle}}
							</text>
						</view>
						<view style="margin-left: auto;" @click="modalKline=false">
							<CustomSvg :color="$theme.PRIMARY" :path="$svg.close" />
						</view>
					</view>

					<KlineSmall ref="klineSmall" :list="klineData" @action="changeKline" />
				</view>
			</view>
		</template>

	</view>
</template>

<script>
	import * as ext from './ext.js';
	import * as history from './history.js';
	import * as position from './position.js';
	import * as orders from './orders.js';
	import Depth from './components/Depth.vue';
	import Latest from './components/Latest.vue';
	import DataSmall from './components/DataSmall.vue';
	import DataLarge from './components/DataLarge.vue';
	import History from './components/History.vue';
	import Position from './components/Position.vue';
	import OrdersList from './components/OrdersList.vue';
	import CryptoList from './components/CryptoList.vue';
	// import CryptoKline from './components/CryptoKline.vue';
	import KlineLarge from '@/components/KlineChart/KlineLarge.vue';
	import KlineSmall from '@/components/KlineChart/KlineSmall.vue';
	export default {
		components: {
			Depth,
			Latest,
			DataSmall,
			DataLarge,
			History,
			Position,
			OrdersList,
			CryptoList,
			// CryptoKline,
			KlineLarge,
			KlineSmall,
		},
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
				curTab: 0, // 宽屏下，多合一，当前tab
				tabs: ext.tabs(), // 竖屏header中的tabs
				symbol: '', // url带入值
				detail: null, // crypto的详情
				depthData: null, // depth数据
				latestData: null, // 最新交易数据
				isLimt: false, // 是否限价模式
				levers: [10, 100, 150, 300, 500], // 杠杆数组
				curLever: 1, // 当前杠杆
				price: '', // 限价模式输入值，市价模式crypto详情Price值
				amount: '', // 买卖量。crypto.name或lots
				percents: [25, 50, 75, 100], // 百分比预置值组
				curPercent: -1, // 当前百分比
				tabOrder: ext.tabOrder(), // 买卖切换以及买卖按钮文字
				curOrderKey: null, // 当前买 or 卖
				keyword: '', // 检索关键字
				list: null, // 左侧列表数据
				setStyleBody: ext.setStyleBody(),
				isMask: false, // 是否仅显示当前crypto数据
				historyData: null, // 历史记录
				positionData: null, // 持仓列表
				orderData: null, // 当前委托
				curList: 0, // 当前显示列表
				lot: 1000, // 默认1lots=1000
				isSell: false, // isSPT模式下，当前是buy or sell
				balance: null, // 余额 兼容币币和合约
				info: null, // 底部行上数据选中。如止盈止损或平仓
				// 底部持仓数据平仓弹层
				showModalClose: false,
				modalCryptos: false, // 侧入crypto列表
				modalKline: false, // Kline 弹层 上入
				curTime: 0, // kline selected time
				klineData: null, // kline 数据
				latestKline: null, // 跟随ws实时赋值的最新数据，用于更新子组件的kline
				wsClient: null, // websocket
				isConnected: false, // ws是否连接
				isBtnLock: false, // 按钮是否锁定
			}
		},
		computed: {
			// 顶部tab 选中key
			curKey() {
				console.log(`curKey:`, this.tabs[this.curTab]);
				return this.tabs[this.curTab].key;
			},
			// 底部tab 选中key
			curFooterKey() {
				console.log(`curList:`, this.curList);
				console.log(`curList:`, this.footerTabs[this.curList].key);
				return this.footerTabs[this.curList].key;
			},
			// 底部tabs
			footerTabs() {
				return ext.footerTabs(this.isSPT);
			},
			// 当前是否 SPT 币币交易
			isSPT() {
				return this.curKey == this.$C.KEY_CRYPTO_SPT;
			},

			// 横屏基本信息组件
			largeData() {
				return !this.detail ? null : {
					name: this.detail.name,
					...this.detail.info,
				}
			},

			// 是否显示杠杆选择
			showLever() {
				return !this.isSPT;
			},

			// amount 输入框后缀单位
			amountUnit() {
				return this.curKey == this.$C.KEY_CRYPTO_SPT ?
					this.detail ? this.detail.number_code : '' : this.$t('common.lots')
			},
			// 最大购买
			maxQTY() {
				// 市價模式： 餘額/單價。 限價模式：餘額/輸入值
				if (!this.detail || !this.balance) return '';
				// 市價或限價模式下的單價
				const temp = this.isLimt ? this.price : this.detail.current_price;
				if (!temp || temp * 1 <= 0) return '';
				return this.$fmt.fmtNumber(this.balance / (this.lot / this.curLever), this.$decimal);
			},

			// 保证金
			marginAmount() {
				if (!this.detail) return 0;
				// console.log(this.detail.current_price);
				const temp = this.isLimt ? this.price : this.detail.current_price;
				// 價格*數量/杠桿
				// const temmTotal = temp * 1 * this.amount * 1 / this.curLever;
				const temmTotal = this.amount * 1 * (this.lot / this.curLever);
				if (!temmTotal || temmTotal * 1 <= 0) return '';
				return this.$fmt.fmtNumber(temmTotal, 4);
			},

			// 左侧列表数据
			setList() {
				return !this.list ? [] : Object.values(this.list);
			},
			// 根据关键字，过滤数据
			filterList() {
				if (this.setList && this.setList.length > 0) {
					// 输入三个字符以上才检索
					if (this.keyword.length >= 3) {
						return this.setList.filter(item => item.code.includes(this.keyword) ||
							item.name.includes(this.keyword));
					} else {
						return this.setList;
					}
				} else {
					return []
				}
			},
			// 竖屏模式下，设置kline浮层的title
			setKlineModalTitle() {
				return this.detail.number_code + ` ` + this.$fmt.fmtText(this.$t('common.kline'))
			},
		},
		onLoad(opt) {
			const temp = this.tabs.findIndex(item => item.key === opt.tag);
			this.curTab = temp > 0 ? temp : this.curTab;
			// 默認 btcusdt
			this.symbol = opt.symbol || 'btcusdt';
		},
		onShow() {
			if (!this.$linkTo.checkToken()) return false;
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
			this.changeTab(this.curTab);
			// crypto当前模式
			this.curOrderKey = this.tabOrder[0].key;
			// 获取列表数据
			this.getList();
			// 获取用户资产
			this.getUserAssets();
			if (this.wsClient) this.disconnect();
			// 如果没有启动ws ，则启动ws 。全程断线重连，负责spt及ct所有逻辑
			if (!this.wsClient) this.initWebSocket();
		},
		onHide() {
			console.log(`onHide:`, this.isDark);
			this.isAnimat = false;
			if (this.wsClient) this.disconnect();
		},
		// onPullDownRefresh() {
		// 	this.changeTab(this.curTab);
		// 	uni.stopPullDownRefresh();
		// },
		deactivated() {
			if (this.wsClient) this.disconnect();
		},
		onUnload() {
			if (this.wsClient) this.disconnect();
		},

		methods: {
			changeTab(val) {
				this.curTab = val;
				this.getDetail();
				this.getDepthData();
				this.getLatestData();
				this.changFooterTab(this.curList);

			},
			// Crypto 买卖切换
			changeTabOrder(val) {
				this.curOrderKey = val;
				this.isSell = this.curOrderKey != this.$C.KEY_CRYPTO_BUY;
				this.getUserAssets();
			},

			// 杠杆选择
			chooseLever(v) {
				this.curLever = v;
				console.log(`curLever`, this.curLever);
				// 有值需要重新计算。
				// this.calculateQTY();
			},
			// 百分比选择
			choosePercent(v) {
				this.curPercent = v;
				console.log(`curPercent`, this.curPercent);
				// 有值需要重新计算。
				this.calculateQTY();
			},
			// 当前crypto的detatil中设置的小数点位数
			curDecimal() {
				console.log(this.detail);
				return this.detail && this.detail.goods_info && this.detail.goods_info.shudian ? this.detail.goods_info
					.shudian : this.$decimal;
			},

			// quantity 值计算
			calculateQTY() {
				if (this.detail) {
					// 市價或限價模式下的單價
					const temp = this.isLimt ? this.price : this.detail.current_price;
					this.amount = this.$fmt.fmtNumber(this.balance / (this.lot / this.curLever) *
						(this.curPercent * 0.01), this.curDecimal);
				} else {
					this.amount = '';
				}
			},

			// 跳转到规则页面
			linkRule(val) {
				this.$linkTo.rule(this.curKey);
			},

			// 是否仅显示当前crypto数据
			toggleMask() {
				this.isMask = !this.isMask;
			},
			// 底部列表切换
			changFooterTab(val) {
				this.curList = val;
				// 使用key判定请求那个。兼容不同顶级tab需要不同底部tabs
				if (this.curFooterKey == this.$C.KEY_CRYPTO_POSITION) this.gePositionList();
				if (this.curFooterKey == this.$C.KEY_CRYPTO_ORDER) this.getOrders();
				if (this.curFooterKey == this.$C.KEY_CRYPTO_HISTORY) this.getHistoryData();
			},

			// 当前委托 cancel事件逐层上递
			updateList(val) {
				this.changFooterTab(this.curList);
			},

			// 底部列表刷新 仅刷当前列表
			handleRefesh() {
				this.changFooterTab(this.curList);
			},

			// 止盈止损
			setPL(val) {
				this.changFooterTab(this.curList);
			},
			// 平仓
			handleClose(val) {
				this.changFooterTab(this.curList);
			},

			// 显示kline 仅限小屏
			showKline() {
				// 浮层上显示kline及相关操作。时间，技术指标，覆盖物。
				this.modalKline = true;
			},
			// 关闭klien浮层 仅限小屏
			closeKline(val) {
				this.modalKline = false;
			},
			// kline time 选中
			changeKline(val) {
				this.curTime = val;
				console.log(`val:`, this.curTime);
				this.getDetail();
			},

			// 竖屏侧入列表
			showCryptos() {
				this.modalCryptos = true;
				this.getList();
			},
			// 选择一项
			chooseCrypto(val) {
				this.modalCryptos = false;
				if (val != 1) this.selectedCrypto(val);
			},

			// 宽屏左侧crypto列表
			async getList() {
				uni.showLoading({
					title: this.$t('api.requestData'),
				});
				const temp = this.curKey;
				console.log('gpIndex:', this.$C.GPINDEX[temp]);
				const result = await this.$http.post(`api/goods/list`, {
					page: 1,
					gp_index: this.$C.GPINDEX[temp]
				});
				console.log(`coin result:`, result);
				if (!result) return false;
				this.list = result;
			},

			// 左侧选择一个crypto
			selectedCrypto(val) {
				this.symbol = val.locate;
				this.changeTab(this.curTab);
			},

			// 获取 crypto详情
			async getDetail() {
				const result = await this.$http.post(`api/product/info`, {
					code: this.symbol,
					time_index: this.curTime
				});
				if (!result) return false;
				this.detail = result[0];
				if (!this.isLimt) this.price = this.detail.info.lastPrice;
				console.log(this.price);
				this.getUserAssets();
				setTimeout(() => {
					this.getKlineData();
				}, 1000);
			},

			// 获取当前crypto kline历史数据
			async getKlineData() {
				const result = await this.$http.get(`api/product/lishi`, {
					ac_time: this.curTime,
					project_type_id: this.detail.project_type_id,
					// 此处用code ，用locate报错
					code: this.detail.code
				})
				console.log('k data:', result);
				if (!result) return false;
				result.forEach(item => {
					item.volume = item.vol || 0;
				})
				this.klineData = result;
			},

			// 买入卖出第三方请求
			async getDepthData() {
				const result = await ext.getDepthData(this.symbol);
				if (!result) return false;
				this.depthData = result;
			},
			// 最新交易第三方请求
			async getLatestData() {
				const tempSize = this.$theme.setLayout(this.$C.SMALL) ? 5 : 10;
				const result = await ext.getLatestData(this.symbol, tempSize);
				if (!result) return false;
				this.latestData = result;
			},

			// 历史记录
			async getHistoryData() {
				const temp = this.isMask ? this.symbol : '';
				const result = this.curKey == this.$C.KEY_CRYPTO_SPT ?
					await history.getHistorySPT(temp) :
					await history.getHistoryCT(temp);
				this.historyData = result;
			},
			// 持仓
			async gePositionList() {
				const temp = this.isMask ? this.symbol : '';
				const result = await position.gePositionList(temp);
				this.positionData = result;
			},
			// 当前委托
			async getOrders() {
				const temp = this.isMask ? this.symbol : '';
				const result = await orders.getOrders(temp);
				this.orderData = result;
			},

			// 获取用户资产
			async getUserAssets() {
				let fromData = {};
				// 欧美心心 合约交易 type: 1,name: 'USDT'
				// 欧美心心 币币交易 buy type:2,name: 'USDT'
				// 欧美心心 币币交易 sell type:2,name: 当前币种
				fromData.type = this.isSPT ? 2 : 1;
				if (this.isSPT) {
					fromData.name = this.isSell ? this.detail.number_code : 'USDT';
				} else {
					fromData.name = 'USDT';
				}
				const result = await ext.getUserAssets(fromData);
				console.log(`balance:`, result);
				this.balance = result * 1;
			},
			checkFrom() {
				if (this.amount == '' || this.amount <= 0) {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('common.amount')),
						icon: 'none'
					});
					return false;
				}
				if (!this.$util.checkInputNumber(this.amount)) return false;

				if (this.isLimt) {
					if (this.price == '' || this.price <= 0) {
						uni.showToast({
							title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('common.price')),
							icon: 'none'
						});
						return false;
					}
				}
				return true;
			},
			// 买卖
			async handleSubmit(val) {
				console.log(`handleSubmit val:`, val);
				if (!this.checkFrom()) return false;
				// 如果按钮锁定，则不执行提交事件
				if (this.isBtnLock) return false;
				this.isBtnLock = true; // 锁住按钮
				const result = await uni.showModal({
					title: '',
					content: `${this.detail.name} Quantity ${this.amount}`,
					cancelText: this.$fmt.fmtText(this.$t('common.cancel')),
					confirmText: this.$fmt.fmtText(this.$t('common.confirm')),
					showCancel: true, // 是否显示取消按钮，默认为 true
					confirmColor: this.$theme.SECOND,
					cancelColor: this.$theme.MODAL_CANCEL,
				});
				if (result[1].confirm) {
					if (this.curKey == this.$C.KEY_CRYPTO_SPT)
						this.handleTradeSPT();
					if (this.curKey == this.$C.KEY_CRYPTO_CT)
						this.handleTradeCT(val);
				}
			},

			// 合约交易 买卖
			async handleTradeCT(val) {
				let formData = {
					num: this.amount,
					gid: this.detail.gid,
					fx: this.isLimt ? 2 : 1, // 1市价 2限价
					// direct   1买多    2卖少
					direct: val == this.$C.KEY_CRYPTO_BUY ? 1 : 2,
					ganggan: this.curLever, // 杠桿
				}
				if (this.isLimt) formData.price = this.amount;
				const result = await ext.handleTradeCT(formData);
				this.isBtnLock = false; // 提交成功，解锁按钮
				// 刷新当前激活的列表
				setTimeout(() => {
					this.changFooterTab(this.curList);
					this.getUserAssets();
				}, 1000);
			},
			// 币币交易 买卖
			async handleTradeSPT() {
				let formData = {
					num: Number(this.amount),
					fx: this.isLimt ? 2 : 1, // 1市价 2限价
				}
				if (this.isSell) formData.code = this.detail.locate;
				if (!this.isSell) formData.gid = this.detail.gid;
				if (this.isLimt) formData.price = Number(this.price);
				const result = await ext.handleTradeSPT(formData, this.isSell);
				this.isBtnLock = false; // 提交成功，解锁按钮
				// 刷新当前激活的列表
				setTimeout(() => {
					this.changFooterTab(this.curList);
					this.getUserAssets();
				}, 1000);
			},

			// 初始化webSocket
			initWebSocket() {
				if (this.wsClient) this.disconnect();
				this.wsClient = uni.connectSocket({
					url: this.$http.WS_COIN_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.info(`success res:`, res);
					},
					fail: (res) => {
						console.info(`fail res:`, res);
					}
				});

				console.log(`socket:`, this.wsClient);
				this.wsClient.onOpen((res) => {
					console.info("socket onOpen:", res);
					this.isConnected = true; // 已连接
					// if (this.messageHanlder) {
					// 	this.socket.onMessage(this.messageHanlder);
					// }
				});
				this.wsClient.onClose((res) => {
					// code:1000(手动关闭) 1006(异常关闭) 
					console.log(`onClose:`, res);
					this.isConnected = false;
					if (res.code !== 1000) {
						this.reconnectWebSocket();
					}
				});
				this.wsClient.onError((err) => {
					console.log(`onError:`, err);
					this.isConnected = false;
					this.reconnectWebSocket();
				});
				this.wsClient.onMessage((res) => {
					const data = JSON.parse(res.data);
					// 宽屏左侧列表 注意判断null
					if (this.list && data.type == "ticker") {
						if (this.list[data.market] && data.market && data.lastPrice > 0) {
							this.list[data.market].current_price = data.lastPrice;
							this.list[data.market].rate = data.rate || 0;
							this.list[data.market].vol = data.vol || 0;
						}
					}

					// 当前选中crypto 基础数据
					if (this.detail && this.detail.code) {
						// 基础数据
						if (data.type == "ticker" && this.detail.code == data.market && data.lastPrice > 0) {
							// console.log('data:', this.detail.code, data);
							this.detail.info.lastPrice = data.lastPrice * 1;
							this.detail.info.rate = data.rate * 1;
							this.detail.info.rate_num = data.rate_num * 1;
							// 市价模式下 价格实时更新
							if (!this.isLimt) this.price = this.detail.info.lastPrice;
							// 更新子组件的最新kline数据
							if ((this.$refs.klineLarge && this.$refs.klineLarge.chart) ||
								(this.$refs.klineSmall && this.$refs.klineSmall.chart)) {
								let temp;
								if (this.$theme.setLayout(this.$C.SMALL))
									temp = this.$refs.klineSmall.chart.getDataList();
								else
									temp = this.$refs.klineLarge.chart.getDataList();
								// 数据中的最后一个元素
								const last = temp[temp.length - 1];
								// 新建数据
								const newData = {
									...last
								};
								newData.close = data.lastPrice * 1;
								newData.rate = data.rate * 1;
								newData.rate_num = data.rate_num * 1;
								if (this.$theme.setLayout(this.$C.SMALL))
									this.$refs.klineSmall.chart.updateData(newData);
								else
									this.$refs.klineLarge.chart.updateData(newData);

							}
						}

						// 	当前k线更新	
						if (
							data.type == "kline" && this.detail.code == data.market) {
							this.detail.info.high = data.high * 1;
							this.detail.info.close = data.close * 1;
							this.detail.info.open = data.open * 1;
							// this.detail.info.high = data.high;
							this.detail.info.low = data.low * 1;
							this.detail.info.amount = data.amount * 1;
							this.detail.info.vol = data.vol;
							// 更新子组件的最新kline数据
							if ((this.$refs.klineLarge && this.$refs.klineLarge.chart) ||
								(this.$refs.klineSmall && this.$refs.klineSmall.chart)) {
								let temp;
								if (this.$theme.setLayout(this.$C.SMALL))
									temp = this.$refs.klineSmall.chart.getDataList();
								else
									temp = this.$refs.klineLarge.chart.getDataList();
								// 数据中的最后一个元素
								const last = temp[temp.length - 1];
								// 新建数据
								const newData = {
									...last
								};
								newData.close = data.close * 1;
								newData.high = data.high * 1;
								newData.low = data.low * 1;
								newData.volume = data.vol * 1;
								newData.open = data.open * 1;
								newData.rate = data.rate * 1;
								newData.rate_num = data.rate_num * 1;
								// 当前ws时间戳 - 最后一个元素时间戳，>指定秒数，追加一根蜡烛
								if (data.time - newData.timestamp > 60000)
									newData.timestamp = data.time;
								if (this.$theme.setLayout(this.$C.SMALL))
									this.$refs.klineSmall.chart.updateData(newData);
								else
									this.$refs.klineLarge.chart.updateData(newData);
							}
						}


						// 当前选中crypto 买卖盘实时数据
						if (this.depthData && this.detail.code == data.market && data.type == "depth") {
							// console.log('data depth:', data);
							// 直接提取前五條，替換數據
							const tempAsk = data.ask.slice(0, 5);
							const tempBid = data.bid.slice(0, 5);
							this.depthData.asks = tempAsk.map(item => [item.price, item.quantity]);
							this.depthData.bids = tempBid.map(item => [item.price, item.quantity]);
							// 當前數組中，數量最大值， *1.01(餘量，避免求出100%)
							this.depthData.asksMax = Math.max(...this.depthData.asks.map(item => item[1])) * 1.01;
							// 當前數組中，數量最大值， *1.01(餘量，避免求出100%)
							this.depthData.bidsMax = Math.max(...this.depthData.bids.map(item => item[1])) * 1.01;
						}

						// 当前选中crypto 实时最新交易记录
						if (this.latestData && this.detail.code == data.market &&
							data.type == "tradelog" && data.num * 1 > 0) {
							// console.log('data trade:', data);
							this.latestData.unshift({
								amount: data.num,
								price: data.price,
								ts: data.id,
								dir: data.trade_type, // 1買 2 賣
							});
							this.latestData.pop();
						}
					}
					// 底部持仓计算 注意判断null
					// 匹配hold列表的每条数据。计算对应数据的floatPL值
					if (this.positionData && this.positionData.length > 0) {
						this.positionData.forEach(item => {
							if (item.code == data.market && data.lastPrice > 0) {
								item.latestPrice = data.lastPrice;
								if (item.direct == 1) {
									// 买多的计算公式: (当前价-买入价-手续费)*数量
									// 手数✖️1000✖️平仓价*（平仓价-成交价）/成交价 =盈亏
									item.floatPLBuy = this.$fmt.fmtNumber(item.quantity * 1000 * (data
											.lastPrice * 1 - item.price * 1) / data.lastPrice * 1,
										this.$decimal);

									item.buyPL = this.$fmt.fmtNumber(item.quantity * 1000 * (
											data.lastPrice * 1 - item.price * 1) / data.lastPrice * 1 -
										item.fee, this.$decimal);
								}
								if (item.direct == 2) {
									// 卖少的计算公式: (买入价-当前价-手续费)*数量
									item.floatPLSell = this.$fmt.fmtNumber(item.quantity * 1000 * (
											item.price * 1 - data.lastPrice * 1) / data.lastPrice * 1,
										this.$decimal);
									item.sellPL = this.$fmt.fmtNumber(item.quantity * 1000 * (
											item.price * 1 - data.lastPrice * 1) / data.lastPrice * 1 -
										item.fee, this.$decimal);
								}
							}
						});
					}

				});
			},
			// websocket 断线重连
			reconnectWebSocket() {
				// 连接中，并且非手动关闭
				if (this.isConnected) return;
				console.log(`reconnect!`, this.isConnected);
				this.wsClient = null;
				console.log(`reconnect! socket:`, this.wsClient);
				this.initWebSocket();
			},

			// 关闭 websocket链接
			disconnect() {
				if (this.wsClient) {
					this.wsClient.close();
					this.wsClient = null;
					this.isConnected = false;
				}
			},
		},
	}
</script>

<style lang="scss" scoped>
	.header_small {
		padding: 24px 20px 10px 20px;
		display: flex;
		align-items: center;
		border-bottom: 1px solid #34393e;
	}

	/deep/uni-slider {
		margin: 2px 3px;
		margin-right: 0;

		.uni-slider-value {
			width: max-content !important;
		}
	}
</style>