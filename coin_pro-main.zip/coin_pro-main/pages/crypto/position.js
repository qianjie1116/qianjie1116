// position 
import Vue from 'vue';
import * as constants from '@/common/constants.js';
import http from '@/common/http.js';
import * as fmt from '@/common/format.js';
import * as theme from '@/theme/index.js';
import {
	translate
} from '@/common/util.js';

// 合约交易，宽屏表头  持仓记录
export const headerCT = {
	direction: {
		flex: `150px`,
		text: fmt.fmtText(translate('common.direction'))
	},
	name: {
		flex: `96px`,
		text: fmt.fmtText(translate('crypto.name'))
	},
	price: {
		flex: `8%`,
		text: fmt.fmtText(translate('common.price'))
	},
	qty: {
		flex: `7%`,
		text: fmt.fmtText(translate('common.qty'))
	},
	total: {
		flex: `8%`,
		text: fmt.fmtText(translate('crypto.total'))
	},
	latest: {
		flex: `8%`,
		text: fmt.fmtText(translate('crypto.latestPrice'))
	},
	fee: {
		flex: `6%`,
		text: fmt.fmtText(translate('crypto.fee'))
	},
	profit: {
		flex: `8%`,
		text: fmt.fmtText(translate('crypto.profit'))
	},
	takeProfit: {
		flex: `80px`,
		text: fmt.fmtText(translate('crypto.takeProfit')),
		borderBottom: `1px dashed ${theme.PRIMARY}`,
	},
	stopLoss: {
		flex: `80px`,
		text: fmt.fmtText(translate('crypto.stopLoss')),
		borderBottom: `1px dashed ${theme.PRIMARY}`,
	},
	floatPL: {
		flex: `8%`,
		text: fmt.fmtText(translate('crypto.floatPL'))
	},
	dt: {
		flex: `70px`,
		text: fmt.fmtText(translate('common.dt'))
	},
	action: {
		flex: `5%`,
		text: fmt.fmtText(translate('common.action')),
		textAlign: 'right'
	}
};


// 合约交易 获取持仓记录
export const gePositionList = async (symbol = '') => {
	let formData = {};
	formData.status = 1;
	if (symbol != '') {
		formData.code = symbol = '';
	}
	uni.showLoading({
		title: translate('api.requestData'),
	});

	const result = await http.post(`api/user/order`, formData);
	if (!result) return false;
	console.log(`hold result:`, result);
	const temp = !Array.isArray(result) || result.length < 0 ? [] :
		result.filter(item => item.goods_info && item.goods_info.gid > 0 && item.order_buy && item
			.order_buy.gid > 0);
	console.log(`hold result temp:`, temp);
	return temp.length <= 0 ? [] : temp.map(item => {
		// 用每条数据自己的小数点位数值，否则使用全局设置值
		const decimal = item.goods_info.shudian || Vue.prototype.$decimal;
		// fx   1市价 2限价
		const fx = item.order_buy.fx;
		// direct   1:买涨 买入 买多；2：买跌 卖出 卖少
		const direct = item.order_buy.direct;
		return {
			id: item.id,
			code: item.goods_info.code,
			name: item.goods_info.name,
			// fx   1市价 2限价
			fx: fx,
			fxText: fx == 1 ? fmt.fmtText(translate('crypto.market')) : fmt.fmtText(translate(
				'crypto.limit')),
			direct: direct,
			// direct   1:买涨 买入 买多；2：买跌 卖出 卖少
			directText: direct == 1 ? fmt.fmtText(translate('crypto.buy')) : fmt.fmtText(translate(
				'crypto.sell')),
			price: fmt.fmtNumber(item.order_buy.price, decimal),
			quantity: item.order_buy.num,
			amount: item.order_buy.amount,
			total: item.order_buy.user_pay,
			sn: item.order_sn,
			dt: item.order_buy.created_at,
			lever: item.order_buy.double,
			takeProfit: item.order_buy.zhiying || '--',
			stopLoss: item.order_buy.zhisun || '--',
			latestPrice: item.goods_info.current_price, // 最新价
			/*
			万分之5 因为1lot=1000USDT，手续费是万5% 就是0.0005或者0.05%，
			10手的手续费 10 lot*1000=10万，手续费就是5USDT了
			*/
			fee: item.order_buy.buy_fee,
			// 1买多 浮动盈亏 1lot=1000USDT
			floatPLBuy: fmt.fmtNumber(item.order_buy.num * 1000 * (item.goods_info
					.current_price * 1 - item.order_buy.price * 1) / item.goods_info.current_price *
				1, decimal),
			// 2 卖少 浮动盈亏 1lot=1000USDT
			floatPLSell: fmt.fmtNumber(item.order_buy.num * 1000 * (item.order_buy.price * 1 -
				item.goods_info.current_price * 1) / item.goods_info.current_price * 1, decimal),
			// 1买多 盈亏 1lot=1000USDT
			buyPL: fmt.fmtNumber(item.order_buy.num * 1000 * (
					item.goods_info.current_price * 1 - item.order_buy.price * 1) / item.goods_info
				.current_price * 1 - item.order_buy.buy_fee, decimal),
			// 2 卖少 盈亏 1lot=1000USDT
			sellPL: fmt.fmtNumber(item.order_buy.num * 1000 * (item.order_buy.price *
					1 - item.goods_info.current_price * 1) / item.goods_info.current_price * 1 -
				item.order_buy.buy_fee, decimal),
		}
	})
};


