// Crypto通用
import Vue from 'vue';
import i18n from '@/locales/index.js';
import * as constants from '@/common/constants.js';
import http from '@/common/http.js';
import * as fmt from '@/common/format.js';
import * as theme from '@/theme/index.js';

// tabs
export const tabs = () => {
	return [{
		key: constants.KEY_CRYPTO_SPT,
		value: fmt.fmtText(i18n.t('crypto.spt')),
	}, {
		key: constants.KEY_CRYPTO_CT,
		value: fmt.fmtText(i18n.t('crypto.ct')),
	}, 
	// {
	// 	key: constants.KEY_CRYPTO_PERP,
	// 	value: fmt.fmtText(i18n.t('crypto.perp')),
	// }, {
	// 	key: constants.KEY_CRYPTO_OPT,
	// 	value: fmt.fmtText(i18n.t('crypto.opt')),
	// }, {
	// 	key: constants.KEY_CRYPTO_USDT,
	// 	value: fmt.fmtText(i18n.t('crypto.usdt')),
	// }, {
	// 	key: constants.KEY_CRYPTO_CMT,
	// 	value: fmt.fmtText(i18n.t('crypto.cmt')),
	// }, 
	]
};

// crypto 买卖tab
export const tabOrder = () => {
	return [{
		key: constants.KEY_CRYPTO_BUY,
		value: fmt.fmtText(i18n.t('crypto.buy')),
	}, {
		key: constants.KEY_CRYPTO_SELL,
		value: fmt.fmtText(i18n.t('crypto.sell')),
	}]
};

// crypto 底部list
export const footerTabs = (val) => {
	const all = [{
		key: constants.KEY_CRYPTO_POSITION,
		value: fmt.fmtText(i18n.t('crypto.position')),
	}, {
		key: constants.KEY_CRYPTO_ORDER,
		value: fmt.fmtText(i18n.t('crypto.order')),
	}, {
		key: constants.KEY_CRYPTO_HISTORY,
		value: fmt.fmtText(i18n.t('crypto.history')),
	}];

	// 根据不同的传入值,显示不同的底部tabs
	const sptTabs = all.filter(item => item.key == constants.KEY_CRYPTO_HISTORY);

	return val ? sptTabs : all;
};


// 页面容器宽度自动调整
export const setStyleBody = () => {
	let temp = {};
	// 当前布局调整 小屏样式，紧凑样式，宽屏样式
	if (theme.setLayout(constants.SMALL))
		temp.padding = `16px 16px 80px 16px`;
	if (theme.setLayout(constants.MEDIUM))
		temp.padding = `80px 40px 20px 40px`;
	if (theme.setLayout(constants.LARGE)) {
		temp.padding = `80px 0 20px 0`;
		temp.minWidth = constants.WIDTH_PC + `px`;
		temp.margin = `0 24px`;
	}
	// console.log(temp)
	return temp;
}

// 买入卖出第三方请求
export const getDepthData = async (symbol) => {
	const response = await uni.request({
		url: `https://api.huobi.pro/market/depth`,
		method: 'GET',
		data: {
			symbol: symbol,
			depth: 5,
			type: 'step0'
		},
	});
	const [err, res] = response;
	console.log('err:', err, 'res:', res);
	if (res && res.data.status == 'ok') {
		// const temp = res.data;
		return {
			asks: res.data.tick.asks || [],
			bids: res.data.tick.bids || [],
			// 當前數組中，數量最大值， *1.01(餘量，避免求出100%)
			asksMax: Math.max(...res.data.tick.asks.map(item => item[1])) * 1.01,
			// 當前數組中，數量最大值， *1.01(餘量，避免求出100%)
			bidsMax: Math.max(...res.data.tick.bids.map(item => item[1])) * 1.01
		}
	}
	return null;
}

// 最新交易第三方群跪求
export const getLatestData = async (symbol, size = 5) => {
	const response = await uni.request({
		url: `https://api.huobi.pro/market/history/trade`,
		method: 'GET',
		data: {
			symbol: symbol, // this.info.locate,
			size: size,
		},
	});
	const [err, res] = response;
	console.log('err:', err, 'res:', res);
	if (res && res.data.status == 'ok') {
		const temp = res.data.data;
		console.log(`trade temp:`, temp);
		return temp.map(item => {
			return {
				...item.data[0],
				dir: item.data[0].direction == 'buy' ? 1 : 2,
			}
		});
	}
	return null;
}

export const setStyleDirect = (val) => {
	const temp = val == 1 ? theme.RISE : theme.FALL;
	return {
		backgroundColor: theme.convertRGBA(temp, 20),
		color: temp,
		borderRadius: `4px`,
		minWidth: `30px`,
		padding: `3px 8px`,
		fontSize: `11px`,
		textAlign: `center`,
	}
};

// 获取账户 資產 信息 仅限合约使用
export const getUserAssets = async (fromData) => {
	const result = await http.post(`api/user/assets`, fromData);
	if (!result) return false;
	console.log(`assets:`, result);
	const temp = result[0];
	if (!temp || !temp.money) return null;
	return fmt.fmtNumber(temp.money, Vue.prototype.$decimal)
};


// 合约交易 买卖
export const handleTradeCT = async (val = {}) => {
	uni.showLoading({
		title: fmt.fmtText(i18n.t('api.submiting')),
		icon: 'loading'
	});
	const result = await http.post(`api/product/purchase`, val);
	if (!result) return false;
	console.log(`buy result:`, result);
	uni.showToast({
		title: result.message,
		icon: 'success'
	});
	return true;
};

// 币币交易 买卖
export const handleTradeSPT = async (val, isSell) => {
	// 
	// 
	console.log(`币币交易，买卖表单:`, val);

	uni.showLoading({
		title: fmt.fmtText(i18n.t('api.submiting')),
		icon: 'loading'
	});
	const temp = isSell ? `api/user/sell_bi` : `api/product/bi_buy`;
	const result = await http.post(temp, val);
	if (!result) return false;
	console.log(`handleTradeSPT result:`, result);
	uni.showToast({
		title: result.message,
		icon: 'success'
	});
	return true;
};