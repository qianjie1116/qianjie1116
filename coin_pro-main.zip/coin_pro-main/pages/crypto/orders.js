// orders 当前委托
import Vue from 'vue';
import * as constants from '@/common/constants.js';
import http from '@/common/http.js';
import * as fmt from '@/common/format.js';
import * as theme from '@/theme/index.js';
import {
	translate
} from '@/common/util.js';

// 合约交易， 当前委托记录 宽屏表头 竖屏title用用
export const headerCT = {
	direction: {
		flex: `1`,
		title: fmt.fmtText(translate('common.direction'))
	},
	name: {
		flex: `1`,
		title: fmt.fmtText(translate('crypto.name'))
	},
	price: {
		flex: `1`,
		title: fmt.fmtText(translate('common.price'))
	},
	qty: {
		flex: `1`,
		title: fmt.fmtText(translate('crypto.lot'))
	},
	total: {
		flex: `10%`,
		title: fmt.fmtText(translate('crypto.total'))
	},
	dt: {
		flex: `1`,
		title: fmt.fmtText(translate('common.dt'))
	},
	action: {
		flex: `1`,
		title: fmt.fmtText(translate('common.action')),
		textAlign: 'right'
	},
}

// 获取当前委托 只有限价模式会显示？
export const getOrders = async (symbol = '') => {
	let formData = {};
	formData.status = 0;
	if (symbol != '') {
		formData.code = symbol = '';
	}
	const result = await http.post(`api/user/order`, formData);
	if (!result) return false;
	const temp = !Array.isArray(result) || result.length < 0 ? [] :
		result.filter(item => item.goods_info && item.goods_info.gid > 0 && item.order_buy && item
			.order_buy.gid > 0);
	return temp.length <= 0 ? [] : temp.map(item => {
		// 用每条数据自己的小数点位数值，否则使用全局设置值
		const decimal = item.goods_info.shudian || Vue.prototype.$decimal;
		// fx   1市价 2限价
		const fx = item.order_buy.fx;
		// direct   1:买涨 买入 买多；2：买跌 卖出 卖少
		const direct = item.order_buy.direct;
		return {
			id: item.id,
			name: item.goods_info.name,
			fx: fx,
			fxText: fx == 1 ? fmt.fmtText(translate('crypto.market')) : fmt.fmtText(translate(
				'crypto.limit')),
			direct: direct,
			directText: direct == 1 ? fmt.fmtText(translate('crypto.buy')) : fmt.fmtText(translate(
				'crypto.sell')),
			price: fmt.fmtNumber(item.order_buy.price, decimal),
			quantity: item.order_buy.num,
			total: item.order_buy.user_pay,
			dt: item.order_buy.created_at,
			decimal: decimal,
		}
	})
};

// 当前委托的撤销事件
export const handleCanel = async (val) => {
	uni.showLoading({
		title: fmt.fmtText(translate('api.submiting')),
	});
	const result = await http.get(`api/product/hy_cancel`, {
		id: val
	});
	if (!result) return false;
	console.log(`result:`, result);
	uni.showToast({
		title: result.message,
		icon: 'success'
	});
	return true;
};