// history 相关
import Vue from 'vue';
import i18n from '@/locales/index.js';
import * as constants from '@/common/constants.js';
import http from '@/common/http.js';
import * as fmt from '@/common/format.js';
import * as theme from '@/theme/index.js';

// 币币交易，宽屏表头  历史记录
export const headerSPT = () => {
	return {
		direction: {
			flex: `160px`,
			text: fmt.fmtText(i18n.t('common.direction'))
		},
		name: {
			flex: `10%`,
			text: fmt.fmtText(i18n.t('crypto.name'))
		},
		price: {
			flex: `10%`,
			text: fmt.fmtText(i18n.t('common.price'))
		},
		qty: {
			flex: `10%`,
			text: fmt.fmtText(i18n.t('crypto.lot'))
		},
		total: {
			flex: `10%`,
			text: fmt.fmtText(i18n.t('crypto.total'))
		},
		fee: {
			flex: `8%`,
			text: fmt.fmtText(i18n.t('crypto.fee'))
		},
		// sn: {
		// 	flex: `120px`,
		// 	text: fmt.fmtText(i18n.t('common.sn'))
		// },
		dt: {
			flex: `120px`,
			text: fmt.fmtText(i18n.t('common.dt'))
		},
		status: {
			flex: `64px`,
			text: fmt.fmtText(i18n.t('common.status')),
			textAlign: 'right'
		},
	}
};

// 合约交易，宽屏表头  历史记录
export const headerCT = () => {
	return {
		direction: {
			flex: `160px`,
			text: fmt.fmtText(i18n.t('common.direction'))
		},
		name: {
			flex: `10%`,
			text: fmt.fmtText(i18n.t('crypto.name'))
		},
		buyPrice: {
			flex: `10%`,
			text: fmt.fmtText(i18n.t('crypto.buyPrice'))
		},
		sellPrice: {
			flex: `10%`,
			text: fmt.fmtText(i18n.t('crypto.sellPrice'))
		},
		qty: {
			flex: `10%`,
			text: fmt.fmtText(i18n.t('crypto.lot'))
		},
		total: {
			flex: `10%`,
			text: fmt.fmtText(i18n.t('crypto.total'))
		},
		fee: {
			flex: `8%`,
			text: fmt.fmtText(i18n.t('crypto.fee'))
		},
		profit: {
			flex: `10%`,
			text: fmt.fmtText(i18n.t('crypto.profit'))
		},
		dt: {
			flex: `120px`,
			text: fmt.fmtText(i18n.t('common.dt'))
		},
		status: {
			flex: `64px`,
			text: fmt.fmtText(i18n.t('common.status')),
			textAlign: 'right'
		},
	}
}

// 币币交易 history 历史数据
export const getHistorySPT = async (symbol = '') => {
	let formData = {};
	formData.status = 1;
	if (symbol != '') {
		formData.code = symbol = '';
	}
	uni.showLoading({
		title: i18n.t('api.requestData'),
	});
	const result = await http.post(`api/user/order_bi`, formData);
	if (!result) return false;
	console.log(`result:`, result);
	const temp = !Array.isArray(result) || result.length < 0 ? [] :
		result.filter(item => item.goods_info && item.goods_info.gid > 0 && item.order_bi_info && item
			.order_bi_info.gid > 0);
	return temp.length <= 0 ? [] : temp.map(item => {
		const decimal = item.goods_info.shudian || Vue.prototype.$decimal;
		return {
			id: item.id,
			name: item.goods_info.name,
			// fx   1市价 2限价
			fx: item.fx,
			fxText: item.fx == 1 ? fmt.fmtText(i18n.t('crypto.market')) : fmt.fmtText(i18n.t(
				'crypto.limit')),
			direct: item.direct,
			// direct   1:买涨 买入；2：买跌 卖出
			directText: item.direct == 1 ? fmt.fmtText(i18n.t('crypto.buy')) : fmt.fmtText(i18n.t(
				'crypto.sell')),
			price: fmt.fmtNumber(item.order_bi_info.price, decimal),
			amount: item.order_bi_info.num,
			total: item.order_bi_info.user_pay,
			sn: item.order_sn,
			dt: item.order_bi_info.created_at,
			fee: item.order_bi_info.buy_fee,
			status: item.status,
		}
	})
};



// 合约交易 历史数据
export const getHistoryCT = async (symbol = '') => {
	let formData = {};
	formData.status = 2;
	if (symbol != '') {
		formData.code = symbol = '';
	}
	uni.showLoading({
		title: i18n.t('api.requestData'),
	});
	const result = await http.post(`api/user/order`, formData);
	if (!result) return false;
	console.log(`result:`, result);
	const temp = !Array.isArray(result) || result.length < 0 ? [] :
		result.filter(item => item.goods_info && item.goods_info.gid > 0 && item.gid > 0);
	return temp.length <= 0 ? [] : temp.map(item => {
		// 用每条数据自己的小数点位数值，否则使用全局设置值
		const decimal = item.goods_info.shudian || Vue.prototype.$decimal;
		// fx   1市价 2限价
		const fx = item.order_buy.fx;
		// direct   1:买涨 买入 买多；2：买跌 卖出 卖少
		const direct = item.order_buy.direct;
		return {
			id: item.id,
			name: item.goods_info.name,
			fx: fx,
			fxText: fx == 1 ? fmt.fmtText(i18n.t('crypto.market')) : fmt.fmtText(i18n.t(
				'crypto.limit')),
			direct: direct,
			// direct   1:买涨 买入；2：买跌 卖出
			directText: direct == 1 ? fmt.fmtText(i18n.t('crypto.buy')) : fmt.fmtText(
				i18n.t(
					'crypto.sell')),
			price: fmt.fmtNumber(item.price, decimal),
			buyPrice: item.order_buy.price,
			margin: item.order_buy.amount, // 保证金
			quantity: item.num,
			total: item.amount,
			dt: item.created_at,
			fee: item.order_buy.buy_fee,
			lever: item.order_buy.double,
			interest: item.interest, // profit
		}
	});
};