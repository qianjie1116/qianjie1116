<template>
	<view class="custom_table">
		<view class="table_header">
			<view class="table_row" :style="{color:$theme.TXT_UNACT}">
				<block v-for="(v,k) in Object.values(heaers)" :key="k">
					<view class="table_cell" :style="{flex:`${v.flex}`,textAlign:v.textAlign}">
						{{v.title}}
					</view>
				</block>
			</view>
		</view>
		<view class="table_body">
			<block v-for="(item,index) in list" :key="index">
				<view class="table_row" style="display: flex;" :style="{borderBottom:`1px solid ${$theme.TXT_UNACT}`}">
					<view class="table_cell" :style="{flex:`${heaers.direction.flex}`}">
						<text :style="setStyleDirect(item.direct)">{{item.directText}}</text>
						<text style="padding:0 6px" :style="{color:item.fx==1?$theme.PRIMARY:$theme.TXT_UNACT}">
							{{item.fxText}}
						</text>
					</view>

					<view class="table_cell" :style="{flex:`${heaers.name.flex}`}"> {{item.name}} </view>
					<view class="table_cell" :style="{flex:`${heaers.price.flex}`}">
						{{$fmt.fmtCrypto(`${item.price}`)}}
					</view>
					<view class="table_cell" :style="{flex:`${heaers.qty.flex}`}">
						{{$fmt.fmtNumber(item.quantity,item.decimal)}}
					</view>
					<view class="table_cell" :style="{flex:`${heaers.total.flex}`}">
						{{$fmt.fmtCrypto(`${item.total}`)}}
					</view>
					<view class="table_cell" style="font-size: 11px;" :style="{color:$theme.TXT_UNACT,
					flex:`${heaers.dt.flex}`}">
						{{item.dt}}
					</view>
					<view class="table_cell" :style="{color:item.status==-1? $theme.FALL:$theme.TXT_UNACT,
					flex:`${heaers.action.flex}`,textAlign:heaers.action.titleAlign}">
						<view class="btn_common" style="margin-left: 0;line-height:24px;"
							:style="{backgroundColor:$theme.convertRGBA($theme.PRIMARY,20)}"
							@click="handleCanel(item.id)">
							{{$fmt.fmtText($t('common.cancel'))}}
						</view>
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import * as ext from '../ext.js';
	import * as orders from '../orders.js';
	export default {
		name: 'OrdersLarge',
		props: {
			dark: {
				type: Boolean,
				default: true,
			},
			list: {
				type: Array,
				default: []
			},
			heaers: {
				type: Object,
				default: {}
			},
		},
		data() {
			return {
				isDark: this.dark, // 当前主题方案
			}
		},

		methods: {
			// cancel
			handleCanel(val) {
				if (!val) return false;
				this.$emit('cancel', val);
			},

			setStyleDirect(val) {
				return ext.setStyleDirect(val);
			},
		}
	}
</script>

<style>
</style>