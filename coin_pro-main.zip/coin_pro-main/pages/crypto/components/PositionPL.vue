<template>
	<view>
		<view class="overlay" style="background-color: rgba(0, 0, 0, 0.5);" @click="modalClose()"></view>
		<view :class="[$theme.setLayout($C.SMALL)?`modal_wrapper_bottom`:`modal_wrapper_center`,'bottom_in' ]"
			:style="{backgroundColor:$theme.BASIC_BG}">
			<view style="min-height: 30vh;padding:12px 12px 24px 12px;">
				<view style="display: flex;align-items: center;padding-bottom: 12px;">
					<view style="width: 24px;"></view>
					<view style="flex:1;text-align:center;">
						<text style="padding-bottom: 4px;" :style="{borderBottom:`1px solid ${$theme.PRIMARY}`}">
							{{setTitle}}
						</text>
					</view>
					<view style="margin-left: auto;">
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.close" @click="modalClose()" />
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="padding-right: 12px;font-size: 14px;">
						{{info.name}}
					</view>
					<view style="font-size: 12px;padding:3px 8px;margin:0 14px"
						:style="{color:info.fx==1?$theme.PRIMARY:$theme.TXT_UNACT}">
						{{info.fxText}}
					</view>
					<view style="font-size: 12px;padding:3px 8px;margin:0 14px" :style="{color:$theme.FALL}">
						{{info.lever+` X`}}
					</view>
					<view style="margin-left: auto;">
						<view :style="setStyleDirect(info.direct)">
							{{info.directText}}
						</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
					<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('common.price'))}}</view>
					<FmtNumber :value="info.price" usdt />
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
					<view :style="{color:$theme.TXT_UNACT}">{{ $fmt.fmtText($t('common.qty')) }}</view>
					<view>{{$fmt.fmtNumber(info.quantity,$decimal)}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
					<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('crypto.total'))}}</view>
					<FmtNumber :value="info.total" usdt />
				</view>

				<view style="font: 14px; margin-top: 12px;margin-bottom: 8px;">
					{{$fmt.fmtText($t('crypto.takeProfit')+$t('common.amount'))}}
				</view>
				<view class="input_wrapper" style="padding:0 12px;margin-top: 0;" :style="$theme.setInputStyle(isDark)">
					<input v-model="profitAmount" type="digit"
						:placeholder="$fmt.fmtText($t('crypto.takeProfit')+$t('common.amount'))"
						:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"
						@blur="checkProfitAmount"></input>
				</view>
				<view style="font-size: 12px;padding-top: 4px;" :style="{color:$theme.TXT_UNACT}">
					{{$fmt.fmtText($t('crypto.estimatedProfit')) + `: `+$fmt.fmtCrypto(`${estimatedProfit}`)+ ` USDT`}}
				</view>

				<view style="font: 14px; margin-top: 12px;margin-bottom: 8px;">
					{{$fmt.fmtText($t('crypto.stopLoss')+$t('common.amount'))}}
				</view>
				<view class="input_wrapper" style="padding:0 12px;margin-top: 0;" :style="$theme.setInputStyle(isDark)">
					<input v-model="lossAmount" type="digit"
						:placeholder="$fmt.fmtText($t('crypto.stopLoss')+$t('common.amount'))"
						:placeholder-style="$theme.setPlaceholder()" style="flex:auto;" @blur="checkLossAmount"></input>
				</view>
				<view style="font-size: 12px;padding-top: 4px;" :style="{color:$theme.TXT_UNACT}">
					{{$fmt.fmtText($t('crypto.estimatedLoss'))+ `: `+$fmt.fmtCrypto(`${estimatedLoss}`)+ ` USDT`}}
				</view>

				<view style="display: flex; align-items: center;justify-content: space-between;padding: 12px 0;">
					<view class="btn_common"
						style="margin:0 auto; flex:1;border:none;padding:4px;margin-left: 0;line-height: 24px;"
						:style="{backgroundColor:$theme.RISE}" @click="handleSubmit()">
						{{ $fmt.fmtText($t('common.submit'))}}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import * as ext from '../ext.js';
	import * as position from '../position.js';
	export default {
		name: 'PositionPL',
		props: {
			dark: {
				type: Boolean,
				default: true,
			},
			info: {
				type: Object,
				default: {}
			},
		},
		data() {
			return {
				isDark: this.dark, // 当前主题方案
				// curInfo: this.info,
				profitAmount: '', // 止盈輸入金額
				lossAmount: '', // 止損輸入金額
				estimatedProfit: '', // 预估盈
				estimatedLoss: '', // 预估损
			}
		},
		computed: {
			// 止盈止损弹层
			setTitle() {
				//  Take Profit & Stop Loss
				return this.$fmt.fmtText(this.$t('crypto.takeProfit') + ` & ` + this.$t('crypto.stopLoss'))
			},
			// 持仓列表中，当前选中数据 direct   1:买涨 买入 买多；2：买跌 卖出 卖少
			isBuy() {
				if (this.info) return this.info.direct == 1;
			},
		},
		beforeMount() {},
		methods: {
			// 止盈止损 弹层关闭
			modalClose() {
				this.profitAmount = '';
				this.lossAmount = '';
				this.$emit('action', 1);
			},
			// check 止盈输入值 并计算预估止盈值
			checkProfitAmount() {
				console.log(`checkProfitAmount:`, this.profitAmount);
				if (this.profitAmount == '') return false;
				if (!this.$util.checkInputNumber(this.profitAmount)) return false;
				this.profitAmount = this.$util.checkInputNumber(this.profitAmount);

				// 买涨：止盈>price 
				if (this.isBuy) {
					if (this.profitAmount < this.info.price * 1) {
						uni.showToast({
							title: this.$fmt.fmtText(this.$t('crypto.profitBuy')),
							icon: 'none'
						});
						return false;
					}
				} else {
					// 买跌：止盈 < price
					if (this.profitAmount > this.info.price * 1) {
						uni.showToast({
							title: this.$fmt.fmtText(this.$t('crypto.profitSell')),
							icon: 'none'
						});
						return false;
					}
				}
				// 计算预估盈
				// 止盈设置10000，买入价9000，如果买涨，就是1000;如果买跌，就是-1000
				this.estimatedProfit = this.isBuy ?
					this.$fmt.fmtNumber(this.profitAmount - this.info.price * 1, this.$decimal) :
					this.$fmt.fmtNumber(this.info.price * 1 - this.profitAmount, this.$decimal);

				return true;
			},
			checkLossAmount() {
				console.log(`checkLossAmount:`, this.lossAmount);
				if (this.lossAmount == '') return false;
				if (!this.$util.checkInputNumber(this.lossAmount)) return false;
				this.lossAmount = this.$util.checkInputNumber(this.lossAmount);

				// 买涨：止损<price
				if (this.isBuy) {
					if (this.lossAmount > this.info.price * 1) {
						uni.showToast({
							title: this.$fmt.fmtText(this.$t('crypto.lossBuy')),
							icon: 'none'
						});
						return false;
					}
				} else {
					//  买跌：止损>price
					if (this.lossAmount < this.info.price * 1) {
						uni.showToast({
							title: this.$fmt.fmtText(this.$t('crypto.lossSell')),
							icon: 'none'
						});
						return false;
					}
				}
				// 计算预估损
				// 止损设置8000，买入价是9000，如果买涨，就是-1000;  如果买跌，就是1000
				this.estimatedLoss = this.isBuy ?
					this.$fmt.fmtNumber(this.lossAmount - this.info.price * 1, this.$decimal) :
					this.$fmt.fmtNumber(this.info.price * 1 - this.lossAmount, this.$decimal);

				return true;
			},

			async handleSubmitPL() {
				// console.log(`profitAmount:`, this.profitAmount);
				// console.log(`lossAmount:`, this.lossAmount);
				// 两个输入框全都未输入时，提示用户输入
				if (this.profitAmount == '' && this.lossAmount == '') {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enterValidValue')),
						icon: 'none'
					});
					return false;
				}
				let isCheck = false; // 当前带提交表单数据是否验证合法
				// 如果止盈输入框有内容，判断其合法性
				if (this.profitAmount != '') {
					// console.log(`止盈验证 profitAmount:`, this.profitAmount);
					isCheck = this.checkProfitAmount();
				}
				if (this.lossAmount != '') {
					// console.log(`止损验证 profitAmount:`, this.profitAmount);
					isCheck = this.checkLossAmount();
				}
				console.log(`验证结果:`, isCheck);
				if (!isCheck) return false;
				// 如果验证无误，执行提交事件
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.submiting')),
					icon: 'loading'
				});
				// 止盈止损是可以设置一个,没有设置值的为'',
				const result = await this.$http.post(`api/user/yingsun`, {
					id: this.info.id,
					zhiying: this.profitAmount > 0 ? this.profitAmount : '',
					zhisun: this.lossAmount > 0 ? this.lossAmount : '',
				});
				if (!result) return false;
				console.log(`result:`, result);
				uni.showToast({
					title: result.message,
					icon: 'success'
				});
				setTimeout(() => {
					this.modalClose();
				}, 1000);
			},
			setStyleDirect(val) {
				return ext.setStyleDirect(val);
			},
		}
	}
</script>

<style>
</style>