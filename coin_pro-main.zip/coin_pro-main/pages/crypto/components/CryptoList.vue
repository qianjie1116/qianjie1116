<template>
	<view>
		<view class="overlay" style="background-color: rgba(0, 0, 0, 0.5);" @click="modalClose()"></view>
		<view class="crypto_modal_wrapper left_in" :style="{backgroundColor:$theme.BASIC_BG}">
			<view style="min-height: 100vh;width: 100%;">
				<view style="display: flex;align-items: center;justify-content: space-between;padding:20px 20px;">
					<view style="font-size: 16px;">
						{{$fmt.fmtText($t('common.choose') +$C.KEY_CRYPTO)}}
					</view>
					<view>
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.close" @click="modalClose()" />
					</view>
				</view>
				<view style="height: 90vh; overflow-y: auto;">
					<block v-for="(v,k) in list" :key="k">
						<view style="padding:0 12px 8px 12px;">
							<view style="display: flex;align-items: center;" @click="selectedCrypto(v)">
								<view style="margin-right: auto;">
									<CustomLogo :logo="v.logo" :name="v.name" :size="24" />
								</view>
								<view style="flex:0 0 10%;">
									<view style="font-size: 11px;padding-left: 10px;">
										{{v.name}}
									</view>
								</view>
								<view style="flex:1 0 auto;">
									<view style="font-size: 14px;font-weight: 500;text-align: center;">
										{{$fmt.fmtCrypto(`${v.current_price}`)}}
									</view>
								</view>
								<view style="margin-left: auto;">
									<view style="min-width: 60px;text-align: center;"
										:style="$theme.setRiseFall(v.rate)">
										{{`${v.rate>0?'+':'-'} `+ $fmt.fmtNumber (Math.abs(v.rate))}}%
									</view>
								</view>
							</view>
						</view>
					</block>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'CryptoList',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		methods: {
			modalClose() {
				this.$emit('action', 1);
			},
			selectedCrypto(val) {
				this.$emit('action', val);
			},
		}
	}
</script>

<style>
</style>