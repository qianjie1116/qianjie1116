<template>
	<view :style="{width:width+`%`}">
		<view style="display: flex;align-items: center;padding-bottom: 4px;">
			<view style="font-size: 12px;flex:0 0 68px;" :style="{color:$theme.TXT_UNACT}">
				{{$fmt.fmtText($t('common.direction'))}}
			</view>
			<view style="font-size: 12px;flex:0 0 30%;text-align: center;" :style="{color:$theme.TXT_UNACT}">
				{{$fmt.fmtText($t('common.price'))}}({{$t('common.unitUSDT')}})
			</view>
			<view style="font-size: 12px;flex:0 0 30%;text-align: center;" :style="{color:$theme.TXT_UNACT}">
				{{$fmt.fmtText($t('common.vol'))}}({{code}})
			</view>
			<view style="font-size: 12px;flex:0 0 20%;text-align: right;" :style="{color:$theme.TXT_UNACT}">
				{{$fmt.fmtText($t('common.time'))}}
			</view>
		</view>

		<template v-if="!data || data.length<=0">
			<EmptyData :size="80" />
		</template>
		<template v-else>
			<block v-for="(item,index) in data" :key="index">
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.3;">
					<view style="font-size: 10px;flex:0 0 68px;" :style="$theme.setRiseFall(item.dir==1?1:-1)">
						{{ item.dir==1?$t('crypto.buy'):$t('crypto.sell')}}
					</view>
					<view style="font-size: 12px;flex:0 0 30%;text-align: center;">
						{{$fmt.fmtCrypto(`${$fmt.fmtNumber(`${item.price}`,4)}`)}}
					</view>
					<view style="font-size: 12px;font-weight: 100;flex:0 0 30%;text-align: center;">
						{{$fmt.fmtCrypto(`${$fmt.fmtNumber(`${item.amount}`,4)}`)}}
					</view>
					<view style="font-size: 12px;flex:0 0 20%;text-align: right;">{{$fmt.fmtToHMS(item.ts)}}</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		// 最新交易
		name: 'Latest',
		props: {
			// 布局占比
			width: {
				type: Number,
				default: 100
			},
			// 币种
			code: {
				type: String,
				default: 'BTC'
			},
			// 传入数据
			data: {
				type: Array,
				default: []
			},
		}
	}
</script>

<style>
</style>