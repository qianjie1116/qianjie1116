<template>
	<view>
		<view class="overlay" style="background-color: rgba(0, 0, 0, 0.5);" @click="modalClose()"></view>
		<view :class="[$theme.setLayout($C.SMALL)?`modal_wrapper_bottom`:`modal_wrapper_center`,'bottom_in' ]"
			:style="{backgroundColor:$theme.BASIC_BG}">
			<view style="min-height: 30vh;padding:12px 12px 24px 12px;">
				<view style="display: flex;align-items: center;padding-bottom: 12px;">
					<view style="width: 24px;"></view>
					<view style="flex:1;text-align:center;">
						<text style="padding-bottom: 4px;" :style="{borderBottom:`1px solid ${$theme.PRIMARY}`}">
							{{setTitle}}
						</text>
					</view>
					<view style="margin-left: auto;">
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.close" @click="modalClose()" />
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="padding-right: 12px;font-size: 14px;">
						{{info.name}}
					</view>
					<view style="font-size: 11px;padding:3px 8px;margin:0 14px"
						:style="{color:info.fx==1?$theme.PRIMARY:$theme.TXT_UNACT}">
						{{info.fxText}}
					</view>
					<view style="font-size: 11px;padding:3px 8px;margin:0 14px" :style="{color:$theme.FALL}">
						{{info.lever+` X`}}
					</view>
					<view style="margin-left: auto;">
						<view :style="setStyleDirect(info.direct)">
							{{info.directText}}
						</view>
					</view>
				</view>
				<!-- 市价、限价、限价输入框 -->
				<view style="display: flex;align-items: center;padding-top: 8px;">
					<view style="padding-right: 12px;" @click="changeMode(false)">
						<text
							:style="{color:!isLimt?$theme.PRIMARY:$theme.TXT_UNACT,borderBottom:`1px dashed ${!isLimt?$theme.PRIMARY:$theme.TXT_UNACT}`}">
							{{$fmt.fmtText($t('crypto.market'))}}</text>
					</view>
					<view style="padding-right: 12px;" @click="changeMode(true)">
						<text
							:style="{color:isLimt?$theme.PRIMARY:$theme.TXT_UNACT,borderBottom:`1px dashed ${isLimt?$theme.PRIMARY:$theme.TXT_UNACT}`}">
							{{$fmt.fmtText($t('crypto.limit'))}}</text>
					</view>
					<view style="flex:auto;">
						<view class="input_wrapper" style="padding:0 12px;margin-top: 0;"
							:style="$theme.setInputStyle(isDark)">
							<input v-model="price" type="digit"
								:placeholder="$fmt.fmtText($t('common.enter')+ $t('common.price'))"
								:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"
								:disabled="!isLimt"></input>
							<view style="margin-left: auto;">
								<view :style="{color:$theme.TXT_UNACT}">{{$t('common.unitUSDT')}}</view>
							</view>
						</view>
					</view>
				</view>
				<!-- crypto输入框、lot输入框 。输入框根据当前tab判断显示。合约类是lot,否则是crypto  -->
				<view style="display: flex;align-items: center;padding-top: 8px;">
					<view style="padding-right: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('common.amount'))}}
					</view>
					<view style="flex:auto;">
						<view class="input_wrapper" style="padding:0 12px;margin-top: 0;"
							:style="$theme.setInputStyle(isDark)">
							<input v-model="amount" type="digit"
								:placeholder="$fmt.fmtText($t('common.enter')+ $t('common.amount'))"
								:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
							<view style="margin-left: auto;">
								<view :style="{color:$theme.TXT_UNACT}">{{$t('common.lots')}}</view>
							</view>
						</view>
					</view>
				</view>
				<!-- 百分比 根据tab判定，部分tab不显示百分比一项 -->
				<Percent :list="percents" @action="choosePercent" />

				<Balance :balance="balance" usdt :unit="$t('common.unitUSDT')" />

				<view style="display: flex;align-items: center;padding-top: 8px;">
					<view style="padding-right: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('crypto.closeLot'))}}
					</view>
					<view style="margin-left: auto;">{{info.quantity}}</view>
				</view>

				<view style="display: flex; align-items: center;justify-content: space-between;padding: 12px 0;">
					<view class="btn_common"
						style="margin:0 auto; flex:1;border:none;padding:4px;margin-left: 0;line-height: 24px;"
						:style="{backgroundColor:$theme.RISE}" @click="handleSubmit()">
						{{ $fmt.fmtText($t('common.submit'))}}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import * as ext from '../ext.js';
	import * as position from '../position.js';
	export default {
		name: 'PositionClose',
		props: {
			dark: {
				type: Boolean,
				default: true,
			},
			info: {
				type: Object,
				default: {}
			},
			balance: {
				type: [Number, String],
				default: 0
			}
		},
		data() {
			return {
				isDark: this.dark, // 当前主题方案
				// curInfo: this.info,
				isLimt: false, // 是否限价模式
				price: '', // 限价模式输入值，市价模式crypto详情Price值
				amount: '', // 买卖量。crypto.name或lots
				percents: [25, 50, 75, 100], // 百分比预置值组
				curPercent: -1, // 当前百分比
			}
		},
		computed: {
			// 止盈止损弹层
			setTitle() {
				return this.$fmt.fmtText(this.$t('common.close') + ` ` + this.$t('crypto.order'))
			},
		},
		beforeMount() {
			console.log(`?`, this.info);
			this.price = this.info.price * 1;
		},
		methods: {
			// 切换市价限价
			changeMode(val) {
				this.isLimt = val;
				if (!this.isLimt) this.price = this.info.price * 1;
			},
			// 止盈止损 弹层关闭
			modalClose() {
				this.profitAmount = '';
				this.lossAmount = '';
				this.$emit('close', 1);
			},
			// amount 值计算
			calculateQTY() {
				this.amount = this.$fmt.fmtNumber(this.info.amount * (this.curPercent * 0.01), this.$decimal);
			},
			// 百分比选择
			choosePercent(v) {
				this.curPercent = v;
				console.log(`curPercent`, this.curPercent);
				// 有值需要重新计算。
				this.calculateQTY();
			},

			async handleSubmit() {
				if (this.amount == '' || this.amount <= 0) {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('common.amount')),
						icon: 'none'
					});
					return false;
				}
				if (!this.$util.checkInputNumber(this.amount)) return false;

				let formData = {
					num: this.amount,
					id: this.info.id,
					fx: this.isLimt ? 2 : 1, // 1市价 2限价
				}
				if (this.isLimt) formData.price = this.price;
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.submiting')),
					icon: 'loading'
				});
				const result = await this.$http.get(`api/user/sell`, formData);
				if (!result) return false;
				console.log(`result:`, result);
				uni.showToast({
					title: result.message,
					icon: 'success'
				});
				setTimeout(() => {
					this.$emit('close', 1);
				}, 1000);
			},

			setStyleDirect(val) {
				return ext.setStyleDirect(val);
			},
		}
	}
</script>

<style>
</style>