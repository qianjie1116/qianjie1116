<template>
	<view class="custom_table">
		<view class="table_header">
			<view class="table_row" :style="{color:$theme.TXT_UNACT}">
				<block v-for="(v,k) in Object.values(heaers)" :key="k">
					<view class="table_cell" :style="{flex:`${v.flex}`,textAlign:v.textAlign}"> {{v.text}} </view>
				</block>
			</view>
		</view>
		<view class="table_body" style="overflow-x: auto;">
			<block v-for="(item,index) in list" :key="index">
				<view class="table_row" :style="{borderBottom:`1px solid ${$theme.TXT_UNACT}`}">
					<view class="table_cell" :style="{flex:`${heaers.direction.flex}`}">
						<text :style="setStyleDirect(item.direct)">{{item.directText}}</text>
						<text style="padding:0 6px" :style="{color:item.fx==1?$theme.PRIMARY:$theme.TXT_UNACT}">
							{{item.fxText}}
						</text>
						<text>{{item.lever+`X`}}</text>
					</view>
					<view class="table_cell" :style="{flex:`${heaers.name.flex}`}"> {{item.name}} </view>
					<view class="table_cell" :style="{flex:`${heaers.price.flex}`}">
						{{$fmt.fmtCrypto(`${item.price}` )}}
					</view>
					<view class="table_cell" :style="{flex:`${heaers.qty.flex}`}">
						{{$fmt.fmtNumber(item.quantity,4)}}
					</view>
					<view class="table_cell" :style="{flex:`${heaers.total.flex}`}">
						{{$fmt.fmtCrypto(`${item.total}` )}}
					</view>
					<view class="table_cell" :style="{flex:`${heaers.latest.flex}`}">
						{{$fmt.fmtCrypto(`${item.latestPrice}` )}}
					</view>
					<view class="table_cell" :style="{flex:`${heaers.fee.flex}`}">
						{{$fmt.fmtCrypto(`${item.fee}` )}}
					</view>
					<view class="table_cell" :style="{...$theme.setRiseFall(item.direct==1? item.buyPL:item.sellPL),
					flex:`${heaers.profit.flex}`}">
						{{$fmt.fmtCrypto(`${item.direct==1? item.buyPL:item.sellPL}` )}}
					</view>
					<view class="table_cell" :style="{...$theme.setRiseFall(1),
					flex:`${heaers.takeProfit.flex}`}" @click="setPL(item)">
						<text :style="{borderBottom:heaers.takeProfit.borderBottom}">
							{{ item.takeProfit=='--'?item.takeProfit:$fmt.fmtCrypto(`${item.takeProfit}`) }}
						</text>
					</view>
					<view class="table_cell" :style="{...$theme.setRiseFall(-1),flex:`${heaers.stopLoss.flex}`}"
						@click="setPL(item)">
						<text :style="{borderBottom:heaers.stopLoss.borderBottom}">
							{{ item.stopLoss=='--'?item.stopLoss:$fmt.fmtCrypto(`${item.stopLoss}`) }}
						</text>
					</view>
					<view class="table_cell" :style="{...$theme.setRiseFall(item.direct==1? item.floatPLBuy:item.floatPLSell),
					flex:`${heaers.floatPL.flex}`}">
						{{$fmt.fmtCrypto(`${item.direct==1? item.floatPLBuy:item.floatPLSell}` )}}
					</view>
					<view class="table_cell" style="font-size: 11px;" :style="{color:$theme.TXT_UNACT,
					flex:`${heaers.dt.flex}`}">
						{{item.dt}}
					</view>

					<view class="table_cell" :style="{color:item.status==-1? $theme.FALL:$theme.TXT_UNACT,
					flex:`${heaers.action.flex}`,textAlign:heaers.action.textAlign}">
						<view class="btn_common" style="margin-left: 0;line-height:24px;"
							:style="{backgroundColor:$theme.convertRGBA($theme.PRIMARY,20)}" @click="handleClose(item)">
							{{$fmt.fmtText($t('common.close'))}}
						</view>
					</view>

				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import * as ext from '../ext.js';
	import * as position from '../position.js';
	export default {
		name: 'PositionLarge',
		props: {
			dark: {
				type: Boolean,
				default: true,
			},
			list: {
				type: Array,
				default: []
			},
			heaers: {
				type: Object,
				default: {}
			},
		},
		computed: {},
		methods: {
			// 设置止盈止损
			setPL(val) {
				this.$emit('action', val);
			},
			// 平仓
			handleClose(val) {
				this.$emit('close', val);
			},
			setStyleDirect(val) {
				return ext.setStyleDirect(val);
			},
		}
	}
</script>

<style>
</style>