<template>
	<view style="display: flex;align-items: center;">
		<view style="padding-right: 24px;">
			<view style="font-size: 16px;font-weight: 700;">{{data.name}}</view>
			<view style="font-size: 12px;padding-top: 4px;" :style="{color:$theme.TXT_UNACT}">
				24H:{{$fmt.fmtCrypto(`${data.vol}`)}}
			</view>
		</view>

		<view style="flex:1;">
			<view style="display: flex;align-items: center;justify-content: space-between;padding-right: 24px;">
				<view style="text-align: center;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('common.price'))}}
					</view>
					<view style="font-size: 16px;padding-top: 4px;" :style="$theme.setRiseFall(data.rate)">
						{{$fmt.fmtCrypto(`${data.lastPrice}`,4)}}
					</view>
				</view>
				<view style="text-align: center;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('common.rateNum'))}}
					</view>
					<view style="font-size: 16px;padding-top: 4px;" :style="$theme.setRiseFall(data.rate)">
						{{$fmt.fmtCrypto(`${data.rate_num}`,4)}}
					</view>
				</view>
				<view style="text-align: center;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('common.rate'))}}
					</view>
					<view style="font-size: 16px;padding-top: 4px;" :style="$theme.setRiseFall(data.rate)">
						{{`${data.rate>0?'+':'-'} `+ ($fmt.fmtNumber(Math.abs(data.rate),2))}}%
					</view>
				</view>

				<template v-if="data.open">
					<view style="text-align: center;">
						<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('common.open'))}}
						</view>
						<view style="padding-top: 4px;" :style="{color:$theme.LOG_VALUE}">
							{{$fmt.fmtCrypto(`${data.open}`,4)}}
						</view>
					</view>
				</template>
				<template v-if="data.close">
					<view style="text-align: center;">
						<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('common.close'))}}
						</view>
						<view style="padding-top: 4px;" :style="{color:$theme.LOG_VALUE}">
							{{$fmt.fmtCrypto(`${data.close}`,4)}}
						</view>
					</view>
				</template>
				<template v-if="data.high">
					<view style="text-align: center;">
						<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('common.high'))}}
						</view>
						<view style="padding-top: 4px;" :style="{color:$theme.LOG_VALUE}">
							{{$fmt.fmtCrypto(`${data.high}`,4)}}
						</view>
					</view>
				</template>
				<template v-if="data.low">
					<view style="text-align: center;">
						<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('common.low'))}}
						</view>
						<view style="padding-top: 4px;" :style="{color:$theme.LOG_VALUE}">
							{{$fmt.fmtCrypto(`${data.low}`,4)}}
						</view>
					</view>
				</template>
			</view>
		</view>

		<view style="margin-left: auto;">
			<CustomSvg :color="$theme.PRIMARY" :size="20" :path="$svg.rule" @click="linkRule()" />
		</view>

	</view>
</template>

<script>
	export default {
		name: 'DataLarge',
		props: {
			data: {
				type: Object,
				default: {}
			},
			code: {
				type: String,
				default: ''
			},
		},
		methods: {
			linkRule() {
				this.$emit('action', 1);
			}
		}
	}
</script>

<style>
</style>