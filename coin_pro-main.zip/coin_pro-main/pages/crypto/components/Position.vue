<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData />
		</template>
		<template v-else>
			<template v-if="$theme.setLayout($C.SMALL)">
				<PositionSmall :dark="dark" :list="list" :heaers="heaers" @action="showPL" @close="showClose" />
			</template>
			<template v-else>
				<PositionLarge :dark="dark" :list="list" :heaers="heaers" @action="showPL" @close="showClose" />
			</template>
		</template>

		<!-- 止盈止损弹层 -->
		<template v-if="showModalPL">
			<PositionPL :dark="dark" :info="info" @action="setPL" />
		</template>
		<!-- 平仓 -->
		<template v-if="showModalClose">
			<PositionClose :dark="dark" :info="info" @close="hanldeClose" :balance="balance" />
		</template>
	</view>
</template>

<script>
	import * as position from '../position.js';
	import PositionSmall from './PositionSmall.vue';
	import PositionLarge from './PositionLarge.vue';
	import PositionPL from './PositionPL.vue';
	import PositionClose from './PositionClose.vue';
	export default {
		name: 'Position',
		components: {
			PositionSmall,
			PositionLarge,
			PositionPL,
			PositionClose,
		},
		props: {
			dark: {
				type: Boolean,
				default: true,
			},
			list: {
				type: Array,
				default: []
			},
			balance: {
				type: [Number, String],
				default: 0
			}
		},
		data() {
			return {
				isDark: this.dark, // 当前主题方案
				showModalPL: false, // 显示止盈止损弹层
				info: null, // 子组件选中的数据
				showModalClose: false, // 显示平仓弹层
			}
		},
		computed: {
			heaers() {
				return position.headerCT
			},
		},
		methods: {
			// 显示止盈止损弹层
			showPL(val) {
				this.showModalPL = true;
				this.info = val;
			},
			// 设置止盈止损
			setPL(val) {
				this.showModalPL = false;
				this.info = null;
				this.$emit('action', val);
			},
			// 显示平仓弹层
			showClose(val) {
				this.showModalClose = true;
				this.info = val;

			},
			// 平仓
			hanldeClose(val) {
				this.showModalClose = false;
				this.info = null;
				this.$emit('close', val);
			}
		}
	}
</script>

<style>
</style>