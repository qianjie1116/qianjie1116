<template>
	<view class="custom_table">
		<view class="table_header">
			<view class="table_row" :style="{color:$theme.TXT_UNACT}">
				<block v-for="(v,k) in headers" :key="k">
					<view class="table_cell" :style="{flex:`${v.flex}`,textAlign:v.textAlign}">
						{{v.text}}
					</view>
				</block>
			</view>
		</view>
		<view class="table_body">
			<block v-for="(item,index) in list" :key="index">
				<view class="table_row" style="display: flex;" :style="{borderBottom:`1px solid ${$theme.TXT_UNACT}`}">
					<view class="table_cell" :style="{flex:`${headers.direction.flex}`}">
						<text :style="setStyleDirect(item.direct)">{{item.directText}}</text>
						<text style="padding:0 6px" :style="{color:item.fx==1?$theme.PRIMARY:$theme.TXT_UNACT}">
							{{item.fxText}}
						</text>
						<text>{{!isspt?item.lever+`X`:``}}</text>
					</view>

					<view class="table_cell" :style="{flex:`${headers.name.flex}`}"> {{item.name}} </view>
					<template v-if="!isspt">
						<view class="table_cell" :style="{flex:`${headers.buyPrice.flex}`}">
							{{$fmt.fmtCrypto(`${item.buyPrice}`,4)}}
						</view>
						<view class="table_cell" :style="{flex:`${headers.sellPrice.flex}`}">
							{{$fmt.fmtCrypto(`${item.price}`,4)}}
						</view>
					</template>
					<template v-else>
						<view class="table_cell" :style="{flex:`${headers.price.flex}`}">
							{{$fmt.fmtCrypto(`${item.price}`,4)}}
						</view>
					</template>

					<view class="table_cell" :style="{flex:`${headers.qty.flex}`}">
						{{$fmt.fmtNumber(item.quantity,4)}}
					</view>
					<view class="table_cell" :style="{flex:`${headers.qty.flex}`}">
						{{isspt?$fmt.fmtCrypto(`${item.total}`,4):$fmt.fmtCrypto(`${item.margin}`,4)}}
					</view>
					<view class="table_cell" :style="{flex:`${headers.fee.flex}`}">
						{{$fmt.fmtCrypto(`${item.fee}`,4)}}
					</view>
					<template v-if="!isspt">
						<view class="table_cell"
							:style="{...$theme.setRiseFall(item.interest),flex:`${headers.profit.flex}`}">
							{{$fmt.fmtCrypto(`${item.interest}`,4)}}
						</view>
					</template>
					<view class="table_cell" style="font-size: 11px;" :style="{color:$theme.TXT_UNACT,
					flex:`${headers.dt.flex}`}">
						{{item.dt}}
					</view>
					<view class="table_cell" :style="{color:item.status==-1? $theme.FALL:$theme.TXT_UNACT,
					flex:`${headers.status.flex}`,textAlign:headers.status.textAlign}">
						{{item.status==-1?$fmt.fmtText($t('crypto.cancel'))
						:$fmt.fmtText($t('crypto.traded'))}}
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import * as ext from '../ext.js';
	import * as history from '../history.js';
	export default {
		name: 'HistoryLarge',
		props: {
			list: {
				type: Array,
				default: []
			},
			// 是否是SPT(币币交易)
			isspt: {
				type: Boolean,
				default: true
			}
		},
		computed: {
			headers() {
				return this.isspt ? history.headerSPT() : history.headerCT()
			},
		},

		methods: {
			setStyleDirect(val) {
				return ext.setStyleDirect(val);
			},
		}
	}
</script>

<style>
</style>