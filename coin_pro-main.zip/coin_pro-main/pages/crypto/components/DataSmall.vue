<template>
	<view style="display: flex;align-items: center;justify-content: space-between;padding:4px 0;">
		<template v-if="data.open">
			<view style="text-align: center;">
				<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
					{{$fmt.fmtText($t('common.open'))}}
				</view>
				<view :style="{color:$theme.LOG_VALUE}">
					{{$fmt.fmtCrypto(`${data.open}`,4)}}
				</view>
			</view>
		</template>
		<template v-if="data.close">
			<view style="text-align: center;">
				<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
					{{$fmt.fmtText($t('common.close'))}}
				</view>
				<view :style="{color:$theme.LOG_VALUE}">
					{{$fmt.fmtCrypto(`${data.close}`,4)}}
				</view>
			</view>
		</template>
		<template v-if="data.high">
			<view style="text-align: center;">
				<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
					{{$fmt.fmtText($t('common.high'))}}
				</view>
				<view :style="{color:$theme.LOG_VALUE}">
					{{$fmt.fmtCrypto(`${data.high}`,4)}}
				</view>
			</view>
		</template>
		<template v-if="data.low">
			<view style="text-align: center;">
				<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
					{{$fmt.fmtText($t('common.low'))}}
				</view>
				<view :style="{color:$theme.LOG_VALUE}">
					{{$fmt.fmtCrypto(`${data.low}`,4)}}
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	export default {
		name: 'DataSmall',
		props: {
			data: {
				type: Object,
				default: {}
			}
		},
	}
</script>

<style>
</style>