<template>
	<view>
		<block v-for="(item,index) in list" :key="index">
			<view style="padding:8px 0;" :style="{borderBottom:`1px solid ${$theme.TXT_UNACT}`}">
				<view style="display: flex;align-items: center;">
					<view style="padding-right: 12px;font-size: 14px;">
						{{item.name}}
					</view>
					<view style="font-size: 11px;padding:3px 8px;margin:0 14px"
						:style="{color:item.fx==1?$theme.PRIMARY:$theme.TXT_UNACT}">
						{{item.fxText}}
					</view>
					<view :style="setStyleDirect(item.direct)">
						{{item.directText}}
					</view>
					<template v-if="!isspt">
						<view style="font-size: 11px;padding:3px 8px;margin:0 14px" :style="{color:$theme.FALL}">
							{{item.lever+` X`}}
						</view>
					</template>
					<template v-if="isspt">
						<view style="margin-left: auto;font-size: 12px;"
							:style="{color:item.status==-1? $theme.FALL:$theme.TXT_UNACT}">
							{{item.status==-1?`CANCEL`:`TRADE`}}
						</view>
					</template>
				</view>
				<template v-if="!isspt">
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
						<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('crypto.buyPrice'))}}</view>
						<view>{{$fmt.fmtCrypto(`${item.buyPrice}`)}}</view>
					</view>
				</template>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('common.price'))}}</view>
					<view>{{$fmt.fmtCrypto(`${item.price}`)}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{isspt?$fmt.fmtText($t('common.qty'))
					:$fmt.fmtText($t('crypto.lot'))}}</view>
					<view>{{$fmt.fmtNumber(item.quantity,$decimal)}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{isspt?$fmt.fmtText($t('crypto.total'))
					:$fmt.fmtText($t('crypto.margin'))}}</view>
					<view>{{$fmt.fmtCrypto(`${item.total}`)}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('crypto.fee'))}}
					</view>
					<view>{{$fmt.fmtCrypto(`${item.fee}`)}}</view>
				</view>
				<template v-if="!isspt">
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
						<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('crypto.profit'))}}
						</view>
						<view :style="$theme.setRiseFall(item.interest)">{{$fmt.fmtCrypto(`${item.interest}`,4)}}</view>
					</view>
				</template>
				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;font-size: 12px;">
					<view :style="{color:$theme.TXT_UNACT}"> {{$fmt.fmtText($t('common.dt'))}}
					</view>
					<view> {{item.dt}} </view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import * as ext from '../ext.js';
	export default {
		name: 'HistorySmall',
		props: {
			list: {
				type: Array,
				default: []
			},
			// 是否是SPT(币币交易)
			isspt: {
				type: Boolean,
				default: true
			}
		},
		methods: {
			setStyleDirect(val) {
				return ext.setStyleDirect(val);
			},
		}
	}
</script>

<style>
</style>