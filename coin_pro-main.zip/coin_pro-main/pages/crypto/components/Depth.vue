<template>
	<view :style="{width:width+`%`}">
		<view style="display: flex;align-items: center;justify-content: space-between;">
			<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
				{{$fmt.fmtText($t('common.vol'))}}({{code}})
			</view>
			<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
				{{$fmt.fmtText($t('common.price'))}}({{$t('common.unitUSDT')}})
			</view>
			<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
				{{$fmt.fmtText($t('common.vol'))}}({{code}})
			</view>
		</view>

		<view style="display: flex;align-items: center;">
			<view style="flex:0 0 50%;">
				<AsksList :list="data.asks" :max="data.asksMax" dir="row-reverse" />
			</view>
			<view style="flex:0 0 50%;">
				<BidsList :list="data.bids" :max="data.bidsMax"></BidsList>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		// 买卖实时
		name: 'Depth',
		props: {
			// 布局占比
			width: {
				type: Number,
				default: 100
			},
			// 币种
			code: {
				type: String,
				default: 'BTC'
			},
			// 传入数据
			data: {
				type: Object,
				default: {}
			},
		},
	}
</script>

<style>
</style>