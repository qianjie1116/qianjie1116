<template>
	<view>
		<block v-for="(item,index) in list" :key="index">
			<view style="padding:8px 0;" :style="{borderBottom:`1px solid ${$theme.TXT_UNACT}`}">
				<view style="display: flex;align-items: center;">
					<view style="padding-right: 12px;font-size: 14px;">
						{{item.name}}
					</view>
					<view style="font-size: 11px;padding:3px 8px;margin:0 14px"
						:style="{color:item.fx==1?$theme.PRIMARY:$theme.TXT_UNACT}">
						{{item.fxText}}
					</view>
					<view :style="setStyleDirect(item.direct)">
						{{item.directText}}
					</view>
					<view style="font-size: 11px;padding:3px 8px;margin:0 14px" :style="{color:$theme.FALL}">
						{{item.lever+` X`}}
					</view>
					<view style="margin-left: auto;">
						<view class="btn_common" style="margin-left: 0;line-height:24px;"
							:style="{backgroundColor:$theme.convertRGBA($theme.PRIMARY,20)}" @click="handleClose(item)">
							{{$fmt.fmtText($t('common.close'))}}
						</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
					<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('common.price'))}}</view>
					<view>{{$fmt.fmtCrypto(`${item.price}`)}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
					<view :style="{color:$theme.TXT_UNACT}">{{ $fmt.fmtText($t('common.qty')) }}</view>
					<view>{{$fmt.fmtNumber(item.quantity,4)}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
					<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('crypto.total'))}}</view>
					<view>{{$fmt.fmtCrypto(`${item.total}` )}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
					<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('crypto.latestPrice'))}}</view>
					<view>{{$fmt.fmtCrypto(`${item.latestPrice}` )}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
					<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('crypto.fee'))}}</view>
					<view>{{$fmt.fmtCrypto(`${item.fee}` )}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
					<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('crypto.profit'))}}</view>
					<view :style="$theme.setRiseFall(item.direct==1? item.buyPL:item.sellPL)">
						{{$fmt.fmtCrypto(`${item.direct==1? item.buyPL:item.sellPL}` )}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
					<view :style="{color:$theme.TXT_UNACT,borderBottom:`1px dashed ${$theme.PRIMARY}`}"
						@click="setPL(item)">
						{{$fmt.fmtText($t('crypto.takeProfit'))}}
					</view>
					<view :style="$theme.setRiseFall(1)">
						{{ item.takeProfit=='--'?item.takeProfit:$fmt.fmtCrypto(`${item.takeProfit}`) }}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
					<view :style="{color:$theme.TXT_UNACT,borderBottom:`1px dashed ${$theme.PRIMARY}`}"
						@click="setPL(item)">
						{{$fmt.fmtText($t('crypto.stopLoss'))}}
					</view>
					<view :style="$theme.setRiseFall(-1)">
						{{item.stopLoss=='--'?item.stopLoss:$fmt.fmtCrypto(`${item.stopLoss}`)}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
					<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('crypto.floatPL'))}}</view>
					<view :style="$theme.setRiseFall(item.direct==1? item.floatPLBuy:item.floatPLSell)">
						{{$fmt.fmtCrypto(`${item.direct==1? item.floatPLBuy:item.floatPLSell}` )}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}"> {{$fmt.fmtText($t('common.dt'))}}
					</view>
					<view style="font-size:12px;"> {{item.dt}} </view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import * as ext from '../ext.js';
	import * as position from '../position.js';
	export default {
		name: 'PositionSmall',
		props: {
			dark: {
				type: Boolean,
				default: true,
			},
			list: {
				type: Array,
				default: []
			},
		},
		methods: {
			// 设置止盈止损
			setPL(val) {
				this.$emit('action', val);
			},

			// 平仓
			handleClose(val) {
				this.$emit('close', val);
			},

			setStyleDirect(val) {
				return ext.setStyleDirect(val);
			},
		}
	}
</script>

<style>
</style>