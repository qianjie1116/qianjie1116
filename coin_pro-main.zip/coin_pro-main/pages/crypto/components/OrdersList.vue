<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData />
		</template>
		<template v-else>
			<template v-if="$theme.setLayout($C.SMALL)">
				<OrdersSmall :list="list" :heaers="heaers" @cancel="handleCanel" />
			</template>
			<template v-else>
				<OrdersLarge :list="list" :heaers="heaers" @cancel="handleCanel" />
			</template>
		</template>
	</view>
</template>

<script>
	import * as orders from '../orders.js';
	import OrdersSmall from './OrdersSmall.vue';
	import OrdersLarge from './OrdersLarge.vue';
	export default {
		name: 'OrdersList',
		components: {
			OrdersSmall,
			OrdersLarge,
		},
		props: {
			list: {
				type: Array,
				default: []
			},
		},
		computed: {
			heaers() {
				return orders.headerCT
			},
		},
		methods: {
			async handleCanel(val) {
				console.log(`cancel val:`, val);
				const result = await orders.handleCanel(val);
				if (!result) return false;
				// 通知上级组件刷新
				this.$emit('action', true);
			},
		}
	}
</script>

<style>
</style>