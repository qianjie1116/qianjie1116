<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData />
		</template>
		<template v-else>
			<template v-if="$theme.setLayout($C.SMALL)">
				<HistorySmall :list="list" :isspt="isspt" />
			</template>
			<template v-else>
				<HistoryLarge :list="list" :isspt="isspt" />
			</template>
		</template>
	</view>
</template>

<script>
	import * as ext from '../ext.js';
	import HistoryLarge from './HistoryLarge.vue';
	import HistorySmall from './HistorySmall.vue';
	export default {
		name: 'History',
		components: {
			HistoryLarge,
			HistorySmall,
		},
		props: {
			list: {
				type: Array,
				default: []
			},
			// 是否是SPT(币币交易)
			isspt: {
				type: Boolean,
				default: true
			}
		},
		methods: {
			setStyleDirect(val) {
				return ext.setStyleDirect(val);
			},
		}

	}
</script>

<style>
</style>