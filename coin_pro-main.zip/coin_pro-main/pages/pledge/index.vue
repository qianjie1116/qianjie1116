<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.SMALL)">
			<HeaderSmall :dark="isDark" @update:dark="isDark = $event" :title="$t('header.pledge')" />
		</template>

		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<view :style="$theme.setStyleBody()">
			<template v-if="$theme.setLayout($C.SMALL)">
				<view style="display: flex;align-items: center;line-height:2.8;">
					<view>{{$fmt.fmtText($t('pledge.host'))}}</view>
					<image src='/static/show.png' mode="aspectFit" style="padding-left: 20px;"
						:style="$theme.setImageSize(16)"></image>
					<view style="margin-left: auto;" @click="linkRecord()">
						<view style="display: flex;align-items: center;">
							<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
								{{$fmt.fmtText($t('common.record'))}}
							</view>
							<image :src="`/static/arrow_right_small.svg`" mode="aspectFit"
								:style="$theme.setImageSize(12)"></image>
						</view>
					</view>
				</view>
				<view style="border-bottom: 1px solid #AAAAAA;padding-bottom: 20px;font-size:24px;">
					{{$fmt.fmtNumber(13579.9751)}} {{$t('common.unitUSDT')}}
				</view>

				<view style="line-height:1.8;margin: 10px 0;padding:10px 0;border-bottom: 1px solid #AAAAAA;">
					<view style="display: flex;align-items: center;justify-content: space-between; ">
						<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('pledge.today'))}}</view>
						<view>{{$fmt.fmtNumber(0.00)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between; ">
						<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('pledge.income'))}}</view>
						<view>{{$fmt.fmtNumber(23.4040)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between; ">
						<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('pledge.orders'))}}</view>
						<view>{{$fmt.fmtNumber(0)}}</view>
					</view>
				</view>

				<view style="background-color: #1f212d;border-radius: 4px;padding:10px;margin-bottom: 20px;">
					<view style="display: flex;align-items: center;line-height: 3.2;">
						<image src="/static/logo.png" mode="aspectFit" style="padding-right: 20px;"
							:style="$theme.setImageSize(36)"></image>
						<view>{{$t('common.unitUSDT')}}</view>
						<view style="margin-left: auto;">
							Available times： 4/10
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8; ">
						<view :style="{color:$theme.TXT_UNACT}">Limit</view>
						<view>{{$fmt.fmtNumber(1000)}}~{{$fmt.fmtNumber(50000)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8; ">
						<view :style="{color:$theme.TXT_UNACT}">Daily yield</view>
						<view>0.6%~1%</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.8;">
						<view :style="{color:$theme.TXT_UNACT}">Cycle ( Day) </view>
						<view>30</view>
					</view>
					<view class="btn_common" @click="handleSubmit()"
						style="margin: 16px 0;width: 30%;background-color: #536fff;">
						{{$fmt.fmtText($t('common.submit'))}}
					</view>
				</view>
				<view style="background-color: #1f212d;border-radius: 4px;padding:10px;margin-bottom: 20px;">
					<view style="display: flex;align-items: center;line-height: 3.2;">
						<image src="/static/logo.png" mode="aspectFit" style="padding-right: 20px;"
							:style="$theme.setImageSize(36)"></image>
						<view>{{$t('common.unitUSDT')}}</view>
						<view style="margin-left: auto;">
							Available times： 4/10
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8; ">
						<view :style="{color:$theme.TXT_UNACT}">Limit</view>
						<view>{{$fmt.fmtNumber(1000)}}~{{$fmt.fmtNumber(50000)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8; ">
						<view :style="{color:$theme.TXT_UNACT}">Daily yield</view>
						<view>0.6%~1%</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between; line-height: 1.8;">
						<view :style="{color:$theme.TXT_UNACT}">Cycle ( Day) </view>
						<view>30</view>
					</view>
					<view class="btn_common" @click="handleSubmit()"
						style="margin: 16px 0;width: 30%;background-color: #536fff;">
						{{$fmt.fmtText($t('common.submit'))}}
					</view>
				</view>
			</template>

			<template v-if="$theme.setLayout($C.MEDIUM) || $theme.setLayout($C.LARGE)">
				<view style="max-width: 800px;margin: auto;margin-top: 24px;">
					<view style="display: flex;align-items: center;line-height:2.8;">
						<view>{{$fmt.fmtText($t('pledge.host'))}}</view>
						<image src='/static/show.png' mode="aspectFit" style="padding-left: 20px;"
							:style="$theme.setImageSize(16)"></image>
						<view style="margin-left: auto;" @click="linkRecord()">
							<view style="display: flex;align-items: center;">
								<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
									{{$fmt.fmtText($t('common.record'))}}
								</view>
								<image :src="`/static/arrow_right_small.svg`" mode="aspectFit"
									:style="$theme.setImageSize(12)"></image>
							</view>
						</view>
					</view>

					<view style="border-bottom: 1px solid #AAAAAA;padding-bottom: 20px;font-size:48px;">
						{{$fmt.fmtNumber(13579.9751)}} {{$t('common.unitUSDT')}}
					</view>

					<view
						style="display: flex;align-items: center;justify-content: space-between; line-height:2.8;margin: 10px 0;padding:20px 40px;border-bottom: 1px solid #AAAAAA;">
						<view style="text-align: center;">
							<view>{{$fmt.fmtText($t('pledge.today'))}}</view>
							<view>{{$fmt.fmtNumber(0.00)}}</view>
						</view>
						<view style="text-align: center;">
							<view>{{$fmt.fmtText($t('pledge.income'))}}</view>
							<view>{{$fmt.fmtNumber(23.4040)}}</view>
						</view>
						<view style="text-align: center;">
							<view>{{$fmt.fmtText($t('pledge.orders'))}}</view>
							<view>{{$fmt.fmtNumber(0)}}</view>
						</view>
					</view>

					<view style="display: grid; grid-auto-flow: column;column-gap: 10px;">
						<view style="background-color: #1f212d;border-radius: 4px;padding:20px;">
							<view style="display: flex;align-items: center;line-height: 3.2;">
								<image src="/static/logo.png" mode="aspectFit" style="padding-right: 20px;"
									:style="$theme.setImageSize(36)"></image>
								<view>{{$t('common.unitUSDT')}}</view>
								<view style="margin-left: auto;">
									Available times： 4/10
								</view>
							</view>
							<view style="display: grid; grid-auto-flow: column;column-gap: 10px;line-height: 2.4;">
								<view>
									<view>Limit</view>
									<view>{{$fmt.fmtNumber(1000)}}~{{$fmt.fmtNumber(50000)}}</view>
								</view>
								<view>
									<view>Daily yield</view>
									<view>0.6%~1%</view>
								</view>
								<view>
									<view>Cycle ( Day) </view>
									<view>30</view>
								</view>
							</view>
							<view class="btn_common" @click="handleSubmit()"
								style="margin: 16px 0;width: 30%;background-color: #536fff;">
								{{$fmt.fmtText($t('common.submit'))}}
							</view>
						</view>
						<view style="background-color: #1f212d;border-radius: 4px;padding:20px;">
							<view style="display: flex;align-items: center;line-height: 3.2;">
								<image src="/static/logo.png" mode="aspectFit" style="padding-right: 20px;"
									:style="$theme.setImageSize(36)"></image>
								<view>{{$t('common.unitUSDT')}}</view>
								<view style="margin-left: auto;">
									Available times： 4/10
								</view>
							</view>
							<view style="display: grid; grid-auto-flow: column;column-gap: 10px;line-height: 2.4;">
								<view>
									<view>Limit</view>
									<view>{{$fmt.fmtNumber(1000)}}~{{$fmt.fmtNumber(50000)}}</view>
								</view>
								<view>
									<view>Daily yield</view>
									<view>0.6%~1%</view>
								</view>
								<view>
									<view>Cycle ( Day) </view>
									<view>30</view>
								</view>
							</view>
							<view class="btn_common" @click="handleSubmit()"
								style="margin: 16px 0;width: 30%;background-color: #536fff;">
								{{$fmt.fmtText($t('common.submit'))}}
							</view>
						</view>
					</view>
				</view>
			</template>
			<view class="second_medium">
				<view style="font-size: 24px;padding-top: 20px;">{{$t('pledge.desc')}}</view>
				<view style="display: grid; grid-auto-flow: column;column-gap: 10px;width: 50%;">
					<view style="border:1px solid #1f212d;border-radius: 4px;padding:20px;line-height: 1.6;">
						<view>title 质押挖矿说明</view>
						<view>What is staking mining?</view>
						<view style="text-align: right;">09/08/2024 11:11:11</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		components: {},
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
			}
		},
		computed: {

		},

		onShow() {
			if (!this.$linkTo.checkToken()) return false;
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
		},
		onReady() {},
		onHide() {
			console.log(`onHide:`, this.isDark);
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.refreshChild();
			uni.stopPullDownRefresh();
		},
		deactivated() {},

		methods: {
			// 此为驱动子组件强刷的方案。
			refreshChild() {
				this.isUpdate = false;
				this.$nextTick(() => {
					this.isUpdate = true;
				})
			},
			// 设置主题
			toogleTheme(val) {
				this.isDark = val;
				this.refreshChild();
			},

			// 跳转到订单记录。 质押挖矿单独的记录页面
			linkRecord() {
				uni.navigateTo({
					url: this.$linkTo.PAGES + this.$linkTo.PLEDGE_RECORD
				})
			}
		},
	}
</script>

<style>
</style>