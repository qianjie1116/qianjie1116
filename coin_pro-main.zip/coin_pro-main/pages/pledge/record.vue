<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.SMALL)">
			<HeaderSmall :dark="isDark" @update:dark="isDark = $event"
				:title="$t('header.pledge')+` `+$t('common.record')" />
		</template>

		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<view :style="$theme.setStyleBody()">
			<template v-if="$theme.setLayout($C.SMALL)">
				PLEDGE Record
			</template>

			<template v-if="$theme.setLayout($C.MEDIUM) || $theme.setLayout($C.LARGE)">
				PLEDGE Record
			</template>

		</view>
	</view>
</template>

<script>
	export default {
		components: {},
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
			}
		},
		computed: {},

		onShow() {
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
		},
		onReady() {},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			// this.refreshChild();
			uni.stopPullDownRefresh();
		},
		deactivated() {},

		methods: {
			// // 此为驱动子组件强刷的方案。
			// refreshChild() {
			// 	this.isUpdate = false;
			// 	this.$nextTick(() => {
			// 		this.isUpdate = true;
			// 	})
			// },
		},
	}
</script>

<style>
</style>