<template>
	<view class="right_in">
		<view :class="$theme.setLayout($C.SMALL)?`second_small`:`second_medium`">
			<template v-if="!info">
				<view style="text-align: center;" :style="{color:$theme.TXT_UNACT}">
					{{$fmt.fmtText($t('common.emptyData'))}}
				</view>
			</template>
			<template v-else>
				<view v-html="info.content"></view>
			</template>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'QA',
		data() {
			return {
				info: null
			}
		},
		beforeMount() {
			this.getData();
		},
		methods: {
			async getData() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.requestData')),
				});
				const result = await this.$http.get(`api/article/content`, {
					cate_id: 22
				});
				console.log('result:', result);
				if (!result) return false;
				this.info = {
					title: result.title,
					content: result.content,
				}
			},
		}
	}
</script>

<style>
</style>