<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.SMALL)">
			<template v-if="curActive==0">
				<HeaderSmall :dark="isDark" @update:dark="isDark = $event" :title="setTitle" />
			</template>
			<template v-if="curTag != ''">
				<HeaderSmall :dark="isDark" @update:dark="isDark = $event" :title="setTitle" isLink @back="goBack">
					<!-- <view style="padding-left: 10px;" :style="$theme.setImageSize(24)" @click="linkRecord()">
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.record" />
					</view> -->
				</HeaderSmall>
			</template>
		</template>

		<view :style="$theme.setStyleBody()">
			<template v-if="!$theme.setLayout($C.SMALL)">
				<view
					style="display: flex;align-items: center;justify-content: space-between;line-height: 2.6;padding-bottom: 20px;">
					<block v-for="(item,index) in tabs" :key="index">
						<view class="sec_nav_item" :style="setStyleNav(curActive ==index)" @click="changeTab(index)">
							{{item.name}}
						</view>
					</block>
				</view>
			</template>

			<template v-if="curActive==0">
				<template v-if="!$theme.setLayout($C.SMALL)">
					<Overview :dark="isDark" />
				</template>

				<template v-if="$theme.setLayout($C.SMALL)">
					<view style="display: flex;align-items: center;padding-bottom: 24px;">
						<view style="padding-right: 12px;">
							<image :src="!userInfo|| !userInfo.avatar?`/static/logo.png`:userInfo.avatar"
								mode="aspectFit" style="border-radius: 100%;"
								:style="{...$theme.setImageSize(60),border:`1px solid ${$theme.PRIMARY}`}"></image>
						</view>
						<template v-if="userInfo">
							<view style="flex:1;">
								<view>{{userInfo.real_name}}</view>
								<view style="font-size: 12px;padding-top: 8px;" :style="{color:$theme.TXT_UNACT}">
									{{userInfo.mobile}}
								</view>
							</view>
						</template>
					</view>

					<block v-for="(v,k) in tabs.slice(1,tabs.length)" :key="k">
						<view class="menu_item" style="line-height:2.4" @click="changeTab(v.key)">
							<!-- <view>
								<CustomSvg :color="$theme.PRIMARY" :path="v.icon" />
							</view> -->
							<view style="font-size: 14px;flex: auto;" :style="{color:$theme.BASIC_TXT}">
								{{$fmt.fmtText(v.name)}}
							</view>
							<view>
								<CustomSvg :color="$theme.TXT_UNACT" :path="$svg.arrowRight" />
							</view>
						</view>
					</block>
					<view style="display: flex; align-items: center;justify-content: space-between;">
						<view class="btn_common" style="margin:20px;line-height: 40px;width: 100%;" @click="signOut()">
							{{ $fmt.fmtText($t('sigin.out'))}}
						</view>
					</view>
				</template>
			</template>

			<template v-if="curTag==$C.KEY_AUTH_ADVANCED">
				<AuthAdvanced :dark="isDark" />
			</template>

			<template v-if="curTag==$C.KEY_ADDRESS">
				<WalletAddress :dark="isDark" />
			</template>

			<!-- <template v-if="curTag==$C.KEY_BANK">
				<BankCard :dark="isDark" />
			</template> -->

			<template v-if="curTag==$C.KEY_PWD_SIGNIN || curTag==$C.KEY_PWD_PAY">
				<SetPassword :dark="isDark" :pay="curTag==$C.KEY_PWD_PAY" />
			</template>

			<template v-if="curTag==$C.KEY_TERMS">
				<Terms :dark="isDark" />
			</template>

			<template v-if="curTag==$C.KEY_QA">
				<QA :dark="isDark" />
			</template>

			<template v-if="curTag==$C.KEY_REFERRAL">
				<Referral :dark="isDark" />
			</template>

			<template v-if="curTag==$C.KEY_ABOUT">
				<AboutUs :dark="isDark" />
			</template>

			<!-- <template v-if="curTag==$C.KEY_PAPER">
				<Paper :dark="isDark" />
			</template>

			<template v-if="curTag==$C.KEY_HELP">
				<Help :dark="isDark" />
			</template> -->
		</view>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	import Overview from './Overview.vue';
	import AuthAdvanced from './AuthAdvanced.vue';
	import SetPassword from './SetPassword.vue';
	import WalletAddress from './WalletAddress.vue';
	import BankCard from './BankCard.vue';
	import Terms from '../terms/components/Terms.vue';
	import QA from './QA.vue';
	import Referral from './Referral.vue';
	import AboutUs from './AboutUs.vue';
	// import Paper from './Paper.vue';
	// import Help from './Help.vue';
	export default {
		components: {
			Overview,
			AuthAdvanced,
			WalletAddress,
			SetPassword,
			BankCard,
			Terms,
			QA,
			Referral,
			AboutUs,
			// Paper,
			// Help,
		},
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
				tabs: ext.tabs(), // tabs
				curActive: 0, // 当前项
				curTag: '',
				userInfo: null, // 账户信息
			}
		},
		computed: {
			// 当前标题
			setTitle() {
				return this.curTag == this.$C.KEY_REFERRAL ?
					this.$fmt.fmtText(this.$t('referral.title')) :
					this.tabs[this.curActive].name;
			},
		},
		onLoad(opt) {
			console.log(`opt:`, opt);
			this.curTag = opt.tag || this.curTag;
			// this.curTitle = this.titles.get(this.curTag);
			this.curActive = this.tabs.findIndex(item => item.key == this.curTag);
		},

		onShow() {
			if (!this.$linkTo.checkToken()) return false;
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
			console.log(this.tabs);
			this.changeTab(this.curActive);
			this.getAccount();
		},
		onHide() {
			console.log(`onHide:`, this.isDark);
			this.isAnimat = false;
		},
		deactivated() {},
		onPullDownRefresh() {
			this.changeTab(this.curActive);
			this.getAccount();
			uni.stopPullDownRefresh();
		},
		methods: {
			// 回退
			goBack() {
				if (this.curActive == 0) {
					this.$linkTo.home();
				} else {
					this.curActive = 0;
					this.changeTab(this.curActive);
				}
			},

			// 导航跳转
			changeTab(val) {
				console.log(val);
				if (typeof(val) === 'number') {
					this.curActive = val;
					console.log(`val:`, this.tabs[this.curActive]);
					this.curTag = this.tabs[this.curActive].key;
				} else {
					console.log(`val:`, this.tabs[this.curActive]);
					this.curActive = this.tabs.findIndex(item => item.key == val);
					this.curTag = this.tabs[this.curActive].key;
				}
			},

			async getAccount() {
				const result = await ext.getAccount();
				this.userInfo = result;
			},
			// 登出
			signOut() {
				uni.removeStorageSync('token');
				this.$linkTo.home();
			},

			// 导航激活样式
			setStyleNav(val) {
				return {
					color: val ? this.$theme.PRIMARY : this.$theme.TXT_UNACT,
					borderBottom: `1px solid  ${val?this.$theme.PRIMARY_TXT:this.$theme.TRANSPARENT}`,
				}
			}
		}
	}
</script>

<style>
</style>