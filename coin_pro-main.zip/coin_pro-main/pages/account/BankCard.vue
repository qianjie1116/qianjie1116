<template>
	<view class="left_in">
		<view :class="$theme.setLayout($C.SMALL)?`second_small`:`second_medium`">
			<!-- 真实姓名 -->
			<view style="font: 14px;font-weight: 700;margin-bottom: 8px;">
				{{$fmt.fmtText($t('bank.real'))}}
			</view>
			<view class="input_wrapper" :style="$theme.setInputStyle(dark)">
				<input v-model="realName" type="text" :placeholder="$fmt.fmtText($t('common.enter')+$t('bank.real'))"
					:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
			</view>

			<!-- 银行名称 -->
			<view style="font: 14px;font-weight: 700;margin-bottom: 8px;margin-top: 24px;">
				{{$fmt.fmtText($t('bank.name'))}}
			</view>
			<view class="input_wrapper" :style="$theme.setInputStyle(dark)">
				<input v-model="bankName" type="text" :placeholder="$fmt.fmtText($t('common.enter')+$t('bank.name'))"
					:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
			</view>

			<!-- 银行卡号 -->
			<view style="font: 14px;font-weight: 700;margin-bottom: 8px;margin-top: 24px;">
				{{$fmt.fmtText($t('bank.card'))}}
			</view>
			<view class="input_wrapper" :style="$theme.setInputStyle(dark)">
				<input v-model="cardNumber" type="text" :placeholder="$fmt.fmtText($t('common.enter')+$t('bank.card'))"
					:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
			</view>

			<view class="btn_common" @click="handleSubmit()" style="margin: 24px 0;line-height: 40px;">
				{{$fmt.fmtText($t('common.submit')) }}
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'BankCard',
		props: {
			dark: {
				type: Boolean,
				default: true,
			},
		},
		data() {
			return {
				realName: '', // 真实姓名
				bankName: '', // 银行名称
				cardNumber: '', // 银行卡号
			}
		},
		methods: {
			// 检查表单
			checkForm() {
				if (this.realName == '') {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('bank.real')),
						icon: 'none'
					});
					return false;
				}
				if (this.bankName == '') {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('bank.name')),
						icon: 'none'
					});
					return false;
				}
				if (this.cardNumber == '') {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('bank.card')),
						icon: 'none'
					});
					return false;
				}
				return true;
			},

			// 提交事件
			async handleSubmit() {
				if (!this.checkForm()) return false;
				uni.showToast({
					title: this.$fmt.fmtText(this.$t('api.submiting')),
					icon: 'loading',
				});
				const result = await this.$http.post(`api/user/bindBankCard`, {
					realname: this.realName,
					bank_name: this.bankName,
					card_sn: this.cardNumber,
				})
				console.log(result);
				if (!result) return false;
				uni.showToast({
					title: this.$fmt.fmtText(this.$t('common.success')),
					icon: 'success',
				});
				setTimeout(() => {
					// 切换到银行卡列表
				}, 1000)
			},
		}
	}
</script>

<style>
</style>