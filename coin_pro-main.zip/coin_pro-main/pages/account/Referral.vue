<template>
	<view class="left_in">
		<view :class="$theme.setLayout($C.SMALL)?`second_small`:`second_medium`">
			<view style="padding:12px;">
				<template v-if="userInfo">
					<view style="display: flex;align-items: center;padding-bottom: 24px;">
						<image src="/static/logo.png" mode="aspectFit" :style="$theme.setImageSize(40)"></image>
						<view style="padding-left: 20px;">
							<view style="font-size: 16px;">{{userInfo.real_name}}</view>
							<view :style="{color:$theme.TXT_UNACT}">{{userInfo.mobile}}</view>
						</view>
					</view>
					<view style="">{{$fmt.fmtText($t('referral.code'))}}</view>
					<view style="display: flex;align-items: center;">
						<view :style="{color:$theme.TXT_UNACT}">{{userInfo.invite}}</view>
						<view style="padding-left: 24px;" @tap="handleCopy(userInfo.invite)">
							<view style="display: flex;align-items: center;">
								<view style="font-size: 12px;padding-right:4px;" :style="{color:$theme.PRIMARY}">
									{{$fmt.fmtText($t('common.copy'))}}
								</view>
								<CustomSvg :color="$theme.PRIMARY" :path="$svg.copy" />
							</view>
						</view>
					</view>
				</template>

				<view style="padding-top: 8px;">{{$fmt.fmtText($t('referral.link'))}}</view>
				<view style="display: flex;align-items: center;">
					<view style="word-wrap: break-word;font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{shareLink}}
					</view>
					<view style="padding-left: 24px;" @tap="handleCopy(shareLink)">
						<view style="display: flex;align-items: center;">
							<view style="font-size: 12px;padding-right: 4px;width: 70%;"
								:style="{color:$theme.PRIMARY}">
								{{$fmt.fmtText($t('common.copy'))}}
							</view>
							<CustomSvg :color="$theme.PRIMARY" :path="$svg.copy" />
						</view>
					</view>
				</view>
			</view>

			<view style="display: flex;align-items: center;flex-wrap: wrap;">
				<view style="flex: 0 0 50%;">
					<view style="border-radius: 12px;padding:12px 6px;margin:12px 12px 0 0;"
						:style="{backgroundColor:$theme.convertRGBA('#935EBD',20)}">
						<view style="text-align: center;font-size: 18px;font-weight:bold;line-height: 2;">
							97</view>
						<view style="display: flex;align-items: center;justify-content: center;">
							<image src="@/assets/invite1.png" mode="aspectFit" :style="$theme.setImageSize(48)">
							</image>
							<view style="padding-left: 6px;">{{$fmt.fmtText($t('referral.invited'))}}</view>
						</view>
					</view>
				</view>
				<view style="flex: 0 0 50%;">
					<view style=" border-radius: 12px;padding:12px 6px;margin:12px 12px 0 0;"
						:style="{backgroundColor:$theme.convertRGBA('#2196F3',20)}">
						<view style="text-align: center;font-size: 18px;font-weight:bold;line-height: 2;">
							75</view>
						<view style="display: flex;align-items: center;justify-content: center;">
							<image src="@/assets/invite2.png" mode="aspectFit" :style="$theme.setImageSize(48)">
							</image>
							<view style="padding-left: 6px;">{{$fmt.fmtText($t('referral.act'))}}</view>
						</view>
					</view>
				</view>
				<view style="flex: 0 0 50%;">
					<view style=" border-radius: 12px;padding:12px 6px;margin:12px 12px 0 0;"
						:style="{backgroundColor:$theme.convertRGBA('#3F51B5',20)}">
						<view style="text-align: center;font-size: 18px;font-weight:bold;line-height: 2;">
							35,000</view>
						<view style="display: flex;align-items: center;justify-content: center;">
							<image src="@/assets/invite3.png" mode="aspectFit" :style="$theme.setImageSize(48)">
							</image>
							<view style="padding-left: 6px;">{{$fmt.fmtText($t('referral.day'))}}</view>
						</view>
					</view>
				</view>
				<view style="flex: 0 0 50%;">
					<view style=" border-radius: 12px;padding:12px 6px;margin:12px 12px 0 0;"
						:style="{backgroundColor:$theme.convertRGBA('#01C5C4',20)}">
						<view style="text-align: center;font-size: 18px;font-weight:bold;line-height: 2;">
							79,000</view>
						<view style="display: flex;align-items: center;justify-content: center;">
							<image src="@/assets/invite4.png" mode="aspectFit" :style="$theme.setImageSize(48)">
							</image>
							<view style="padding-left: 6px;">{{$fmt.fmtText($t('referral.accrue'))}}</view>
						</view>
					</view>
				</view>
			</view>

			<view style="padding:12px 0;">
				<view style="font: 28rpx;font-weight: 700;line-height: 3;">
					{{$fmt.fmtText($t('referral.rule'))}}
				</view>
				<template v-if="rule">
					<view v-html="rule" style="font-weight: 100;"></view>
					<!-- <block v-for="(v,k) in rule" :key="k">
						<view style="padding-bottom: 12rpx;" :style="{color:$theme.TXT_UNACT}">
							<text style="font-size: 28rpx;">{{k+1+`. `}}</text>
							{{v}}
						</view>
					</block> -->
				</template>
			</view>
		</view>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	import {
		getReferral
	} from '@/rules/index.js';
	export default {
		name: 'Referral',
		data() {
			return {
				userInfo: null,
				rule: null
			}
		},
		computed: {
			// 邀请链接
			shareLink() {
				if (this.userInfo) {
					const temp = window.location.origin + `/#`;
					return temp + this.$linkTo.SIGN_IN + `?code=${this.userInfo.invite}`;
					// return temp
				}
			}
		},
		beforeMount() {
			this.getAccount();
			const temp = uni.getStorageSync('locale');
			this.rule = getReferral(temp);
		},
		methods: {
			// 获取账户绑定的所有钱包地址。
			async getAccount() {
				const result = await ext.getAccount();
				console.log(result);
				this.userInfo = result;
			},

			async handleCopy(val) {
				const result = await uni.setClipboardData({
					data: val, //要被复制的内容
				});
				if (result[1].confirm) {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.success')),
						duration: 2000,
						icon: 'success'
					})
				}
			},
		}
	}
</script>

<style>
</style>