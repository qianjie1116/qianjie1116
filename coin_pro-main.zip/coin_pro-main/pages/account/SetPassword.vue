<template>
	<view :class="pay?`right_in`:`left_in`">
		<view :class="$theme.setLayout($C.SMALL)?`second_small`:`second_medium`">
			<!-- 旧密码 -->
			<view style="font: 14px;font-weight: 700;margin-bottom: 8px;">
				{{$fmt.fmtText($t('pwd.old'))}}
			</view>
			<view class="input_wrapper" :style="$theme.setInputStyle(dark)">
				<input v-model="oldPwd" :password="isMask" :placeholder="$fmt.fmtText($t('common.enter')+$t('pwd.old'))"
					:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
				<view style="margin-left: auto;padding-right: 10px;">
					<CustomSvg :color="$theme.PRIMARY" :size="18" :path="isMask?$svg.mask:$svg.unmask"
						@click="toggleMask()" />
				</view>
			</view>

			<!-- 新密码 -->
			<view style="font: 14px;font-weight: 700;margin-bottom: 8px;margin-top: 24px;">
				{{$fmt.fmtText($t('pwd.new'))}}
			</view>
			<view class="input_wrapper" :style="$theme.setInputStyle(dark)">
				<input v-model="newPwd" :password="isMask" :placeholder="$fmt.fmtText($t('common.enter')+$t('pwd.new'))"
					:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
				<view style="margin-left: auto;padding-right: 10px;">
					<CustomSvg :color="$theme.PRIMARY" :size="18" :path="isMask?$svg.mask:$svg.unmask"
						@click="toggleMask()" />
				</view>
			</view>

			<!-- 确认新密码 -->
			<view style="font: 14px;font-weight: 700;margin-bottom: 8px;margin-top: 24px;">
				{{$fmt.fmtText($t('pwd.newConfim'))}}
			</view>
			<view class="input_wrapper" :style="$theme.setInputStyle(dark)">
				<input v-model="confimPwd" :password="isMask"
					:placeholder="$fmt.fmtText($t('common.enter')+$t('pwd.newConfim'))"
					:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
				<view style="margin-left: auto;padding-right: 10px;">
					<CustomSvg :color="$theme.PRIMARY" :size="18" :path="isMask?$svg.mask:$svg.unmask"
						@click="toggleMask()" />
				</view>
			</view>

			<view class="btn_common" @click="handleSubmit()" style="margin: 24px 0;line-height: 40px;">
				{{$fmt.fmtText($t('common.submit')) }}
			</view>

			<view style="padding-top: 40px;line-height: 2.4;" :style="{color:$theme.PRIMARY}"
				@click="$util.linkCustomerService()">
				{{ $fmt.fmtText($t('pwd.tip'))}}
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'SetPassword',
		props: {
			dark: {
				type: Boolean,
				default: true,
			},
			pay: {
				type: Boolean,
				default: false
			},
		},
		data() {
			return {
				isMask: null, // 是否掩码
				oldPwd: "", // 旧密码
				newPwd: "", // 新密码
				confimPwd: "", // 验证新密码
			};
		},
		computed: {},
		beforeMount() {
			this.isMask = uni.getStorageSync('masking'); // 当前掩码状态
		},
		methods: {
			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
			// 检查表单
			checkForm() {
				if (this.oldPwd == '') {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('pwd.old')),
						icon: 'none'
					});
					return false;
				}
				if (this.newPwd == '') {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('pwd.new')),
						icon: 'none'
					});
					return false;
				}
				if (this.confimPwd == '') {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('pwd.newConfim')),
						icon: 'none'
					});
					return false;
				}
				if (this.newPwd != this.confimPwd) {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('tip.towPwdDiff')),
						icon: 'none'
					});
					return false;
				}
				return true;
			},
			// 提交事件
			handleSubmit() {
				if (!this.checkForm()) return false;
				this.updatePassword();
			},
			//修改密码
			async updatePassword() {
				uni.showToast({
					title: this.$fmt.fmtText(this.$t('api.submiting')),
					icon: 'loading',
				});
				const temp = this.pay ? `updatePayPassword` : `updateLoginPassword`
				const result = await this.$http.post(`api/user/${temp}`, {
					oldpass: this.oldPwd,
					newpass: this.newPwd,
					confirmpass: this.confimPwd,
				});
				console.log(result);
				if (!result) return false;
				uni.showToast({
					title: this.$fmt.fmtText(this.$t('common.success')),
					icon: 'success'
				});
				setTimeout(() => {
					this.$linkTo.home();
				}, 1000)
			},
		}
	}
</script>

<style>
</style>