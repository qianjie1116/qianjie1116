<template>
	<view class="right_in">
		<view :class="$theme.setLayout($C.SMALL)?`second_small`:`second_medium`">
			Help
		</view>
	</view>
</template>

<script>
	export default {
		name: 'Help'
	}
</script>

<style>
</style>