<template>
	<view class="left_in">
		<view :class="$theme.setLayout($C.SMALL)?`second_small`:`second_medium`">
			<template v-if="!wallets || wallets.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(v,k) in wallets" :key="k">
					<view class="input_wrapper" :style="$theme.setInputStyle(dark)">
						<view style="margin-right: auto;width: 100px;font-weight: 700;" :style="{color:$theme.PRIMARY}">
							{{v.huobi}}
						</view>
						<input v-model="v.address" :password="isMask" :placeholder-style="$theme.setPlaceholder()"
							style="flex:auto;"></input>

						<view style="margin-left: auto;">
							<view style="display: flex;align-items: center;">
								<view style="padding-right: 6px;" @click="toggleMask()">
									<CustomSvg :color="$theme.PRIMARY" :path="isMask?$svg.mask:$svg.unmask" />
								</view>
								<view style="padding-right: 6px;" @click="handleCopy(v.address)">
									<CustomSvg :color="$theme.PRIMARY" :path="$svg.copy" />
								</view>
								<view style="padding-right: 6px;" @click="handleEdit(v)">
									<CustomSvg :color="$theme.PRIMARY" :path="$svg.edit" />
								</view>
							</view>
						</view>
					</view>
				</block>

				<view class="btn_common" @click="handleAdd()" style="margin: 24px 0;line-height: 40px;">
					{{$fmt.fmtText($t('wallet.add')) }}
				</view>
			</template>

			<!-- 浮层 -->
			<template v-if="isShow">
				<ModalWallet :info="curInfo" @action="closeModal" />
			</template>

		</view>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	import ModalWallet from './ModalWallet.vue';
	export default {
		name: 'WalletAddress',
		components: {
			ModalWallet
		},
		props: {
			dark: {
				type: Boolean,
				default: true,
			},
		},
		data() {
			return {
				wallets: null,
				isMask: null, // 是否掩码
				isShow: false, // 是否显示浮层
				curInfo: null, // 选中的钱包
			}
		},
		beforeMount() {
			this.isMask = uni.getStorageSync('masking'); // 当前掩码状态
			this.getAccount();
		},
		methods: {
			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},

			// 新增
			handleAdd() {
				console.log(`add`, this.curInfo);
				this.isShow = true;
			},

			// 编辑
			handleEdit(val) {
				this.curInfo = val;
				this.isShow = true;
			},

			// 复制
			async handleCopy(val) {
				const result = await uni.setClipboardData({
					data: val, //要被复制的内容
				});
				if (result[1].confirm) {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.copy') + this.$t('common.success')),
						duration: 2000,
						icon: 'success'
					})
				}
			},

			// 关闭浮层
			closeModal(val) {
				this.isShow = false;
				this.curInfo = null; // 每次关闭浮层，清理该值
				this.getAccount();
			},

			// 获取账户绑定的所有钱包地址。
			async getAccount() {
				const result = await ext.getAccount();
				console.log(result);
				this.wallets = result.bank_card_info || [];
			},
		}
	}
</script>

<style>
</style>