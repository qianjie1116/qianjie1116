<template>
	<view class="right_in">
		<view :class="$theme.setLayout($C.SMALL)?`second_small`:`second_medium`">
			<!-- 账号 -->
			<view style="font: 14px;font-weight: 700;margin-bottom: 8px;">
				{{$fmt.fmtText($t('auth.realName'))}}
			</view>
			<view class="input_wrapper" :style="$theme.setInputStyle(dark)">
				<input v-model="realName" type="text"
					:placeholder="$fmt.fmtText($t('common.enter')+ $t('auth.realName'))"
					:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
			</view>

			<!-- ID  -->
			<view style="font: 14px;font-weight: 700;margin-top: 20px;margin-bottom: 8px;">
				{{$fmt.fmtText($t('auth.id'))}}
			</view>
			<view class="input_wrapper" :style="$theme.setInputStyle(dark)">
				<input v-model="cardID" :password="isMask" :placeholder="$fmt.fmtText($t('common.enter')+$t('auth.id'))"
					:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>

				<view style="margin-left: auto;padding-right: 10px;" @click="toggleMask()">
					<CustomSvg :color="$theme.PRIMARY" :path="isMask?$svg.mask:$svg.unmask" />
				</view>
			</view>

			<!-- 证件上传 -->
			<view style="display: flex;align-items: center;flex-wrap: wrap;justify-content: space-between;">
				<view>
					<view style="font: 14px;font-weight: 700;margin-top: 24px;margin-bottom: 8px;">
						{{$fmt.fmtText($t('auth.front'))}}
					</view>

					<view @click="selectImg('front')"
						style="display: flex;align-items: center;justify-content: center;padding: 24px;border-radius: 8rpx;border: 1px solid #AAAAAA;">
						<template v-if="!frontURL">
							<view
								style="margin:20rpx;width:220px;height:120px;display: flex;align-items: center;justify-content: center;flex-direction: column;">
								<image src="/static/icon_upload.png" mode="aspectFit" :style="$theme.setImageSize(96)">
								</image>
							</view>
						</template>
						<template v-else>
							<image :src="frontURL" style="margin:20rpx;width:220px;height:120px;">
							</image>
						</template>
					</view>
				</view>
				<view>
					<view style="font: 14px;font-weight: 700;margin-top: 24px;margin-bottom: 8px;">
						{{$fmt.fmtText($t('auth.back'))}}
					</view>

					<view @click="selectImg('back')"
						style="display: flex;align-items: center;justify-content: center;padding: 24px;border-radius: 8rpx;border: 1px solid #AAAAAA;">
						<template v-if="!backURL">
							<view
								style="margin:20rpx;width:220px;height:120px;display: flex;align-items: center;justify-content: center;flex-direction: column;">
								<image src="/static/icon_upload.png" mode="aspectFit" :style="$theme.setImageSize(96)">
								</image>
							</view>
						</template>
						<template v-else>
							<image :src="backURL" style="margin:20rpx;width:220px;height:120px;">
							</image>
						</template>
					</view>
				</view>
			</view>

			<view class="btn_common" @click="handleSubmit()" style="margin: 24px 0;line-height: 40px;">
				{{$fmt.fmtText($t('common.submit')) }}
			</view>

		</view>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	export default {
		name: 'AuthAdvanced',
		props: {
			dark: {
				type: Boolean,
				default: true,
			},
		},
		data() {
			return {
				isMask: null, // 是否掩码
				realName: '', // 真实姓名
				cardID: '', // ID 卡号
				frontURL: null, // 正面照
				backURL: null, // 背面照
			};
		},
		computed: {},
		beforeMount() {
			this.isMask = uni.getStorageSync('masking'); // 当前掩码状态
			this.getAccount();
		},
		methods: {
			// masking 开关
			toggleMask() {
				this.isMask = !this.isMask;
				this.$util.setDataMask(this.isMask);
			},
			// 获取账户信息
			async getAccount() {
				const result = await ext.getAccount();
				this.realName = result.real_name || '';
				this.cardID = result.idno || '';
				this.frontURL = result.front_image || '';
				this.backURL = result.back_image || '';
			},

			// 提交
			async handleSubmit() {
				if (!this.realName || this.realName == '') {
					uni.showToast({
						title: this.$t('common.enter') + this.$t('auth.realName'),
						icon: 'none'
					});
					return false;
				}
				if (!this.cardID || this.cardID == '') {
					uni.showToast({
						title: this.$t('common.enter') + this.$t('auth.id'),
						icon: 'none'
					});
					return false;
				}
				uni.showLoading({
					title: this.$t('api.submiting'),
				});
				const result = await this.$http.post(`api/user/real-auth1`, {
					real_name: this.realName,
					idno: this.cardID,
					front_image: this.frontURL || '',
					back_image: this.backURL || '',
				});
				if (!result) return false;
				console.log('result:', result);
				uni.showToast({
					// title: result,
					icon: 'success'
				});
				setTimeout(() => {
					this.$linkTo.home();
				}, 1000);
			},
			// 点击上传
			async selectImg(val) {
				const result = await uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
				});
				console.log('result:', result);
				const imageFile = result[1].tempFiles[0];
				console.log('imageFile:', imageFile);
				const reultURL = await this.$http.uploadImage(imageFile.path);
				console.log(`resultURL:`, reultURL);
				if (!reultURL) return false;
				if (val == 'front') {
					this.frontURL = reultURL;
					console.log(`frontURL:`, this.frontURL);
				}
				if (val == 'back') {
					this.backURL = reultURL;
					console.log(`backURL:`, this.backURL);
				}
			},
		}
	}
</script>

<style>
</style>