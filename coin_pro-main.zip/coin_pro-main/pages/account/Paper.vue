<template>
	<view class="left_in">
		<view :class="$theme.setLayout($C.SMALL)?`second_small`:`second_medium`">
			Paper
		</view>
	</view>
</template>

<script>
	export default {
		name:'Paper',
	}
</script>

<style>
</style>