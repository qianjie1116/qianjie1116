<template>
	<view>
		<view class="overlay" style="background-color: rgba(0, 0, 0, 0.1);" @click="modalClose()"></view>
		<view :class="[$theme.setLayout($C.SMALL)?`modal_wrapper_bottom`:`modal_wallet_center`,'bottom_in' ]"
			:style="{backgroundColor:$theme.BASIC_BG}">
			<view style="min-height: 30vh;padding:12px 12px 24px 12px;">
				<view style="display: flex;align-items: center;padding-bottom: 12px;">
					<view style="width: 24px;"></view>
					<view style="flex:1;text-align:center;">
						<text style="padding-bottom: 4px;" :style="{borderBottom:`1px solid ${$theme.PRIMARY}`}">
							{{setTitle}}
						</text>
					</view>
					<view style="margin-left: auto;">
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.close" @click="modalClose()" />
					</view>
				</view>

				<view style="position: relative;">
					<view class="input_wrapper" :style="$theme.setInputStyle(dark)">
						<template v-if="curCrypto">
							<view style="margin-right: auto;" @click="showSelect()">
								<CustomSvg :color="$theme.PRIMARY" :size="16" :path="$svg.arrowDown" />
							</view>
							<view style="width: 100px;padding-left: 8px;" @click="showSelect()">
								<view style="padding-right: 12px;" :style="{color:$theme.PRIMARY}">
									{{curCrypto}}
								</view>
							</view>
							<input v-model="address" type="text"
								:placeholder="$fmt.fmtText($t('common.enter')+$t('common.address'))"
								:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
						</template>
					</view>
					<template v-if="isSelect">
						<view style="position: absolute;z-index: 9;left: 0; background-color: #0a0c13;">
							<block v-for="(v,k) in cryptos" :key="k">
								<view style="text-align: center;padding:10px 20px;" @click="chooseCrypto(v)">
									{{v}}
								</view>
							</block>
						</view>
						<view class="overlay" @click.stop="isSelect=false"> </view>
					</template>
				</view>

				<view style="display: flex; align-items: center;justify-content: space-between;padding: 12px 0;">
					<view class="btn_common" style="margin: 24px 0;line-height: 40px;width: 40%;" @click="handleDel()">
						{{ $fmt.fmtText($t('common.delete'))}}
					</view>
					<view class="btn_common" style="margin: 24px 0;line-height: 40px;width: 40%;"
						:style="{backgroundColor:$theme.PRIMARY}" @click="handleSubmit()">
						{{ $fmt.fmtText($t('common.submit'))}}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	export default {
		name: 'ModalWallet',
		props: {
			dark: {
				type: Boolean,
				default: true,
			},
			info: {
				type: Object,
				default: {}
			}
		},
		data() {
			return {
				address: '', // 输入的地址
				cryptos: ext.cryptos, // 备选组
				curCrypto: '', // 选中
				curIndex: '', // 当前选中
				isSelect: false, // 是否显示选项组
			}
		},
		computed: {
			setTitle() {
				return this.$fmt.fmtText(this.$t('account.address'))
			}
		},
		beforeMount() {
			// this.crypto = !this.info ? '' : this.info.huobi;
			this.address = !this.info ? '' : this.info.address;
			this.curCrypto = !this.info ? this.cryptos[0] : this.info.huobi;
		},
		methods: {
			// 关闭浮层
			modalClose() {
				this.amount = '';
				this.$emit('action', 1);
			},
			// 显示选项组
			showSelect() {
				this.isSelect = true;
			},
			// 选中crypto
			chooseCrypto(val) {
				this.curCrypto = val;
				this.isSelect = false;
			},
			// 删除
			async handleDel() {
				const result = await this.$http.post(`api/user/deladdress`, {
					id: this.info.id
				});
				if (!result) return false;
				uni.showToast({
					title: this.$fmt.fmtText(this.$t('common.success')),
					icon: 'success'
				});
				setTimeout(() => {
					this.modalClose();
				}, 1000);
			},

			// 提交
			async handleSubmit() {
				if (this.curCrypto == '') {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('wallet.crypto')),
						icon: 'none'
					})
					return false;
				}
				if (this.address == '') {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('account.address')),
						icon: 'none'
					})
					return false;
				}
				const temp = this.cryptos.findIndex(item => item === this.curCrypto);
				const result = await this.$http.post(`api/user/bindBankCard`, {
					address: this.address,
					type: temp + 1,
					huobi: this.curCrypto, // huobi: ERC20-USDT / TRC20-USDT
					// 未用到
					id: !this.info ? '' : this.info.id,
					realname: '',
					bank_name: '',
					bank_sub_name_address: '',
					bank_code: '',
				});
				if (!result) return false;
				console.log(`result:`, result);
				uni.showToast({
					title: this.$fmt.fmtText(this.$t('common.success')),
					icon: 'success'
				});
				setTimeout(() => {
					this.modalClose();
				}, 1000);
			}
		}
	}
</script>

<style>
</style>