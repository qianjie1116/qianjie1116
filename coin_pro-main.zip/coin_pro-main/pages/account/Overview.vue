<template>
	<view class="left_in">
		<view :class="$theme.setLayout($C.SMALL)?`second_small`:`second_medium`">
			<view style="display: flex;align-items: center;padding-bottom: 24px;">
				<view style="padding-right: 12px;">
					<image :src="!userInfo|| !userInfo.avatar?`/static/logo.png`:userInfo.avatar" mode="aspectFit"
						style="border-radius: 100%;"
						:style="{...$theme.setImageSize(60),border:`1px solid ${$theme.PRIMARY}`}"></image>
				</view>
				<template v-if="userInfo">
					<view style="flex:1;">
						<view>{{userInfo.real_name}}</view>
						<view style="font-size: 12px;padding-top: 8px;" :style="{color:$theme.TXT_UNACT}">
							{{userInfo.mobile}}
						</view>
					</view>
				</template>
			</view>

			<template v-if="!$theme.setLayout($C.SMALL)">
				<view style="font-size: 14px;font-weight: 500;">{{$fmt.fmtText($t('assets.detail'))}}</view>
				<RecordLarge :list="list" />
			</template>
		</view>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	import RecordLarge from './components/RecordLarge.vue';
	export default {
		name: 'Overview',
		components: {
			RecordLarge
		},
		props: {
			dark: {
				type: Boolean,
				default: true,
			}
		},
		data() {
			return {
				curLanguage: null, // 语言
				tabs: ext.tabs(),
				userInfo: null, // 账户信息
				list: null,
			};
		},
		computed: {},
		beforeMount() {
			this.getAccount();
			this.getAssetsList();
		},
		methods: {
			async getAccount() {
				const result = await ext.getAccount();
				this.userInfo = result;
			},
			async getAssetsList() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.requestData')),
				});
				const result = await this.$http.post(`api/user/assets`, {
					type: 2, // 2:assets 1:contract
					hide_money: this.isHideZero ? 1 : 0,
				});
				if (!result) return false;
				console.log(`assets:`, result);
				this.list = result;
			},

			async getContractList() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.requestData')),
				});
				const result = await this.$http.post(`api/user/finance`, {
					type: this.curTab == 1 ? 1 : 3, // 合約賬戶
					name: 'USDT',
				});
				if (!result) return false;
				console.log(`contract:`, result);
				this.list = result;
			},
		}
	}
</script>

<style>
</style>