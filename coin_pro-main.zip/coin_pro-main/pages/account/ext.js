// account
import Vue from 'vue';
import i18n from '@/locales/index.js';
import * as constants from '@/common/constants.js';
import * as fmt from '@/common/format.js';
import http from '@/common/http.js';
import * as icons from '@/icons/index.js';

// tabs
export const tabs = () => {
	return [{
			key: '',
			name: fmt.fmtText(i18n.t('account.overview')),
		},
		// {
		// 	key: constants.KEY_AUTH_PRIMARY,
		// 	name: fmt.fmtText(i18n.t('account.authPrimary')),
		// }, 
		{
			key: constants.KEY_AUTH_ADVANCED,
			name: fmt.fmtText(i18n.t('account.authAdvanced')),
			icon: icons.auth,
		}, {
			key: constants.KEY_ADDRESS,
			name: fmt.fmtText(i18n.t('account.address')),
			icon: icons.address,
		},
		// {
		// 	key: constants.KEY_BANK,
		// 	name: fmt.fmtText(i18n.t('account.bank')),
		// icon:'',
		// }, 
		{
			key: constants.KEY_PWD_SIGNIN,
			name: fmt.fmtText(i18n.t('account.pwdSign')),
			icon: icons.pwdSign,
		}, {
			key: constants.KEY_PWD_PAY,
			name: fmt.fmtText(i18n.t('account.pwdPay')),
			icon: icons.pwdPay,
		},
		{
			key: constants.KEY_TERMS,
			name: fmt.fmtText(i18n.t('account.terms')),
			icon: icons.terms,
		},
		{
			key: constants.KEY_QA,
			name: fmt.fmtText(i18n.t('account.qa')),
			icon: icons.qa,
		},
		{
			key: constants.KEY_REFERRAL,
			name: fmt.fmtText(i18n.t('account.referral')),
			icon: icons.referral,
		},
		{
			key: constants.KEY_ABOUT,
			name: fmt.fmtText(i18n.t('account.about')),
			icon: icons.about,
		},
		// {
		// 	key: constants.KEY_PAPER,
		// 	name: fmt.fmtText(i18n.t('account.paper')),
		// 	icon: icons.paper,
		// },
		// {
		// 	key: constants.KEY_HELP,
		// 	name: fmt.fmtText(i18n.t('account.help')),
		// 	icon: icons.help,
		// },

	]
};

// 钱包地址可绑定crypto组
export const cryptos = [
	'ERC20-USDT',
	'TRC20-USDT',
	'BTC',
	'ETH',
	'TRX'
];

export const headers = () => {
	return {
		token: {
			flex: 1,
			text: fmt.fmtText(i18n.t('assets.token'))
		},
		money: {
			flex: 1,
			text: fmt.fmtText(i18n.t('assets.amount'))
		},
		freeze: {
			flex: 1,
			text: fmt.fmtText(i18n.t('assets.amount'))
		},
		total: {
			flex: 1,
			text: fmt.fmtText(i18n.t('assets.amount'))
		},
	}
}


// 获取账户信息
export const getAccount = async () => {
	uni.showLoading({
		title: i18n.t('api.requestData'),
	});
	const result = await http.get(`api/user/fastInfo`);
	if (!result) return false;
	return result;
};