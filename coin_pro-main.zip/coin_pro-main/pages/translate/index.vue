<template>
	<view :style="$theme.setPageStyle(isDark)">
		<header class="header">
			<view class="left" @click="$util.goBack()">
				<image :src="`/static/go-back_${isDark?0:1}.svg`" mode="aspectFit" :style="$theme.setImageSize(20)"
					style="cursor: pointer;">
				</image>
			</view>
			<view class="center" :class="[`center_${isDark?0:1}`]" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.PAGE_TITLE}">{{curLanguage}}</text>
			</view>
			<view class="right" @click="$util.linkCustomerService()">
				<image :src="`/static/service_${isDark?0:1}.svg`" mode="aspectFit" :style="$theme.setImageSize()"
					style="cursor: pointer;">
				</image>
			</view>
		</header>

		<view style="padding:16px;font-size: 16px;">{{$t('common.selectLanguage')}}</view>

		<view style="line-height: 2;">
			<block v-for="(item,index) in list" :key="index">
				<view style="display: flex;align-items: center;padding:8px 16px;cursor: pointer;"
					@click="chooseLang(item,index)">
					<image :src="`/static/flags/${item.flag}.svg`" mode="scaleToFill" :style="$theme.setImageSize(36)">
					</image>
					<view style="padding-left: 12px;">{{item.lang}}</view>
					<view style="margin-left: auto;">
						<image :src="`/static/lang_check_${item.code==curLocale?1:0}.svg`" mode="scaleToFill"
							:style="$theme.setImageSize(24,16)">
						</image>
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import localize from '@/common/localize.js';
	export default {
		data() {
			return {
				isDark: null, // 是否深色调
				curLanguage: null, // 语言
				curLocale: null, // 本地化
			}
		},
		computed: {
			list() {
				console.log(localize)
				return localize;
			}
		},
		onShow() {
			this.isDark = uni.getStorageSync('theme');
			this.curLanguage = uni.getStorageSync('lang'); // 语言
			this.curLocale = uni.getStorageSync('locale'); // 本地化
		},
		onHide() {},
		methods: {
			// 切换选中语言
			chooseLang(item, index) {
				uni.setStorageSync('locale', val.code);
				uni.setStorageSync('lang', val.lang);
				this.curLocale = uni.getStorageSync('locale');
				this.curLanguage = uni.getStorageSync('lang');
				this.$i18n.locale = val.code;

			},
		}
	}
</script>

<style lang="scss" scoped>
	.header {
		padding: 48rpx 40rpx 0 40rpx;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}

		.center_dark {
			color: #FFFFFF;
		}

		.center_dark {
			color: #1f2329;
		}
	}
</style>