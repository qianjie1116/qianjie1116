<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.SMALL)">
			<HeaderSmall :dark="isDark" :title="$fmt.fmtText($t('tradeDay.title'))" />
		</template>

		<view :style="$theme.setStyleBody()">
			<view :class="curTab%2==0?`right_in`:`left_in`">
				<template v-if="$theme.setLayout($C.SMALL)">
					<view
						style="background-image: url(/static/img_defi.png);background-position: 0 0;background-repeat: no-repeat;background-size: 100% 100%;height: 150px;border-radius: 4px;margin-bottom: 20px;">
					</view>
					<view style="background-color: #1f212d;border-radius: 4px;padding:20px 10px;">

						<view style="font: 14px;font-weight: 700;">
							{{$fmt.fmtText($t('common.amount'))}}
						</view>
						<view class="input_wrapper" :style="$theme.setInputStyle(isDark)">
							<input v-model="amount" type="number"
								:placeholder="$fmt.fmtText($t('common.enter')+ $t('common.amount'))"
								:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
						</view>
						<!-- <view
							style="display: flex;align-items: center;justify-content: space-between;padding-top: 8px;">
							<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
								{{$fmt.fmtText($t('stock.total'))}}
							</view>
							<MultiDisplayNumber :value="totalAmount" :config="setFmtConfig" />
						</view> -->
						<!-- <Balance :balance="balance" /> -->

						<view style="display: flex;align-items: center;padding-top: 8px;">
							<view style="flex:auto; font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
								{{$fmt.fmtText($t('common.balance'))}}
							</view>
							<view style="margin-left: auto;padding-right: 8px;">
								<MultiDisplayNumber :value="balance" :config="setFmtConfig" />
							</view>
							<view style="margin-left: auto; font-size: 12px;"
								:style="{color:$theme.PRIMARY,borderBottom:`1px solid `+$theme.PRIMARY}"
								@click="$linkTo.linkAssets($C.KEY_RECHARGE)">
								{{$fmt.fmtText($t('assets.recharge'))}}
							</view>
						</view>
						<view class="btn_common" @click="handleSubmit()" style="margin: 24px 0;line-height: 40px;">
							{{$fmt.fmtText($t('common.buy'))}}
						</view>
					</view>
				</template>

				<view style="display: flex;align-items: center;justify-content: space-between; padding: 16px 0;">
					<block v-for="(v,k) in tabs" :key="k">
						<view style="padding-right: 12px;" @click="changeTab(k)">
							{{$fmt.fmtText(v)}}
						</view>
					</block>
					<!-- 右边使用过滤模式。【待审、同意、拒绝】 -->
				</view>

				<template v-if="!setList || setList.length<=0">
					<EmptyData />
				</template>
				<template v-else>
					<!-- 无论宽竖，显示当前tab数据。竖屏块状，横屏一行一条数据 -->
					<template v-if="$theme.setLayout($C.SMALL)">
						<block v-for="(v,k) in setList" :key="k">
							<view style="border-bottom: 1px solid #333;padding:6px;padding-top: 12px;line-height: 1.6;">
								<view style="text-align: right;" :style="{color:$theme.colorStatus[1]}">
									{{status[1]}}
								</view>
								<view style="display: flex;align-items: center;justify-content: space-between;">
									<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('tradeDay.applyAmount'))}}
									</view>
									<view :style="{color:$theme.PRIMARY}">{{$fmt.fmtCurrency(`${13579.246}`)}}</view>
								</view>
								<view style="display: flex;align-items: center;justify-content: space-between;">
									<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('tradeDay.passAmount'))}}
									</view>
									<view :style="{color:$theme.PRIMARY}">
										{{curTab!=1?`--`:$fmt.fmtCurrency(`${13579.246}`)}}
									</view>
								</view>
								<view style="display: flex;align-items: center;justify-content: space-between;">
									<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('common.sn'))}}</view>
									<view>2024101011111</view>
								</view>
								<view style="display: flex;align-items: center;justify-content: space-between;">
									<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('common.dt'))}}</view>
									<view>10/10/2024 11:11:11</view>
								</view>
							</view>
						</block>
					</template>
					<template v-else>
						<view style="display: flex;align-items: center;justify-content: space-between;"
							:style="{color:$theme.TXT_UNACT}">
							<view style="flex:0 0 20%;">订单状态</view>
							<view style="flex:0 0 25%;">{{$fmt.fmtText($t('tradeDay.applyAmount'))}}</view>
							<view style="flex:0 0 20%;">{{$fmt.fmtText($t('tradeDay.passAmount'))}}</view>
							<view style="flex:0 0 25%;">{{$fmt.fmtText($t('common.sn'))}}</view>
							<view style="margin-left: auto;">{{$fmt.fmtText($t('common.dt'))}}</view>
						</view>
						<block v-for="(v,k) in setList" :key="k">
							<view
								style="border-bottom: 1px solid #1f212d;display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
								<view style="flex:0 0 20%;">{{$fmt.fmtCurrency(`${13579.246}`)}}</view>
								<view style="flex:0 0 25%;">{{$fmt.fmtCurrency(`${13579.246}`)}}</view>
								<view style="flex:0 0 20%;">
									{{curTab!=1?`--`:$fmt.fmtCurrency(`${13579.246}`)}}
								</view>
								<view style="flex:0 0 25%;">{{$fmt.fmtCurrency(`${13579.246}`)}}</view>
								<view style="margin-left: auto;">{{$fmt.fmtCurrency(`${13579.246}`)}}</view>
							</view>
						</block>
					</template>

				</template>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
				tabs: [this.$t('tradeDay.apply'),
					this.$t('tradeDay.approval')
				],
				curTab: 0,
				applyList: [], // 申请记录
				approvalList: [], // 审批记录
				config: null, // 获取配置
				balance: '', // 账户余额
				amount: '', // 输入值
				status: [this.$t('tradeDay.await'),
					this.$t('tradeDay.pass'),
					this.$t('tradeDay.reject')
				],
			}
		},
		computed: {
			setList() {
				return this.curTab == 0 ? this.applyList : this.approvalList;
			},
			// 格式化配置，获取汇率
			setFmtConfig() {
				// temp[`en-US`].rate = this.config.get('eur_usd') || 1;
				console.log(`locale:`, uni.getStorageSync('locale'));
				return this.$fmt.prioritizeLocale(this.$fmt.fmtConfig());
			},
		},
		onShow() {
			if (!this.$linkTo.checkToken()) return false;
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
			this.changeTab(this.curTab);
		},
		onHide() {
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.changeTab(this.curTab);
			uni.stopPullDownRefresh();
		},
		methods: {
			changeTab(val) {
				this.curTab = val;
				this.getAccountInfo();
				this.getConfig();
				// this.getConfig(); // 每次重新请求汇率
				if (this.curTab == 0) this.getApplyList();
				if (this.curTab == 1) this.getApprovalList();
			},

			// 购买
			async handleSubmit() {
				if (!this.amount || this.amount <= 0) {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('common.amount')),
						icon: 'none'
					});
					return false;
				}
				const result = await uni.showModal({
					title: '',
					content: this.$lang.TRADE_DAY_MODAL_CONTENT,
					cancelText: this.$fmt.fmtText(this.$t('common.cancel')),
					confirmText: this.$fmt.fmtText(this.$t('common.confirm')),
					confirmColor: this.$theme.PRIMARY,
					cancelColor: this.$theme.TXT_UNACT,
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.submitBuy();
				}
			},

			// 提交 购买
			async submitBuy() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.submiting')),
				});
				const result = await this.$http.post(`api/rinei/buy`, {
					money: this.amount,
				});
				console.log(result);
				if (!result) return false;
				uni.showToast({
					title: '',
					icon: 'success'
				});
				setTimeout(() => {
					this.changeTab(this.curTab);
				}, 1000);
			},

			// 申请记录
			async getApplyList() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.requestData')),
				});
				const result = await this.$http.get(`api/rinei/sq-list`);
				if (!result) return false;
				console.log(result);
				this.applyList = result.length <= 0 ? [] : result;
			},
			// 审批结果
			async getApprovalList() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.requestData')),
				});
				const result = await this.$http.get(`api/rinei/order-list`);
				if (!result) return false;
				console.log(result);
				this.approvalList = result.length <= 0 ? [] : result;
			},

			// 获取账户信息
			async getAccountInfo() {
				const result = await this.$http.get(`api/user/fastInfo`);
				if (!result) return false;
				console.log(`getAccountInfo:`, result);
				this.balance = result.money || 0;
			},

			// 获取配置
			async getConfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				console.log(`getConfig:`, result);
				this.config = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				console.log(`getConfig:`, this.config);
			},
		}
	}
</script>

<style>
</style>