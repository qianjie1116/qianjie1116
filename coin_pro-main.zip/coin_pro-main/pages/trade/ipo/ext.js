import * as constants from '@/common/constants.js';
import * as fmt from '@/common/format.js';
import http from '@/common/http.js';
import {
	translate
} from '@/common/util.js';

// 顶部tabs
export const tabs = () => {
	return [
		fmt.fmtText(translate('tradeIPO.product')),
		// fmt.fmtText(translate('tradeIPO.apply')),
		fmt.fmtText(translate('tradeIPO.approval'))
	]
};

// 横屏 headers
export const headers = () => {
	return {
		token: {
			flex: 1,
			text: fmt.fmtText(translate('tradeIPO.token'))
		},
		price: {
			flex: 1,
			text: fmt.fmtText(translate('tradeIPO.price'))
		},
		lower: {
			flex: 1,
			text: fmt.fmtText(translate('tradeIPO.lower'))
		},
		upper: {
			flex: 1,
			text: fmt.fmtText(translate('tradeIPO.upper'))
		},
		st: {
			flex: 1,
			text: fmt.fmtText(translate('tradeIPO.st'))
		},
		et: {
			flex: 1,
			text: fmt.fmtText(translate('tradeIPO.et'))
		},
		win: {
			flex: 1,
			text: fmt.fmtText(translate('tradeIPO.win'))
		},
		qty: {
			flex: 1,
			text: fmt.fmtText(translate('tradeIPO.qty'))
		},
		action: {
			flex: 1,
			text: fmt.fmtText(translate('common.action')),
			align: 'right',
		}
	}
};

export const recordHeaders = () => {
	return {
		token: {
			flex: 1,
			text: fmt.fmtText(translate('tradeIPO.token'))
		},
		price: {
			flex: 1,
			text: fmt.fmtText(translate('tradeIPO.price'))
		},
		amount: {
			flex: 1,
			text: fmt.fmtText(translate('tradeIPO.quantity'))
		},
		success: {
			flex: 1,
			text: fmt.fmtText(translate('tradeIPO.success'))
		},
		lt: {
			flex: 1,
			text: fmt.fmtText(translate('tradeIPO.lt'))
		}
	}
};


// 获取产品列表
export const getGoods = async (code = 1) => {
	uni.showLoading({
		title: translate('api.requestData'),
	});
	const result = await http.get(`api/goods-shengou/calendar`, {
		type: code, // 传参 1或2
	});
	const temp = result.filter(item => item.goods);

	return !temp || temp.length <= 0 ? [] : temp.map(item => {
		return {
			id: item.id,
			name: item.goods.name,
			price: item.price,
			lower: item.min_num,
			upper: item.max_num,
			st: item.shengou_date,
			ot: item.online_date,
			sell: item.sell_num,
			total: item.fa_amount,
			pt: item.gb_date || fmt.fmtText(translate('tradeIPO.unp')),
			paper: item.baipishu,
			desc: item.jianjie,
		}
	})
};

// 中签列表
export const getApproval = async () => {
	uni.showLoading({
		title: translate('api.requestData'),
	});
	const result = await http.get(`api/goods-shengou/user-success-log`);
	if (!result) return false;
	console.log(`result:`, result);
	const temp = result.filter(item => item.goods);
	return temp.map(item => {
		console.log(item.goods);
		return {
			name: item.goods.name,
			price: item.price,
			amount: item.apply_amount,
			success: item.success || 0,
			ct: item.created_at,
		}
	});
};

// 申请列表