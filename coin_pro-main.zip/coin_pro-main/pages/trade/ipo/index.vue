<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.SMALL)">
			<HeaderSmall :dark="isDark" :title="$fmt.fmtText($t('tradeIPO.title'))" />
		</template>

		<view :style="$theme.setStyleBody()">
			<template v-if="$theme.setLayout($C.SMALL)">
				<view
					style="background-image: url(/static/img_defi.png);background-position: 0 0;background-repeat: no-repeat;background-size: 100% 100%;height: 150px;border-radius: 4px;margin-bottom: 20px;">
				</view>

				<view style="display: flex;align-items: center;padding: 20px 0 4px 0;">
					<block v-for="(v,k) in tabs" :key="k">
						<view style="padding-right: 12px;font-size: 16px;" @click="changeTab(k)">
							<text :style="{color:curTab==k?$theme.PRIMARY:$theme.TXT_UNACT,
									borderBottom:`1px dashed ${curTab==k?$theme.PRIMARY:$theme.TXT_UNACT}`}">
								{{v}}
							</text>
						</view>
					</block>
					<!-- <view style="margin-left: auto;">
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.refesh" @click="handleRefesh()" />
					</view> -->
				</view>

				<template v-if="!list ||list.length<=0">
					<EmptyData></EmptyData>
				</template>
				<template v-else>
					<template v-if="curTab==0">
						<GoodsSmall :list="goods" :headers="headers" @action="showBuy"></GoodsSmall>
					</template>
					<template v-else>
						<RecordSmall :list="list"></RecordSmall>
					</template>
				</template>
			</template>
			<template v-else>
				<view style="display: flex;align-items: center;margin-bottom: 20px;height: 150px;">
					<view style="flex: 0 0 60%;">
						<template v-if="goods && goods[0]">
							<GoodsTop :info="goods[0]" :headers="headers" @action="openModal" />
						</template>
						<template v-else>
							<!-- 没有数据时，补一个什么在这里 -->
							<view></view>
						</template>
					</view>
					<view style="flex:0 0 40%">
						<view
							style="background-image: url(/static/img_defi.png);background-position: 0 0;background-repeat: no-repeat;background-size: 100% 100%;height: 150px;border-radius: 4px;margin-left: 20px;">
						</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;padding: 20px 0 4px 0;">
					<block v-for="(v,k) in tabs" :key="k">
						<view style="padding-right: 12px;font-size: 16px;" @click="changeTab(k)">
							<text :style="{color:curTab==k?$theme.PRIMARY:$theme.TXT_UNACT,
									borderBottom:`1px dashed ${curTab==k?$theme.PRIMARY:$theme.TXT_UNACT}`}">
								{{v}}
							</text>
						</view>
					</block>
					<view style="margin-left: auto;">
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.refesh" @click="handleRefesh()" />
					</view>
				</view>
				<template v-if="curTab==0">
					<GoodsLarge :list="goods" :headers="headers" @action="showBuy" />
				</template>
				<template v-else>
					<RecordLarge :list="record" />
				</template>
			</template>
		</view>

		<!-- 购买的浮层 -->
		<template v-if="isShow">
			<ModalBuy :info="curInfo" @action="closeModal" />
		</template>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	import ModalBuy from './components/ModalBuy.vue';
	import GoodsLarge from './components/GoodsLarge.vue';
	import GoodsSmall from './components/GoodsSmall.vue';
	import GoodsTop from './components/GoodsTop.vue';
	import RecordSmall from './components/RecordSmall.vue';
	import RecordLarge from './components/RecordLarge.vue';

	export default {
		components: {
			ModalBuy,
			GoodsLarge,
			GoodsSmall,
			GoodsTop,
			RecordSmall,
			RecordLarge,
		},
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
				goods: null, // 产品列表
				isShow: false, // 是否显示浮层
				curInfo: null, // 选中数据
				tabs: ext.tabs(), // 顶部tab
				curTab: 0, // 顶部当前激活项				
				record: null, // 持仓及赎回列表
				headers: ext.headers(), // 
			}
		},
		computed: {
			list() {
				return this.curTab == 0 ? this.goods : this.record;
			}
		},
		onShow() {
			if (!this.$linkTo.checkToken()) return false;
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
			this.changeTab(this.curTab);
		},
		onHide() {
			console.log(`onHide:`, this.isDark);
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			this.changeTab(this.curTab);
			uni.stopPullDownRefresh();
		},
		methods: {
			// 显示浮层
			showModal(val) {
				this.curInfo = val;
				this.isShow = true;
			},
			// 关闭浮层
			closeModal(val) {
				this.isShow = false;
				this.changeTab(this.curTab);
			},
			// 横屏所需购买浮层
			showBuy(val) {
				this.showModal(val);
			},
			// goods top 购买按钮
			openModal(val) {
				this.showModal(val);
			},

			// tabs
			changeTab(val) {
				this.curTab = val;
				if (this.curTab == 0) this.getList();
				if (this.curTab > 0) this.getRecord();
			},
			// 宽屏列表数据刷新
			handleRefesh() {
				this.changeTab(this.curTab);
			},

			// 获取产品列表
			async getList() {
				const result = await ext.getGoods();
				this.goods = result;
			},

			// record
			async getRecord() {
				const result = await ext.getApproval();
				this.record = result;
			}
		}
	}
</script>

<style>
</style>