<template>
	<view class="custom_table">
		<view class="table_header">
			<view class="table_row" :style="{color:$theme.TXT_UNACT}">
				<block v-for="(v,k) in Object.values(headers)" :key="k">
					<view class="table_cell" :style="{flex:`${v.flex}`,textAlign:v.align}"> {{v.text}} </view>
				</block>
			</view>
		</view>
		<view class="table_body" style="overflow-x: auto;">
			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<block v-for="(item,index) in list" :key="index">
				<view class="table_row" :style="{borderBottom:`1px solid ${$theme.TXT_UNACT}`}">
					<view class="table_cell" :style="{flex:`${headers.token.flex}`}"> {{item.name}} </view>
					<view class="table_cell" :style="{flex:`${headers.price.flex}`}">
						{{item.price}}
					</view>
					<view class="table_cell" :style="{flex:`${headers.lower.flex}`}">
						{{$fmt.fmtCrypto(`${item.lower}` )}}
					</view>
					<view class="table_cell" :style="{flex:`${headers.upper.flex}`}">
						{{$fmt.fmtCrypto(`${item.upper}` )}}
					</view>
					<view class="table_cell" style="font-size: 11px;" :style="{color:$theme.TXT_UNACT,
					flex:`${headers.st.flex}`}">
						{{item.st}}
					</view>
					<view class="table_cell" style="font-size: 11px;" :style="{color:$theme.TXT_UNACT,
					flex:`${headers.et.flex}`}">
						{{item.ot}}
					</view>
					<view class="table_cell" style="font-size: 11px;" :style="{color:$theme.TXT_UNACT,
					flex:`${headers.win.flex}`}">
						{{item.ot}}
					</view>
					<view class="table_cell" style="font-size: 11px;" :style="{color:$theme.TXT_UNACT,
					flex:`${headers.qty.flex}`}">
						{{$fmt.fmtCrypto(`${$fmt.fmtNumber(item.sell,0)}`)}}/
						{{$fmt.fmtCrypto(`${$fmt.fmtNumber(item.total,0)}`)}}
					</view>
					<view class="table_cell" :style="{ flex:`${headers.action.flex}`,textAlign:headers.action.align}">
						<view class="btn_common" style="margin-left: 0;line-height:24px;"
							:style="{backgroundColor:$theme.convertRGBA($theme.PRIMARY,20)}" @click="chooseGoods(item)">
							{{$fmt.fmtText($t('tradeIPO.sub'))}}
						</view>
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'GoodsLarge',
		props: {
			list: {
				type: Array,
				default: []
			},
			headers: {
				type: Object,
				default: {}
			}
		},
		methods: {
			chooseGoods(val) {
				this.$emit('action', val);
			}
		}
	}
</script>

<style>
</style>