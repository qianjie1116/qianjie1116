<template>
	<view>
		<block v-for="(v,k) in list" :key="k">
			<view style="background-color: #1f212d;border-radius: 4px;padding:20px 10px;margin-bottom: 20px;">
				<view style="display: flex;align-items: center;padding-bottom: 10px;">
					<image src="/static/logo.png" mode="aspectFit" style="padding-right: 10px;"
						:style="$theme.setImageSize(28)"></image>
					<view style="font-size: 18px;font-weight: 500;">{{v.name}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{headers.price.text}}
					</view>
					<view>
						{{$fmt.fmtCrypto(`${$fmt.fmtNumber(v.price)}`)}}
						<text style="font-size: 11px;" :style="{color:$theme.TXT_UNACT}">
							{{$t('common.unitUSDT')}}</text>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{headers.amount.text}}
					</view>
					<view>{{$fmt.fmtCrypto(`${$fmt.fmtNumber(v.amount)}`)}}
						<text style="font-size: 11px;" :style="{color:$theme.TXT_UNACT}">
							{{$t('common.unitUSDT')}}</text>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{headers.success.text}}
					</view>
					<view>{{$fmt.fmtCrypto(`${$fmt.fmtNumber(v.success)}`)}}
						<text style="font-size: 11px;" :style="{color:$theme.TXT_UNACT}">
							{{$t('common.unitUSDT')}}</text>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{headers.lt.text}}
					</view>
					<view>{{v.ct}}</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import * as ext from '../ext.js';
	export default {
		name: 'RecordSmall',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				headers: ext.recordHeaders
			}
		}
	}
</script>

<style>
</style>