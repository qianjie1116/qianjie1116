<template>
	<view style="background-color: #1f212d;border-radius: 4px;padding:20px;height: 110px;display: flex;">
		<!-- <view style="display: flex;"> -->
			<view>
				<image src="/static/logo.png" mode="aspectFit" style="padding-right: 20px;"
					:style="$theme.setImageSize(48)"></image>
			</view>
			<view style="flex: 1;">
				<view style="display: flex;align-items: center;">
					<view style="font-size: 24px;font-weight: 500;">{{info.name}}</view>
					<view
						style="flex:1;display: flex;align-items: center;justify-content: space-around;line-height: 1.8;">
						<view style="text-align: center;">
							<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
								{{$fmt.fmtText($t('tradeIPO.price'))}}({{$t('common.unitUSDT')}})
							</view>
							<view>{{$fmt.fmtCrypto(`${$fmt.fmtNumber(info.price)}`)}}</view>
						</view>
						<view style="text-align: center;">
							<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
								{{$fmt.fmtText($t('tradeIPO.lower'))}}({{$t('common.unitUSDT')}})
							</view>
							<view>{{$fmt.fmtCrypto(`${$fmt.fmtNumber(info.lower)}`)}}</view>
						</view>
						<view style="text-align: center;">
							<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
								{{$fmt.fmtText($t('tradeIPO.upper'))}}({{$t('common.unitUSDT')}})
							</view>
							<view>{{$fmt.fmtCrypto(`${$fmt.fmtNumber(info.upper)}`)}}</view>
						</view>
					</view>
					<view style="margin-left: auto;">
						<view class="btn_common" @click="chooseGoods(info)" :style="{backgroundColor:$theme.PRIMARY}">
							{{$fmt.fmtText($t('tradeIPO.sub'))}}
						</view>
					</view>
				</view>
				<view style="display: grid; grid-auto-flow: column;column-gap: 10px;line-height: 1.6;margin-top: 16px;">
					<view>
						<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('tradeIPO.st'))}}
						</view>
						<view>{{info.st}}</view>
					</view>
					<view>
						<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('tradeIPO.et'))}}
						</view>
						<view>{{info.ot}}</view>
					</view>
					<view>
						<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('tradeIPO.win'))}}
						</view>
						<view>{{info.ot}}</view>
					</view>
					<view>
						<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('tradeIPO.qty'))}}
						</view>
						<view>
							{{$fmt.fmtCrypto(`${$fmt.fmtNumber(info.sell,0)}`)}}/
							{{$fmt.fmtCrypto(`${$fmt.fmtNumber(info.total,0)}`)}}
						</view>
					</view>
				</view>
			</view>
		<!-- </view> -->
	</view>
</template>

<script>
	export default {
		name: 'GoodsTop',
		props: {
			info: {
				type: Object,
				default: {}
			},
			headers:{
				type: Object,
				default: {}
			}
		},
		methods: {
			chooseGoods(val) {
				this.$emit('action', val);
			}
		}
	}
</script>

<style>
</style>