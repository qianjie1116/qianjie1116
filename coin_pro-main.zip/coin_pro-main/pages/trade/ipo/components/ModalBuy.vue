<template>
	<view>
		<view class="overlay" style="background-color: rgba(0, 0, 0, 0.5);" @click="modalClose()"></view>
		<view :class="[$theme.setLayout($C.SMALL)?`modal_wrapper_bottom`:`modal_wrapper_center`,'bottom_in' ]"
			:style="{backgroundColor:$theme.BASIC_BG}">
			<view style="min-height: 30vh;padding:12px 12px 24px 12px;">
				<view style="display: flex;align-items: center;padding-bottom: 12px;">
					<view style="width: 24px;"></view>
					<view style="flex:1;text-align:center;">
						<text style="padding-bottom: 4px;" :style="{borderBottom:`1px solid ${$theme.PRIMARY}`}">
							{{setTitle}}
						</text>
					</view>
					<view style="margin-left: auto;">
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.close" @click="modalClose()" />
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('tradeIPO.token'))}}
					</view>
					<view style="font-size: 16px;font-weight: 500;">{{info.name}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('tradeIPO.price'))}}
					</view>
					<view>{{$fmt.fmtCrypto(`${$fmt.fmtNumber(info.price)}`)}}
						<text style="font-size: 11px;" :style="{color:$theme.TXT_UNACT}">
							{{$t('common.unitUSDT')}}</text>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('tradeIPO.total'))}}
					</view>
					<view>{{$fmt.fmtCrypto(`${$fmt.fmtNumber(info.total)}`)}}
						<text style="font-size: 11px;" :style="{color:$theme.TXT_UNACT}">
							{{$t('common.unitUSDT')}}</text>
					</view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('tradeIPO.pt'))}}
					</view>
					<view>{{info.pt}} </view>
				</view>


				<view style="font: 14px; margin-top: 8px;margin-bottom: 8px;">
					{{$fmt.fmtText($t('common.amount'))}}
				</view>
				<view class="input_wrapper" style="padding:0 12px;margin-top: 0;" :style="$theme.setInputStyle(dark)">
					<input v-model="amount" type="number"
						:placeholder="$fmt.fmtText($t('common.enter')+$t('common.amount'))"
						:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('tradeIPO.totalAmount'))}}
					</view>
					<view>{{$fmt.fmtCrypto(`${$fmt.fmtNumber(totalAmount)}`)}}
						<text style="font-size: 11px;" :style="{color:$theme.TXT_UNACT}">
							{{$t('common.unitUSDT')}}</text>
					</view>
				</view>


				<view style="display: flex; align-items: center;justify-content: space-between;padding: 12px 0;">
					<view class="btn_common"
						style="margin:0 auto; flex:1;border:none;padding:4px;margin-left: 0;line-height: 24px;"
						:style="{backgroundColor:$theme.PRIMARY}" @click="handleSubmit()">
						{{ $fmt.fmtText($t('common.buy'))}}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'ModalBuy',
		props: {
			dark: {
				type: Boolean,
				default: true,
			},
			info: {
				type: Object,
				default: {}
			}
		},
		data() {
			return {
				amount: 100, // 输入值
			}
		},
		computed: {
			setTitle() {
				return this.$fmt.fmtText(this.$t('common.buy') + ` ` + this.$t('common.detail'))
			},
			// 计算总价
			totalAmount() {
				console.log(`??`, this.amount);
				return this.amount * 1 > 0 ? this.info.price * this.amount : 0;
			}
		},
		methods: {
			// 关闭浮层
			modalClose() {
				this.amount = '';
				this.$emit('action', 1);
			},
			// 购买
			async handleSubmit() {
				if (this.amount == '' || this.amount <= 0) {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('common.amount')),
						icon: 'none'
					});
					return false;
				}
				const result = await this.$http.post(`api/goods-shengou/doOrder`, {
					id: this.info.id,
					num: this.amount,
				});
				console.log(`result:`, result);
				if (!result) return false;
				uni.showToast({
					title: result,
					icon: 'none'
				});
				setTimeout(() => {
					this.modalClose();
				}, 1000);
			},
		}
	}
</script>

<style>
</style>