<template>
	<view class="custom_table">
		<view class="table_header">
			<view class="table_row" :style="{color:$theme.TXT_UNACT}">
				<block v-for="(v,k) in Object.values(headers)" :key="k">
					<view class="table_cell" :style="{flex:`${v.flex}`,textAlign:v.align}"> {{v.text}} </view>
				</block>
			</view>
		</view>
		<view class="table_body" style="overflow-x: auto;">
			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<block v-for="(item,index) in list" :key="index">
				<view class="table_row" :style="{borderBottom:`1px solid ${$theme.TXT_UNACT}`}">
					<view class="table_cell" :style="{flex:`${headers.token.flex}`}"> {{item.name}} </view>
					<view class="table_cell" :style="{flex:`${headers.price.flex}`}">
						{{item.price}}
					</view>
					<view class="table_cell" :style="{flex:`${headers.amount.flex}`}">
						{{$fmt.fmtCrypto(`${item.amount}` )}}
					</view>
					<view class="table_cell" :style="{flex:`${headers.success.flex}`}">
						{{$fmt.fmtCrypto(`${item.success}` )}}
					</view>
					<view class="table_cell" style="font-size: 11px;" :style="{color:$theme.TXT_UNACT,
					flex:`${headers.lt.flex}`}">
						{{item.ct}}
					</view>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	import * as ext from '../ext.js';
	export default {
		name: 'RecordLarge',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				headers: ext.recordHeaders()
			}
		}
	}
</script>

<style>
</style>