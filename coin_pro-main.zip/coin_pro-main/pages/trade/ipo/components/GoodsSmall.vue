<template>
	<view style="padding-top: 14px;">
		<block v-for="(v,k) in list" :key="k">
			<view style="background-color: #1f212d;border-radius: 4px;padding:20px 10px;margin-bottom: 20px;">
				<view style="display: flex;align-items: center;padding-bottom: 10px;">
					<image src="/static/logo.png" mode="aspectFit" style="padding-right: 10px;"
						:style="$theme.setImageSize(28)"></image>
					<view style="font-size: 18px;font-weight: 500;">{{v.name}}</view>
					<view style="margin-left: auto;">
						<view class="btn_common" @click="showModal(v)" :style="{backgroundColor:$theme.PRIMARY}">
							{{$fmt.fmtText($t('tradeIPO.sub'))}}
						</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{headers.price.text}}
					</view>
					<view>
						{{$fmt.fmtCrypto(`${$fmt.fmtNumber(v.price)}`)}}
						<text style="font-size: 11px;" :style="{color:$theme.TXT_UNACT}">
							{{$t('common.unitUSDT')}}</text>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{headers.lower.text}}
					</view>
					<view>{{$fmt.fmtCrypto(`${$fmt.fmtNumber(v.lower)}`)}}
						<text style="font-size: 11px;" :style="{color:$theme.TXT_UNACT}">
							{{$t('common.unitUSDT')}}</text>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{headers.upper.text}}
					</view>
					<view>{{$fmt.fmtCrypto(`${$fmt.fmtNumber(v.upper)}`)}}
						<text style="font-size: 11px;" :style="{color:$theme.TXT_UNACT}">
							{{$t('common.unitUSDT')}}</text>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{headers.st.text}}
					</view>
					<view>{{v.st}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{headers.et.text}}
					</view>
					<view>{{v.ot}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}"> {{headers.win.text}} </view>
					<view>{{v.ot}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{headers.qty.text}}
					</view>
					<view>
						{{$fmt.fmtCrypto(`${$fmt.fmtNumber(v.sell,0)}`)}}/
						{{$fmt.fmtCrypto(`${$fmt.fmtNumber(v.total,0)}`)}}
					</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: 'GoodsSmall',
		props: {
			list: {
				type: Array,
				default: []
			},
			headers: {
				type: Object,
				default: {}
			}
		},
		methods: {
			chooseGoods(val) {
				this.$emit('action', val);
			}
		}
	}
</script>

<style>
</style>