<template>
	<view>
		这里仿照 assets 二级菜单模式。将用户玩转的一些交易模式放在这里。
		tabs 横向可滚动。每个tab走自己的组件逻辑
	</view>
</template>

<script>
</script>

<style>
</style>