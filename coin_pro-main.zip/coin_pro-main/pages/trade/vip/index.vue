<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.SMALL)">
			<HeaderSmall :dark="isDark" :title="$fmt.fmtText($t('tradeVIP.title'))" />
		</template>

		<view :style="$theme.setStyleBody()">



		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
				tabs: [this.$t('tradeVIP.product'),
					this.$t('tradeVIP.apply'),
					this.$t('tradeVIP.approval')
				]
			}
		},
		onShow() {
			if (!this.$linkTo.checkToken()) return false;
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
		},
	}
</script>

<style>
</style>