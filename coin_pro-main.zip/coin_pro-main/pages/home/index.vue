<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.SMALL)">
			<HeaderSmall :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.SMALL)">
			<view class="banner_bg_small">
				<BannerSmall :dark="isDark" />
				<view
					style="padding:0 20px;display: flex;align-items: center;flex-wrap: wrap;justify-content: space-between;">
					<block v-for="(item,index) in btns" :key="index">
						<view style="flex:0 0 25%;" @click="linkTo(index)">
							<view style="display: flex;align-items: center;justify-content: center;padding-top: 20px;">
								<image :src="item.icon" mode="aspectFit" :style="$theme.setImageSize()"></image>
							</view>
							<view style="text-align: center;line-height: 2.4;">{{item.name}}</view>
						</view>
					</block>
				</view>

				<!-- <NotifySmall></NotifySmall> -->

				<view style="display: flex;align-items: center;padding:0 16px;line-height: 2.8;padding-bottom: 24px;">
					<view style="flex:0 0 36%;">
						<view @click="$linkTo.linkAssets($C.KEY_RECHARGE)"
							style="display: flex;align-items: center;justify-content: center; background-color: #34393e;padding:12px 6px;border-radius: 4px;margin-right: 16px;">
							<image src="/static/recharge.svg" mode="aspectFit" :style="$theme.setImageSize(28)"></image>
							<view style="padding-left: 6px;">{{$fmt.fmtText($t('assets.recharge'))}}</view>
						</view>
					</view>
					<view style="flex:0 0 36%;">
						<view @click="$linkTo.linkAssets($C.KEY_WITHDRAW)"
							style="display: flex;align-items: center;justify-content: center; background-color: #34393e;padding:12px 6px;border-radius: 4px;">
							<image src="/static/withdraw.svg" mode="aspectFit" :style="$theme.setImageSize(28)"></image>
							<view style="padding-left: 6px;">{{$fmt.fmtText($t('assets.withdraw'))}}</view>
						</view>
					</view>
					<view style="margin-left: auto;">
						<view style="display: flex;align-items: center;justify-content: center;max-width: 80px;">
							<image src="/static/withdraw.svg" mode="aspectFit" :style="$theme.setImageSize(20)"></image>
						</view>
						<view style="font-size: 11px;text-align: center;padding-top: 6px;line-height: 1;">
							{{$fmt.fmtText($t('service.title'))}}
						</view>
					</view>
				</view>
			</view>
		</template>

		<view :style="$theme.setStyleBody()">
			<template v-if="$theme.setLayout($C.MEDIUM)">
				<BannerMedium :dark="isDark" />
			</template>
			<template v-if="$theme.setLayout($C.LARGE) ">
				<BannerLarge :dark="isDark" :code="curTab" />
			</template>

			<template v-if="$theme.setLayout($C.LARGE)">
				<!-- 公告 -->
				<!-- <NotifyLarge v-if="isUpdate" /> -->
			</template>

			<template v-if="$theme.setLayout($C.MEDIUM) || $theme.setLayout($C.LARGE)">
				<PopularList :dark="isDark" />
			</template>

			<!-- 宽竖通用 列表显示切换 -->
			<scroll-view :scroll-x="true" style="white-space: nowrap;width: 100%;padding:0;" @touchmove.stop>
				<view style="display: flex;margin:0 4px;">
					<block v-for="(v,k) in tabs" :key='k'>
						<view :style="setStyleTab(curTab==k)" @click="changeTab(k)">
							{{$fmt.fmtText( v.value)}}
						</view>
					</block>
				</view>
			</scroll-view>

			<!-- 全布局通用 -->
			<view :class="curTab%2===0?'right_in':'left_in'">
				<template v-if="!setList || setList.length<=0">
					<EmptyData />
				</template>
				<template v-else>
					<block v-for="(item,index) in setList" :key="index">
						<view class="item" style="padding:12px 0;">
							<view style="display: flex;align-items: center;" @click="linkDetail(item)">
								<view style="margin-right: auto;">
									<CustomLogo :logo="item.logo" :name="item.name" />
								</view>
								<view style="flex:0 0 20%;">
									<view style="font-size: 14px;padding-left: 10px;">
										{{item.name}}
									</view>
								</view>
								<view style="flex:1 1 auto;">
									<view style="font-size: 14px;font-weight: 500;" :style="{textAlign:$theme.setLayout($C.SMALL)?`right`:`center`,
									paddingRight:$theme.setLayout($C.SMALL)?`12px`:``}">
										<!-- <MultiDisplayNumber :value="item.current_price" :config="setFmtConfig"
											:code="curKey" /> -->
										{{$fmt.fmtCrypto(`${item.current_price}`)}}
									</view>
								</view>
								<view style="margin-left: auto;">
									<view style="padding:8px;border-radius: 4px;min-width: 60px;text-align: center;"
										:style="$theme.setRiseFall(item.rate,true)">
										{{`${item.rate>0?'+':'-'} `+ $fmt.fmtNumber(Math.abs(item.rate))}}%
									</view>
								</view>
								<template v-if="$theme.setLayout($C.LARGE)||$theme.setLayout($C.MEDIUM)">
									<view style="margin-left: auto;">
										<view class="btn_common" :class="isDark ? `btn_dark` : `btn_light`"
											@click.stop="hanldeBuy(item)">{{$fmt.fmtText($t('common.buy'))}}</view>
									</view>
								</template>
							</view>
						</view>
					</block>
				</template>
			</view>

			<template v-if="$theme.setLayout($C.SMALL)">
				<FooterSmall :dark="isDark" />
			</template>

			<!-- <template v-if="layout==$C.MEDIUM || layout==$C.LARGE">
				<FooterLarge v-if="isUpdate" />
			</template> -->
		</view>
	</view>
</template>

<script>
	import * as ext from './ext.js';
	import HeaderSmall from './components/HeaderSmall.vue';
	import BannerLarge from './components/BannerLarge.vue';
	import BannerMedium from './components/BannerMedium.vue';
	import BannerSmall from './components/BannerSmall.vue';
	import PopularList from './components/PopularList.vue';
	import localize from '../../common/localize';
	// import FooterLarge from '@/components/footer/FooterLarge.vue';
	// import NotifyLarge from '../notify/components/NotifyLarge.vue';	

	export default {
		components: {
			HeaderSmall,
			BannerLarge,
			BannerMedium,
			BannerSmall,
			PopularList,
			// FooterLarge,
			// NotifyLarge,
		},
		data() {
			return {
				layout: null, // 当前布局方案
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
				curTab: 0, // 当前显示列表
				list: null,
				wsClient: null, // ws实例
				isConnected: false, // ws是否连接
				tabs: ext.tabs(),
				btns: ext.btns(),
				popList: null, // 放在竖屏的pop数据。
			}
		},
		watch: {
			isDark(val, newVal) {
				console.log(`val:`, val, `newVal:`, newVal);
			},
		},
		computed: {
			// // 格式化配置，获取汇率
			// setFmtConfig() {
			// 	let temp;
			// 	// 根据 config 接口返回，改变指定币种的汇率
			// 	if (this.curKey == 'ukstock') {
			// 		console.log(this.curKey)
			// 		temp = this.$fmt.prioritizeLocale(this.$fmt.fmtConfig(), 'it-IT');
			// 	} else {
			// 		temp = this.$fmt.prioritizeLocale(this.$fmt.fmtConfig(), 'en-US');
			// 	}
			// 	temp[`en-US`].rate = 1.3579;
			// 	return temp;
			// },
			// 当前显示列表的key
			curKey() {
				console.log(`curKey:`, this.tabs[this.curTab].key);
				return this.tabs[this.curTab].key;
			},

			// 当前 使用的locale。用于本页tab切换时。
			curLocale() {
				// 如果是coin及外汇期货，使用美元，否则使用指定的货币
				switch (this.curKey) {
					case this.$C.KEY_CRYPTO:
					case this.$C.KEY_FOREX:
					case this.$C.KEY_FUTURE:
						return this.$C.LOCALE_ENUS;

					case this.$C.KEY_UKSTOCK:
						return this.$C.LOCALE_FRFR;

						// 如果需要，你可以添加一个 default 情况来处理其他值
						// default:
						// 	// 可以选择返回一个默认值或其他处理
						// 	break;
				}
			},

			setList() {
				return !this.list ? [] : Object.values(this.list);
			},
			// 竖屏前三
			setPopList() {
				return !this.setList ? [] : this.setList.length >= 3 ?
					this.setList : this.setList.slice(0, 3)
			},

			// 当前 ws url
			curURL() {
				if (this.curKey == this.$C.KEY_CRYPTO) return this.$http.WS_COIN_URL;
				return this.$http.WS_OTHER_URL;
			},
		},
		onLoad() {},

		onShow() {
			console.log(`onShow:`);
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
			this.changeTab(this.curTab);
		},
		onHide() {
			// console.log(`onHide:`, this.isDark);
			this.isAnimat = false;
			if (this.wsClient) this.disconnect();
		},
		onUnload() {
			if (this.wsClient) this.disconnect();
		},
		onPullDownRefresh() {
			if (this.wsClient) this.disconnect();
			// this.refreshChild();
			uni.stopPullDownRefresh();
		},

		deactivated() {
			if (this.wsClient) this.disconnect();
		},

		methods: {
			// 竖屏按钮组跳转事件
			linkTo(val) {
				const temp = this.btns[val];
				uni.navigateTo({
					url: this.$linkTo.PAGES + temp.url,
				})
			},

			changeTab(val) {
				this.curTab = val;
				this.getList();
			},

			// linkDetail 行点击
			linkDetail(val) {
				if (!this.$linkTo.checkToken()) return false;
				console.log(`val:`, val);
				console.log(val.locate);
				// 分为股票详情，和加密币详情
				if (this.$util.isUSDT(this.curKey)) {
					this.$linkTo.cryptoDetail(val.code);
				} else {
					this.$linkTo.stockDetail(val.locate);
				}
			},

			// buy按钮点击
			hanldeBuy(val) {
				this.linkDetail(val);
			},

			async getList() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.requestData')),
				});
				this.list = null;
				console.log('gpIndex:', this.$C.GPINDEX[this.curKey]);
				const result = await this.$http.post(`api/goods/list`, {
					page: 1,
					gp_index: this.$C.GPINDEX[this.curKey]
					// gp_index: 7
				});
				console.log(`crypto result:`, result);
				if (!result) return false;
				this.list = result;

				if (Object.values(this.list).length > 0) {
					if (this.wsClient) this.disconnect();
					if (this.curTab == 0) this.initWebsocket();
				}
			},

			// websocket 断线重连
			reconnectWebSocket() {
				// 连接中，并且非手动关闭
				if (this.isConnected) return;
				console.log(`reconnect!`, this.isConnected);
				this.wsClient = null;
				console.log(`reconnect! socket:`, this.wsClient);
				this.initWebsocket();
			},

			// 关闭 websocket链接
			disconnect() {
				if (this.wsClient) {
					this.wsClient.close();
					this.wsClient = null;
					this.isConnected = false;
				}
			},

			//  websocket
			initWebsocket() {
				if (this.wsClient) this.disconnect();
				this.wsClient = uni.connectSocket({
					url: this.curURL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.info(`success res:`, res);
					},
					fail: (res) => {
						console.info(`fail res:`, res);
					}
				});

				console.log(`socket:`, this.wsClient);
				this.wsClient.onOpen((res) => {
					console.info("socket onOpen:", res);
					this.isConnected = true; // 已连接
					// if (this.messageHanlder) {
					// 	this.socket.onMessage(this.messageHanlder);
					// }
				});
				this.wsClient.onClose((res) => {
					// code:1000(手动关闭) 1006(异常关闭) 
					console.log(`onClose:`, res);
					this.isConnected = false;
					if (res.code !== 1000) {
						this.reconnectWebSocket();
					}
				});
				this.wsClient.onError((err) => {
					console.log(`onError:`, err);
					this.isConnected = false;
					this.reconnectWebSocket();
				});
				this.wsClient.onMessage((res) => {
					const data = JSON.parse(res.data);
					if (data.type == "ticker") {
						if (this.curTab == 0) {
							if (this.list[data.market] && data.market && data.lastPrice > 0) {
								// if (data.market == 'btcusdt') {
								// 	console.log(data.type, data);
								// }
								this.list[data.market].current_price = data.lastPrice;
								this.list[data.market].rate = data.rate || 0;
								this.list[data.market].vol = data.vol || 0;
							}
						} else {
							if (this.list[data.pid] && data.pid && data.last > 0) {
								this.list[data.pid].current_price = data.last;
								this.list[data.pid].rate = data.pcp || 0;
							}
							// if (this.listFutures[data.pid] && data.pid && data.last > 0) {
							// 	this.listFutures[data.pid].current_price = data.last;
							// 	this.listFutures[data.pid].rate = data.pcp || 0;
							// }
						}
					}
				});
			},

			setStyleTab(val) {
				return {
					width: `max-content`,
					padding: `6px 16px 6px 0`,
					color: val ? this.$theme.PRIMARY : '#838b9c',
					textAlign: 'center',
					fontSize: `18px`,
					fontWeight: `700`,
				}
			},
		},
	}
</script>

<style lang="scss" scoped>
	.banner_bg_small {
		background-image: url(/static/img_home_bnner.jpg);
		background-repeat: no-repeat;
		background-position: 0 -50px;
		background-size: 100% 180px;
		min-height: 100%;
	}
</style>