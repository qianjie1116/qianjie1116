// 凡此类文件，属于对应页面辅助函数。
import Vue from 'vue';
import i18n from '@/locales/index.js';
import * as linkTo from '@/common/linkTo.js';
import * as constants from '@/common/constants.js';
import * as fmt from '@/common/format.js';
import http from '@/common/http.js';

// 按钮组
export const btns = () => {
	return [{
			name: fmt.fmtText(i18n.t('header.defi')),
			icon: `/static/home_btn_defi.png`,
			url: linkTo.DEFI,
		},
		// {
		// 	name: fmt.fmtText(i18n.t('header.pledge')),
		// 	icon: `/static/home_btn_pledge.png`,
		// 	url: linkTo.PLEDGE
		// }, 
		// {
		// 	name: fmt.fmtText(i18n.t('header.wealth')),
		// 	icon: `/static/home_btn_wealth.png`,
		// 	url: linkTo.WEALTH
		// }, 

		{
			name: fmt.fmtText(i18n.t('crypto.spt')),
			icon: `/static/home_btn_spot.png`,
			url: linkTo.CRYPTO + `?tag=${constants.KEY_CRYPTO_SPT}`
		},
		{
			name: fmt.fmtText(i18n.t('crypto.ct')),
			icon: `/static/home_btn_perp.png`,
			url: linkTo.CRYPTO + `?tag=${constants.KEY_CRYPTO_CT}`
		},
		// {
		// 	name: fmt.fmtText(i18n.t('crypto.spt')),
		// 	icon: `/static/home_btn_spot.png`,
		// 	url: linkTo.CRYPTO + `?tag=${constants.KEY_CRYPTO_SPT}`
		// }, {
		// 	name: fmt.fmtText(i18n.t('crypto.perp')),
		// 	icon: `/static/home_btn_perp.png`,
		// 	url: linkTo.CRYPTO + `?tag=${constants.KEY_CRYPTO_PERP}`
		// }, {
		// 	name: fmt.fmtText(i18n.t('crypto.usdt')),
		// 	icon: `/static/home_btn_usdt.png`,
		// 	url: linkTo.CRYPTO + `?tag=${constants.KEY_CRYPTO_USDT}`
		// },
		// {
		// 	name: fmt.fmtText(i18n.t('tradeDay.title')),
		// 	icon: `/static/home_btn_convert.png`,
		// 	url: linkTo.TRADE_DAY
		// },
		// {
		// 	name: fmt.fmtText(i18n.t('tradeBlock.title')),
		// 	icon: `/static/home_btn_convert.png`,
		// 	url: linkTo.TRADE_BLOCK
		// },
		{
			name: fmt.fmtText(i18n.t('tradeIPO.title')),
			icon: `/static/home_btn_convert.png`,
			url: linkTo.TRADE_IPO
		},
		// {
		// 	name: fmt.fmtText(i18n.t('tradeVIP.title')),
		// 	icon: `/static/home_btn_convert.png`,
		// 	url: linkTo.TRADE_VIP
		// },
		{
			name: fmt.fmtText(i18n.t('assets.convert')),
			icon: `/static/home_btn_convert.png`,
			url: linkTo.ASSETS + `?tag=${constants.KEY_CONVERT}`
		},
		{
			name: fmt.fmtText(i18n.t('assets.transfer')),
			icon: `/static/home_btn_convert.png`,
			url: linkTo.ASSETS + `?tag=${constants.KEY_TRANSFER}`
		},
		{
			name: fmt.fmtText(i18n.t('account.authAdvanced')),
			icon: `/static/home_btn_convert.png`,
			url: linkTo.ACCOUNT + `?tag=${constants.KEY_AUTH_ADVANCED}`
		},
		{
			name: fmt.fmtText(i18n.t('header.loan')),
			icon: `/static/home_btn_loan.png`,
			url: linkTo.LOAN
		},
	]
};

// 数据列表tab
export const tabs = () => {
	return [{
			key: constants.KEY_CRYPTO,
			value: fmt.fmtText(i18n.t('market.crypto')),
		},
		// {
		// 	key: constants.KEY_FOREX,
		// 	value: fmt.fmtText(i18n.t('market.forex')),
		// }, {
		// 	key: constants.KEY_FUTURE,
		// 	value: fmt.fmtText(i18n.t('market.future')),
		// }, 
		// {
		// 	key: constants.KEY_USSTOCK,
		// 	value: fmt.fmtText(i18n.t('market.usstock')),
		// }, {
		// 	key: constants.KEY_UKSTOCK,
		// 	value: fmt.fmtText(i18n.t('market.ukstock')),
		// },
	]
};