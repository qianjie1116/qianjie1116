<template>
	<view class="banner_bg">
		<view style="padding:20px 0;width: 50%;">
			<u-count-to :endVal="contVal" :color="$theme.PRIMARY" :fontSize="84" :bold="true"
				separator=","></u-count-to>

			<view style="font-size: 64px;font-weight: 900;">USERS</view>
			<view style="font-size: 64px;font-weight: 900;">TRUST US</view>

			<view style="display: flex;align-items: center;">
				<view style="flex:0 0 70%;">
					<view class="search_wrapper">
						<image src="/static/search_0.png" mode="aspectFit" :style="$theme.setImageSize(16)"></image>
						<input v-model="keyword" type="text"
							:placeholder="$fmt.fmtText($t('common.enter')+ $t('common.keywords'))"
							:placeholder-style="$theme.setPlaceholder()"></input>
					</view>
				</view>
				<view style="flex:0 0 30%;">
					<view class="btn_common" @click="linkMarket()"
						style="margin:0;line-height: 52px;background-color: #536fff;font-size: 16px;">
						{{$fmt.fmtText($t('common.search'))}}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'BannerMedium',
		props: {
			dark: {
				type: Boolean,
				default: true,
			},
			code: {
				type: Number,
				default: 0
			},
		},
		data() {
			return {
				keyword: '',
				contVal: 9876531,
			}
		},

		methods: {
			// 跳转到市场页面
			linkMarket() {
				this.$linkTo.market(this.code, this.keyword);
			}
		}
	}
</script>
