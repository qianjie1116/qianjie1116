<template>
	<view class="banner_bg">
		<view style="max-width: 70%;">
			<view style="font-size: 64px;font-weight: 900;">
				{{$fmt.fmtText($t('common.welcome'))}}
			</view>
			<view style="font-size: 84px;font-weight: 900;cursor: pointer;" :style="{color:$theme.PRIMARY}"
				@click="linkHome()">{{$APP_NAME}}</view>
			<view style="font-size: 48px;font-weight: 700;word-break: break-word;">
				{{$fmt.fmtText($t('common.platform'))}}
			</view>
			<view style="padding:20px 0;display: flex;align-items: center;width: 60%;">
				<view style="flex:0 0 70%;">
					<view class="search_wrapper">
						<image src="/static/search_0.png" mode="aspectFit" :style="$theme.setImageSize(16)"></image>
						<input v-model="keyword" type="text"
							:placeholder="$fmt.fmtText($t('common.enter')+ $t('common.keywords'))"
							:placeholder-style="$theme.setPlaceholder()"></input>
					</view>
				</view>
				<view style="flex:0 0 30%;">
					<view class="btn_common" @click="linkMarket()"
						style="margin:0;line-height: 52px; font-size: 16px;font-weight: 700;"
						:style="{backgroundColor:$theme.PRIMARY}">
						{{$fmt.fmtText($t('common.search'))}}
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'BannerLarge',
		props: {
			dark: {
				type: Boolean,
				default: true,
			},
			code: {
				type: Number,
				default: 0
			},
		},
		data() {
			return {
				keyword: '',
			}
		},
		methods: {
			// 跳转到市场页面
			linkMarket() {
				this.$linkTo.market(this.code, this.keyword);
			}
		}

	}
</script>