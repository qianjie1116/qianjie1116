<template>
	<view style="display: grid; grid-auto-flow: column;column-gap: 10px;margin-bottom: 20px; ">
		<template v-if="setList && setList.length>0">
			<block v-for="(item,index) in setList" :key="index">
				<view class="item" :class="dark ? `btn_dark` : `btn_light`" @click="linkInfo(item.code)">
					<view style="display: flex;align-items: center;justify-content: center;">
						<CustomLogo :logo="item.logo" :name="item.name" />
					</view>
					<view style="display: flex;align-items: center;justify-content: center;line-height: 1.4;">
						{{item.name}}
					</view>

					<view style="display: flex;align-items: center;justify-content: space-around;line-height:2.8;">
						<view style="text-align: center;font-size: 16px;" :style="$theme.setRiseFall(item.rate)">
							{{$fmt.fmtCrypto(`${item.current_price}`) }}
						</view>
						<view style="color:#3c4047;font-size: 12px;">|</view>
						<view style="text-align: center;font-size: 16px;" :style="$theme.setRiseFall(item.rate)">
							{{`${item.rate>0?'+':'-'} `+ ($fmt.fmtNumber(Math.abs(item.rate),false))}}%
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import WebSocketTool from '@/common/websocket.js';
	export default {
		// 宽屏首页热门币种横向滚动
		name: 'PopularList',
		components: {},
		props: {
			dark: {
				type: Boolean,
				default: true,
			},
		},
		data() {
			return {
				wsClient: null,
				list: null,
			};
		},
		computed: {
			// 当前页面宽度，可容纳元素数量
			curCount() {
				console.log(`width:`, this.$WINDOW_WIDTH);
				console.log(this.$WINDOW_WIDTH / 200);
				const temp = this.$WINDOW_WIDTH > this.$C.WIDTH_PC ? this.$C.WIDTH_PC : this.$WINDOW_WIDTH;
				return Math.floor(temp / 200);
			},

			setList() {
				console.log(this.curCount);
				return this.list ? Object.values(this.list).slice(0, this.curCount) : [];
			}
		},
		beforeMount() {
			this.getList();
		},
		deactivated() {
			console.log('CoinList deactivated');
		},
		beforeDestroy() {
			console.log(`CoinList beforeDestroy`);
			if (this.wsClient) this.wsClient.disconnect();
		},
		destroyed() {
			console.log(`CoinList destroyed`);
			if (this.wsClient) this.wsClient.disconnect();
		},
		methods: {
			// 跳转到 coin trade index
			linkInfo(code) {
				uni.reLaunch({
					url: this.$linkTo.PAGES + this.$linkTo.TRADE + `?symbol=${code}`
				});
			},

			async getList() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.requestData')),
				});
				const result = await this.$http.post(`api/goods/list`, {
					page: 1,
					gp_index: 1
				});
				console.log(`coin result:`, result);
				if (!result) return false;
				this.list = result;
				this.wsClient = new WebSocketTool(this.$http.WS_COIN_URL);
				// this.initWebsocket();

			},
			// 初始化 websocket
			initWebsocket() {
				this.wsClient.connect();
				console.log(`init:`, this.wsClient);
				this.wsClient.onMessage(this.wsOnMessage);
			},
			// 接受并处理ws返回消息
			wsOnMessage(res) {
				const data = JSON.parse(res.data);
				// check websocket返回的数据， 能够在list中找到。 ws价格 > 0， 更新数据。
				if (this.list[data.market] && data.market && data.lastPrice > 0) {
					this.list[data.market].current_price = data.lastPrice;
					this.list[data.market].rate = data.rate || 0;
					this.list[data.market].vol = data.vol || 0;
				}
			}
		}
	}
</script>

<style lang="scss" scoped>
	.item {
		width: 180px;
		border-radius: 10px;
		font-size: 24px;
		text-align: center;
		padding: 16px;
		box-sizing: border-box;
		cursor: pointer;
		border: 1px solid #536fff;
	}
</style>