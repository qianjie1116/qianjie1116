<template>
	<view style="padding-top: 100px;">
		<template v-if="setList.length>0">
			<view
				style="margin:0 20px;border-radius: 8px;padding:12px 0;display: flex;align-items: center;line-height: 1.4;"
				:style="{border:`1px solid ${$theme.BASIC_BORDER}`,
			backgroundColor:$theme.CARD_BG}">
				<block v-for="(item,index) in setList" :key="index">
					<view style="flex:0 0 33%;">
						<view style="text-align: center;font-size: 14px;font-weight: 700;">{{item.name}}</view>
						<view style="font-size: 14px;font-weight: 500;text-align: center;"
							:style="$theme.setRiseFall(item.rate)">
							{{`${item.rate>0?'+':'-'} `+ ($fmt.fmtNumber(Math.abs(item.rate),2))}}%
						</view>
						<view style="font-size: 14px;font-weight: 500;text-align: center;"
							:style="$theme.setRiseFall(item.rate)">
							{{$fmt.fmtCrypto(`${item.current_price}`)}}
						</view>
					</view>
				</block>
			</view>
		</template>
	</view>
</template>

<script>
	import WebSocketTool from '@/common/websocket.js';
	export default {
		name: 'BannerSmall',
		props: {
			dark: {
				type: Boolean,
				default: true,
			},
		},
		data() {
			return {
				wsClient: null,
				list: null,
			};
		},
		computed: {
			setList() {
				if (!this.list || Object.values(this.list).length <= 0) return [];
				const temp = Object.values(this.list);
				return temp.length <= 3 ? temp : temp.slice(0, 3);
			},
		},
		beforeMount() {
			this.getList();
		},
		deactivated() {
			console.log('CoinList deactivated');
		},
		beforeDestroy() {
			console.log(`CoinList beforeDestroy`);
			if (this.wsClient) this.wsClient.disconnect();
		},
		destroyed() {
			console.log(`CoinList destroyed`);
			if (this.wsClient) this.wsClient.disconnect();
		},
		methods: {
			// // 跳转到 coin trade index
			// linkInfo(code) {
			// 	uni.reLaunch({
			// 		url: this.$linkTo.PAGES + this.$linkTo.TRADE + `?symbol=${code}`
			// 	});
			// },

			async getList() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.requestData')),
				});
				const result = await this.$http.post(`api/goods/list`, {
					page: 1,
					gp_index: 1
				});
				console.log(`coin result:`, result);
				if (!result) return false;
				this.list = result;
				this.wsClient = new WebSocketTool(this.$http.WS_COIN_URL);
				// this.initWebsocket();

			},
			// 初始化 websocket
			initWebsocket() {
				this.wsClient.connect();
				console.log(`init:`, this.wsClient);
				this.wsClient.onMessage(this.wsOnMessage);
			},
			// 接受并处理ws返回消息
			wsOnMessage(res) {
				const data = JSON.parse(res.data);
				// check websocket返回的数据， 能够在list中找到。 ws价格 > 0， 更新数据。
				if (this.list[data.market] && data.market && data.lastPrice > 0) {
					this.list[data.market].current_price = data.lastPrice;
					this.list[data.market].rate = data.rate || 0;
					this.list[data.market].vol = data.vol || 0;
				}
			}
		}
	}
</script>

<style>
</style>