<template>
	<view class="btns " style="">
		<block v-for="(item,index) in btnConfig" :key="index">
			<view class="item" @click="actionEvent(item.url)">
				<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$theme.setImageSize(60)"></image>
				<text style="padding: 16rpx 0;">{{item.name}}</text>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "ButtonGroup",
		computed: {
			btnConfig() {
				// 根据客户需求，调整位置，注释不需要要显示的项
				const temp = [{
						name: this.$lang.TRADE_IPO_TITLE, // IPO
						url: this.$paths.TRADE_IPO,
					},
					{
						name: this.$lang.DEPOSIT_TITLE, // 入金/充值
						url: this.$paths.DEPOSIT_INDEX,
					}, {
						name: this.$lang.WITHDRAW_TITLE, // 出金/提款
						url: this.$paths.WITHDRAW_INDEX,
					}, 
					// {
					// 	name: this.$lang.TRANSFER_TITLE, // 劃轉
					// 	url: this.$paths.TRANSFER_INDEX,
					// },
					{
						name: this.$lang.Qiquan_name, // 秒合约
						url: '/pages/qiquan/index',
						icon:"qiquan"
					},
					{
						name: this.$lang.PROFILE_SERVICE, // 客服
						// url: this.$paths.SERVICE, //
						url: 'service',
					},
					{
						name: this.$lang.AUTH_TITLE, // 实名认证
						url: this.$paths.ACCOUNT_AUTH,
					},
					{
						name: this.$lang.BORROW_TITLE, // borrow
						url: "/pages/borrow/record",
					},
					{
						name: this.$lang.COMMON_MORE, // 更多
						url: 'modal',
					},

				].map((item, index,icon) => {
					return {
						name: item.name,
						icon: item.icon?item.icon:`top${index}`,
						url: item.url
					}
				});
				return temp;
			}
		},

		methods: {
			actionEvent(url) {
				if (url.includes('service')) {
					this.$util.linkCustomerService();
				} else if (url.includes('pages')) {
					uni.navigateTo({
						url: url
					})
				} else {
					this.$emit('action', url);
				}
			},
		}
	}
</script>

<style lang="scss">
	.btns {
		display: flex;
		flex-wrap: wrap;
		padding-bottom: 6px;
		padding: 10px 0;

		.item {
			width: 25%;
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			color: #121212;
			padding: 4px 0;
		}
	}
</style>