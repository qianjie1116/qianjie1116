<template>
	<header class="header_small" :style="{borderBottomColor:`1px solid ${$theme.BASIC_TXT}`}">
		<view class="left">
			<image src="/static/logo.png" mode="aspectFit" :style="$theme.setImageSize(30)"></image>
		</view>
		<view class="center"></view>
		<view class="right">
			<image src="/static/user.png" mode="aspectFit" :style="$theme.setImageSize()"
				@tap="$linkTo.linkAccount()">
			</image>
		</view>
	</header>
</template>

<script>
	export default {
		name: 'HeaderSmall',
		components: {},
		props: {
			dark: {
				type: Boolean,
				default: true,
			}
		},
		data() {
			return {
				isDark: this.dark, // 当前主题方案
			}
		},
		beforeMount() {},
		methods: {}
	}
</script>


<style lang="scss" scoped>
	.header_small {
		padding: 24px 20px 10px 20px;
		display: flex;
		align-items: center;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			font-size: 32rpx;
			font-weight: 500;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>