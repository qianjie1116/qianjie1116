import Vue from 'vue';
import i18n from '@/locales/index.js';
import * as constants from '@/common/constants.js';
import * as fmt from '@/common/format.js';
import http from '@/common/http.js';

// 顶部tabs
export const tabs = () => {
	return [
		fmt.fmtText(i18n.t('common.goods')),
		fmt.fmtText(i18n.t('defi.position')),
		fmt.fmtText(i18n.t('defi.redeemed'))
	]
};

// 底部list
export const footerTabs = () => {
	return [
		fmt.fmtText(i18n.t('defi.position')),
		fmt.fmtText(i18n.t('defi.redeemed'))
	]
};

// record header
export const headers = () => {
	return {
		token: {
			flex: 1,
			text: fmt.fmtText(i18n.t('defi.token'))
		},
		rate: {
			flex: 1,
			text: fmt.fmtText(i18n.t('defi.rate'))
		},
		cycle: {
			flex: 1,
			text: fmt.fmtText(i18n.t('defi.cycle'))
		},
		price: {
			flex: 1,
			text: fmt.fmtText(i18n.t('common.price'))
		},
		payPrice: {
			flex: 1,
			text: fmt.fmtText(i18n.t('defi.payPrice'))
		},
		profit: {
			flex: 1,
			text: fmt.fmtText(i18n.t('defi.profit'))
		},
		ct: {
			flex: 1,
			text: fmt.fmtText(i18n.t('defi.ct'))
		},
		et: {
			flex: 1,
			text: fmt.fmtText(i18n.t('defi.et'))
		},
	}
};

// 获取record区域的数据
export const getRecord = async (code) => {
	uni.showLoading({
		title: i18n.t('api.requestData'),
	});
	const result = await http.post(`api/jijin/order`, {
		status: code,
	});
	console.log(`result:`, result);
	if (!result) return false;

	return result.map(item => {
		return {
			token: item.goodname,
			rate: item.fudu,
			cycle: item.zhouqi,
			price: item.price,
			payPrice: item.pay_price,
			profit: item.shouyi,
			ct: item.time,
			et: item.endtime
		}
	});
}