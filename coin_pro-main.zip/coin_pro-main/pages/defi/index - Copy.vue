<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.SMALL)">
			<HeaderSmall :dark="isDark" @update:dark="isDark = $event" :title="$t('header.defi')" />
		</template>

		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>


		<view :style="$theme.setStyleBody()">
			<template v-if="$theme.setLayout($C.SMALL)">
				<view
					style="background-image: url(/static/img_defi.png);background-position: 0 0;background-repeat: no-repeat;background-size: 100% 100%;height: 150px;border-radius: 4px;margin-bottom: 20px;">
				</view>

				<view style="background-color: #1f212d;border-radius: 4px;padding:20px 10px;">
					<view style="display: flex;align-items: center;padding-bottom: 10px;">
						<image src="/static/logo.png" mode="aspectFit" style="padding-right: 10px;"
							:style="$theme.setImageSize(28)"></image>
						<view style="font-size: 24px;font-weight: 500;">ETH</view>
						<view style="margin-left: auto;">
							<view class="btn_common" @click="handleSubmit()" style="background-color: #536fff;">
								{{$fmt.fmtText($t('common.submit'))}}
							</view>
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.TXT_UNACT}">Total Output(ETH)</view>
						<view>{{$fmt.fmtNumber(50000)}} ETH</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.TXT_UNACT}">Vaild Nodes</view>
						<view>{{$fmt.fmtNumber(37336)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.TXT_UNACT}"> Participant </view>
						<view>{{$fmt.fmtNumber(37336)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.TXT_UNACT}"> User Benefits(USDT) </view>
						<view>{{$fmt.fmtNumber(37336.68)}} U</view>
					</view>
				</view>

				<view style="padding: 20px 0 12px 0;">收益比率</view>
				<view style="border:1px solid #AAAAAA;border-radius: 6px;padding:10px;">
					<view
						style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 10px;">
						<view :style="{color:$theme.TXT_UNACT}">档位</view>
						<view :style="{color:$theme.TXT_UNACT}">数量</view>
						<view :style="{color:$theme.TXT_UNACT}">收益率</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
						<view>1</view>
						<view>1-{{$fmt.fmtNumber(4999)}}</view>
						<view>{{$fmt.fmtNumber(1.00)}}%</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
						<view>6</view>
						<view>{{$fmt.fmtNumber(300000)}}-{{$fmt.fmtNumber(2000000)}}</view>
						<view>{{$fmt.fmtNumber(3.00)}}%</view>
					</view>
				</view>

				<view style="padding: 20px 0 12px 0;">用户输出</view>
				<view style="border:1px solid #AAAAAA;border-radius: 6px;padding:10px;">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.TXT_UNACT}">地址</view>
						<view :style="{color:$theme.TXT_UNACT}">数量</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
						<view>0xa12a6******a4a46a</view>
						<view>{{$fmt.fmtNumber(8.675)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
						<view>0xa12a6******a4a46a</view>
						<view>{{$fmt.fmtNumber(8.675)}}</view>
					</view>
				</view>

			</template>

			<template v-else>
				<!-- DEFI display: grid; grid-auto-flow: column;column-gap: 10px; -->
				<view style="display: flex;align-items: center;margin-bottom: 40px;height: 150px;">
					<view style="flex: 0 0 60%;">
						<view style="background-color: #1f212d;border-radius: 4px;padding:20px;">
							<view style="display: flex;">
								<view>
									<image src="/static/logo.png" mode="aspectFit" style="padding-right: 20px;"
										:style="$theme.setImageSize(48)"></image>
								</view>

								<view style="flex: 1;">
									<view style="display: flex;align-items: center;">
										<view style="font-size: 24px;font-weight: 500;">ETH</view>
										<view style="margin-left: auto;">
											<view class="btn_common" @click="handleSubmit()"
												style="background-color: #536fff;">
												{{$fmt.fmtText($t('common.submit'))}}
											</view>
										</view>
									</view>
									<view
										style="display: grid; grid-auto-flow: column;column-gap: 10px;line-height: 2.4;margin-top: 16px;">
										<view>
											<view :style="{color:$theme.TXT_UNACT}">Total Output(ETH)</view>
											<view>{{$fmt.fmtNumber(50000)}} ETH</view>
										</view>
										<view>
											<view :style="{color:$theme.TXT_UNACT}">Vaild Nodes</view>
											<view>{{$fmt.fmtNumber(37336)}} </view>
										</view>
										<view>
											<view :style="{color:$theme.TXT_UNACT}"> Participant </view>
											<view>{{$fmt.fmtNumber(37336)}} </view>
										</view>
										<view>
											<view :style="{color:$theme.TXT_UNACT}"> User Benefits(USDT) </view>
											<view>{{$fmt.fmtNumber(37336.68)}} U</view>
										</view>
									</view>
								</view>
							</view>
						</view>
					</view>
					<view style="flex:0 0 40%">
						<view
							style="background-image: url(/static/img_defi.png);background-position: 0 0;background-repeat: no-repeat;background-size: 100% 100%;height: 150px;border-radius: 4px;margin-left: 20px;">
						</view>
					</view>
				</view>

				<view style="display: flex;align-items: center;line-height: 2.8;">
					<view style="flex: 0 0 60%;">
						<view>收益比率</view>
						<view style="border:1px solid #AAAAAA;border-radius: 6px;padding:16px 20px;">
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view>档位</view>
								<view>数量</view>
								<view>收益率</view>
							</view>
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view>1</view>
								<view>1-{{$fmt.fmtNumber(4999)}}</view>
								<view>{{$fmt.fmtNumber(1.00)}}%</view>
							</view>
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view>6</view>
								<view>{{$fmt.fmtNumber(300000)}}-{{$fmt.fmtNumber(2000000)}}</view>
								<view>{{$fmt.fmtNumber(3.00)}}%</view>
							</view>
						</view>
					</view>
					<view style="flex:0 0 40%">
						<view style="padding-left: 20px;">用户输出</view>
						<view style="margin-left: 20px;border:1px solid #AAAAAA;border-radius: 6px;padding:16px 20px;">
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view>地址</view>
								<view>数量</view>
							</view>
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view>0xa12a6******a4a46a</view>
								<view>8.675</view>
							</view>
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view>0xa12a6******a4a46a</view>
								<view>8.675</view>
							</view>
						</view>
					</view>
				</view>
			</template>
			<view style="font-size: 24px;font-weight: 700;margin-top: 40px;">Gear return ratio</view>
			<view style="margin:20px 0;border:1px solid #AAAAAA;border-radius: 6px;padding:16px 20px;">
				一大段文字
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		components: {},
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
			}
		},
		computed: {

		},

		onShow() {
			if (!this.$linkTo.checkToken()) return false;
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
		},
		onReady() {},
		onHide() {
			console.log(`onHide:`, this.isDark);
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			// this.refreshChild();
			uni.stopPullDownRefresh();
		},
		deactivated() {},

		methods: {
			// // 此为驱动子组件强刷的方案。
			// refreshChild() {
			// 	this.isUpdate = false;
			// 	this.$nextTick(() => {
			// 		this.isUpdate = true;
			// 	})
			// },
			async handleSubmit() {

			},
		},
	}
</script>

<style>
</style>