<template>
	<view>
		<view class="overlay" style="background-color: rgba(0, 0, 0, 0.5);" @click="modalClose()"></view>
		<view :class="[$theme.setLayout($C.SMALL)?`modal_wrapper_bottom`:`modal_wrapper_center`,'bottom_in' ]"
			:style="{backgroundColor:$theme.BASIC_BG}">
			<view style="min-height: 30vh;padding:12px 12px 24px 12px;">
				<view style="display: flex;align-items: center;padding-bottom: 12px;">
					<view style="width: 24px;"></view>
					<view style="flex:1;text-align:center;">
						<text style="padding-bottom: 4px;" :style="{borderBottom:`1px solid ${$theme.PRIMARY}`}">
							{{setTitle}}
						</text>
					</view>
					<view style="margin-left: auto;">
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.close" @click="modalClose()" />
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('defi.token'))}}
					</view>
					<view style="font-size: 16px;font-weight: 500;">{{info.name}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('defi.rateReturn'))}}
					</view>
					<view>{{$fmt.fmtNumber(info.syl)}}%</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('defi.numberDays'))}}
					</view>
					<view>{{$fmt.fmtNumber(info.zhouqi)}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('defi.min'))}}({{$t('common.unitUSDT')}})
					</view>
					<view>{{$fmt.fmtCrypto(`${$fmt.fmtNumber(info.min_price)}`)}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
					<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtText($t('defi.max'))}}({{$t('common.unitUSDT')}})
					</view>
					<view>{{$fmt.fmtCrypto(`${$fmt.fmtNumber(info.max_price)}`)}}</view>
				</view>
				<template v-if="info.is_new==0">
					<view style="font: 14px; margin-top: 8px;margin-bottom: 8px;">
						{{$fmt.fmtText($t('common.amount'))}}
					</view>
					<view class="input_wrapper" style="padding:0 12px;margin-top: 0;"
						:style="$theme.setInputStyle(dark)">
						<input v-model="amount" type="number"
							:placeholder="$fmt.fmtText($t('common.enter')+$t('common.amount'))"
							:placeholder-style="$theme.setPlaceholder()" style="flex:auto;"></input>
					</view>
				</template>
				<view style="display: flex; align-items: center;justify-content: space-between;padding: 12px 0;">
					<template v-if="info.is_new==0">
						<view class="btn_common"
							style="margin:0 auto; flex:1;border:none;padding:4px;margin-left: 0;line-height: 24px;"
							:style="{backgroundColor:$theme.PRIMARY}" @click="handleSubmit()">
							{{ $fmt.fmtText($t('common.buy'))}}
						</view>
					</template>
					<template v-else>
						<view class="btn_common"
							style="margin:0 auto; flex:1;border:none;padding:4px;margin-left: 0;line-height: 24px;"
							:style="{backgroundColor:$theme.PRIMARY}" @click="$util.linkCustomerService()">
							{{ $fmt.fmtText($t('service.title'))}}
						</view>
					</template>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'ModalBuy',
		props: {
			dark: {
				type: Boolean,
				default: true,
			},
			info: {
				type: Object,
				default: {}
			}
		},
		data() {
			return {
				amount: '', // 输入值
			}
		},
		computed: {
			setTitle() {
				//  Buy Orders
				return this.$fmt.fmtText(this.$t('common.buy') + ` ` + this.$t('common.detail'))
			}
		},
		methods: {
			// 关闭浮层
			modalClose() {
				this.amount = '';
				this.$emit('action', 1);
			},
			// 购买
			async handleSubmit() {
				if (this.amount == '' || this.amount <= 0) {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('common.enter') + this.$t('common.amount')),
						icon: 'none'
					});
					return false;
				}
				if (this.amount < this.info.min_price) {
					uni.showToast({
						title: this.$fmt.fmtText(this.$t('defi.buyTip')),
						icon: 'none'
					});
					return false;
				}
				const result = await uni.showModal({
					title: this.$fmt.fmtText(this.$t('common.buy') + ` ` + this.$t('common.detail')),
					content: `${this.info.name} Payment Amount ${this.$fmt.fmtNumber(this.amount)}`,
					cancelText: this.$fmt.fmtText(this.$t('common.cancel')),
					confirmText: this.$fmt.fmtText(this.$t('common.confirm')),
					confirmColor: this.$theme.PRIMARY,
					cancelColor: this.$theme.TXT_UNACT,
				});
				if (result[1].confirm) this.buy();
			},
			// 买
			async buy() {
				const result = await this.$http.post(`api/jijin/buy`, {
					id: this.info.id,
					ganggan: 1,
					price: this.amount,
				});
				console.log(`result:`, result);
				if (!result) return false;
				uni.showToast({
					title: result,
					icon: 'none'
				});
				this.modalClose();
			}
		}
	}
</script>

<style>
</style>