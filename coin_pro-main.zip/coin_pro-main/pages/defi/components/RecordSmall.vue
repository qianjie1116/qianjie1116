<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(v,k) in list" :key="k">
				<view style="padding:8px 0;" :style="{borderBottom:`1px solid ${$theme.TXT_UNACT}`}">
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
						<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('defi.token'))}}
						</view>
						<view>{{v.token}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
						<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('defi.rate'))}}
						</view>
						<view>{{v.rate}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
						<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('defi.cycle'))}}
						</view>
						<view>{{v.cycle}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
						<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('common.price'))}}
						</view>
						<view>{{$fmt.fmtCrypto(`${v.price}`)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
						<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('defi.payPrice'))}}
						</view>
						<view>{{$fmt.fmtCrypto(`${v.payPrice}`)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
						<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('defi.profit'))}}
						</view>
						<view :style="$theme.setRiseFall(v.profit)">{{$fmt.fmtCrypto(`${v.profit}`)}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
						<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('defi.ct'))}}
						</view>
						<view>{{v.ct}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height:1.6;">
						<view style="font-size: 12px;" :style="{color:$theme.TXT_UNACT}">
							{{$fmt.fmtText($t('defi.et'))}}
						</view>
						<view>{{v.et}}</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	export default {
		name: 'RecordSmall',
		props: {
			list: {
				type: Array,
				default: []
			},
		},
	}
</script>

<style>
</style>