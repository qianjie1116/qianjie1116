<template>
	<view :class="isAnimat?'fade_in':'fade_out'" :style="$theme.setPageStyle(isDark)">
		<template v-if="$theme.setLayout($C.SMALL)">
			<HeaderSmall :dark="isDark" @update:dark="isDark = $event" :title="$t('header.defi')"> </HeaderSmall>
		</template>

		<template v-if="$theme.setLayout($C.MEDIUM)">
			<HeaderMedium :dark="isDark" @update:dark="isDark = $event" />
		</template>

		<template v-if="$theme.setLayout($C.LARGE)">
			<HeaderLarge :dark="isDark" @update:dark="isDark = $event" />
		</template>


		<view :style="$theme.setStyleBody()">
			<template v-if="$theme.setLayout($C.SMALL)">
				<view style="display: flex;align-items: center;padding-bottom: 12px;">
					<block v-for="(v,k) in tabs" :key="k">
						<view style="padding-right: 12px;font-size: 16px;" @click="changeTab(k)">
							<text :style="{color:curTab==k?$theme.PRIMARY:$theme.TXT_UNACT,
								borderBottom:`1px dashed ${curTab==k?$theme.PRIMARY:$theme.TXT_UNACT}`}">{{v}}
							</text>
						</view>
					</block>
				</view>

				<template v-if="curTab==0">
					<view
						style="background-image: url(/static/img_defi.png);background-position: 0 0;background-repeat: no-repeat;background-size: 100% 100%;height: 150px;border-radius: 4px;margin-bottom: 20px;">
					</view>

					<view style="background-color: #1f212d;border-radius: 4px;padding:20px 10px;">
						<view style="display: flex;align-items: center;padding-bottom: 10px;">
							<image src="/static/logo.png" mode="aspectFit" style="padding-right: 10px;"
								:style="$theme.setImageSize(28)"></image>
							<view style="font-size: 24px;font-weight: 500;">{{maxSylData.name}}</view>
							<view style="margin-left: auto;">
								<view class="btn_common" @click="showModal(maxSylData)"
									:style="{backgroundColor:$theme.PRIMARY}">
									{{$fmt.fmtText($t('common.buy'))}}
								</view>
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('defi.rateReturn'))}}</view>
							<view>{{$fmt.fmtNumber(maxSylData.syl)}}%</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view :style="{color:$theme.TXT_UNACT}">{{$fmt.fmtText($t('defi.numberDays'))}}</view>
							<view>{{$fmt.fmtNumber(maxSylData.zhouqi)}}</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view :style="{color:$theme.TXT_UNACT}">
								{{$fmt.fmtText($t('defi.min'))}}({{$t('common.unitUSDT')}})
							</view>
							<view>{{$fmt.fmtCrypto(`${$fmt.fmtNumber(maxSylData.min_price)}`)}}</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view :style="{color:$theme.TXT_UNACT}">
								{{$fmt.fmtText($t('defi.max'))}}({{$t('common.unitUSDT')}})
							</view>
							<view>{{$fmt.fmtCrypto(`${$fmt.fmtNumber(maxSylData.max_price)}`)}}</view>
						</view>
					</view>
				</template>
			</template>

			<template v-if="!$theme.setLayout($C.SMALL)">
				<!-- DEFI display: grid; grid-auto-flow: column;column-gap: 10px; -->
				<view style="display: flex;align-items: center;margin-bottom: 20px;height: 150px;">
					<view style="flex: 0 0 60%;">
						<view style="background-color: #1f212d;border-radius: 4px;padding:20px;">
							<view style="display: flex;">
								<view>
									<image src="/static/logo.png" mode="aspectFit" style="padding-right: 20px;"
										:style="$theme.setImageSize(48)"></image>
								</view>
								<view style="flex: 1;">
									<view style="display: flex;align-items: center;">
										<view style="font-size: 24px;font-weight: 500;">{{maxSylData.name}}</view>
										<view style="margin-left: auto;">
											<view class="btn_common" @click="showModal(maxSylData)"
												:style="{backgroundColor:$theme.PRIMARY}">
												{{$fmt.fmtText($t('common.buy'))}}
											</view>
										</view>
									</view>
									<view
										style="display: grid; grid-auto-flow: column;column-gap: 10px;line-height: 2.4;margin-top: 16px;">
										<view>
											<view :style="{color:$theme.TXT_UNACT}">
												{{$fmt.fmtText($t('defi.rateReturn'))}}
											</view>
											<view>{{$fmt.fmtNumber(maxSylData.syl)}}%</view>
										</view>
										<view>
											<view :style="{color:$theme.TXT_UNACT}">
												{{$fmt.fmtText($t('defi.numberDays'))}}
											</view>
											<view>{{$fmt.fmtNumber(maxSylData.zhouqi)}} </view>
										</view>
										<view>
											<view :style="{color:$theme.TXT_UNACT}">
												{{$fmt.fmtText($t('defi.min'))}}({{$t('common.unitUSDT')}})
											</view>
											<view>{{$fmt.fmtCrypto(`${$fmt.fmtNumber(maxSylData.min_price)}`)}} </view>
										</view>
										<view>
											<view :style="{color:$theme.TXT_UNACT}">
												{{$fmt.fmtText($t('defi.max'))}}({{$t('common.unitUSDT')}})
											</view>
											<view>{{$fmt.fmtCrypto(`${$fmt.fmtNumber(maxSylData.max_price)}`)}}</view>
										</view>
									</view>
								</view>
							</view>
						</view>
					</view>
					<view style="flex:0 0 40%">
						<view
							style="background-image: url(/static/img_defi.png);background-position: 0 0;background-repeat: no-repeat;background-size: 100% 100%;height: 150px;border-radius: 4px;margin-left: 20px;">
						</view>
					</view>
				</view>
			</template>

			<template v-if="!$theme.setLayout($C.SMALL) || curTab==0">

				<template v-if="!list || list.length<=0">
					<EmptyData></EmptyData>
				</template>
				<template v-else>
					<view style="display: flex;align-items: center;justify-content: space-between;flex-wrap: wrap;">
						<block v-for="(item,index) in Object.keys(fmtList)" :key="index">
							<view :style="{flex:$theme.setLayout($C.SMALL)?`0 0 100%`:`0 0 30%`,
							marginTop:$theme.setLayout($C.SMALL)?`24px`:``}">
								<view style="font: 14px;font-weight: 700;padding-bottom: 8px;">
									{{item.toLocaleUpperCase()}}
								</view>
								<view
									style="border:1px solid #AAAAAA;border-radius: 6px;padding:12px 20px;padding-bottom: 8px;">
									<view
										style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
										<view style="flex:1;">{{$fmt.fmtText($t('defi.rateReturn'))}}</view>
										<view style="flex:1;">{{$fmt.fmtText($t('defi.numberDays'))}}</view>
										<view style="flex:1;"></view>
									</view>
									<block v-for="(v,k) in fmtList[item]" :key="k">
										<view
											style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 8px;">
											<view style="flex:1;">{{$fmt.fmtNumber(v.syl)}}%</view>
											<view style="flex:1;">{{$fmt.fmtNumber(v.zhouqi)}}</view>
											<view style="margin-left: auto;">
												<view class="btn_common" :class="isDark ? `btn_dark` : `btn_light`"
													style="font-size: 12px;line-height:18px;" @click="showModal(v)">
													{{$fmt.fmtText($t('common.buy'))}}
												</view>
											</view>
										</view>
									</block>
								</view>
							</view>
						</block>
					</view>
				</template>
			</template>

			<template v-if="curTab>0">
				<RecordSmall :list="record"></RecordSmall>
			</template>

			<!-- 横屏按照crypto 的底部列表模式。 -->
			<template v-if="!$theme.setLayout($C.SMALL)">
				<view style="display: flex;align-items: center;padding: 20px 0 4px 0;">
					<block v-for="(v,k) in footerTabs" :key="k">
						<view style="padding-right: 12px;font-size: 16px;" @click="changeTabRecord(k)">
							<text :style="{color:curFooterTab==k?$theme.PRIMARY:$theme.TXT_UNACT,
									borderBottom:`1px dashed ${curFooterTab==k?$theme.PRIMARY:$theme.TXT_UNACT}`}">
								{{v}}
							</text>
						</view>
					</block>
					<view style="margin-left: auto;">
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.refesh" @click="handleRefesh()" />
					</view>
				</view>
				<template v-if="!list || list.length<=0">
					<EmptyData></EmptyData>
				</template>
				<template v-else>
					<RecordLarge :list="record" />
				</template>
			</template>
		</view>

		<!-- 购买的浮层 -->
		<template v-if="isShow">
			<ModalBuy :info="curInfo" @action="closeModal" />
		</template>

	</view>
</template>

<script>
	import * as ext from './ext.js';
	import ModalBuy from './components/ModalBuy.vue';
	import RecordLarge from './components/RecordLarge.vue';
	import RecordSmall from './components/RecordSmall.vue';
	export default {
		components: {
			ModalBuy,
			RecordLarge,
			RecordSmall,
		},
		data() {
			return {
				isDark: null, // 当前主题方案
				isAnimat: null, // 页面动画
				list: null, // 列表数据
				isShow: false, // 是否显示浮层
				curInfo: null, // 选中数据
				tabs: ext.tabs(), // 顶部tabs
				curTab: 0, // 当前tab
				footerTabs: ext.footerTabs(), // 底部tab数组
				curFooterTab: 0, // 底部tabs
				record: null, // 持仓及赎回列表
			}
		},
		computed: {
			// 找出当前list中，最高收益的的一条数据，放在醒目位置
			maxSylData() {
				if (!this.list) return [];
				// 找到syl值最大的对象
				return this.list.reduce((maxItem, currentItem) => {
					return parseFloat(currentItem.syl) > parseFloat(maxItem.syl) ? currentItem : maxItem;
				});
			},

			// 将列表数据，分组。
			fmtList() {
				if (!this.list) return [];
				// 创建一个对象来存储分组结果
				return this.list.reduce((acc, item) => {
					// 将 name 转换为小写并用作键
					const key = item.name.toLowerCase();
					// 检查这个键在累加器中是否已经存在,如果不存在，则初始化为一个空数组
					if (!acc[key]) acc[key] = [];
					// 将当前项添加到对应的数组中
					acc[key].push(item);
					return acc;
				}, {});
			},
		},

		onShow() {
			if (!this.$linkTo.checkToken()) return false;
			this.isAnimat = true;
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
			if (this.$theme.setLayout(this.$C.SMALL)) this.changeTab(this.curTab);
			else {
				this.getList();
				this.changeTabRecord(this.curFooterTab);
			}
		},
		onReady() {},
		onHide() {
			console.log(`onHide:`, this.isDark);
			this.isAnimat = false;
		},
		onPullDownRefresh() {
			if (this.$theme.setLayout(this.$C.SMALL)) this.changeTab(this.curTab);
			else {
				this.getList();
				this.changeTabRecord(this.curFooterTab);
			}
			uni.stopPullDownRefresh();
		},
		deactivated() {},

		methods: {
			// 显示浮层
			showModal(val) {
				this.curInfo = val;
				this.isShow = true;
			},
			// 关闭浮层
			closeModal(val) {
				this.isShow = false;
				this.getList();
			},
			// 顶部tabs
			changeTab(val) {
				this.curTab = val;
				if (this.curTab == 0) this.getList();
				if (this.curTab > 0) this.getRecord();
			},
			// 底部列表切换
			changeTabRecord(val) {
				this.curFooterTab = val;
				this.getRecord();
			},
			// 底部刷新
			handleRefesh() {
				this.getList();
				this.changeTabRecord(this.curFooterTab);
			},

			// 获取列表数据
			async getList() {
				uni.showLoading({
					title: this.$fmt.fmtText(this.$t('api.requestData')),
				});
				const result = await this.$http.get(`api/jijin/list`);
				if (!result) return false;
				this.list = result;
			},
			// 获取持仓及赎回列表
			async getRecord() {
				// 1是持仓   2是赎回
				const temp = this.$theme.setLayout(this.$C.SMALL) ? this.curTab : this.curFooterTab + 1;
				const result = await ext.getRecord(temp);
				this.record = result;
			},
		},
	}
</script>

<style>
</style>