<template>
	<view class="custom_table">
		<view class="table_header">
			<view class="table_row">
				<block v-for="(v,k) in table.header" :key="k">
					<view class="table_cell" :style="{textAlign:table.config[k]}">
						{{v.text}}
					</view>
				</block>
			</view>
		</view>
		<view class="table_body">
			<block v-for="(v,k) in table.body" :key="k">
				<view class="table_row">
					<block v-for="(subV,index) in Object.values(v)" :key="index">
						<view class="table_cell" :style="{textAlign:table.config[index]}">{{ subV }}</view>
					</block>
				</view>
			</block>
		</view>
	</view>
</template>

<script>
	export default {
		name: "CustomTable",
		// props: {
		// 	table: {
		// 		type: Object,
		// 		default: {}
		// 	}
		// },
		data() {
			return {
				table: {
					// 文字对齐方式，文字颜色，或是使用整个自定义样式 customStyle:{}
					config:['left','left','right'],
					header: [{
						text: 'a'
					}, {
						text: 'b'
					}, {
						text: 'c',
					}],
					body: [{
						a: 1,
						b: 2,
						c: 3
					}, {
						a: 1,
						b: 2,
						c: 3
					}, {
						a: 1,
						b: 2,
						c: 3
					}],
				}
			};
		}
	}
</script>

<style>

</style>