<template>
	<view>
		<block v-for="(item,index) in list" :key="index">
			<view style="margin:2px 0;" :style="$theme.depathBidsBG(item[1],max,to)">
				<view style="display: flex;align-items: center;justify-content: space-between;padding-right:4px;"
					:style="{flexDirection:dir}">
					<view style="font-size: 12px;padding:4px 0;" :style="$theme.setRiseFall(-1)">
						{{$fmt.fmtCrypto(`${$fmt.fmtNumber(item[0],4)}`)}}
					</view>
					<view style="font-size: 12px;padding:4px 0;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtCrypto(`${$fmt.fmtNumber(item[1],4)}`)}}
					</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "BidsList",
		props: {
			list: {
				type: Array,
				default: []
			},
			max: {
				type: Number,
				default: 100
			},
			// to 表示 动态背景的to方向。 
			to: {
				type: String,
				default: ''
			},
			// 方向，兼容detail頁面反向顯示
			dir: {
				type: String,
				default: 'row', // row-reverse
			}
		},
	}
</script>

<style>

</style>