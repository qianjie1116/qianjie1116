<template>
	<view>
		<block v-for="(item,index) in list" :key="index">
			<view style="margin:2px 0;" :style="$theme.depathAsksBG(item[1],max)">
				<view style="display: flex;align-items: center;justify-content: space-between;padding-right:4px;"
					:style="{flexDirection:dir}">
					<view style="font-size: 12px;padding:4px 0;" :style="$theme.setRiseFall(1)">
						{{$fmt.fmtCrypto(`${$fmt.fmtNumber(item[0],4)}`)}}
					</view>
					<view style="font-size: 12px;padding:4px 0;" :style="{color:$theme.TXT_UNACT}">
						{{$fmt.fmtCrypto(`${$fmt.fmtNumber(item[1],4)}`)}}
					</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "AsksList",
		props: {
			list: {
				type: Array,
				default: []
			},
			max: {
				type: Number,
				default: 100
			},
			dir: {
				type: String,
				default: 'row', // row-reverse
			},
		},
	}
</script>

<style>

</style>