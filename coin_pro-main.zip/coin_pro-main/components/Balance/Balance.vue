<template>
	<view style="display: flex;align-items: center;padding-top: 8px;">
		<view style="padding-right: 12px;" :style="{color:$theme.TXT_UNACT}">
			{{$fmt.fmtText($t('common.balance'))}}
		</view>
		<view style="margin-left: auto;">
			<view style="display: flex;align-items: center;">
				<view>
					<template v-if="usdt">
						<view style="display: flex;align-items: center;">
							<FmtNumber :value="balance" :usdt="usdt" />
							<text style="font-size: 10px;padding-left: 4px;"
								:style="{color:$theme.TXT_UNACT}">{{fmtUnit}}</text>
						</view>
					</template>
					<block v-for="(v,k) in setConfig" :key="k">
						<FmtNumber :value="$fmt.fmtNumber(balance*v.rate,$decimal)" :color="v.color" :code="v.code" />
					</block>
				</view>
				<template v-if="recharge">
					<text style="font-size: 12px;padding-left: 4px;"
						:style="{color:$theme.PRIMARY,borderBottom:`1px solid `+$theme.PRIMARY}"
						@click="$linkTo.linkAssets($C.KEY_RECHARGE)">
						{{$fmt.fmtText($t('assets.recharge'))}}
					</text>
				</template>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "Balance",
		props: {
			// 余额值
			balance: {
				type: [Number, String],
				default: 0
			},
			// 余额单位
			unit: {
				type: String,
				default: ''
			},
			// 是否需要快捷充值入口
			recharge: {
				type: Boolean,
				default: false
			},
			// 是否usdt
			usdt: {
				type: Boolean,
				default: false
			},
			// 汇率 
			config: {
				type: Array,
				default: () => {
					return [
						// 	{
						// 	code: "en-US",
						// 	rate: 1
						// }
						// , {
						// 	code: "it-IT",
						// 	rate: 1.3
						// },
					]
				}
			},
		},
		computed: {
			// 余额单位
			fmtUnit() {
				return this.unit == 'USDT' ? this.unit : this.$fmt.fmtText(this.unit);
			},

			// 多显
			setConfig() {
				return this.config.map((item, index) => {
					return {
						...item,
						color: index == 0 ? this.$theme.TXT_UNACT : this.$theme.randomBGColor()
					}
				})
			}
		}
	}
</script>

<style>

</style>