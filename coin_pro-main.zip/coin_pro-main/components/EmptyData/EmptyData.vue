<template>
	<view style="text-align: center;padding-top: 40px;">
		<image :src="`/static/empty_${img}.png`" mode="aspectFit" :style="$theme.setImageSize(size)"></image>
		<view style="font-size: 14px;" :style="{color:isDark?'#838b9c':'#838b9c' }">{{$t('common.emptyData')}}</view>
	</view>
</template>

<script>
	export default {
		name: "EmptyData",
		props: {
			dark: {
				type: Boolean,
				default: true
			},
			// 空数据时，显示的图片
			img: {
				type: String,
				default: 'data'
			},
			size: {
				type: Number,
				default: 200
			}
		},
		data() {
			return {
				isDark: this.dark,
			};
		},
	}
</script>

<style>

</style>