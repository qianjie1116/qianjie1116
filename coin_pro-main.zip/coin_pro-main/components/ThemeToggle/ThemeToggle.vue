<template>
	<view style="display: flex;align-items: center;flex-direction: column;justify-content: center;">
		<image :src="`/static/theme_${isDark?0:1}.svg`" mode="widthFix" style="cursor: pointer;"
			:style="$theme.setImageSize(20)" @click="toggleTheme()"></image>
	</view>
</template>

<script>
	export default {
		name: 'ThemeToggle',
		props: {
			dark: {
				type: Boolean,
				default: true,
				required: true,
			}
		},
		data() {
			return {
				isDark: this.dark,
			}
		},
		watch: {
			// 确保 prop 的变化可以同步到 isDark
			dark(newVal) {
				this.isDark = newVal;
			},
		},
		methods: {
			// 主题切换
			toggleTheme() {
				this.isDark = !this.isDark;
				console.log(`toggle:`, this.isDark);
				this.$theme.setTheme(this.isDark);
				this.$emit('update:dark', this.isDark);
			},
		}
	}
</script>

<style>
</style>