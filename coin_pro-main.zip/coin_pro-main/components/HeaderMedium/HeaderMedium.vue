<template>
	<header class="header_medium" :style="setStyle(isDark)">
		<view style="display: flex;align-items: center;">
			<image src="/static/logo_name.png" mode="aspectFit" style="cursor: pointer;"
				:style="$theme.setImageSize(120,28)" @click="$linkTo.home()"></image>
			<view style="margin-left: auto;">
				<view style="display: flex;align-items: center;">
					<template v-if="isSignIn">
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.wallet" @click="$linkTo.linkAssets()" />
						<view style=" width: 12px;"></view>
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.user" @click="$linkTo.linkAccount()" />
					</template>
					<template v-else>
						<view @click="$linkTo.signIn()"
							style=" padding:0 6px;border-radius: 3px;cursor: pointer;min-width: max-content;"
							:style="{backgroundColor:$theme.PRIMARY}">
							{{$fmt.fmtText($t('sigin.titleIn'))}}
						</view>
					</template>
					<view style=" width: 12px;"></view>
					<CustomSvg :color="$theme.PRIMARY" :path="$svg.menu" @click="openMenu()" />
				</view>
			</view>
		</view>

		<!-- 菜单 的弹层 -->
		<template v-if="isShowMenu">
			<MenuMedium @action="handleClose" :dark.sync="isDark" @update:dark="updateTheme"></MenuMedium>
		</template>
	</header>
</template>

<script>
	export default {
		name: "HeaderMedium",
		props: {
			dark: {
				type: Boolean,
				default: true,
			}
		},
		data() {
			return {
				isDark: this.dark, // 当前主题方案
				isShowMenu: false, // 打开菜单
				isSignIn: null, // 当前是否已登入
			}
		},
		computed: {},
		beforeMount() {
			this.isSignIn = uni.getStorageSync('token').length > 0;
			console.log(this.isSignIn);
		},

		methods: {
			updateTheme(newTheme) {
				this.$emit('update:dark', newTheme);
			},

			// 右侧打开菜单
			openMenu() {
				this.isShowMenu = true;
			},
			handleClose(val) {
				if (val == 'theme') {
					this.toggleTheme();
					return false;
				}
				this.isShowMenu = false;
			},

			// header 主题样式
			setStyle() {
				return {
					backgroundColor: this.$theme.HEADER_BG,
					borderBottom: `1px solid ${this.$theme.HEADER_BORDER}`,
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	.header_medium {
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		height: 36px;
		line-height: 36px;
		padding: 10px 20px;
		z-index: 9;
	}
</style>