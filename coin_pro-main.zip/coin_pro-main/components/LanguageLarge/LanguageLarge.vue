<template>
	<view>
		<view class="overlay" style="background-color: rgba(0, 0, 0, 0.6);" @click="handleClose()"></view>
		<view class="modal_wrapper" :style="{backgroundColor:$theme.BASIC_BG}">
			<view style="min-height: 100vh;width: 100%;overflow-y: auto;">
				<view style="display: flex;align-items: center;justify-content: space-between;padding:40px 20px;">
					<text style="font-size: 20px;font-weight: 700;">
						{{$fmt.fmtText($t('common.selectLanguage'))}}
					</text>

					<view>
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.close" @click="handleClose()" />
					</view>

					<!-- <image :src="`/static/close_${dark?0:1}.svg`" mode="aspectFit" style="cursor: pointer;"
						:style="$theme.setImageSize()" @click="handleClose()">
					</image> -->
				</view>
				<block v-for="(v,k) in list" :key="k">
					<view class="item" @click="chooseLang(v)">
						<image :src="`/static/flags/${v.flag}.svg`" mode="scaleToFill" :style="$theme.setImageSize()">
						</image>
						<view style="padding-left:8px;min-width: max-content;">{{v.lang}}</view>
					</view>
				</block>
			</view>
		</view>
	</view>
</template>

<script>
	import localize from '@/common/localize.js';
	export default {
		name: "LanguageLarge",
		props: {
			dark: {
				type: Boolean,
				default: true,
				required: true,
			}
		},
		computed: {
			list() {
				console.log(localize)
				return localize;
			}
		},
		beforeMount() {
			console.log(`list:`, this.list);
		},
		methods: {
			handleClose() {
				this.$emit('close', null);
			},
			// 切换选中语言
			chooseLang(val) {
				console.log(`lang ???`, val);
				uni.setStorageSync('locale', val.code);
				uni.setStorageSync('lang', val.lang);
				// this.$i18n.locale = 'zh-Hans';

				this.$i18n.locale = val.code;
				console.log(`i18n:`, this.$i18n.locale);
				// 強制刷新當前頁面
				const currentPage = this.$route.fullPath;
				uni.reLaunch({
					url: currentPage
				});
				this.$emit('close', val.code);
			},
		}
	}
</script>

<style lang="scss" scoped>
	.modal_wrapper {
		position: fixed;
		top: 0;
		bottom: 0;
		right: 0;
		z-index: 13;
		width: 20vw;
		animation: rightIn 300ms forwards;
		overflow-y: auto;
	}

	.item {
		display: flex;
		align-items: center;
		padding: 12px 24px;
	}

	.item:hover {
		background-color: #3c3f4b;
	}
</style>