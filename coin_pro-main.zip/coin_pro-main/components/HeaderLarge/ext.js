import Vue from 'vue';
import i18n from '@/locales/index.js';
import * as constants from '@/common/constants.js';
import * as fmt from '@/common/format.js';
import http from '@/common/http.js';
import * as icons from '@/icons/index.js';
import * as linkTo from '@/common/linkTo.js';
// import {
// 	translate
// } from '@/common/util.js';


export const headers = () => {
	return [{
			name: fmt.fmtText(i18n.t('header.home')),
			url: linkTo.HOME,
		}, {
			name: fmt.fmtText(i18n.t("header.markets")),
			url: linkTo.MARKET,
			auth: true,
		}, {
			name: fmt.fmtText(i18n.t("header.trade")),
			url: linkTo.CRYPTO + `?tag=${constants.KEY_CRYPTO_SPT}`,
			auth: true,
		}, {
			name: fmt.fmtText(i18n.t("header.defi")),
			url: linkTo.DEFI,
			auth: true,
		},
		// {
		// 	name: fmt.fmtText(i18n.t("header.pledge")),
		// 	url: linkTo.PLEDGE,
		// 	auth: true,
		// },
		{
			name: fmt.fmtText(i18n.t("header.ctc")),
			url: linkTo.CTC,
			auth: true,
		},
		{
			name: fmt.fmtText(i18n.t("tradeIPO.title")),
			url: linkTo.TRADE_IPO,
			auth: true,
		},
		{
			name: fmt.fmtText(i18n.t("header.loan")),
			url: linkTo.LOAN,
			auth: true,
		},
		// {
		// 	name: fmt.fmtText(i18n.t("header.rule")),
		// 	url: linkTo.RULE,
		// 	auth: true,
		// }, {
		// 	name: fmt.fmtText(i18n.t("header.wealth")),
		// 	url: linkTo.WEALTH,
		// 	auth: true,
		// },
	]
}