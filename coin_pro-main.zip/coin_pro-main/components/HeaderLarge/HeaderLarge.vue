<template>
	<header class="header_large" :style="{
					backgroundColor: this.$theme.HEADER_BG,
					borderBottom: `1px solid ${this.$theme.HEADER_BORDER}`,
				}">
		<view style="display: flex;align-items: center;">
			<image src="/static/logo.png" mode="aspectFit" :style="$theme.setImageSize(28)"></image>
			<view style="padding-left: 16px;">
				<view style="display: flex;align-items: center;">
					<block v-for="(v,k) in headers" :key="k">
						<view class="nav_item" :style="setStyleNav(curActive ==k)" @click="linkTo(v,k)">
							{{$fmt.fmtText(v.name)}}
						</view>
					</block>
				</view>
			</view>
			<view style="margin-left: auto;">
				<view style="display: flex;align-items: center;">
					<template v-if="isSignIn">
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.wallet" @click="$linkTo.linkAssets()" />
						<view style=" width: 12px;"></view>
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.user" @click="$linkTo.linkAccount()" />
					</template>
					<template v-else>
						<view @click="$linkTo.signIn()"
							style="padding:0 6px;border-radius: 3px;cursor: pointer;min-width: max-content;"
							:style="{backgroundColor:$theme.PRIMARY}">
							{{$fmt.fmtText($t('sigin.titleIn'))}}
						</view>
					</template>
					<view style=" width: 12px;"></view>
					<!-- <CustomSvg :color="$theme.PRIMARY" :path="$svg.download" :size="32" @click="$linkTo.download()" />
					<view style=" width: 12px;"></view> -->
					<CustomSvg :color="$theme.PRIMARY" :path="$svg.service" @click="$util.linkCustomerService()" />
					<view style=" width: 12px;"></view>
					<CustomSvg :color="$theme.PRIMARY" :path="$svg.translate" @click="showTranslate()" />
					<view style=" width: 12px;"></view>
					<view style="margin-left: auto;">
						<ThemeToggle :dark.sync="isDark" @update:dark="updateTheme" />
					</view>
				</view>
			</view>
		</view>

		<!-- 语言选择弹层 LanguageLarge   -->
		<template v-if="showModal">
			<LanguageLarge :dark="isDark" @close="closeTranslate" />
		</template>
	</header>
</template>

<script>
	import * as ext from './ext.js';
	export default {
		name: "HeaderLarge",
		props: {
			dark: {
				type: Boolean,
				default: true,
			}
		},
		data() {
			return {
				curActive: 0,
				isDark: this.dark, // 当前主题方案
				// curLanguage: null, // 语言
				// curLocale: null, // 本地化
				showModal: false, // 是否显示语言选项组(宽屏使用)
				isSignIn: null, // 当前是否已登入
				headers: ext.headers(),
			};
		},
		computed: {},
		beforeMount() {
			// 根据url，找到包含当前url在数组的下标。 
			const curURL = this.$route.fullPath.slice(7).split('/');
			const temp = this.headers.findIndex(item => item.url.split('/')[0] == curURL[0]);
			this.curActive = temp;
			this.isSignIn = uni.getStorageSync('token').length > 0;
			console.log(`isSignIn:`, this.isSignIn);
		},

		methods: {
			updateTheme(newTheme) {
				this.$emit('update:dark', newTheme);
			},

			// 显示语言选项组
			showTranslate() {
				this.showModal = true;
			},
			closeTranslate(val) {
				console.log(`close val:`, val);
				this.showModal = false;
				this.headers = ext.headers();
				console.log(`headers:`, this.headers);
			},

			// 跳转到 指定页面
			linkTo(val, index) {
				console.log(`val:`, val);
				const temp = this.headers[index];
				if (temp.auth) {
					if (!this.$linkTo.checkToken()) return false;
				}
				uni.navigateTo({
					url: this.$linkTo.PAGES + temp.url,
				})
			},
			// 导航激活样式
			setStyleNav(val) {
				return {
					color: val ? this.$theme.PRIMARY : this.$theme.TXT_UNACT,
					borderBottom: `1px solid  ${val?this.$theme.PRIMARY_TXT:this.$theme.TRANSPARENT}`,
				}
			},

		}
	}
</script>

<style lang="scss" scoped>
	@import url(./style.css);
</style>