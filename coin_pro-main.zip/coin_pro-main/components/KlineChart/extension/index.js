import circle from "./circle.js";
import rect from './rect.js';
import parallelogram from './parallelogram.js';
import triangle from './triangle.js';
import abcd from "./abcd.js";
import anyWaves from './anyWaves.js';
import arrow from './arrow.js';
import eightWaves from './eightWaves.js';
import fibonacciCircle from './fibonacciCircle.js';
import fibonacciExtension from './fibonacciExtension.js';
import fibonacciSegment from './fibonacciSegment.js';
import fibonacciSpeedResistanceFan from './fibonacciSpeedResistanceFan.js';
import fibonacciSpiral from './fibonacciSpiral.js';
import fiveWaves from './fiveWaves.js';
import gannBox from './gannBox.js';
import threeWaves from './threeWaves.js';
import xabcd from './xabcd.js';

const overlays = [
	circle,
	rect,
	parallelogram,
	triangle,
	abcd,
	anyWaves,
	arrow,
	eightWaves,
	fibonacciCircle,
	fibonacciExtension,
	fibonacciSegment,
	fibonacciSpeedResistanceFan,
	fibonacciSpiral,
	fiveWaves,
	gannBox,
	threeWaves,
	xabcd,
];

export default overlays;