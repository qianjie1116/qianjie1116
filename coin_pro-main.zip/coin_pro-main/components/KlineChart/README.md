# Custom KlineChart

```
extension:扩展的overlay
icons:svg转字符串
locale:多语言
modal:各个工具的弹层（包含选项及参数调整）
config.js:配置项
KlineChart:外部使用组件
utils.js:工具类
```