<template>
	<view>
		<view style="display: flex;align-items: center;padding-bottom: 12px;">
			<view style="padding-right: 6px;font-size:11px;">{{$fmt.fmtText($t('common.time'))}}:</view>
			<view style="padding-right: 12px;" @click="isTimes = true">
				<view style="position: relative;">
					<text :style="{color:$theme.PRIMARY,borderBottom:`1px dashed ${$theme.PRIMARY}`}">
						{{curTime}}</text>
					<template v-if="isTimes">
						<view style="position: absolute;z-index: 9;right: 0; background-color: #0a0c13;">
							<block v-for="(v,k) in times" :key="k">
								<view style="text-align: center;padding:8px 20px;" @click.stop="chooseTime(v,k)">{{v}}
								</view>
							</block>
						</view>
						<view class="overlay" @click.stop="closeChoose()"> </view>
					</template>
				</view>
			</view>
			<view style="padding-right: 6px;font-size:11px;">{{$fmt.fmtText($t('common.indicator'))}}:
			</view>
			<view style="padding-right: 12px;" @click="isIndicators = true">
				<view style="position: relative;">
					<text
						:style="{color:$theme.PRIMARY,borderBottom:`1px dashed ${$theme.PRIMARY}`}">{{curIndicator}}</text>
					<template v-if="isIndicators">
						<view style="position: absolute;z-index: 9;right: 0; background-color: #0a0c13;">
							<view style="height: 360px;overflow-y: auto;">
								<block v-for="(v,k) in indicators" :key="k">
									<view style="text-align: center;padding:8px 20px;"
										@click.stop="chooseIndicator(v,k)">
										{{v}}
									</view>
								</block>
							</view>
						</view>
						<view class="overlay" @click.stop="closeChoose()"> </view>
					</template>
				</view>
			</view>
			<view style="padding-right: 6px;font-size:11px;">{{$fmt.fmtText($t('common.candle'))}}:</view>
			<view style="padding-right: 12px;" @click="isCandles=true">
				<view style="position: relative;">
					<text
						:style="{color:$theme.PRIMARY,borderBottom:`1px dashed ${$theme.PRIMARY}`}">{{fmtCandle}}</text>
					<template v-if="isCandles">
						<view style="position: absolute;z-index: 9;right: -30px; background-color: #0a0c13;">
							<block v-for="(v,k) in candles" :key="k">
								<view style="text-align: center;padding:8px 20px;" @click.stop="chooseCandle(v,k)">
									{{$fmt.fmtText(v)}}
								</view>
							</block>
						</view>
						<view class="overlay" @click.stop="closeChoose()"> </view>
					</template>
				</view>
			</view>
			<view style="padding-right: 6px;font-size:11px;">{{$fmt.fmtText($t('common.brush'))}}:</view>
			<view style="padding-right: 12px;" @click="isBrushs=true">
				<view :style="{color:$theme.PRIMARY,borderBottom:`1px dashed ${$theme.PRIMARY}`}">
					<view style="position: relative;">
						<view>
							<CustomSvg :color="$theme.PRIMARY" :path="curBrush.icon" />
						</view>
					</view>
					<template v-if="isBrushs">
						<view style="position: absolute;z-index: 9;right: 50px;width: 80px; background-color: #0a0c13;">
							<view style="height: 360px;overflow-y: auto;">
								<block v-for="(v,k) in brushs" :key="k">
									<view @click.stop="chooseBrush(v,k)">
										<CustomSvg :color="$theme.PRIMARY" :path="v.icon" />
									</view>
								</block>
							</view>
						</view>
						<view class="overlay" @click.stop="closeChoose()"> </view>
					</template>
				</view>
			</view>
			<view style="margin-left: auto;">
				<CustomSvg :color="$theme.TXT_UNACT" :path="$svg.eraser" @click="clearBrush()" />
			</view>
		</view>

		<view id="kline-small" style="width: 100%;height:560px;"> </view>

	</view>
</template>

<script>
	import {
		init,
		registerOverlay,
		dispose,
	} from './klinecharts.min.js';
	import overlays from './extension/index.js';
	import * as config from './config/index.js';
	import genChartData from "./genChartData.js";
	// 将定义好的扩展覆盖物绘制，逐一注册到klinechart中
	overlays.forEach(item => registerOverlay(item));
	import localize from '@/common/localize.js';
	export default {
		name: 'KlineSmall',
		props: {
			list: {
				type: Array,
				default: () => []
			}
		},
		data() {
			return {
				chart: null, // 当前kline实例
				indicator: null, // 当前技术指标实例
				times: config.times,
				indicators: config.indicators,
				candles: config.candles,
				brushs: config.brushs(),
				curTime: null,
				curIndicator: null,
				curCandle: null,
				curBrush: null, // 笔刷
				isTimes: false, // 是否显示时间选择器
				isIndicators: false, // 是否显示技术指标选择器
				isCandles: false, // 是否显示柱形选择器
				isBrushs: false, // 是否显示笔刷选择器
			};
		},

		computed: {
			// 当前柱形显示值格式化
			fmtCandle() {
				if (this.curCandle.includes('up'))
					return this.$fmt.fmtText(this.curCandle.split('_')[0]);
				if (this.curCandle.includes('down'))
					return this.$fmt.fmtText(this.curCandle.split('_')[0]);
				return this.$fmt.fmtText(this.curCandle);
			},
		},

		beforeMount() {
			this.curTime = this.times[0];
			this.curIndicator = this.indicators[0];
			this.curCandle = this.candles[0];
			this.curBrush = this.brushs[0]; // 笔刷
		},

		mounted() {
			this.chart = init("kline-small");
			const temp = localize[uni.getStorageSync('locale')];
			this.chart.setTimezone(temp.timeZone);
			this.setCandle();
			this.chart.setPriceVolumePrecision(this.$decimal, 0)
			this.chart.applyNewData(this.list)

			if (!this.indicator) {
				this.indicator = this.chart.createIndicator(this.curIndicator);
			}
		},
		unmounted() {
			this.clearIndicator();
			this.clearBrush();
			dispose("kline-small");
			this.clearData();
		},
		methods: {
			// 通用关闭选择器
			closeChoose() {
				this.isTimes = false;
				this.isIndicators = false;
				this.isCandles = false;
				this.isBrushs = false;
			},

			// 选中一个时间
			chooseTime(val, index) {
				this.curTime = val;
				// 逐层上递，到index.vue中做请求。
				this.isTimes = false;
				this.$emit('action', index);
			},

			// 选择一个技术指标
			chooseIndicator(val, index) {
				// 直接在当前组件中处理
				this.curIndicator = val;
				this.isIndicators = false;
				this.clearIndicator();
				// 主图表之下的技术指标先死
				this.indicator = this.chart.createIndicator(this.curIndicator, false);
				// 主图表上的技术指标设置
				// this.chart.createIndicator(this.curIndicator, true, {
				// 	id: 'candle_pane'
				// })
			},

			// 选择一个柱形
			chooseCandle(val, index) {
				// 直接在当前组件中处理
				this.curCandle = val;
				this.isCandles = false;
				this.setCandle();
			},

			// 选择一个笔刷工具
			chooseBrush(val) {
				this.curBrush = val;
				this.isBrushs = false;
				// 创建选中笔刷绘制覆盖物
				this.chart.createOverlay(val.key);
			},

			// 设置主图表图形显示方式
			setCandle() {
				let temp;
				if (this.curCandle == 'area') temp = config.klineArea;
				else if (this.curCandle == 'ohlc') {
					config.klineCandle.type = this.curCandle;
					temp = config.klineCandle;
				} else {
					config.klineCandle.type = `candle_${this.curCandle}`;
					temp = config.klineCandle;
				}
				this.chart.setStyles({
					grid: config.klineGird,
					// Area用面积图 后面用蜡烛图
					candle: temp,
				});
			},

			// 创建一个注解 （属于覆盖物的一种，随橡皮擦一同清除）
			createAnnotation() {
				const dataList = this.chart.getDataList();
				const data = dataList[dataList.length - 20];
				this.chart.createOverlay({
					name: "simpleAnnotation",
					extendData: "注解注解注解",
					points: [{
						timestamp: data.timestamp,
						value: data.high
					}, ],
				});
			},

			// 创建一个标签  （属于覆盖物的一种，随橡皮擦一同清除）
			createTag() {
				const dataList = this.chart.getDataList();
				const data = dataList[dataList.length - 10];
				this.chart.createOverlay({
					name: "simpleTag",
					extendData: "标签标签",
					points: [{
						value: data.high
					}],
				});
			},

			// 橡皮擦，清理所有覆盖物
			clearBrush() {
				this.chart.removeOverlay();
			},
			// 清理数据
			clearData() {
				if (this.chart) this.chart.clearData();
				this.chart = null;
			},
			// 清理技术指标
			clearIndicator() {
				if (this.indicator) {
					this.chart.removeIndicator(this.indicator);
					this.indicator = null;
				}
			}
		},
	}
</script>

<style>
</style>