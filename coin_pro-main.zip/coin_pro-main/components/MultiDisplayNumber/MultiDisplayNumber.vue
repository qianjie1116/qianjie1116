<template>
	<view>
		<template v-if="$util.isUSDT(code)">
			<text :style="{fontSize:`${size}px`}">{{$fmt.fmtCrypto(`${value}`) }}</text>
		</template>
		<template v-else>
			<block v-for="(v,k,index) in config" :key="k">
				<template v-if="!multi">
					<template v-if="index==0">
						<view style="font-size: 12px;" :style="{color:v.color}">
							{{$fmt.fmtCurrency(`${$fmt.fmtNumber(`${value*v.rate}`,v.decimal)}`, k)}}
						</view>
					</template>
				</template>
				<template v-else>
					<view style="font-size: 12px;" :style="{color:v.color}">
						{{$fmt.fmtCurrency(`${$fmt.fmtNumber(`${value*v.rate}`,v.decimal)}`, k)}}
					</view>
				</template>
			</block>
		</template>
	</view>
</template>

<script>
	/**
	 * @example
		<MultiDisplayNumber 
		:value="需要格式化的值" 
		:config="格式化配置项",因为汇率后台可改,随页面打开调用获取最新汇率
		:code="curKey" 用于判断是否为usdt相关
		 />
	 */
	export default {
		// 传入值多种显示方式。通常为非usdt的一些金额值
		name: "MultiDisplayNumber",
		props: {
			// 字号
			size: {
				type: Number,
				default: 12
			},
			// 带有最新汇率的数组对象
			config: {
				type: Object,
				default: {}
			},
			// 值
			value: {
				type: [Number, String],
				default: 0
			},
			// code  用于判定当前值是否为usdt。
			code: {
				type: String,
				default: ''
			},
			multi: {
				type: Boolean,
				default: false
			}
		},
		data() {
			return {};
		},
		beforeMount() {
			// console.log(`code:`, this.code);
			console.log(`value:`, this.value);
		}
	}
</script>

<style>

</style>