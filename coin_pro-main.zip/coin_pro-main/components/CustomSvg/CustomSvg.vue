<template>
	<div class="svg-container" @click="handleClick">
		<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1024 1024" :width="size" :height="size" :fill="color"
			v-html="path">
		</svg>
	</div>
</template>

<script>
	export default {
		name: "CustomSvg",
		props: {
			size: {
				type: [Number, String],
				default: 24,
			},
			color: {
				type: String,
				default: ''
			},
			path: {
				type: String,
				default: ''
			},
		},
		methods: {
			// 部分icon需要挂载点击事件
			handleClick() {
				// 处理点击事件的逻辑
				this.$emit('click'); // 发出点击事件，供父组件捕获
			}
		}
	}
</script>

<style>

</style>