<template>
	<view class="right_in">
		<view style="font-size: 24px;padding-top: 40px;padding-bottom: 10px;">Fund your account to start trading</view>
		<view style="">{{$APP_NAME}}Multiple deposit methods are supported, and you can choose the
			method that suits you
			best.</view>

		<view style="display: flex;align-items: center;justify-content: space-between;padding-top: 40px;">
			<view style="flex:0 0 32%;" @click="recharge($C.KEY_RECHARGE)">
				<view style="padding: 10px 16px;   font-size: 14px;   background: #1f212d;   color: #acacac;
				border-radius: 2px;   cursor: pointer;display: flex;align-items: center;height:100px;">
					<image src="/static/top3.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
					<view style="padding-left: 10px;">
						<view style="padding-bottom: 10px;" :style="{color:$theme.BASIC_TXT}">
							{{$t('assets.recharge')}}
						</view>
						<view style="font-size: 12px;line-height: 1.4;">{{$t('tip.recharge')}}</view>

					</view>
				</view>
			</view>

			<view style="flex:0 0 32%;" @click="withdraw($C.KEY_WITHDRAW)">
				<view style="padding: 10px 16px;   font-size: 14px;   background: #1f212d;   color: #acacac;
				border-radius: 2px;   cursor: pointer;display: flex;align-items: center;height:100px;">
					<image src="/static/top2.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
					<view style="padding-left: 10px;">
						<view style="padding-bottom: 10px;" :style="{color:$theme.BASIC_TXT}">
							{{$t('assets.withdraw')}}
						</view>
						<view style="font-size: 12px;line-height: 1.4;">{{$t('tip.withdraw')}}</view>
					</view>
				</view>
			</view>

			<view style="flex:0 0 32%;" @click="transfer($C.KEY_TRANSFER)">
				<view style="padding: 10px 16px;   font-size: 14px;   background: #1f212d;   color: #acacac;
				border-radius: 2px;   cursor: pointer;display: flex;align-items: center;height:100px;">
					<image src="/static/top3.png" mode="aspectFit" :style="$theme.setImageSize(60)"></image>
					<view style="padding-left: 10px;">
						<view style="padding-bottom: 10px;" :style="{color:$theme.BASIC_TXT}">
							{{$t('assets.transfer')}}
						</view>
						<view style="font-size: 12px;line-height: 1.4;">{{$t('tip.transfer')}}</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "AssetOper",
		data() {
			return {
				info: null, // 帮助中心信息
			}
		},

		beforeMount() {},

		methods: {
			recharge(val) {
				this.$emit('action', val);
			},
			withdraw(val) {
				this.$emit('action', val);
			},
			transfer(val) {
				this.$emit('action', val);
			}
		},
	}
</script>

<style>

</style>