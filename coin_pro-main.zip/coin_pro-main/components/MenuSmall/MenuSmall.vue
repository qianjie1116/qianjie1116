<template>
	<view>
		
	</view>
</template>

<script>
	export default {
		name:"MenuSmall",
		data() {
			return {
				
			};
		}
	}
</script>

<style>

</style>