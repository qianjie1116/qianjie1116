<template>
	<header class="app_header">
		<view class="left">
			<CustomSvg :color="$theme.PRIMARY" :path="$svg.arrowLeft" @click="goBack()" />
		</view>
		<view class="center">
			<view style="text-align: center;">{{title}}</view>
		</view>
		<view class="right">
			<view style="display: flex;align-items: center;">
				<template v-if="isClose">
					<view>
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.close" @click="$linkTo.home()" />
					</view>
				</template>
				<template v-if="isService">
					<view>
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.service" @click="$util.linkCustomerService()" />
					</view>
				</template>
				<!-- 用于扩展，通常是 rule 或者 record -->
				<slot></slot>
			</view>
		</view>
	</header>
</template>

<script>
	export default {
		name: "HeaderSmall",
		props: {
			dark: {
				type: Boolean,
				default: true
			},
			title: {
				type: String,
				default: ''
			},
			isService: {
				type: Boolean,
				default: false,
			},
			isClose: {
				type: Boolean,
				default: false,
			},
			// 是否外部自定义跳转
			isLink: {
				type: Boolean,
				default: false,
			}
		},
		data() {
			return {
				isDark: this.dark, // 当前主题方案
			}
		},
		created() {},
		mounted() {},
		methods: {
			// 回退
			goBack() {
				if (this.isLink) {
					this.$emit('back', this.isLink);
				} else {
					this.$util.goBack()
				}
			},
		},
	}
</script>

<style lang="scss" scoped>
	.app_header {
		padding: 24px 20px 10px 20px;
		display: flex;
		align-items: center;
		border-bottom: 1px solid #34393e;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			font-size: 32rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>