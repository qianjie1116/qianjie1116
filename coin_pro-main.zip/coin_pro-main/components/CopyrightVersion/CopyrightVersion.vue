<template>
	<view style="padding-bottom: 10px;display: flex;align-items: center;justify-content: center;">
		<view>{{copyright}}</view>
		<view style="padding-left: 40px;">{{version}}</view>
	</view>
</template>

<script>
	import localize from '@/common/localize.js';
	export default {
		name: "CopyrightVersion",
		data() {
			return {
				isDark: null, // 是否深色调
			}
		},
		computed: {
			copyright() {
				return this.$APP_NAME + ` © ` + this.setToYear
			},
			version() {
				return this.$fmt.fmtText(this.$t('common.version')) + ` ` + this.$VERSION
			},

			setToYear() {
				const opt = {
					year: 'numeric',
				};
				const tempLocale = uni.getStorageSync('locale') || this.$C.DEFAULT_LOCALE;
				const temp = localize[tempLocale];
				return new Intl.DateTimeFormat(temp.code, {
					...opt,
					timeZone: temp.timeZone
				}).format(new Date());
			}
		},
		beforeMount() {
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
		},
	}
</script>

<style>

</style>