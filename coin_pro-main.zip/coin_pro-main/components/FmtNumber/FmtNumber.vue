<template>
	<view :style="{fontSize:`${size}px`,color:color}">{{fmtValue}}</view>
</template>

<script>
	/**
	 * @example
	 * <FmtNumber :value="$fmt.fmtNumber(balance*v.rate,$decimal)" :color="v.color" :code="v.code" />
	 */
	export default {
		name: "FmtNumber",
		props: {
			// 字号
			size: {
				type: Number,
				default: 12
			},
			// 需要格式化的值
			value: {
				type: [Number, String],
				default: 0
			},
			// 是否usdt
			usdt: {
				type: Boolean,
				default: false
			},
			// 字色
			color: {
				type: String,
				default: ''
			},
			// 区域代码
			code: {
				type: String,
				default: ''
			}
		},
		computed: {
			fmtValue() {
				return this.usdt ? this.$fmt.fmtCrypto(`${this.value}`) :
					// 非usdt 需根据区域代码格式化为指定区域数字易读格式
					this.$fmt.fmtCurrency(`${this.value}`, this.code);
			},
		}
	}
</script>

<style>

</style>