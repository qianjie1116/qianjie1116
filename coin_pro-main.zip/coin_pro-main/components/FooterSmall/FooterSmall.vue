<template>
	<footer :style="setStyle()">
		<view style="display: flex;align-items: center;">
			<block v-for="(item,index) in navList" :key="index">
				<view style="flex:0 0 20%;">
					<view :style="setStyleNav(curActive ==index)" @click="linkTo(item.url)">
						<!-- ${active==index?'_act':''} -->
						<view>
							<CustomSvg :color="curActive ==index?$theme.PRIMARY:$theme.TXT_UNACT"
								:path="curActive ==index?item.act:item.unact" />
						</view>
						<view style="font-size: 12.48px;padding-top: 4px;">
							{{$fmt.fmtText( item.name)}}
						</view>
					</view>
				</view>
			</block>
		</view>
	</footer>
</template>

<script>
	export default {
		name: "FooterSmall",
		props: {
			dark: {
				type: Boolean,
				default: true,
			}
		},
		data() {
			return {
				isDark: this.dark, // 当前主题方案
				curActive: 0,
				navList: [{
					name: this.$t('header.home'),
					act: this.$svg.footerHome,
					unact: this.$svg.footerHomeUn,
					url: this.$linkTo.HOME,
				}, {
					name: this.$t('header.markets'),
					act: this.$svg.footerMarket,
					unact: this.$svg.footerMarketUn,
					url: this.$linkTo.MARKET
				}, {
					name: this.$t('header.trade'),
					act: this.$svg.footerTrade,
					unact: this.$svg.footerTradeUn,
					url: this.$linkTo.TRADE
				}, {
					name: this.$t('header.wealth'),
					act: this.$svg.footerWealth,
					unact: this.$svg.footerWealthUn,
					url: this.$linkTo.WEALTH
				}, {
					name: this.$t('header.assets'),
					act: this.$svg.footerAssets,
					unact: this.$svg.footerAssetsUn,
					url: this.$linkTo.ASSETS
				}]
			};
		},
		computed: {},

		beforeMount() {
			this.isDark = uni.getStorageSync('theme') == this.$C.DARK;
			console.log(`FooterSmall dark:`, this.isDark);
			// 根据url，找到包含当前url在数组的下标。 
			const curURL = this.$route.fullPath.slice(7).split('/');
			const temp = this.navList.findIndex(item => item.url.split('/')[0] == curURL[0]);
			this.curActive = temp;
		},
		methods: {
			// 跳转到 指定页面
			linkTo(val) {
				console.log(`val111:`, val);
				uni.navigateTo({
					url: this.$linkTo.PAGES + val,
				})
			},

			// footer 主题样式
			setStyle() {
				return {
					position: 'fixed',
					bottom: 0,
					left: 0,
					right: 0,
					padding: `8px 0`,
					backgroundColor: this.$theme.HEADER_BG,
					borderTop: `1px solid ${this.$theme.HEADER_BORDER}`,
					zIndex: 9,
				}
			},
			// 导航激活样式
			setStyleNav(val) {
				return {
					color: val ? '#546bff' : '#838b9c',
					textAlign: `center`,
				}
			}
		}
	}
</script>

<style>

</style>