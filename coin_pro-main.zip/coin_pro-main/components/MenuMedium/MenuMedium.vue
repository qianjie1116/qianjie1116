<template>
	<view>
		<view class="overlay" @click="handleClose()"></view>
		<view class="menu_modal_wrapper" :style="{backgroundColor:$theme.BASIC_BG}">
			<view style="min-height: 100vh;width: 100%;overflow-y: auto;">
				<view style="display: flex;align-items: center;justify-content: space-between;padding:40px 20px;">
					<ThemeToggle :dark.sync="isDark" @update:dark="updateTheme" />
					<view>
						<CustomSvg :color="$theme.PRIMARY" :path="$svg.close" @click="handleClose()" />
					</view>
				</view>
				<!-- 功能列表 -->
				<block v-for="(item,index) in menuList" :key="index">
					<view class="menu_item" @click="linkTo(item.url)">
						<view>
							<CustomSvg :color="$theme.PRIMARY" :path="item.icon" />
						</view>
						<view style="font-size: 14px;padding-left: 10px;padding-left: 20px;flex: auto;"
							:style="{color:$theme.BASIC_TXT}">
							{{$fmt.fmtText(item.name)}}
						</view>
						<view>
							<CustomSvg :color="$theme.TXT_UNACT" :path="$svg.arrowRight" />
						</view>
					</view>
				</block>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "MenuMedium",
		props: {
			dark: {
				type: Boolean,
				default: true,
			}
		},
		data() {
			return {
				isDark: this.dark, // 当前主题方案
				curLanguage: null, // 语言
				menuList: [{
						name: this.$t("header.markets"),
						icon: this.$svg.market,
						url: this.$C.MARKET
					}, {
						name: this.fmt.fmtText(this.$t('crypto.spt')),
						icon: this.$svg.spot,
						url: linkTo.CRYPTO + `?tag=${constants.KEY_CRYPTO_SPT}`,
					}, {
						name: this.fmt.fmtText(this.$t('crypto.ct')),
						icon: this.$svg.usdt,
						url: linkTo.CRYPTO + `?tag=${constants.KEY_CRYPTO_CT}`
					}, {
						name: this.$t("header.defi"),
						icon: this.$svg.defi,
						url: this.$C.DEFI
					},
					// {
					// 	name: this.$t("header.pledge"),
					// 	icon: this.$svg.pledge,
					// 	url: this.$C.PLEDGE
					// }, 
					// {
					// 	name: this.$t("header.wealth"),
					// 	icon: this.$svg.wealth,
					// 	url: this.$C.WEALTH
					// }, 
					{
						name: this.$t("header.loan"),
						icon: this.$svg.loan,
						url: this.$C.LOAN
					}, {
						name: this.$t('assets.convert'),
						icon: this.$svg.convert,
						url: this.$C.ASSETS + `?tag=${this.$C.KEY_CONVERT}`
					}, {
						name: this.$t('assets.recharge'),
						icon: this.$svg.recharge,
						url: this.$C.ASSETS + `?tag=${this.$C.KEY_RECHARGE}`
					}, {
						name: this.$t('assets.withdraw'),
						icon: this.$svg.withdraw,
						url: this.$C.ASSETS + `?tag=${this.$C.KEY_WITHDRAW}`
					}, {
						name: this.$t('assets.transfer'),
						icon: this.$svg.transfer,
						url: this.$C.ASSETS + `?tag=${this.$C.KEY_TRANSFER}`
					}, {
						name: this.curLanguage,
						icon: this.$svg.translate,
						url: this.$C.TRANSLATE
					},
					// {
					// 	name: this.$t('header.download'),
					// 	icon: this.$svg.download,
					// 	url: this.$C.DOWNLOAD
					// },
				]
			}
		},
		computed: {},
		beforeMount() {
			this.curLanguage = uni.getStorageSync('lang'); // 语言
		},
		methods: {
			updateTheme(newTheme) {
				this.$emit('update:dark', newTheme);
			},
			handleClose() {
				this.$emit('action', 1);
			},

			linkTo(val) {
				this.handleClose();
				uni.navigateTo({
					url: this.$linkTo.PAGES + val
				})
			},
		}
	}
</script>