// alertPlugin
export default {
	install(Vue) {
		const status = [
			Vue.prototype.$C.PRIMARY,
			Vue.prototype.$C.SUCCESS,
			Vue.prototype.$C.WARNING,
			Vue.prototype.$C.ERROR,
			Vue.prototype.$C.INFO,
		];
		const color = [
			Vue.prototype.$theme.PRIMARY_TXT,
			Vue.prototype.$theme.SUCCESS_TXT,
			Vue.prototype.$theme.WARNING_TXT,
			Vue.prototype.$theme.ERROR_TXT,
			Vue.prototype.$theme.INFO_TXT,
		];

		const bg = [
			Vue.prototype.$theme.PRIMARY_BG,
			Vue.prototype.$theme.SUCCESS_BG,
			Vue.prototype.$theme.WARNING_BG,
			Vue.prototype.$theme.ERROR_BG,
			Vue.prototype.$theme.INFO_BG,
		];

		const conifg = new Map();
		status.forEach((item, index) => {
			conifg.set(item, [bg[index], color[index]]);
		});
		// console.log(`config:`, conifg);

		Vue.prototype.$alert = (opt) => {
			const {
				type,
				title
			} = opt;
			const el = document.createElement('div');
			el.classList.add('overlay');
			const ctx = document.createElement('div');
			// 当前主题
			const isDark = uni.getStorageSync('theme') == Vue.prototype.$C.DARK;
			ctx.classList.add('alert_container');
			ctx.style.backgroundColor = isDark ?
				Vue.prototype.$theme.convertRGBA(conifg.get(type)[0], 9) :
				conifg.get(type)[0];
			ctx.style.color = isDark ?
				Vue.prototype.$theme.convertRGBA(conifg.get(type)[1], 89) :
				conifg.get(type)[1];
			ctx.innerText = title;
			document.body.appendChild(el);
			document.body.appendChild(ctx);
			setTimeout(() => {
				document.body.removeChild(ctx);
				document.body.removeChild(el);
			}, 2000);

		}
	}
}