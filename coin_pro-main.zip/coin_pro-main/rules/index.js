/**
 * @file 项目中所需规则
 * @description 多语言
 */

import referral from './referral.js';
// import recharge from './recharge.js';
// import withdraw from 'withdraw.js';

// 邀请规则
export const getReferral = (code) => {
	return referral[code]
};