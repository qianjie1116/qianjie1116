export default {
	'en-US': ``,
}