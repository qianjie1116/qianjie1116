export default {
	'en-US': `<p>Invite friends to join Starlight, and you and your friends will have the opportunity to receive a digital currency blind box with a maximum value of $1,000.</p>
<p>&nbsp;</p>
<p><span style="white-space: normal;"> </span><span style="white-space: normal;">Step 1: Share your invitation link with your friends.</span></p>
<p>&nbsp;</p>
<p><span style="white-space: normal;"> </span><span style="white-space: normal;">Step 2: After your friend registers, if the contract transaction volume reaches 1,000 USDT within 7 days, you and your friend will each receive a digital currency blind box.</span></p>
<p>&nbsp;</p>
<p><span style="white-space: normal;">&nbsp; &nbsp; Note: The friends you invite must log in to Starlight and complete the transaction before they can receive the blind box. If the friends you invite do not participate in the transaction within 7 days after registration, you and your friends will not be able to receive the blind box.</span></p>
<p>&nbsp;</p>
<p><span style="white-space: normal;">Each blind box can provide you with a maximum value of $1,000 in cryptocurrency, including $BTC, $ETH, $DOGE, $SHIB, $TRX, $USDT and other digital currencies and contract experience gold. Blind box rewards are updated irregularly, please refer to the actual activation.</span></p>
<p>&nbsp;</p>
<p><span style="white-space: normal;">Blind box rewards will be issued to your account within 24 hours, and you can view the rewards in "Recommendation Rewards".</span></p>
<p>&nbsp;</p>
<p><span style="white-space: normal;">There is no upper limit on the number of blind boxes. The more friends you invite, the more blind boxes you get. Go and invite more friends!</span></p>
<p>&nbsp;</p>
<p><span style="white-space: normal;">In addition to the blind box rewards, you can also get a permanent 30% commission for each transaction completed by your friends.</span></p>
<p>&nbsp;</p>
<p><span style="white-space: normal;">The invitation rebate reward will be issued between 20:00-21:00 (UTC+8) the next day after the invitee completes the transaction.</span></p>
<p>&nbsp;</p>
<p><span style="white-space: normal;">Sub-accounts cannot participate in this activity.</span></p>`,

}