<script>
	export default {
		onLaunch: async function() {
			console.log('App Launch');
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide');
		}
	}
</script>

<style lang="scss">
	@import "@/node_modules/uview-ui/index.scss";
	@import "@/common/style.css";

	@font-face {
		font-family: 'BinancePlex';
		font-display: swap;
		src: url('/static/fonts/BinancePlex-Light.woff2') format('woff2'),
			url('/static/fonts/BinancePlex-Light.otf') format('opentype');
		font-weight: 200
	}

	@font-face {
		font-family: 'BinancePlex';
		font-display: swap;
		src: url('/static/fonts/BinancePlex-Light.woff2') format('woff2'),
			url('/static/fonts/BinancePlex-Light.otf') format('opentype');
		font-weight: 300
	}

	@font-face {
		font-family: 'BinancePlex';
		font-display: swap;
		src: url('/static/fonts/BinancePlex-Regular.woff2') format('woff2'),
			url('/static/fonts/BinancePlex-Regular.otf') format('opentype');
		font-weight: 400
	}

	@font-face {
		font-family: 'BinancePlex';
		font-display: swap;
		src: url('/static/fonts/BinancePlex-Medium.woff2') format('woff2'),
			url('/static/fonts/BinancePlex-Medium.otf') format('opentype');
		font-weight: 500
	}

	@font-face {
		font-family: 'BinancePlex';
		font-display: swap;
		src: url('/static/fonts/BinancePlex-SemiBold.woff2') format('woff2'),
			url('/static/fonts/BinancePlex-SemiBold.otf') format('opentype');
		font-weight: 600
	}

	@font-face {
		font-family: 'BinancePlex';
		font-display: swap;
		src: url('/static/fonts/BinancePlex-Bold.woff2') format('woff2'),
			url('/static/fonts/BinancePlex-Bold.otf') format('opentype');
		font-weight: 700
	}

	@font-face {
		font-family: 'BinancePlex';
		font-display: swap;
		src: url('/static/fonts/BinancePlex-Bold.woff2') format('woff2'),
			url('/static/fonts/BinancePlex-Bold.otf') format('opentype');
		font-weight: 800
	}

	@font-face {
		font-family: 'BinancePlex';
		font-display: swap;
		src: url('/static/fonts/BinancePlex-Black.woff2') format('woff2'),
			url('/static/fonts/BinancePlex-Black.otf') format('opentype');
		font-weight: 900
	}

	body {
		font-family: BinancePlex, Arial, sans-serif;
		font-size: 14px;
	}
</style>