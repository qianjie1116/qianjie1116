import App from './App';
import i18n from '@/locales/index.js';
import * as constants from '@/common/constants.js';
import * as config from '@/common/config.js';
import * as linkTo from '@/common/linkTo.js';
import * as theme from '@/theme/index.js';
import * as fmt from '@/common/format.js';
import * as icons from '@/icons/index.js';

import util from '@/common/util.js';
import http from '@/common/http.js';

import AlertPlugin from '@/plugins/AlertPlugin.js';

import uView from "@/node_modules/uview-ui";



// #ifndef VUE3
import Vue from 'vue';
// import VueI18n from 'vue-i18n';
Vue.use(uView);
// Vue.use(VueI18n)
// const i18n = new VueI18n(i18nConfig)

Vue.config.productionTip = false;

Vue.prototype.$C = constants; // 常量
Vue.prototype.$config = config; // 配置
Vue.prototype.$linkTo = linkTo; // 跳转
Vue.prototype.$svg = icons; // 动态svg
Vue.prototype.$util = util; // 工具类
Vue.prototype.$http = http; // api
Vue.prototype.$fmt = fmt; // 格式化
Vue.prototype.$decimal = 4; // 全局设置小数点保留位数

// 初始化设置
util.initialize();

// theme 相关设置
Vue.prototype.$theme = theme;
if (!uni.getStorageSync('theme'))
	uni.setStorageSync('theme', constants.DARK);

theme.setTheme(uni.getStorageSync('theme') == constants.DARK);

Vue.use(AlertPlugin);

App.mpType = 'app'
const app = new Vue({
	i18n,
	...App
})
app.$mount()
// #endif

// #ifdef VUE3
import {
	createSSRApp
} from 'vue'
export function createApp() {
	const app = createSSRApp(App)
	return {
		app
	}
}
// #endif

// util.switchTabBar(); // 切换底部多语言

// 白名单 将无需用户登录也可查看的页面写在这里。默认是启动页、登录页、隐私协议
const whiteList = [
	linkTo.PAGES + linkTo.LAUNCH,
	linkTo.PAGES + linkTo.SIGN_IN,
	linkTo.PAGES + linkTo.SIGN_UP,
	linkTo.PAGES + linkTo.TERMS,
	linkTo.PAGES + linkTo.HOME,
	linkTo.PAGES + linkTo.TRANSLATE,
	linkTo.PAGES + linkTo.DOWNLOAD,
];
// uniapp 跳转行为
const list = ["navigateTo", "reLaunch", "switchTab"]
// 目标url是否需要权限
function hasPermission(url) {
	console.log(url);
	// console.log(uni.getStorageSync("token"));
	return (whiteList.indexOf(url) !== -1 || uni.getStorageSync("token").length > 0);
}

list.forEach((item) => {
	// 路由拦截
	uni.addInterceptor(item, {
		// 页面跳转前进行拦截, invoke根据返回值进行判断是否继续执行跳转
		invoke(e) {
			if (!hasPermission(e.url)) {
				// 将用户的目标路径保存下来 这样可以实现 用户登录之后，直接跳转到目标页面
				// uni.setStorageSync("URL", e.url)
				linkTo.signIn();
				return false;
			}
			return true;
		}
	});
})