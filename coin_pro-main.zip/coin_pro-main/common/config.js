// 应用配置项

/* 是否启用主题切换 */
export const enableTheme = true;
/* 是否启用多语言 */
export const enableLocale = true;

/* 是否启用提款支付密码 */
export const withdrawPwd = false;
