// constants.js 常量。 全局唯一硬编码
// use  $C.DARK or Vue.prototype.$C

// market/index  api/goods/list 所需
export const GPINDEX = {
	crypto: 1, // crypto 接口 gp_index: 1,
	future: 2, // 期货
	forex: 3, // forex gp_index: 3 外汇
	usstock: 4, // gp_index: 4 美股
	ukstock: 6, // gp_index: 6 英股
	// eustock:7, // gp_index: 7 欧股
	// 8和9是指标 指标是不能购买
};

// 用于设置数字值的locale
export const LOCALE_ENUS = `en-US`;
export const LOCALE_FRFR = `fr-FR`;

// 明文格式化模式 
// 标题或重要标签 每个单词首字母大写 （Title Case）
export const FMT_METHOD_TC = 'title';
// 一般描述文本 首个单词首字母大写 （Sentence Case）
export const FMT_METHOD_SC = 'sentence';

// 充提多币种的key
export const KEY_ERC = "erc20";
export const KEY_TRC = "trc20";
export const KEY_BTC = "btc";
export const KEY_ETH = "eth";
export const KEY_TRX = 'trx';


// 市场tab 分类 key
export const KEY_CRYPTO = `crypto`;
export const KEY_FOREX = `forex`;
export const KEY_FUTURE = `future`;
export const KEY_USSTOCK = `usstock`;
export const KEY_UKSTOCK = `ukstock`;

// rule
export const KEY_RULE_LOAN = `loan`;
export const KEY_RULE_PERP = `perp`;
export const KEY_RULE_SPOT = `spot`;
export const KEY_RULE_USDT = `usdt`;

// assets key 资产管理 子页面跳转所需 tag
export const KEY_RECHARGE = `recharge`;
export const KEY_WITHDRAW = `withdraw`;
export const KEY_CONVERT = `convert`;
export const KEY_TRANSFER = `transfer`;
export const KEY_ORDER = `order`;
export const KEY_RECORD = `record`;

// 账户相关的一些页面跳转 tag
export const KEY_AUTH_PRIMARY = `primary`;
export const KEY_AUTH_ADVANCED = `advanced`;
export const KEY_ADDRESS = `address`;
export const KEY_BANK = `bank`;
export const KEY_PWD_SIGNIN = `pwd`;
export const KEY_PWD_PAY = `pay`;
export const KEY_TERMS = `terms`;
export const KEY_PAPER = `paper`;
export const KEY_HELP = `help`;
export const KEY_QA = `qa`;
export const KEY_ABOUT = `about`;
export const KEY_REFERRAL =`referral`;


// crypto 交易的相关跳转 tag 所有与加密货币有关的，视为加密货币交易
//  币币交易  ：Spot Trading (SPT)
export const KEY_CRYPTO_SPT = `spt`;
// 合约交易  Contract Trading   (CT) 或   Derivatives Trading   (DT)
export const KEY_CRYPTO_CT = `ct`;
// 秒合约  ：Perpetual Contract (PERP)
export const KEY_CRYPTO_PERP = `perp`;
// 期权  ：Options Trading (OPT)
export const KEY_CRYPTO_OPT = `opt`;
// U本位交易  ：USDT Margin Trading (USDT Trading)
export const KEY_CRYPTO_USDT = `usdt`;
// 币本位交易  ：Coin Margin Trading (CMT)
export const KEY_CRYPTO_CMT = `cmt`;

export const KEY_CRYPTO_BUY = `buy`;
export const KEY_CRYPTO_SELL = `sell`;
export const KEY_CRYPTO_POSITION = `position`;
export const KEY_CRYPTO_ORDER = `order`;
export const KEY_CRYPTO_HISTORY = `history`;


// 设备类型
export const DEVICE_TYPE_PHONE = 'phone';
export const DEVICE_TYPE_PC = 'pc';
// 程式运行平台
export const UNI_PLATFORM_APP = 'app';
export const UNI_PLATFORM_WEB = 'web';

// 默认 local
export const DEFAULT_LOCALE = 'en-US';
// 默认 语言
export const DEFAULT_LANG = 'English';

// 主题
export const DARK = 'dark';
export const LIGHT = 'light';

// 屏幕方案 适配基准 Small Medium Large
export const SMALL = `small`; // 使用竖屏方案
export const MEDIUM = `medium`; // 紧凑布局方案，即隐藏或移动部分元素
export const LARGE = `large`; // 完整宽屏方案
export const WIDTH_APP = 800; // >=800 使用竖屏方案
// >800 && <1280  紧凑布局方案
export const WIDTH_PC = 1280; // >=1280完整宽屏方案


// 通用状态
export const PRIMARY = 'primary';
export const SUCCESS = 'success';
export const WARNING = 'warning';
export const ERROR = 'error';
export const INFO = 'info';