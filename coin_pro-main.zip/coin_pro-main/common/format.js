/**
 * 应用中相关的格式化函数。较多，单独提出一个文件，便于一键迁移使用
 * 说明：
 */
import * as constants from '@/common/constants.js';
import localize from '@/common/localize.js';
import * as theme from '@/theme/index.js';

/**
 * 
 * @type {object} fmtConfig
 * @type {string} fmtConfig:{object}
 * @type {string} color:显示值颜色
 * @type {number} rate:显示值汇率
 * @type {number} decimal:显示值限制小数的位数
 * @description {货币代码:颜色代码}
 * 需要格式化为哪些loacale。比如，意大利的欧元美元双显。扩展为遍历输出多显.
 * 按照用户需求，调整此处需要遍历渲染的货币。
 */
/**
 * @function 数据多种显示配置
 * @return {object} 用于多显格式化的配置对象
 * @type {number} rate:显示值汇率
 * @type {number} decimal:显示值限制小数的位数
 * @description 其他设置也可以在外部为变量赋值后，再按需调整
 * @example
 * this.$fmt.fmtConfig();
 */
export const fmtConfig = () => {
	let temp = {};
	Object.keys(localize).forEach((key, index) => {
		console.log(key);
		// 确保 temp[key] 被初始化为一个对象
		temp[key] = {}; // 初始化为一个新对象
		temp[key].rate = 1; // 默认 1
		temp[key].decimal = 4; // 默认小数位数 -1视为不主动限制
	});

	// 其他设置写在外面，减少遍历时多次多种 if 判断
	// temp['en-US'] = temp['en-US'] || {}; // 确保存在 'en-US' 对应的对象
	// temp['en-US'].decimal = 4; // 视为主动限制小数位数

	return temp;
};


// 函数: 将指定 locale 对象放在第一位
export const prioritizeLocale = (config, locale = 'en-US') => {
	const keys = Object.keys(config);

	// 如果 locale 存在于 config 中，将其放在数组的开头
	if (keys.includes(locale)) {
		const prioritizedConfig = {
			[locale]: config[locale]
		};
		prioritizedConfig[locale].color = '';

		// 将其余的 locale 追加到新对象中
		keys.forEach((key, index) => {
			if (key !== locale) {
				prioritizedConfig[key] = config[key];
				prioritizedConfig[key].color = theme.colors[index];
			}
		});

		return prioritizedConfig;
	}

	// 如 locale 不在 config 中，返回原对象
	return config;
};




/**
 * @function 格式化数字值
 * @param {string} str 需格式化的字符串
 * @param {number} decimal 保留小数位数
 * @return {string} 格式化为指定小数位数的string类型数值
 * @description 通常用于不限制位数或指定位数的数值。
 * @example
 * this.$fmt.fmtNumber(`0.000013579`)
 * this.$fmt.fmtNumber(`13579.111111`, 5)
 */
export const fmtNumber = (str, decimal = -1) => {
	// console.log(`fmtNumber:`, str);
	// 非数字 135.00
	str = !str || isNaN(str) ? '0.00' : str;
	// console.log(`fmtNumber:`, str);
	// console.log(decimal > -1 ? parseFloat(str).toFixed(decimal) : str);
	// 四舍五入到指定小数位：或原样输出
	return decimal > -1 ? parseFloat(str).toFixed(decimal) : str;
};

/**
 * @function 格式化加密货币,统一使用美元的千分符形式。
 * @param {string} str 需格式化的字符串
 * @return {string} 'en-US'千分格式化
 * @description 因为USDT 与美元1:1。多数情况，交易所会选择在显示价格时，即使是整数价格，也保留两位小数
 * @example
 * this.$fmt.fmtCrypto(`13579.00`);
 * this.$fmt.fmtCrypto(`13579.11`);
 * this.$fmt.fmtCrypto(`13579.1111`);
 * this.$fmt.fmtCrypto(this.$fmt.fmtNumber(`13579.111111`, 5));
 */
export const fmtCrypto = (str) => {
	// console.log(`fmtCrypto:`, str)
	// 合法值
	str = !str || isNaN(str) ? 0 : str;
	// 处理为指定小数位数的字符串
	str = typeof(str) == 'string' ? str : str.toString();
	// console.log(`fmtCrypto:`, str)
	// 整数和小数部分
	const [intPart, decimalPart = ''] = str.split('.');
	// 小数位数最大值
	const mx = decimalPart.length;
	// console.log(`fmtCrypto:`, mx)
	// // 再把整数和小数拼起来。
	// const temp = intPart + '.' + decimalPart;
	// console.log(`fmtCrypto:`, temp)
	return new Intl.NumberFormat(`en-US`, {
		style: 'decimal', // 用于以特定货币格式化数字。
		minimumFractionDigits: 0,
		maximumFractionDigits: mx, // 显示最多位小数
	}).format(intPart) + (decimalPart ? '.' + decimalPart : '')
};

/**
 * @function 格式化传入值为指定货币格式
 * @param {string} str 需格式化的字符串
 * @param {string} locale 货币代码
 * @return {string} 按照指定代码，包含货币符号的千分格式化
 * @description 
 * @example
 * this.$fmt.fmtCurrency(`13579.00`);
 * this.$fmt.fmtCurrency(`13579.11`);
 * this.$fmt.fmtCurrency(`13579.1111`);
 * this.$fmt.fmtCurrency(this.$fmt.fmtNumber(`13579.111111`, 5));
 */
export const fmtCurrency = (str, locale) => {
	// console.log(`fmtCurrency:`, str)
	// 转为字符串
	str = typeof(str) == 'string' ? str : str.toString();
	// 获取整数和小数部分
	const [intPart, decimalPart = ''] = str.split('.');
	// locale没有传入值，使用缓存，否则使用设置值。
	locale = !locale ? uni.getStorageSync('locale') : locale;
	// 当前货币
	const curCurrency = localize[locale].currency;
	// console.log(`fmtCurrency curCurrency:`, curCurrency);
	// 小数位数最小值。传入值小数部分的长度&& 小数*1是否＞0
	const min = decimalPart.length > 0 && decimalPart * 1 > 0 ? 0 : 2;
	// console.log(`fmtCurrency min:`, min);
	// 小数位数最大值
	const max = decimalPart.length || min;
	// console.log(`fmtCurrency max:`, max)
	// 再把整数和小数拼起来。
	const temp = intPart + '.' + decimalPart;
	// console.log(`fmtCurrency temp:`, temp);
	return new Intl.NumberFormat(`${locale}`, {
		// percent:百分比
		style: 'currency', // 用于以特定货币格式化数字。
		// 指定要使用的货币代码（如 'USD'、'EUR'、'CNY' 等）
		currency: curCurrency,
		// 定义货币的显示形式（如 'symbol' 显示符号，'code' 显示货币代码，'name' 显示货币名称）。
		currencyDisplay: 'symbol',
		minimumFractionDigits: min,
		maximumFractionDigits: max, // 显示最多位小数
		// unit: "kilometer-per-hour", // 单位
	}).format(temp);
	// .format(intPart) + (decimalPart ? '.' + decimalPart : '')
}

/**
 * @function 格式化量值(整数)如股票购买的股数
 * @param {number} num 需格式化的数值
 * @param {string} locale 货币代码
 * @return {string} 按照指定代码，包含货币符号的千分格式化
 * @description 只在类似情况下使用该函数。
 * @example
 * this.$fmt.fmtQTY(`13579.00`);
 * this.$fmt.fmtQTY(`13579`);
 */
export const fmtQTY = (num, locale) => {
	num = !num || isNaN(num) ? 0 : Number(num);
	// locale没有传入值，使用缓存，否则使用设置值。
	locale = !locale ? uni.getStorageSync('locale') : locale;
	return new Intl.NumberFormat(`${locale}`, {
		// percent:百分比
		style: 'decimal', // 用于普通数字
		minimumFractionDigits: 0,
		maximumFractionDigits: 0, // 显示最多位小数
		useGrouping: true, // 是否使用千位分隔符，默认为 true
	}).format(num);
};

// 明文格式化 method 
/**
 * @function 格式化明文
 * @param {string} val 需格式化的数值
 * @param {string} method [title|sentence] 默认为`title`每个单词首字母大写
 * @return {string} 按照指定代码，包含货币符号的千分格式化
 * @description 只在类似情况下使用该函数。
 * @example
 * this.$fmt.fmtText( `hello`);
 * this.$fmt.fmtText(this.$t('market.coin'));
 */
export const fmtText = (val, method = '') => {
	const curLocale = uni.getStorageSync('locale');
	// 是否为西文
	const isWestern = !['zh-TW', 'ja-JP', 'ko-KR', 'ar-IL'].includes(curLocale);
	// console.log(`是否西文:`, isWestern);
	if (!isWestern) return val;
	// 西文格式化处理 首个单词首字母大写 （Sentence Case）
	const capitalizeFirstLetter = (str) => str.charAt(0).toUpperCase() + str.slice(1);
	// 西文格式化处理 每个单词首字母大写 （Title Case）
	const toTitleCase = (str) => str.split(' ').map(word => capitalizeFirstLetter(word)).join(' ');
	switch (method) {
		// case constants.FMT_METHOD_TC:
		// 	// 每个单词首字母大写（Title Case）
		// 	return toTitleCase(val);
		case constants.FMT_METHOD_SC:
			// 首个单词首字母大写（Sentence Case）
			return capitalizeFirstLetter(val);

			// 如果有其他模式，在此追加。如，字符全小写。

		default:
			// 每个单词首字母大写（Title Case）
			return toTitleCase(val);
	}
}


// 格式化百分比
// export const fmtPercent = (num, locale) => {
// 	// locale没有传入值，使用缓存，否则使用设置值。
// 	locale = !locale ? uni.getStorageSync('locale') : locale;
// 	return new Intl.NumberFormat(`${locale}`, {
// 		style: 'percent',
// 		minimumFractionDigits: 1,
// 		maximumFractionDigits: 1,
// 	}).format(num);
// }

// 格式化，时分秒
export const fmtToHMS = (timestamp) => {
	// 创建一个 Date 对象
	const date = new Date(timestamp);
	// 使用 toLocaleTimeString 转换为时分秒，并指定 'en-US' 时区
	const curLocale = uni.getStorageSync('locale');

	const options = {
		hour: '2-digit',
		minute: '2-digit',
		second: '2-digit',
		hour12: false, // 24小时制
		timeZone: localize[curLocale].timeZone // 指定美国的时区（如太平洋时区）
	};

	return date.toLocaleTimeString(curLocale, options);
}