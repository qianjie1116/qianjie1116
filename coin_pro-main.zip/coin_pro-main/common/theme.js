import Vue from 'vue';


// 确定当前的$theme,而后使用该文件中的样式





export const PRIMARY = `#6D41FF`;
export const SUCCESS = 'success';
export const WARNING = 'warning';
export const ERROR = 'error';
export const INFO = 'info';

// const color = ['#3c9cff', '#5ac725', '#f9ae3d', '#f56c6c', '#909399'];
// const bg = ['#ecf5ff', '#f4f4f5', '#fdf6ec', '#fef0f0', '#f4f4f5'];

export const SUCCESS_TXT = `#0ECB81`;

export const SUCCESS_BG_DARK = `#102821`;
export const SUCCESS_BG_LIGHT = `#E6FFF1`;

export const BASIC_BG = `#181E25`;

// // 渐变值
// const LG_PRIMARY = linerGradient(90, '#F87D7B', '#AFF8DF');
// const LG_SECOND = linerGradient(90, '#41EB87', '#3AF5C2');
// const LG_THIRD = linerGradient(90, '#FF2D30', '#FE7FD3');
// const LG_FOURTH = linerGradient(90, '#12F6C0', '#FFB044');
// const LG_FIFTH = linerGradient(90, '#BB44FF', '#6458FF');





const PAGE_BG_DARK = '#10131D'; // 暗色页面背景
const PAGE_BG_LIGHT = '#ffffff'; // 亮色页面背景


const INPUT_BG_LIGHT = 'transparent'; // 亮色主题， input 背景


const INPUT_BORDER_LIGHT = '#e9e9e9'; // 亮色主题 input边框



const CHECKBOX_COLOR_ACTIVE = '#6D41FF'; // checkbox 边框及勾选
const CHECKBOX_COLOR_LABEL_DARK = '#e9e9e9'; // checkbox 文字
const CHECKBOX_COLOR_LABEL_LIGHT = '#1f212d'; // checkbox 文字

// const SECOND = '#121117';
// const THIRD = '#FF2D30';

const RISE = '#d62548'; // 涨/跌
const FALL = '#4bbd83'; // 跌/涨 




// 数值转十六进制，确保双位
const toHex = (val) => {
	const hex = val.toString(16);
	return hex.length === 1 ? `0` + hex : hex;
}

// RGB颜色值反转
const invertColor = (hex) => {
	if (hex.length === 4)
		hex = hex[0] + hex[1] + hex[1] + hex[2] + hex[2] + hex[3] + hex[3]
	const r = 255 - parseInt(hex.slice(1, 3), 16);
	const g = 255 - parseInt(hex.slice(3, 5), 16);
	const b = 255 - parseInt(hex.slice(5, 7), 16);
	return `#` + toHex(r) + toHex(g) + toHex(b);
}



// // 设置页面背景,返回style对象，动态替换页面背景图
// setBGCover: (url) => {
// 	return {
// 		backgroundImage: `url(/static/${url}.png)`,
// 		backgroundRepeat: 'no-repeat',
// 		backgroundPosition: '0 0',
// 		backgroundSize: 'cover',
// 		width: '100%',
// 		minHeight: '100vh',
// 	}
// },

// // 另外一种，使用渐变，动态改变background-size的值。
// // val:外部设置该值，可以改变背景的size。 
// setBGSize: (val) => {
// 	return {
// 		...linerGradient(180, '#2D54AB', '#2D54AB00'),
// 		backgroundRepeat: 'no-repeat',
// 		backgroundPosition: '0 0',
// 		backgroundSize: `100% ${val}`,
// 		width: '100%',
// 		minHeight: '100vh',
// 	}
// },

// // 资金变动相关 交易额 字色
// setTradeAmount: (val) => {
// 	return {
// 		color: val ? PRIMARY : PRIMARY
// 	}
// },


// // 交易记录 数据状态
// setStatusPrimary: (val) => {
// 	// 渐变的背景
// 	const temp = [LG_PRIMARY, LG_SECOND, LG_THIRD, LG_THIRD];
// 	// 文字的颜色
// 	// const colors = ['#FF6700', '#00B45A', '#00A9DE', '#f56a6a'];

// 	let style = {
// 		borderRadius: '4rpx',
// 		fontSize: '24rpx',
// 		padding: '4rpx 12rpx',
// 		color: '#14102B',
// 		width: 'max-content',
// 		...temp[val],
// 	};
// 	return style;
// },



// // 统一处理当前页面布局模式(以当前语言为准)
// setDirection: (val) => {
// 	return {
// 		direction: val ? 'rtl' : 'ltr'
// 	}
// },

// // 统一处理flex布局的row镜像
// setFlexRowReverse: (val) => {
// 	return {
// 		flexDirection: val ? 'row-reverse' : 'row'
// 	}
// },

