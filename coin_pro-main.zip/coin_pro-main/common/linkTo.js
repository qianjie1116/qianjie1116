// linkTo
import * as constants from '@/common/constants.js';

// 页面URL 硬编码 通常用于指定跳转
export const PAGES = `/pages/`; // pages 部分

export const LAUNCH = `launch/index`; // 启动页
export const SIGN_IN = `signIn/index`; // 登入
export const DOWNLOAD = `download/index`; // 下载页面
export const TRANSLATE = `translate/index`; // 选择语言

export const HOME = `home/index`; // 主页
export const MARKET = `market/index`; // 市场

export const TRADE = `trade/index`; // 交易[秒合约、币币、U本位]
export const DEFI = `defi/index`; // DeFi挖矿
export const CTC = `ctc/index`;
export const CTC_ORDER = `ctc/order`;

export const PLEDGE = `pledge/index`; // 质押挖矿
export const PLEDGE_RECORD = `pledge/record`;

export const LOAN = `loan/index`; // 助力贷
export const LOAN_RECORD = `loan/record`; // 助力贷 记录

export const RULE = `rule/index`; // 规则

export const WEALTH = `wealth/index`; // 理财
export const WEALTH_RECORD = `wealth/record`; // 记录

export const ASSETS = `assets/index`; // 资产
export const ACCOUNT = `account/index`; // 账户

export const NOTIFIY_INDEX = `notify/index`; // 公告
export const NOTIFY_DETAIL = `notify/detail`; // 公告 詳情

// crypto 币币交易，合约交易，秒合约等。
// 详情，也就是kline页。竖屏点击买卖按钮跳转到/trade。其他直接显示交易部分
export const CRYPTO = `crypto/index`;
// 交易。该页面仅限竖屏使用
export const CRYPTO_TRADE = `crypto/trade`;

// Stock 详情与买入
export const STOCK = `stock/index`;

export const TRADE_DAY = `trade/day/index`; // 日内交易
export const TRADE_BLOCK = `trade/block/index`; // 大宗交易
export const TRADE_IPO = `trade/ipo/index`; // ipo交易
export const TRADE_VIP = `trade/vip/index`; // VIP 抢筹

// export const SERVICE = `/pages/service`; // 客服

// article/index
// article/index?tag=

export const TERMS = `terms/index`; // 用户隐私协议


// export const ASSETS_INDEX = `/pages/assets/index`; // Assets
// export const ASSETS_REACORD = `/pages/assets/record`; // Assets record
// export const ASSETS_CONTRACT = `/pages/assets/contract`; // Assets contract


// export const CAPITAL_FLOW = `/pages/account/flow`; // Capital flow 交易记录

// export const BORROW_INDEX = `/pages/borrow/index`; // borrow
// export const BORROW_RECORD = `/pages/borrow/record`; // borrow record

// ============== old  =========================


// export const ACCOUNT_TRADE_LOG = `/pages/account/tradeLog`; // 账户交易记录
// export const ACCOUNT_AVATAR = `/pages/account/avatar`; // 变更头像
// export const ACCOUNT_CREDIT_SCORE = `/pages/account/creditScore`; // 信用积分
// export const ACCOUNT_NOMINEE = `/pages/account/nominee`; // 遗传继承



// export const TRADE_EA = `/pages/trade/ea/index`; // EA 交易
// export const TRADE_ISSUANCE = `/pages/trade/issuance/index`; // 新股配售


// // 市场概况
// export const MARKET_OVERVIEW = `/pages/market/overview`;

/**
 * @function 检查token
 * @description 用于设置需要检查token的跳转，如onShow，linkTo
 */
export const checkToken = () => {
	if (!uni.getStorageSync('token') ||
		uni.getStorageSync('token') == '') {
		signIn();
		// return false;
	} else {
		return true;
	}
};

/**
 * @function 首页
 * @description 通常不需要token
 */
export const home = () => {
	console.log(PAGES + HOME);
	uni.navigateTo({
		url: PAGES + HOME,
	})
};

/**
 * @function 登入
 */
export const signIn = () => {
	uni.reLaunch({
		url: PAGES + SIGN_IN
	})
};

/**
 * @function 下载页面
 */
export const download = () => {
	uni.navigateTo({
		url: PAGES + DOWNLOAD
	})
};

/**
 * @function 选择语言
 * @description 仅限竖屏跳转到加密币交易页面
 */
export const translate = () => {
	uni.navigateTo({
		url: PAGES + TRANSLATE,
	})
};

/**
 * @function 市场 
 * @param {string} type tab切换时的gpindex值
 * @param {string} symbol 关键字
 * @description 检索关键词用在宽屏search点击
 */
export const market = (type = 0, symbol = '') => {
	if (!checkToken()) return false;
	const temp = symbol == '' ? `&symbol=${symbol}` : '';
	uni.navigateTo({
		// type=1&symbol=btc
		url: PAGES + MARKET + `?type=${type}${temp}`
	});
}

/**
 * @function Stock的详情与交易
 * @param {string} symbol 股票的code
 */
export const stockDetail = (symbol) => {
	console.log(symbol);
	if (!symbol) return false;
	if (!checkToken()) return false;
	uni.navigateTo({
		url: PAGES + STOCK + `?symbol=${symbol}`
	})
}

/**
 * @function Crypto的详情与交易
 * @param {string} symbol Crypto的code
 */
export const cryptoDetail = (symbol) => {
	console.log(symbol);
	if (!symbol) return false;
	if (!checkToken()) return false;
	uni.navigateTo({
		url: PAGES + CRYPTO + `?symbol=${symbol}`
	})
}

/**
 * @function Crypto的交易
 * @param {string} symbol Crypto的code
 * @description 仅限竖屏跳转到加密币交易页面
 */
export const cryptoTrade = (symbol) => {
	console.log(symbol);
	if (!symbol) return false;
	if (!checkToken()) return false;
	uni.navigateTo({
		url: PAGES + CRYPTO_TRADE + `?symbol=${symbol}`
	})
}

/**
 * @function 助力贷 loan record
 */
export const loanRecord = () => {
	if (!checkToken()) return false;
	uni.navigateTo({
		url: PAGES + LOAN_RECORD
	})
};

/**
 * @function 规则
 * @param {string} symbol 指定要查看的规则
 * @description 
 */
export const rule = (symbol) => {
	if (!symbol) return false;
	if (!checkToken()) return false;
	uni.navigateTo({
		url: PAGES + RULE + `?tag=${symbol}`,
	})
};

/**
 * @function 跳转到理财的记录
 */
export const wealthRecord = () => {
	if (!checkToken()) return false;
	uni.navigateTo({
		url: PAGES + WEALTH_RECORD
	})
};

/**
 * @function 资产管理
 * @param {string} symbol 指定子页面
 */
export const linkAssets = (symbol = '') => {
	if (!checkToken()) return false;
	uni.navigateTo({
		url: PAGES + ASSETS + `?tag=${symbol}`
	})
};

/**
 * @function 账户主页面
 */
export const linkAccount = () => {
	if (!checkToken()) return false;
	uni.navigateTo({
		url: PAGES + ACCOUNT,
	})
};

export const ctcOrder = (code, id) => {
	if (!checkToken()) return false;
	uni.navigateTo({
		url: PAGES + CTC_ORDER + `?tag=${code}&id=${id}`,
	})
};

export const linkTerms = () => {
	// if (!checkToken()) return false;
	uni.navigateTo({
		url: PAGES + TERMS,
	})
}