// websocket
export default class WebSocketTool {
	constructor(url) {
		this.socket = null;
		this.isConnected = false;
		this.url = url;
		this.messageHanlder = null;
	}

	// websocket 断线重连
	reconnectWebSocket() {
		// 连接中，并且非手动关闭
		if (this.isConnected) return;
		console.log(`reconnect!`, this.isConnected);
		this.socket = null;
		console.log(`reconnect! socket:`, this.socket);
		this.connect();
	}

	// 关闭 websocket链接
	disconnect() {
		if (this.socket) {
			this.socket.close();
			this.socket = null;
			this.isConnected = false;
		}
	}

	// 链接
	connect() {
		// console.log(`url:`, this.url);
		if (this.socket) this.disconnect();

		this.socket = uni.connectSocket({
			url: this.url,
			header: {
				'content-type': 'application/json'
			},
			success(res) {
				console.info(`success res:`, res);
			},
			fail: (res) => {
				console.info(`fail res:`, res);
			}
		});

		console.log(`socket:`, this.socket);
		this.socket.onOpen((res) => {
			console.info("socket onOpen:", res);
			this.isConnected = true; // 已连接
			if (this.messageHanlder) {
				this.socket.onMessage(this.messageHanlder);
			}
		});
		this.socket.onClose((res) => {
			// code:1000(手动关闭) 1006(异常关闭) 
			console.log(`onClose:`, res);
			this.isConnected = false;
			if (res.code !== 1000) {
				this.reconnectWebSocket();
			}
		});
		this.socket.onError((err) => {
			console.log(`onError:`, err);
			this.isConnected = false;
			this.reconnectWebSocket();
		});
	}

	onMessage(callback) {
		this.messageHanlder = callback;
		if (this.socket) {
			console.log(`ws onMessage`);
			this.socket.onMessage(callback);
		}
	}
}