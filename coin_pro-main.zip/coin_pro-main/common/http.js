import i18nConfig from '@/locales/index.js';
import * as constants from '@/common/constants.js';
import util from '@/common/util.js';
import md5 from '@/common/md5.min.js';

export const HOST = `api.starlight.cyou`;
// export const HOST = `api.meiguotrust.top`;
// export const HOST = `api.ydlstock.top`;

export const BASE_URL = `https://${HOST}`;
export const WS_COIN_URL = `wss://${HOST}/ws`; // coin
export const WS_OTHER_URL = `wss://${HOST}/zonghe`; // 币


const CODE = "Qwd3N5yp";

// 统一处理网络状态 在onShow 及 api请求时调用
export const checkNetwork = async () => {
	try {
		const result = await uni.getNetworkType();
		let [err, res] = result;
		if (!res || res.networkType === 'none') return false;
		return true;
	} catch (err) {
		throw err
	}
}

async function http(url, params = {}) {
	// 发送请求前，检查网络状态
	const result = await checkNetwork();
	if (!result) {
		return {
			message: i18nConfig.messages[i18nConfig.locale]['api.networkNo']
		};
	} else {
		// console.log('url:', url, 'params:', params);
		const token = uni.getStorageSync("token") || '';
		const headers = {
			"Content-Type": "application/x-www-form-urlencoded",
			// 处理携带token
			"Authorization": token == '' ? token : `Bearer ${uni.getStorageSync("token")}`,
			"language": uni.getStorageSync('locale') || 'en', // 'zh-Hans'
		};
		const time = parseInt(new Date().getTime() / 1000);
		const str_url = `/${url}`.toLowerCase();
		const mdd = md5(`XPFXMedS${CODE + str_url + time}`);
		const fmtAPIURL = url.includes('http') ? url : `${BASE_URL}/${url}?sign=${mdd}&t=${time}`;
		try {
			const response = await uni.request({
				url: `${fmtAPIURL}`,
				method: params.method || 'GET',
				data: params.data || {},
				header: headers
			});
			uni.hideLoading();
			const [err, res] = response;
			// console.log('err:', err, 'res:', res);

			if (res && res.statusCode == 200) {
				if (res.data.code === 999) {
					uni.removeStorageSync('token'); // 只移除token的缓存
					uni.showToast({
						title: i18nConfig.messages[i18nConfig.locale]['api.tokenExpires'],
						icon: 'none'
					})
					setTimeout(() => {
						uni.navigateTo({
							url: constants.PAGES + constants.SIGN_IN
						});
					}, 1000);
					return null;
				}
				// console.log('res:', res);
				// console.log('res.data:', res.data);
				if (res.data) {
					// console.log('res.data:', res.data);
					if (res.data.code == 0) {
						// console.log('res.data.data:', res.data.data);
						return res.data.data || null;
					} else {
						uni.showToast({
							title: !res.data.message ? res.message : res.data.message,
							icon: 'none'
						})
						return null;
					}
				}
			} else {
				console.log('err:', err);
				uni.showToast({
					title: err.errMsg ||
						i18nConfig.messages[i18nConfig.locale]['api.httpError'],
					icon: 'none'
				})
			}
		} catch (error) {
			console.log('error:', error);
			throw error;
		}
	}
};

// 外部调用，模拟整理前写法。
const get = (url, data = {}) => {
	const params = {
		method: 'GET',
		data,
	}
	return http(url, params)
}

const post = (url, data = {}) => {
	const params = {
		method: 'POST',
		data,
	}
	return http(url, params)
}


// 图片上传
async function uploadImage(val) {
	console.log(i18nConfig)
	uni.showLoading({
		title: i18nConfig.messages[i18nConfig.locale]['api.upload'],
	})
	let Request = "Qwd3N5yp"
	let time = parseInt(new Date().getTime() / 1000)
	let str_url = ("/api/app/upload").toLowerCase()
	let mdd = md5("XPFXMedS" + Request + str_url + time);

	const result = await uni.uploadFile({
		url: BASE_URL + '/api/app/upload?t=' + time + "&sign=" + mdd,
		filePath: val,
		name: 'file',
	});
	console.log('result:', result);
	uni.hideLoading();
	if (result[1].statusCode == 200) {
		const temp = JSON.parse(result[1].data);
		console.log('temp:', temp);
		// this.obverseUrl = temp[0].url;
		return temp[0].url;
	} else {
		return null;
	}
};


export default {
	BASE_URL,
	WS_COIN_URL,
	WS_OTHER_URL,
	// WS_XAU_URL,
	http,
	get,
	post,
	checkNetwork,
	uploadImage,
};

uni.addInterceptor('request', {
	config(requestConfig) {
		console.log('请求拦截', requestConfig);
	}
})