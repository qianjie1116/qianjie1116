import Vue from 'vue';
import * as constants from '@/common/constants.js';
import * as linkTo from '@/common/linkTo.js';
import http from '@/common/http.js';
import localize from '@/common/localize.js';
import i18n from '@/locales/index.js';

export const translate = (key) => {
	return i18n.t(key);
};

// 初始化布局方案
export const initLayout = (info) => {
	if (info.uniPlatform == constants.UNI_PLATFORM_WEB &&
		info.deviceType == constants.DEVICE_TYPE_PC) {
		console.log(`PC 方案`, info.windowWidth);
		if (info.windowWidth < constants.WIDTH_APP) {
			console.log(`>=800`, constants.SMALL);
			uni.setStorageSync('layout', constants.SMALL);
		}
		if (info.windowWidth > constants.WIDTH_APP &&
			info.windowWidth < constants.WIDTH_PC) {
			console.log(`>800 && <1280 `, constants.MEDIUM);
			uni.setStorageSync('layout', constants.MEDIUM);
		}
		if (info.windowWidth >= constants.WIDTH_PC) {
			console.log(`>=1280`, constants.LARGE);
			uni.setStorageSync('layout', constants.LARGE);
		}
	} else {
		console.log(`PHONE 方案`);
		// 非pc，一律使用竖屏方案
		uni.setStorageSync('layout', constants.SMALL);
	}
};

// 初始化设置
export const initialize = () => {
	// 获取系统信息
	const systemInfo = uni.getSystemInfoSync();
	Vue.prototype.$APP_NAME = systemInfo.appName;
	Vue.prototype.$VERSION = systemInfo.appVersion;
	// 当前屏幕宽度，缓存起来，用于处理每个页面的显示方案
	Vue.prototype.$WINDOW_WIDTH = systemInfo.windowWidth;
	Vue.prototype.$WINDOW_HIGHT = systemInfo.windowHeight;
	console.log('main.js!', systemInfo);

	// 将存储的appName与当前获取的appName对比。
	if (uni.getStorageSync('APP_NAME') != Vue.prototype.$APP_NAME) {
		console.log(`Clear storage!`);
		uni.clearStorageSync();
		uni.setStorageSync('APP_NAME', Vue.prototype.$APP_NAME);
	}

	// 初始化布局方案
	initLayout(systemInfo);

	// 本地化
	if (!uni.getStorageSync('locale'))
		uni.setStorageSync('locale', constants.DEFAULT_LOCALE);

	// 语言
	if (!uni.getStorageSync('lang'))
		uni.setStorageSync('lang', constants.DEFAULT_LANG);
};


// 客服跳转 读取系统配置客服url，外部打开。用于上架
const linkService = async () => {
	const result = await http.get(`api/app/config`);
	// console.log('reslut:', result);
	// console.log('window:', window);
	// console.log('navigator:', navigator);
	// "CustomerLink"
	if (!result) return false;
	const temp = result.reduce((map, item) => {
		map.set(item.key, item.value);
		return map;
	}, new Map());

	let url = temp.get('CustomerLink');

	if (window.android) {
		window.android.callAndroid("open," + url)
		return false;
	}
	if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
		.nativeExt) {
		window.webkit.messageHandlers.nativeExt.postMessage({
			msg: 'open,' + url
		})
		return false;
	}
	let u = navigator.userAgent;
	let isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
	if (isiOS) {
		window.location.href = url;
		return false;
	}
	window.open(url)
}

/*
跳转到客服，：
	上架模式：[`line`|`第三方`] 弹出提示框，联系客户经理
	正常模式：`line`(跳轉到外鏈頁面)，`第三方`(跳轉内頁)
*/
const linkCustomerService = () => {
	// 上架模式：[`line`|`第三方`] 弹出提示框，联系客户经理
	// uni.showToast({
	// 	title: Vue.prototype.$lang.SERVICE_CONTACT_MANAGER,
	// 	icon: 'none'
	// });

	// 正常模式：`line`(跳轉到外鏈頁面)
	linkService();

	// 正常模式：`第三方`(跳轉内頁)
	// uni.navigateTo({
	// 	url: Vue.prototype.$paths.SERVICE
	// });
}

// 根据当前平台，执行 $alert 或 uni.showToast
const showToast = (type, title, icon = 'none') => {
	/*#ifdef APP-PLUS*/
	uni.showToast({
		title: title,
		icon: icon
	});
	/*#endif*/

	/*#ifdef H5*/
	Vue.prototype.$alert({
		title: title,
		type: type,
	})
	/*#endif*/
};


// 检查输入值 是否合法，小数是否大于指定位数。返回处理完成的数字类型的值
const checkInputNumber = (val, point = 4) => {
	const defaultPoint = 4; // 默认最大小数位数;
	val = isNaN(val) ? 0 : Number(val);
	if (val <= 0) {
		showToast('warming', Vue.prototype.$t('tip.valid'));
		return false;
	}

	// 计算小数点后面的位数
	const temp = val.toString().split('.')[1]?.length || 0;
	// console.log(`check`, val, temp);
	if (temp > point) {
		showToast('warming', Vue.prototype.$t('tip.decimalPrefix') +
			defaultPoint + Vue.prototype.$t('tip.decimalSuffix'));
		return false;
	}
	console.log(`check result:`, val);
	return val;
}



// 日期格式化
// // this.$util.formatDate(new Date())
// const formatDate = (timeString) => {
// 	// console.log('原值:', timeString);
// 	// const curLang = uni.getStorageSync('lang');
// 	const curLang = constants.DEFAULT_LOCALE;
// 	// console.log('当前语言', curLang);
// 	const opt = {
// 		year: 'numeric',
// 		month: 'numeric',
// 		day: 'numeric',
// 		hour: 'numeric',
// 		minute: 'numeric',
// 		second: 'numeric',
// 		hour12: false, // 以24小时制处理
// 	};
// 	const result = new Intl.DateTimeFormat(curLang, opt).format(new Date(timeString));
// 	// console.log('格式化：', result);
// 	return result;
// };

// // 格式化 日期时间 不传值即默认当前时间
// formatDate: (val = '') => {
// 	val = val.length <= 0 ? new Date() : val;
// 	// console.log(`val：`, val);
// 	const opt = {
// 		year: 'numeric',
// 		month: '2-digit',
// 		day: '2-digit',
// 		hour: '2-digit',
// 		minute: '2-digit',
// 		second: '2-digit',
// 		hour12: false,
// 	};
// 	const tempLocale = uni.getStorageSync('locale') || constants.DEFAULT_LOCALE;
// 	const temp = localize[tempLocale];
// 	return new Intl.DateTimeFormat(temp.code, {
// 		...opt,
// 		timeZone: temp.timeZone
// 	}).format(val);
// },

// // 格式化 HH:MM:SS
// formatToDayTime: (val = '') => {
// 	val = val.length <= 0 ? new Date() : val;
// 	// console.log(`val：`, val);
// 	const opt = {
// 		hour: '2-digit',
// 		minute: '2-digit',
// 		second: '2-digit',
// 		hour12: false,
// 	};
// 	const tempLocale = uni.getStorageSync('locale') || constants.DEFAULT_LOCALE;
// 	const temp = localize[tempLocale];
// 	return new Intl.DateTimeFormat(temp.code, {
// 		...opt,
// 		timeZone: temp.timeZone
// 	}).format(val);
// },

/**
 * @function 是否为加密币系列
 * @param {string} val tab列的key，通常是market页面
 * @return {boolean} 
 * @description 
 * @example
 * this.$util.isUSDT(this.curKey)
 */
export const isUSDT = (val) => {
	console.log(`isUSDT:`, val);
	return [constants.KEY_CRYPTO,
		constants.KEY_FOREX,
		constants.KEY_FUTURE
	].includes(val);
};

// 对象合并
export const mergeObjects = (obj1, obj2) => {
	const result = {};
	Object.keys(obj1).forEach(key => {
		// 合并 obj1 和 obj2 对于相同 key 的对象
		result[key] = {
			...obj1[key],
			...obj2[key]
		};
	});
	return result;
};

export default {
	initialize,
	linkCustomerService,
	showToast,
	checkInputNumber,
	isUSDT,
	mergeObjects,

	// 根据当前平台，执行回退方式
	goBack: () => {
		/*#ifdef APP-PLUS*/
		uni.navigateBack({
			delta: 1
		});
		/*#endif*/

		/*#ifdef H5*/
		history.back();
		/*#endif*/
	},

	// 设置数据掩码状态
	setDataMask: (val = true) => {
		uni.setStorageSync('masking', val);
	},





	// 邮箱验证
	checkEmail: (val) => {
		const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
		console.log('checkEmail:', !emailPattern.test(val))
		return emailPattern.test(val);
	},

	// 部分页面需要拼接股票完整LOGO的url
	setLogo: (url) => {
		// console.log('url:',url);
		return url.includes('http') ? url : http.BASE_URL + url;
	},
	// 设置 Coin Logo
	setCoinLogo: (url) => {
		return url.includes('http') ? url : http.BASE_URL + url;
	},
	isImageUrl: (url) => {
		// 使用正则表达式检查URL是否以.png或.jpg结尾
		const regex = /\.(png|jpe?g)$/i; // .jpg 和 .jpeg都支持
		return regex.test(url);
	},

	// 统一处理杠杆，后端数据返回不一致。
	leverList: (val) => {
		val = val || [];
		// 如果没有数据。就返回默认杠杆 1
		if (!val || val.length <= 0) return [1];

		console.log(val);

		// 数组对象类型 
		// ganggan: [{name: "", index: ""}] 
		// ganggan: [{name: "2", index: "2"}, {name: "4", index: "4"}, ...]
		if (val.length > 0 && typeof(val[0]) === 'object') {
			// val[0].index && val[0].index * 1 > 0
			const tempFilter = val.filter(item => item.index * 1 > 0);
			const temp = tempFilter.map(item => item.index * 1);
			console.log('lever array object:', temp);
			// 数据中，添加1倍杠杆
			return temp[0] * 1 == 1 ? temp : [1, ...temp];
		} else if (Array.isArray(val)) {
			// [1, '2', '4', '5', '10']
			console.log(1, val);
			return val.map(item => item * 1);
		}

		// 字符串类型 ganggan: "2,3,4,5,6,7,8,9,10" 
		if (typeof(val) === 'string') {
			const temp = val.split(',').map(item => item * 1);
			console.log('lever string:', temp);
			// 数据中，添加1倍杠杆
			return temp[0] * 1 == 1 ? temp : [1, ...temp];
		}

	},
}