// lg-RE 
// 语言:https://ougato.github.io/2019/04/30/Language/
// 时区：
export default {
	'en-US': {
		code: 'en-US', // 美
		lang: 'English',
		timeZone: 'America/New_York',
		flag: 'us',
		currency: 'USD',
	},
	'zh-TW': {
		code: 'zh-TW', // 繁中
		lang: '台湾繁体',
		timeZone: 'Asia/Taipei',
		flag: 'tw',
		currency: 'TWD',
	},
	// 'it-IT': {
	// 	code: 'it-IT', // 意大利
	// 	lang: 'Italiano',
	// 	timeZone: 'Europe/Rome',
	// 	flag: 'it',
	// 	currency: 'EUR',
	// },
	'fr-FR': {
		code: 'fr-FR', // 法
		lang: 'Français',
		timeZone: 'Europe/Paris',
		flag: 'fr',
		currency: 'EUR',
	},
	// 'th-TH': {
	// 	code: 'th-TH', // 泰
	// 	lang: 'ไทย',
	// 	timezone: 'Asia/Bangkok',
	// 	flag: 'th',
	// 	currency: 'THB',
	// },
	'ja-JP': {
		code: 'ja-JP', // 日
		lang: '日本語',
		timeZone: 'Asia/Tokyo',
		flag: 'jp',
		currency: 'JPY',
	},

	'pt-PT': {
		code: 'pt-PT', // 葡萄牙
		lang: 'Português',
		timeZone: 'Europe/Lisbon',
		flag: 'pt',
		currency: 'EUR',
	},

	'es-ES': {
		code: 'es-ES', // 西班牙
		lang: 'Español',
		timeZone: 'Europe/Madrid',
		flag: 'es',
		currency: 'EUR',
	},
	// 'ko-KR': {
	// 	code: 'ko-KR', // 韩
	// 	lang: '한국의',
	// 	timeZone: 'Asia/Seoul',
	// 	flag: 'kr',
	// 	currency: 'KRW',
	// },
	// 'tr-TR': {
	// 	code: 'tr-TR', // 土耳其
	// 	lang: 'Türkçe',
	// 	timeZone: 'Europe/Istanbul',
	// 	flag: 'tr',
	// 	currency: 'TRY',
	// },
	// 'ar-IL': {
	// 	code: 'ar-IL', // 阿拉伯语（以色列)
	// 	lang: 'العربية',
	// 	timezone: 'Asia/Jerusalem',
	// 	flag: 'il',
	// 	currency: 'SAR',
	// },
	// 'vi-VN': {
	// 	code: 'vi-VN', // 越南语
	// 	lang: 'tiếng việt',
	// 	timeZone: 'Asia/Ho_Chi_Minh',
	// 	flag: 'vn',
	// 	currency: 'VND',
	// },


	'ru-RU': {
		code: 'ru-RU', // 俄
		lang: 'Русский',
		timeZone: 'Europe/Moscow',
		flag: 'ru',
		currency: 'RUB',
	},
	// 'zh-CN': {
	// 	code: 'zh-CN', // 简中
	// 	lang: '中文简体',
	// 	timeZone: 'Asia/Shanghai',
	// 	flag: 'cn',
	// }, 
	// {
	// 	code: 'en-GB', // 英国
	// 	lang: 'English（United Kingdom)',
	// 	timeZone: 'Europe/London',
	// 	flag: 'gb',
	// }, {
	// 	code: 'en-AU', // 澳大利亚
	// 	lang: 'English（Australia)',
	// 	timeZone: 'Australia/Sydney',
	// 	flag: 'au',
	// }, 

	// {
	// 	code: 'bn-IN', // 孟加拉语（印度)
	// 	lang: 'বাংলা',
	// 	timeZone: 'Asia/Dhaka',
	// }, {
	// 	code: 'hi-IN', // 印度语
	// 	lang: 'हिंदी',
	// 	timeZone: 'Asia/Kolkata',
	// }, 
};