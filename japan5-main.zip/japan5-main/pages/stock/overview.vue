<!-- 股票详情 -->
<template>
	<view>
		<view>
			<!-- <CustomHeader :title="$lang.TRADE_IPO" @action="handleBack()"></CustomHeader> -->
			<image src="/static/gupiao.png" style="width: 100%;height: 200px;"></image>
			<view class="flex" style="position: absolute;bottom: 93%;color: #FFF;width: 100%;">
				<image src="/static/baisejiantou.png" mode="widthFix"
					style="width: 25px;height: 25px;margin-left: 10px;" @click="home()"></image>
				<view style="font-size: 18px;width: 100%;justify-content: center;display: flex;">株式詳細</view>
				<!-- <view style="width: 80px;margin-right: 10px;" @click="handleChangeTab(0)">申请记录</view> -->
			</view>
		</view>


		<view style="margin: 10px;position: absolute;bottom: 18%;color: #FFF;width: 95%;">
			<view v-show="curren==0">

				<view class="stock-chart" style="padding-top: 10px;border-radius: 10px;">
					<view class="flex flex-b pd10">
						<view class="flex align-center">
							<!-- <u--image :src="getlogo()" shape="circle" width="50px" height="50px" mode="widthFix"></u--image> -->
							<view class="margin-left-15">
								<view class="text-center bold" style="color: #000;font-size: 18px;">
									{{productDetails.name}}
								</view>
								<view class="hui1 padding-5"> {{productDetails.ct_name}} {{productDetails.number_code}}
								</view>
							</view>
						</view>

						<view class="icon margin-right-20" style="width:20px;height: 20px;"
							:class="productDetails.is_collected==1?'yzx':'wzx'"
							@click="handleClickDelProduct(productDetails.gid)"></view>
					</view>

					<template v-if="productDetails">
						<view
							style="display: flex;align-items: center;justify-content: space-around;padding: 10px 10px;"
							:style="$util.calcStyleRiseFall(productDetails.rate>0)">
							<view style="font-size: 20px; font-weight: 700;">
								{{$util.formatNumber(productDetails.current_price,2)}}
							</view>
							<view style="font-size: 20px; font-weight: 700;">
								{{$util.formatNumber(productDetails.rate_num)}}
							</view>
							<view style="font-size: 20px; font-weight: 700;">
								{{$util.formatNumber(productDetails.rate)}}%
							</view>
						</view>

					</template>
					<view class="chart-time" style="position: relative;margin-top: 30px;">
						<view class="txt" :class="ac_time==0?'active':''" @click="ac_time_click(0)">分</view>
						<view class="txt" :class="ac_time==1?'active':''" @click="ac_time_click(1)">日</view>
						<view class="txt" :class="ac_time==2?'active':''" @click="ac_time_click(2)">週</view>
						<view class="txt" :class="ac_time==3?'active':''" @click="ac_time_click(3)">月</view>
					</view>
					<view class="chart" id="chart-type-k-line" style="width: 100%;height: 500rpx;">
					</view>
				</view>
				<view v-if="productDetails.project_type_id==2">
					<view class="common_btn" style="margin:40px;background-color: #24228f;height: 40px;line-height: 40px;"
						@click="purchase(1)">買い上がる</view>
						
					<view class="common_btn" style="margin:40px;background-color: #f92855;height: 40px;line-height: 40px;"
						@click="purchase(2)">買い下がる</view>
				</view>
				
				<view v-else>
					<view class="common_btn" style="margin:40px;background-color: #24228f;height: 40px;line-height: 40px;"
						@click="purchase(1)">買う</view>
						

				</view>
					
					
			</view>
		</view>

		<InfoTwo v-if="curren==1" :code='code' :productDetails='productDetails'></InfoTwo>

		<InfoThree v-if="curren==2" :code='code' :productDetails='productDetails'></InfoThree>



	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import Tbas from '@/components/Tbas.vue';
	import InfoTwo from '@/components/info/InfoTwo.vue'
	import InfoThree from '@/components/info/InfoThree.vue'
	import {
		init,
		registerLocale,
		dispose
	} from 'klinecharts'
	// import generatedKLineDataList from '@/utils/generatedKLineDataList.js'

	export default {
		components: {
			CustomHeader,
			Tbas,
			InfoTwo,
			InfoThree
		},
		data() {
			return {
				zuoshou: 0,
				updata: true,
				productDetails: "",
				today: '',
				yesterday: '',
				buy: "",
				sell: "",
				divide: '',
				sky: '',
				circumference: '',
				moon: '',
				onePoint: '',
				halfhour: '',
				timerId: null,
				option: {},
				time_index: 0,
				list: [],
				gid: 0,
				kLineChart: [],
				ac_time: 0,
				curren: 0,
				lishi: "",
				timer: null,
			};

		},
		onLoad(option) {
			this.code = option.code
		},
		onShow() {
			// this.startTimer()
			this.getData();
		},
		onUnload() {
			if (this.timer) this.clearTimer();
			// clearInterval(this.timerId);
			uni.closeSocket({
				success: () => {},
			})
		},
		onHide() {
			if (this.timer) this.clearTimer();
			// clearInterval(this.timerId);
			uni.closeSocket({
				success: () => {},
			})
		},
		deactivated() {
			if (this.timer) this.clearTimer();
			uni.closeSocket({
				success: () => {},
			})
		},
		mounted() {
			this.kLineChart = init('chart-type-k-line')
			this.init()
			this.sockets()
		},
		//下拉刷新
		onPullDownRefresh() {
			this.getData();
			// this.genKLineData();
			uni.stopPullDownRefresh();
		},
		methods: {
			onSetTimeout() {
				this.timer = setInterval(() => {
					console.log("setInterval");
					this.getData();
				}, 5000);
			},
			clearTimer() {
				if (this.timer) {
					clearInterval(this.timer);
					this.timer = null;
					console.log('clearTimer', this.timer);
				}
			},

			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			sockets() {
				//创建webSocket
				this.webSocketTask = uni.connectSocket({
					url: this.$http.WssUrl,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
				})

				// 监听WebSocket连接打开事件
				this.webSocketTask.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				var that = this;
				// 接收websocket消息及处理
				this.webSocketTask.onMessage((res) => {
					var data = JSON.parse(res.data);
					// console.log(`ws:`,data);
					
					if (that.productDetails) {
						if (that.productDetails.stock_id == data.pid) {
							console.log(`ws:`,data);

							let current_price = data.last.replace(",", '')
							// current_price=current_price.replace("+",'')

							that.productDetails.current_price = current_price;
							let rate = data.pcp.replace("+", '')
							rate = rate.replace("%", '')

							that.productDetails.rate = rate;

							that.productDetails.rate_num = data.pc;
							// that.qiehuan()
							this.lishi[this.lishi.length - 1].close = current_price;

							this.kLineChart.applyNewData(this.lishi)

						}
					}

				});
			},
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			getlogo() {
				return this.$BaseUrl + this.productDetails.logo
			},

			handleChangeTab(val) {
				// clearInterval(this.timer);
				// this.curren = val;
				this.curren_click(val);
			},

			init() {
				this.kLineChart.setStyles({
					"candle": {
						"type": "area",
						"tooltip": {
							"showRule": "none",
						},
						area: {
							lineSize: 2,
							lineColor: this.$util.THEME.PRIMARY,
							value: 'close',
							backgroundColor: [{
								offset: 0,
								color: '#ffbfb9'
							}, {
								offset: 1,
								color: this.$util.THEME.PRIMARY,
							}]
						},
						bar: {
							upColor: '#3779CD',
							downColor: '#F92855',
							noChangeColor: '#888888',
							upBorderColor: '#3779CD',
							downBorderColor: '#F92855',
							noChangeBorderColor: '#888888',
							upWickColor: '#3779CD',
							downWickColor: '#F92855',
							noChangeWickColor: '#888888'
						},
					},
				});
				this.kLineChart.createIndicator('MA', false);
				// this.getData()
				// this.startTimer()
			},
			curren_click(index) {
				this.curren = index;
				this.$forceUpdate()
			},
			ac_time_click(index) {
				this.ac_time = index;
				this.qiehuan()
			},
			async qiehuan() {

				let list = await this.$http.post(this.$http.API_URL.PRODUCT_LISHI, {
					stock_id: this.productDetails.stock_id,
					ac_time: this.ac_time,
					project_type_id: this.productDetails.project_type_id,
					code: this.productDetails.code
				})
				if (this.ac_time >= 1) {

					this.kLineChart.setStyles({
						"candle": {
							"type": "candle_solid",
						},

					});
				} else {

					this.kLineChart.setStyles({
						"candle": {
							"type": "area",
						},

					});
				}
				this.lishi = list.data.data;
				// this.kLineChart.setPriceVolumePrecision(0, 0)
				this.kLineChart.applyNewData(list.data.data)
			},
			time_click(i) {
				this.time_index = i.index
				this.getData()
			},
			// 买入
			purchase(direct) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_BUY}?code=${this.code}&direct=`+direct
					// url: '/pages/marketQuotations/purchase?code=' + this.code

				});
			},
			// 产品详情
			async getData() {
				let list = await this.$http.get('api/product/info', {
					code: this.code,
					time_index: this.time_index
				})
				console.log(`getData :`, list);
				this.productDetails = list.data.data[0]

				// 在沒有定時器，即進入頁面第一次請求時，請求kline
				if (!this.timer) {
					// 延时,等DOM渲染
					setTimeout(() => {
						if (!this.kLineChart) {
							this.kLineChart = init('chart-type-k-line');
							this.init(); // 初始化Kline
						}
						this.qiehuan(); // 获取并生成KLine数据	
					}, 50);
				}

				// 每5s執行該函數時，處理定時器
				if (this.timer) this.clearTimer();
				this.onSetTimeout();

				// let new_price = this.productDetails.data.TDD_CLSPRC.replace(',', "");
				// let rate_num = this.productDetails.rate_num

				// this.zuoshou = (new_price * 1 - rate_num * 1).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

			},
			// //定时器
			// startTimer() {
			// 	const storedTimerId = uni.getStorageSync('timerId');
			// 	if (storedTimerId) {
			// 		clearInterval(storedTimerId);
			// 	}
			// 	this.timerId = setInterval(() => {
			// 		// this.product()
			// 	}, 2000);
			// 	uni.setStorageSync('timerId', this.timerId);
			// 	// 在这里立即执行一次请求
			// },
			//删除
			async handleClickDelProduct(e) {
				let list = await this.$http.post('api/user/collect_edit', {
					gid: e,
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.updata = !this.updata
					this.updata = true
					//按键样式判断
					this.productDetails.is_collected = this.productDetails.is_collected == 1 ? 0 : 1
				} else {
					this.show = false
					uni.$u.toast(list.data.message);
				}
			},

		},
	}
</script>

<style lang="scss">
	.top1 {
		padding: 16px 5px 5px;

		.pd10 {
			padding: 0 5px;
		}

		.t {
			font-size: 19px;
			font-weight: 700;
			color: #333;
		}

		.bt {
			background: #489ce5;
			border-radius: 10px;
			padding: 5px 10px;

			.icon {
				margin-right: 10px;
			}

			view {
				font-size: 17px;
				color: #fefefe;
			}
		}

		.mt30 {
			margin-top: 16px;
		}

		.t1 {
			font-size: 32px;
			font-family: Roboto;
			font-weight: 700;
			color: #333;
			margin-right: 10px;
		}

		.r-bg {
			background: #f7e8e8;
			border-radius: 10px;
			padding: 5px 10px;

			.icon {
				margin-right: 5px;
			}

			span {
				font-family: Roboto;
				font-weight: 700;
				color: #ff3636;
			}
		}

		.b-bg {
			background: #e7f1f9;
			border-radius: 10px;
			padding: 5px 10px;

			span {
				font-family: Roboto;
				font-weight: 700;
				color: #489ce5;
			}
		}

		.list1 {
			background-color: #0332783b;
			border-radius: 8px;
			padding: 10px 5px;
			-webkit-flex-wrap: wrap;
			flex-wrap: wrap;
			margin-top: 10px;

			.item {
				width: 32%;
				line-height: 21px;
			}

			.t2 {
				font-size: 12px;
				color: #999;
			}

			.t3 {
				font-size: 12px;
				color: #333;
				font-family: Roboto;
			}
		}
	}

	.stock-chart {
		background: #fff;

		.chart-time {
			background: #fff;
			// border: 1px solid #999;
			border-radius: 10px;
			display: -webkit-box;
			display: -webkit-flex;
			display: flex;
			-webkit-box-pack: justify;
			-webkit-justify-content: space-between;
			justify-content: space-between;
			-webkit-box-align: center;
			-webkit-align-items: center;
			align-items: center;
			margin: 0 10px 10px;

			.txt {
				-webkit-box-flex: 1;
				-webkit-flex: 1;
				flex: 1;
				text-align: center;
				color: #999;
				border-radius: 5px;
				padding: 10px 0;
			}

			.active.txt {
				color: #fff;
				background-color: #24228f;
				box-shadow: rgba(0, 0, 0, 0.24) 0px 3px 8px;
				border-radius: 20px;
			}
		}
	}
</style>