<template>
	<view >
		<view class="flex" style="background-color: #080d61;height: 90px;">
			<!-- <image src="/static/baisejiantou.png" mode="widthFix" style="width: 20px;" @click="home2()" ></image> -->
			<view style="font-size: 18px;color: #fff;width: 100%;justify-content: center;display: flex;">お気に入り</view>
		</view>
		<view style="margin-top: -20px;border-radius: 10px;width: 100%;background-color: #f5f5f5;">
			<!-- <view class="line" style="display: flex;align-items: center;padding:6px 10px;" :style="{color:$util.THEME.LABEL}">
				<view style="flex:18%;">{{$lang.CODE}}/{{$lang.STOCK}}</view>
				<view style="flex:32%;"></view>
				<view style="flex:25%;text-align: right; padding-right: 16px;">{{$lang.RISE_FALL_AMOUNT}}</view>
				<view style="flex:15%;text-align: right; padding-right: 16px;">{{$lang.RISE_FALL_RATE}}</view>
				<view style="flex:5%;"></view>
			</view> -->
			
			<!-- <u-tabs :list="list1" style="margin: -20px 10px 0px;border-bottom: 5px solid #f5f5f5;border-top: 5px solid #f5f5f5;"
				activeStyle="color:#014bab;font-weight: 700;" lineColor="#014bab" @change="change" :current="current">
			
			</u-tabs> -->
			
			<view style="min-height: 60vh;">
				<block v-for="(item,index) in list" :key="index">
					<view @click="productDetails(item.goods.code,item.id)"
						style="align-items: center;margin:6px 10px;padding-bottom: 6px;">
						
						<view class="flex" style="background-color: #fff;border-radius: 10px;padding: 5px;height: 60px;">
							<view class="flex-4">
							<view style="width: 150%;" :style="{color:$util.THEME.TEXT}">
								{{item.goods.name}}
							</view>
							<view style="font-weight: 900;padding-right: 16px;"
								:style="$util.calcStyleRiseFall(item.goods.rate>0)">{{item.goods.code}}</view>
								</view>				
						<view style="flex:25%;text-align: right; padding-right: 16px;"
							:style="$util.calcStyleRiseFall(item.goods.rate>0)">
							{{$util.formatNumber(item.goods.current_price)}}
						</view>
						<view style="flex:15%;text-align: right; padding-right: 16px;"
							:style="$util.calcStyleRiseFall(item.goods.rate>0)">
							{{item.goods.rate>0?'+':''}}{{item.goods.rate}}%
						</view>
						<view style="flex:5%;">
							<image mode="aspectFit" src="/static/star.png" :style="$util.calcImageSize(22)"
								@click.stop="handleClickDelProduct(item.goods.gid)"></image>
						</view>
						</view>
					</view>
				</block>
				<EmptyData v-if="list.length<=0"></EmptyData>
			</view>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			Header,EmptyData,
		},
		data() {
			return {
				list: [],
				list1: [{
					name: '株式'
				},{
					name: 'がいこくかわせ'
				}],
				timer: null,
				
			}
		},
		onShow() {
			this.getList()
			this.startTimer()
		},
		onHide() {
			clearInterval(this.timer);
		},
		methods: {
			change(index) {
				console.log(index)
				this.current = index.index;
				this.lists()
			},
			productDetails(code,id) {
				uni.navigateTo({
					url: `${this.$util.PAGE_URL.STOCK_OVERVIEW}?code=${code}&id=${id}`
				});
			},
			//定时器
			startTimer() {
				this.timer = setInterval(() => {
					this.getList();
				}, 5000);
			},
			home2() {
						uni.navigateBack({
								delta: 2, //返回层数，2则上上页
							});
						},

			async getList() {
				if (this.list.length <= 0) {
					uni.showLoading({
						title: this.$lang.LOADING,
					})
				}
				const result = await this.$http.get(this.$http.API_URL.COLLECT_LIST, {});
				if (this.list.length <= 0 || result.data.code == 0) {
					uni.hideLoading();
				}
				this.list = result.data.data.list;
			},

			// 点击删除
			async handleClickDelProduct(gid) {
				const result = await this.$http.post(this.$http.API_URL.COLLECT_EDIT, {
					gid: gid,
				})
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					this.getList()
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		},
	}
</script>