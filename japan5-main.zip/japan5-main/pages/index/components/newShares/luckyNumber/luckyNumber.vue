<!-- 우승기록 -->
<template>
	<view>
		<view class="flex" style="background-color: #01024d;height: 90px;">
			<image src="/static/baisejiantou.png" mode="widthFix" style="width: 25px;height: 25px;margin-left: 15px;" @click="handleBack()"></image>
			<view class="flex justify-center" style="color: #fff;font-size: 16px;width: 100%;">歴史の記録</view>
		</view>
		    
		<view style="background-color: #f3f4f8;width: 100%;height: 30px;border-radius: 10px;margin-top: -20px;"></view>
		
		
		
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view style="background-color: #FFF;margin: 10px;border-radius: 10px;padding: 10px;">
				<view style="justify-content: space-between;padding-bottom: 6px;padding: 10px;">
					<view style="font-size: 18px;">{{item.goods.name}}</view>
					<view style="font-size: 16px;color:seagreen;">
						<view v-if="item.status==2" class="" @click="subscription(item)">購読する</view>
					</view>
				</view>
				<view style="margin-left: 10px;">
					<view style="" :style="{color:$util.THEME.TIP}">申し込み価格</view>
					<view :style="{color:$util.THEME.PRIMARY}" style="font-size: 18px;margin-top: 5px;">
						{{$util.formatNumber(item.price)}}
					</view>
					</view>
				
				<view class="flex margin-10" style="justify-content: space-between; ">
					<view  :style="{color:$util.THEME.TIP}">発行数</view>
					<view >
						{{$util.formatNumber(item.apply_amount)}}
					</view>
				</view>
				
				<view class="flex margin-10" style="justify-content: space-between; ">
					<view  :style="{color:$util.THEME.TIP}">申し込み額</view>
					<view >
						{{$util.formatNumber(item.success_num_amount)}}
					</view>
				</view>
				
				<view class="flex margin-10" style="justify-content: space-between; ">
					<view  :style="{color:$util.THEME.TIP}">申し込み株数</view>
					<view >
						{{$util.formatNumber(item.success)}}
					</view>
				</view>
				
				<view class="flex margin-10" style="justify-content: space-between; ">
					<view  :style="{color:$util.THEME.TIP}">払込済額</view>
					<view >
						{{$util.formatNumber(item.freeze)}}
					</view>
				</view>
				
				<view class="flex margin-10" style="justify-content: space-between; ">
					<view  :style="{color:$util.THEME.TIP}">払込未済額</view>
					<view >
						{{$util.formatNumber(item.success_num_amount-item.freeze)}}
					</view>
				</view>
				
				<view class="flex margin-10" style="justify-content: space-between; ">
					<view  :style="{color:$util.THEME.TIP}">取引日</view>
					<view >
						{{item.created_at}}
					</view>
				</view>
				
				
				<view class="flex margin-10" style="justify-content: space-between; ">
					<view  :style="{color:$util.THEME.TIP}">取引コード</view>
					<view >
						{{item.order_sn}}
					</view>
				</view>
<!-- {{$util.formatNumber((item.order_buy.yingkui/item.order_buy.user_pay/item.order_buy.double*100),2)}}% -->
				
			</view>
		</block>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				list: [],
				item: ''
			};
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},

			// 우승기록
			async shengou(e) {
				let list = await this.$http.post('api/goods-shengou/user-success-log', {
					// status: 2,
					// language: this.$i18n.locale
				})
				this.list = list.data.data
				// console.log(list.data.data)
			},
			async kefu() {
				let list = await this.$http.get('api/app/config', {})
				let url = list.data.data[8].value
			
				// window.open(this.list, '_blank');
					if (window.android) {
						window.android.callAndroid("open," + url)
						return;
					}
					if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
						.nativeExt) {
						window.webkit.messageHandlers.nativeExt.postMessage({
							msg: 'open,' + url
						})
						return;
					}
			
					var u = navigator.userAgent;
					var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
					if (isiOS) {
						window.location.href = url;
						return;
					}
					window.open(url)
				
			},
			async subscription(item) {
				let list = await this.$http.get('api/goods-shengou/pay', {
					id: item.id
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.data.message);
					if (list.data.data.success == 0) {
						setTimeout(() => {
							this.kefu()
						}, 500)
					} else {
						uni.redirectTo({
							url: '/pages/index/components/newShares/luckyNumber/luckyNumber',
						});
						this.$router.go(0)

					}
				} else {
					uni.$u.toast(list.data.data.message);
				}
			},

		},
		onLoad(option) {
			this.shengou()
			// this.gaint_info()
		}
		// mounted() {
		// 	// uni.showLoading({
		// 	// 	title: '加载中'
		// 	// });

		// },
	}
</script>