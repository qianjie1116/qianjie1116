<template>
	<view class="page"  style="position: relative;">
		<image src="/static/rinei1.png" mode="widthFix" style="width: 100%;"></image>
		<view>
			<!-- <image src="/static/rinei1.png" mode="widthFix" style="width: 100%;"></image> -->
			
			<image src="/static/rinei2.png" mode="widthFix" style="width: 50%;height: 130px; position: absolute;bottom: 80%;left: 20px;"></image>
			<image src="/static/rinei3.png" mode="widthFix" style="width: 30%;height: 130px; position: absolute;bottom: 72%;left: 260px;"></image>
			<view class="flex flex-c"style="width: 95%;height: 150px; position: absolute;bottom: 85%;color: #fff;"><img
					src="/static/baisejiantou.png" 
					style="width:25px;" @click="$u.route({type:'switchTab',url:'/pages/home'});">
				<view class="header-center flex-1" style="margin-left: 120px;font-size: 18px;">デイトレード</view>
				<view class="" @tap="manages()">申請記録</view>
			</view>
		</view>
		
		<!-- <view class="nav-box">
			<view class="nav-item" @click="dianji(0)" :class="top_index==0?'active':''">
				<font _mstmutation="1">デイトレード</font><span></span>
			</view>
			<view class="nav-item" @click="dianji(1)" :class="top_index==1?'active':''">
				<font _mstmutation="1">申し込む</font><span></span>
			</view>
			<!-- <view class="nav-item" @click="dianji(2)" :class="top_index==2?'active':''">
				<font _mstmutation="1">{{$t('index.Detailed_transaction_history')}}</font><span></span>
			</view> -->
			<!-- <view class="nav-item" @click="dianji(3)" :class="top_index==3?'active':''">
				<font _mstmutation="1">場所</font><span></span>
			</view>
		</view> --> 
		<!-- <view v-if="top_index==3&&list">
			<view class="transaction" style="margin-top: -50px;">
				<view class="" style="border-bottom: 1px solid #e9e9e9;padding: 30rpx 0 ;" v-for="(item,index) in list"
					:key="index">


					<view class="display" style="margin: 30rpx 30rpx 20rpx;font-size: 26rpx;">
						<view class="up-date">購入時間：{{item.created_at}} </view> -->
						<!-- <view class="buy-up">买涨↑</view> -->
						<!-- <view class="time"></view> -->
					<!-- </view>
					<view class="shadow">
						<view class="display">
							<view class="">承認ステータス:</view>
							<view class="quantity" v-if="item.status==0" style="color: #666666;">{{item.zt}}</view>
							<view class="quantity" v-if="item.status==1">{{item.zt}}</view>
							<view class="quantity" v-if="item.status==2" style="color: darkcyan;">{{item.zt}}</view>
						</view>

					</view>

					<view class="shadows">
						<view class="shadows-dis">
							<view class="">購入数量:</view>
							<view class="quantity">{{item.money}}</view>
						</view>
						<view class="shadows-dis">
							<view class="">注文番号:</view>
							<view class="quantity">{{item.ordersn}}</view>
						</view>
					</view>
				</view>
				<view class="finished-text">
					履歴なし
				</view>
			</view> -->
		<!-- </view> -->
		
		<!-- <view class="nodata t-c" v-if="list.length==0&&top_index>0">
			<view class="no-img"></view>
			<view class="txt">履歴なし</view>
		</view> -->
		<!-- <view v-if="top_index==2&&list">
			<view class="transaction">
				<view class="" style="border-bottom: 1px solid #e9e9e9;padding: 30rpx 0 ;" v-for="(item,index) in list">
					<view class="display" style="margin: 30rpx 30rpx 20rpx;font-size: 26rpx;">
						<view class="up-date">購入時間：{{item.created_at}} </view>
					</view>
					<view class="shadow">
						<view class="display">
							<view class="">承認ステータス:</view>
							<view class="quantity" v-if="item.status==0" style="color: #666666;">{{item.zt}}</view>
							<view class="quantity" v-if="item.status==1">{{item.zt}}</view>
				
						</view>
					</view>
		
					<view class="shadows">
						<view class="shadows-dis">
							<view class="">購入数量:</view>
							<view class="quantity">{{item.money}}</view>
						</view>
						<view class="shadows-dis">
							<view class="">収益率:</view>
							<view class="quantity">{{item.yingkui}}</view>
						</view>
					</view>
				</view>
				<view class="finished-text">
					履歴なし
				</view>
			</view>
		</view> -->
		<!-- <view v-if="top_index==1&&list">
			<view class="transaction">
				<view class="" style="border-bottom: 1px solid #e9e9e9;padding: 30rpx 0 ;" v-for="(item,index) in list"
					:key="index">


					<view class="display" style="margin: 30rpx 30rpx 20rpx;font-size: 26rpx;">
						<view class="up-date">購入時間：{{item.created_at}} </view>
					</view>
					<view class="shadow">
						<view class="display">
							<view class="">承認ステータス:</view>
							<view class="quantity" v-if="item.status==0" style="color: #666666;">{{item.zt}}</view>
							<view class="quantity" v-if="item.status==1">{{item.zt}}</view>
				
						</view>
					</view>

					<view class="shadows">
						<view class="shadows-dis">
							<view class="">購入数量:</view>
							<view class="quantity">{{item.money}}</view>
						</view>
						<view class="shadows-dis">
							<view class="">収益率:</view>
							<view class="quantity">{{item.yingkui}}</view>
						</view>
					</view>
					<u-button style="width: 80%;background: #e8d2af;" @click="sell(item.id)">売り</u-button>
				</view>
				<view class="finished-text">
					履歴なし
				</view>
			</view>
		</view> -->
		<view class="tj" v-if="top_index==0" style="margin: 10px;background-color: #fff;width: 95%;height: 520px;margin-top: -30px;border-radius: 10px;">
			<view class="icon dd bold" style="font-size: 16px;margin-right: 50px;padding: 10px;" >取引金額</view>
			<view class="ipt flex" style="margin-top: -200px;">
				<input placeholder="取引金額を入力してください..." class="uni-input-input" maxlength="130" v-model="money" type="number">

			</view>
			<view class="b-btn" @click="buy">もちろん</view>
			<view class="txt">
				<view class="flex">
					<!-- <view class="icon ts"></view> -->
					<!-- <font _mstmutation="1">ガイド:</font> -->
				</view>
				<view>1.日中売買投資家が当日株式を売買し、取引差益に応じて精算する売買技法です。</view>
				<view>2.投資家は株価を一律に売買し決済します.</view>
				<view class="mt40">3.買収後に利益が発生した場合は、「商取引」に直接表示され、売却および利益を選択することができます.</view>
				<view>4.日中取引の利益と機密保持のために、購入期間中に株式コードと詳細は提供されません。</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {

			return {
				money: "",
				top_index: 0,
				list: "",

			}
		},

		methods: {
			dianji(index) {
				this.top_index = index;
				this.list=""
				if (index == 1) {
					this.order_list()
				}else if (index == 2) {
					this.sell_list()
				}
			},
			manages() {
						uni.navigateTo({
						
						url: '/pages/index/rineijilu'
					});
			
			},
			async sq_list() {
			
				let list = await this.$http.get('api/Rinei/sq_list', {
					money: this.money
				})
			
				this.list = list.data.data
			
			},
			async sell(id) {
			
				let list = await this.$http.post('api/Rinei/sell', {
					id: id
				})
				this.order_list()
				if (list.data.code == 1) {
					return uni.$u.toast(list.data.message);
				} else {
					return uni.$u.toast(list.data.data);
				}
				
			},
			async sell_list() {
			
				let list = await this.$http.get('api/Rinei/sell_list', {
					money: this.money
				})
			
				this.list = list.data.data
			},
			async order_list() {

				let list = await this.$http.get('api/Rinei/order_list', {
					money: this.money
				})

				this.list = list.data.data
				console.log(this.list );

			},
			async buy() {
				if (this.money <= 0) {
					return uni.$u.toast("金額を入力してください");
				}
				let list = await this.$http.get('api/Rinei/buy', {
					money: this.money
				})
				if (list.data.code == 1) {
					return uni.$u.toast(list.data.message);
				} else {
					this.money=0;
					this.dianji(1)
					return uni.$u.toast(list.data.data);
					
				}
			},
			//用户信息
			async gaint_info() {
				let list = await this.$http.get(this.$http.API_URL.USER_FASTINFO, {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
				this.cardManagement = list.data.data.bank_card_info
			},
			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
		},

		onShow() {
			this.gaint_info()
			this.is_token()
		},
		onLoad() {

		},

	}
</script>

<style lang="scss">
	view,
	uni-text {
		box-sizing: border-box;
	}

	.page {
		
		// padding: 55px 0 16px;
		// min-height: 100vh;
	}

	.header {
		height: 55px;
		background: #e8d2af;
		box-shadow: 4px 6px 8px 0px rgba(231, 198, 161, .36);
		padding: 0 16px;
		width: 100vw;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.header-left {
			position: absolute;
			top: 18px;
			left: 16px;
			width: 10px;
			height: 18px;
		}

		.header-center {
			font-size: 19px;
			font-weight: 400;
			color: #805d23;
			text-align: center;
		}

		.header-right {
			width: 9px;
			height: 17px;
		}
	}

	.nav-box {
		height: 38px;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;
		background: #ecd09e;
		border-radius: 17px;
		margin: 11px 5px;

		.active {
			font-weight: 700;
			color: #d9bf97;
			background: #001a56;
			border-radius: 17px;
		}

		.nav-item {
			height: 38px;
			width: 33.3333333333%;
			display: -webkit-box;
			display: -webkit-flex;
			display: flex;
			-webkit-box-align: center;
			-webkit-align-items: center;
			align-items: center;
			-webkit-box-pack: center;
			-webkit-justify-content: center;
			justify-content: center;
			font-size: 17px;
			color: #825f26;
		}
	}

	.tj {
		padding: 0 32px;

		.ipt {
			height: 48px;
			background: #F7F9FF;
			border-radius: 10px;
			padding: 0 16px;

			uni-input {
				height: 100%;
				background: transparent;
				color: #333;
			}

			.uni-input-placeholder {
				color: #979797;
			}
		}

		.b-btn {
			width: 100%;
			margin: 33px auto 44px;
		}

		.txt {
			color: #333;
			line-height: 33px;
			font-size: 15px;

			.icon {
				margin-right: 11px;
			}
		}
	}

	.icon.dd {
		width: 143px;
		height: 198px;
		background: url(/static/img/img1.png) no-repeat 50%/100%;
		margin: 44px auto;
	}

	.icon.ts {
		width: 17px;
		height: 17px;
		background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAMAAACdt4HsAAAAAXNSR0IArs4c6QAAAQVQTFRFAAAA/wAA/1VV/0BA/yoq30BA5jMz6C5G6ipA7jMz7zBA5jNA6zM97Tc36zY86zQ77DM57jQ66TE86jQ57DU67DQ57TI76zQ87TQ76jQ76zM66zI86zQ77DI76TQ66zM86zI77DQ86jI66jQ76zI86zQ76zQ76zM67DQ66zM76zM76zM76zI86zQ76zM67DM66zI76zQ67DI67DQ86zM76zM76zM67DM87DI76jQ76zM76zM67DM86jM76zM76zI66zQ76zQ76zM76jM76zM76zM76zM76zM67DM76zM76zM76zM76jM76zM76zM76zM76zM76zM76zM76zM76zM76zM76zM7mFFDKwAAAFZ0Uk5TAAIDBAYICgsMDxAUGRwmJygsLzE1NjhARUpLTE5SU1pbXWFjZmdxcnZ9foKJioyQmJmdnqWpqqusrbCzuLm/wMHL0dPX2Nna3+Ln6ezt7u/w+Pn6/P6DVvT5AAACrElEQVRYw62XbUMSQRDHh6ASUSMhnwpLCxBMKgQqQYinIrhAHu73/T9KL+4Q8XYXjnPe3c3sf3dnZmf+I6KRWCpfavasycTqNUv5VEx8SaLQslkSu1VIrLv6ZaaNUtqZrTWWR3MWWrFy0VXrzwYL82mnVileV2qd6eLf4My4fLcxNxyW0/Hw/Hc4ni4P55rGrn79Qd81qp5GHusip1VX2T/QHn/sWNSTav0b93xj9TVCn11fn+iPeOLG5yqkWP8DgFk2ZHJSKDsD4KfXytl/dLQqTEcj5wye+wPQ3VudKHtdAB754WAMUN9eJ1O36wDjpVjs9gG60fVyfbsL0H+YDw2Akff8+7ej35cR7y1GAL8eOWDm9d/+BOBG4cnZkhuiA4Cs1+7WifqhV5MFGMyvnANoK+LvRIwLRT60AXLOx5YFcKzw1h8H4FyVkwCWUx8yAHWVuy8BuNtR6RoAGRERaQO28v1EboC7d8pYJm2gLSKSAKhqQn54cb6jUVUBEiJSAEiJbzkFKIhICxhG/ANEhkBLJGYDZdlAyoAdkxRAehOAtHP3PEBcY/Psy7+/H3UAcYC8lIBp2LCJ/VqjDE+BkjSBjm6TrwAfdNoO0JQeUNOZfFPUnoXUgJ5YQGUzgApgyQQobgZQBCZBAK6BSZArfAes4E40htEM4ITRmEhGADeRjKlsBHBT2fiYjADuYzI+ZyOA+5yNBcUEMC8oTkk79Q9wX9JMRdUEcF9UpQ2Q9AuwKOtOY2n4BagvGovT2k78ATxsbfrmqgdYaq769q4HWG7vWoLhULe3KwmGnuK8uoPWCw3FaXhJlpek7Xx6/3wdkhWY5gUnmsGpbnCyLaGr1XT/2ED31xg4knXjwPFg5LE3HHmCD12qsa/oa+x7gsFTRLaCjb5PMHz7G///Ax6AVJAjRo6uAAAAAElFTkSuQmCC) no-repeat 50%/100%;
	}

	.b-btn {
		height: 48px;
		background: #24228f;
		box-shadow: -1px 4px 7px 0px rgba(108, 95, 75, .25);
		border-radius: 10px;
		text-align: center;
		font-size: 18px;
		font-weight: 500;
		color: #fff;
		margin: 27px 0;
		display: -webkit-box;
		display: -webkit-flex;
		display: flex;
		-webkit-box-align: center;
		-webkit-align-items: center;
		align-items: center;
		-webkit-box-pack: center;
		-webkit-justify-content: center;
		justify-content: center;
	}

	// 我的交易
	.transaction {

		// padding: 0 30rpx;
		// padding: 0 30rpx;
		.share-certificate {
			h6 {
				font-size: 30rpx;
				margin: 10rpx 0;
			}
		}

		.position {
			background-image: linear-gradient(to right, #1a73e8, #ff3636);
			color: #fff;
			padding: 10rpx 30rpx;
			border-radius: 30rpx;
			font-size: 28rpx;
		}

		.up-date {
			text {
				color: #ff0a0a;
				font-weight: 600;
			}
		}

		.buy-up {
			color: red;
		}

		.time {
			color: #666;
		}

		.shadow {
			background: #aac0ff;
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 20rpx 30rpx;
			font-size: 26rpx;

			.display {
				width: 40%;

				.quantity {
					color: #ff0a0a;
				}
			}
		}

		.shadows {

			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 6rpx 30rpx;
			font-size: 26rpx;

			.shadows-dis {
				width: 40%;

				.quantity {
					margin: 10rpx 0;
					color: #ff0a0a;
				}
			}

			.display {
				width: 40%;

				.quantity {
					color: #ff0a0a;
				}
			}
		}


		// 没有更多
		.finished-text {
			color: #969799;
			font-size: 28rpx;
			margin: 30rpx auto;
			text-align: center;
			padding: 30rpx 0;
		}
	}
	.nodata {
	    padding: 110px 0;
		.txt {
		    font-size: 20px;
		    font-family: Malgun Gothic;
		    font-weight: 700;
		    color: #482608;
		    line-height: 32px;
		    text-shadow: 0px 1px 1px hsla(0,0%,100%,.65);
		    text-align: center;
		    background: #ecd09e;
		    height: 47px;
		    border-radius: 24px;
		    min-width: 289px;
		    display: -webkit-inline-box;
		    display: -webkit-inline-flex;
		    display: inline-flex;
		    -webkit-box-align: center;
		    -webkit-align-items: center;
		    align-items: center;
		    -webkit-box-pack: center;
		    -webkit-justify-content: center;
		    justify-content: center;
		}
	}
	.no-img {
	    width: 253px;
	    height: 209px;
	    background: url(/static/img/not-data.png) no-repeat 50%/100%;
	    margin: 0 auto 22px;
	}
</style>