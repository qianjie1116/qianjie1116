<!-- 关于我们 -->
<template>
	<view :style="{height:`${ $util.calcPageHeight()}px`}">
		<CustomHeader :title="about.title" @action="handleBack()"></CustomHeader>
		<view class="common_block" style="overflow-y: scroll; height: 89vh;padding-bottom: 10px;">
			<view v-html="about.content" style="font-size: 14px;white-space: break-spaces;line-height: 1.5;padding:10px;" :style="{color:$util.THEME.LABEL}"></view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				about: ''
			};
		},
		mounted() {
			this.getAbout()
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			//关于我们
			async getAbout() {
				const result = await this.$http.get(this.$http.API_URL.ABOUT_US, {})
				this.about = result.data.data
			},
		},
	}
</script>