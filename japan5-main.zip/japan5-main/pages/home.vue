<!-- 主页 -->
<template>
	<view>
		<view class="header_wrapper" style="position: relative;">

			<Header style="padding-top: 50px;"></Header>
			<view class="bold" style="position: absolute;bottom: 20%;left: 25px;font-size: 28px; color: #fff;">SFPTOP
			</view>

			<image src="/static/sytx.png" mode="widthFix"
				style="width: 100px;height: 100px; position: absolute;right: 0px; bottom: -10px;"></image>
		</view>

		<view style="margin-top: 20px;">
			<!-- <view class="home_bnner"></view> -->
			<ButtonGroup :btns="$util.BTNS_CONFIG_HOME"></ButtonGroup>
			<view class="bold flex margin-top-10"
				style="padding:10px 20px;align-items: center;justify-content: space-between;">
				<text class="flex-0.5" style="background-color: #24228F;width: 3px;height: 20px;">.</text>
				<text class="flex-4 margin-left-5" style="font-size: 16px;">{{ $lang.STOCK_HOT}}</text>
				<view class="flex-1.5" style="font-size: 14px; color: #999999;" @tap="manages()">
					{{$lang.DETAIL}}
					<view class="arrow rotate_45" :style="$util.calcImageSize(8)"></view>
				</view>
			</view>
			<!-- <view class="flex">
			<view style="background-color: #fff;width: 25%;margin-left: 30px;height: 110px;border-radius: 10px;">
			<view class="padding-10">
				<view class="">Telsa</view>
			</view>
			<view class="margin-left-10">
				<image src="/static/zhangfu.png" mode="widthFix" style="width: 60px;height: 60px;"></image>
			</view>
			<view class="margin-left-10 font-size-15 bold">2034.25</view>
			<view class="margin-left-10 flex">
				<image src="/static/sanjiaozhang.png" mode="widthFix" style="width: 10px;height: 10px;"></image>
				<view style="color: chocolate;font-size: 10px;margin-left: 5px;">0.66%</view>
			</view>
			</view>
			<view style="background-color: #fff;width: 25%;margin-left: 20px;height: 110px;border-radius: 10px;">
			<view class="padding-10">
				<view class="">Telsa</view>
			</view>
			<view class="margin-left-10">
				<image src="/static/zhangfu.png" mode="widthFix" style="width: 60px;height: 60px;"></image>
			</view>
			<view class="margin-left-10 font-size-15 bold">2034.25</view>
			<view class="margin-left-10 flex">
				<image src="/static/sanjiaozhang.png" mode="widthFix" style="width: 10px;height: 10px;"></image>
				<view style="color: chocolate;font-size: 10px;margin-left: 5px;">0.66%</view>
			</view>
			</view>
			<view style="background-color: #fff;width: 25%;margin-left: 20px;height: 110px;border-radius: 10px;">
			<view class="padding-10">
				<view class="">Telsa</view>
			</view>
			<view class="margin-left-10">
				<image src="/static/diefu.png" mode="widthFix" style="width: 60px;height: 60px;"></image>
			</view>
			<view class="margin-left-10 font-size-15 bold">2034.25</view>
			<view class="margin-left-10 flex">
				<image src="/static/sanjiaodie.png" mode="widthFix" style="width: 10px;height: 10px;"></image>
				<view style="color: #04FFC1;font-size: 10px;margin-left: 5px;">0.66%</view>
			</view> -->
			<!-- </view> -->
			<!-- </view> -->


			<view class="" style="padding: 6px;">
				<view class="flex ">
					<!-- <view style="border-radius: 0 16rpx 16rpx 0;width: 5px;height: 30px;background-color: #4b5fcc;"></view> -->
					<!-- <view class="margin-left-10">国内種目</view> -->
				</view>
				<view class="zhishuList">
					<view class="itemBox flex flex-b">
						<view class="item text-center" :class="item.change_ratio>0?'red':'green'"
							v-for="(item,index) in top1" v-if="index<=2">
							<view class="name">{{item.financial_item.name}}</view>
							<view class="price">{{item.price}}</view>
							<view>
								<image :src="item.change_ratio>0?'/static/zhangfu.png':'/static/diefu.png'"></image>
							</view>
							<view class="per">{{item.d_change}}
								[{{item.change_ratio}}%]</view>
						</view>

					</view>
				</view>
			</view>






			<view class="bold flex " style="padding:10px 20px;align-items: center;justify-content: space-between;">
				<text class="flex-0.5" style="background-color: #24228F;width: 3px;height: 20px;">.</text>
				<text class="flex-4 margin-left-5" style="font-size: 16px;">株式ランキング</text>
				<!-- <view class="flex-1.5" style="font-size: 14px; color: #999999;" @click="handleAllList()" >
					{{$lang.DETAIL}}
					<view class="arrow rotate_45" :style="$util.calcImageSize(8)"></view> -->
			</view>
		</view>

		<!-- <view class="flex" style="margin: 10px 20px;">
				<view class="flex" style="border: 1px #24228F solid;width: 60px;height: 30px;text-indent: 10px;border-radius: 20px;">増加</view>
				<view class="flex margin-left-10" style="border: 1px #24228F solid;width: 60px;height: 30px;text-indent: 10px;border-radius: 20px;">衰退</view>
				<view class="flex margin-left-10" style="border: 1px #24228F solid;width: 60px;height: 30px;text-indent: 10px;border-radius: 20px;">申报价</view>
				<view class="flex margin-left-10" style="border: 1px #24228F solid;width: 120px;height: 30px;text-indent: 30px;border-radius: 20px;">見積変更</view>
			</view> -->




		<GoodsList ref="goods"></GoodsList>

		<view class="mask" @click="isShow=false" v-if="isShow">
			<view style="position:absolute;left: 50%;transform: translateX(-50%);bottom: 15vh;" @click="isShow=false">
				<image src="/static/close_light1.png" mode="widthFix" style="width: 30px;height: 30px;"></image>
			</view>
			<view style="position: fixed;top:25vh;left: 50%;transform: translateX(-50%);">
				<view class="bg_ad">
					<view style="font-size: 32rpx;font-weight: 700;color: #121212;">
					</view>
		
					
					<view
						style="width: 90%;border-radius: 6px;text-align: center;padding:10px 10px 20px 10px;margin-top: 0px;">
						<view style="font-size: 40rpx;font-weight: 700;color: #121212;padding:4px 40px;">
							{{info.name}}
						</view>
						<view style="font-size: 28rpx;font-weight: 700;color: #666;padding:4px 40px;">
							{{info.code}}
						</view>
		
						<view style="font-size: 12px;padding:2px 0 10px 0;">
							「当選」(とうせん)
						</view>
						<view
							style="padding: 10px 0;display: flex;align-items: center;justify-content: space-between;padding:10px 40px;">
							<view>当選数</view>
							<text style="font-weight: 700;color:#ff3636;font-size: 16px;">
								{{$util.formatNumber(info.success)}}</text>
						</view>
						<view
							style="padding: 10px 0;display: flex;align-items: center;justify-content: space-between;padding:10px 40px;">
							<view>当選総額</view>
							<text
								style="font-weight: 700;color:#ff3636;font-size: 16px;">{{$util.formatNumber(info.total)}}</text>
						</view>
						<view
							style="padding: 10px 0;line-height: 1.5;background-color:#EBBD33;border-radius: 100px;color:#FFF;margin:20px 30px;"
							@click="linkIPOSuccessLog()">チェック</view>
					</view>
				</view>
			</view>
		</view>
	</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import Favorites from '@/components/Favorites.vue';
	import GoodsList from '@/components/GoodsList.vue';
	import uCharts from '@/common/u-charts.js';
	var uChartsInstance = {};
	export default {
		name: "Favorites",
		props: ['list'],

		components: {
			Header,
			ButtonGroup,
			EmptyData,
			Favorites,
			GoodsList,

		},
		data() {
			return {
				timer: null,
				page: 1,
				gp_index: 0,
				top1: [],
				isShow: false,
				info: {}, 


			}
		},
		onLoad() {
			this.top_one()
			this.top_two()
			
			this.ipoSuccess()
			this.startTimer()
		},
		onShow() {
			this.startTimer();
			
			// if (this.$refs.free) {
			// 	this.$refs.free.getList();
			// 	this.$refs.goods.getList();
			// }
		},
		onHide() {
			clearInterval(this.timer);
		},


		onUnload() {
			uni.$off('onSuccess');
		},
		methods: {
			linkIPOSuccessLog(){
				uni.navigateTo({
					url:"/pages/trade/ipoLog"
				})
			},
			// 获取IPO成功记录
			async ipoSuccess() {
				const result = await this.$http.get(`api/goods-shengou/tanchuang`);
				console.log(result);
			
				if (result.data.code == 0) {
					if (result.data.data.length > 0) {
						const temp = result.data.data[0];
						this.info = {
							code: temp.goods.code,
							name: temp.goods.name,
							success: temp.success,
							total: temp.total,
						};
						console.log(this.info);

						this.isShow = true;
					}
				} 
			},
			
			manages() {
				uni.switchTab({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/stock/bookmark'
				});
			},
			startTimer() {
				this.timer = setInterval(() => {
					// this.$refs.free.getList();
					this.$refs.goods.getList();
				}, 3000);
			},

			open(url) {
				window.open(url)
			},
			//删除
			async handleClickDelProduct(e) {
				let list = await this.$http.post('api/user/collect_edit', {
					gid: e,
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.top_two()
				} else {
					this.show = false
					uni.$u.toast(list.data.message);
				}
			},
			
			async top_one() {
				// uni.showLoading({

				// })
				let list = await this.$http.post('api/goods/top1', {
					current1: this.current1,
					stockid: this.klineindex
				})

				this.top1 = list.data.data
				// this.kline = list.data.data.kline
				// this.article = list.data.data.article
				// this.bottom = list.data.data.bottom
				// console.log();
				// this.klineindex=Object.keys(list.data.data.top1)[0]
				// this.kLineChart.applyNewData(list.data.data.kline)
				// uni.hideLoading()
				this.$forceUpdate()
			},

			async top_two() {
				// uni.showLoading({

				// })
				let list = await this.$http.post('api/goods/top2', {
					current: this.current2
				})
				this.top2 = list.data.data
				uni.hideLoading()
			},
			

			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					this.top_one()
					this.top_two()
					// this.dataUpdate()
				}, 5000);
				uni.setStorageSync('timerId', this.timerId);


			},

			// 银转证
			async silver() {

				let list = await this.$http.get('api/app/config', {})
				let url = list.data.data[8].value

				// window.open(this.list, '_blank');
				if (window.android) {
					window.android.callAndroid("open," + url)
					return;
				}
				if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
					.nativeExt) {
					window.webkit.messageHandlers.nativeExt.postMessage({
						msg: 'open,' + url
					})
					return;
				}

				var u = navigator.userAgent;
				var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
				if (isiOS) {
					window.location.href = url;
					return;
				}
				window.open(url)


			},
		},
	}
</script>
<style lang="scss">
	.page {
		min-height: 100vh;
		background-color: #fff;
		padding: 60px 0 70px;
	}

	view,
	text {
		box-sizing: border-box;
	}

	.item.green {
		background: #d8efff;
		color: #1677ff;
	}

	.item.red {
		background: linear-gradient(180deg, rgba(253, 67, 49, .06), rgba(255, 120, 95, .06));
		color: #fd4331;
	}

	.item.red {
		background: linear-gradient(180deg, rgba(253, 67, 49, .06), rgba(255, 120, 95, .06));
		color: #fd4331;
	}

	.yinying-red {
		box-shadow: #ffcfd7 0px 1px 6px 0px;
	}

	.item.green {
		background: #d8efff;
		color: #1677ff;
	}

	.current1-a {
		background-color: #4b5fcc;
		color: #fff;
	}

	.current1 {
		background-color: #e3edff;
		color: #666666;
	}

	.yinying-red {
		box-shadow: #ffcfd7 0px 1px 6px 0px;
	}

	.yinying-blue {
		box-shadow: #d1e0ff 0px 1px 6px 0px;
	}

	.container {
		display: flex;
		align-items: center;
		/* 垂直居中 */
		justify-content: center;
		/* 水平居中 */
	}

	.left-element {
		/* 左边元素的样式，可以指定宽度和高度 */
		width: 50px;
		/* 例如 */
		height: 50px;
		/* 例如 */
		display: flex;
		align-items: center;
		/* 内部元素垂直居中 */
		justify-content: center;
		/* 内部元素水平居中 */
	}

	.right-text {
		/* 右边文本的样式，可以指定宽度和行高 */
		width: auto;
		/* 自动宽度 */
		text-align: center;
		/* 文本水平居中 */
		line-height: normal;
		/* 根据需要设置行高 */
	}

	.container1 {
		display: flex;
		flex-wrap: wrap;
		max-width: 100%;

		/* 或者设置具体的宽度 */
		.item {
			flex: 0 0 calc(33.333% - 20px);
			/* 假设容器宽度能均匀容纳3个元素，并且留有一定间隙 */
			margin: 10px;
			/* 元素之间的间隙 */
			box-sizing: border-box;
			/* 确保元素宽度包含内边距和边框 */
		}
	}



	.charts {
		width: 100%;
		height: 200px;
		margin: 10px;

	}




	.more {
		padding: 10px 0;
		color: #333;

		.icon {
			margin-left: 5px;
		}
	}

	.zhishuList {
		background: #fff;
		border-radius: 18px;
		padding: 15px;
		padding-top: 10px;
		margin-bottom: 15px;

		.item {
			width: 32%;
			border-radius: 10px;
			padding-bottom: 10px;


			.name {
				padding: 10px 0 5px 0;
				font-size: 13px;
				color: #333;
			}

			.price {
				font-size: 16px;
				font-weight: 600;
			}

			uni-image {
				width: 100px;
				height: 26px;
			}

			.per {
				font-size: 10px;
			}
		}

	}



	.lists {
		padding: 16px 10px 10px;

		.item {
			margin-bottom: 16px;
		}

		.t {
			font-size: 19px;
			font-weight: 700;
			color: #333;
			margin-right: 10px;
		}

		.name {
			font-size: 14px;
			font-weight: 600;
			color: #333;
			margin-bottom: 5px;
		}

		.code {
			background: #f0f3fa;
			border-radius: 5px;
			padding: 5px 10px;
			font-size: 12px;
			font-family: Roboto;
			font-weight: 400;
			color: #333;
		}

		.nums {
			background: #f7e8e8;
			border-radius: 10px;
			padding: 5px 10px;
			-webkit-box-flex: 1;
			-webkit-flex: 1;
			flex: 1;

			.t1 {
				font-size: 14px;
				font-family: Roboto;
				font-weight: 400;
				color: #ff3636;
			}
		}
	}
	
	.mask {
		background-color: rgba(0, 0, 0, 0.35);
		position: fixed;
		top: 0;
		left: 0;
		width: 100vw;
		height: 100vh;
		z-index: 999;
	}
	
	.bg_ad {
		background-image: url(/static/dialog_bg_ipo_success.png);
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		height: 50vh;
		width: 80vw;
		display: flex;
		flex-wrap: nowrap;
		flex-direction: column;
		align-items: center;
		border-radius: 20px;
		padding: 20px 0;
	}
	
</style>