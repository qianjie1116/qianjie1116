<!-- 大宗交易 -->
<template>
	<view>
		<view style="position: relative;">
			<!-- <CustomHeader :title="$lang.TRADE_IPO" @action="handleBack()"></CustomHeader> -->
			<image src="/static/ipo.png" mode="widthFix" style="width: 100%;"></image>
			<view class="flex" style="position: absolute;bottom: 75%;color: #FFF;width: 100%;">
				<image src="/static/baisejiantou.png" mode="widthFix"
					style="width: 28px;height: 28px;margin-left: 15px;" @click="handleBack()"></image>
				<view style="font-size: 18px;width: 100%;justify-content: center;display: flex;">OTC</view>
				<view style="width: 80px;" @click="manages()">履歴</view>
			</view>
			<view>
				<view class="bold" style="position: absolute;bottom: 10%;margin: 20px;color: #fff;font-size: 20px;">
					ブロック取引による購入
				</view>
			</view>
			<view style="width: 105%;justify-content: flex-end; display: flex; ">
				<image src="/static/otc2.png" mode="widthFix"
					style="position: absolute;bottom: -15%;width: 30%;margin: 20px;"></image>
			</view>
		</view>



		<view style="width: 90%;margin: 20px;border-radius: 10px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view class=""
					style="align-items: center;background-color: #FFF;border-radius: 10px;width: 100%;margin-top: 10px;height: 80px;">
					<view class="flex margin-left-10">
						<view :style="{color:$util.THEME.TEXT}" style="flex:40%;margin-top: 5px;">{{item.goods.name}}
						</view>
						<view :style="{color:$util.THEME.PRIMARY}" style="flex:10%;font-size: 18px;margin-top: 20px;">
							{{$util.formatNumber(item.price)}}
						</view>
						<view class="common_btn "
							style="flex:20%;transform: scale(0.75);margin-top: 20px;background-color: #24228f;color: #FFF;height: 40px;"
							@click="handleDetail(item.id)">
							{{$lang.STOCK_DETAIL}}
						</view>
					</view>
					<view style="margin-top: -5px;margin-left: 10px;">
						{{item.goods.number_code}}
					</view>

				</view>
			</block>
		</view>

		<template v-if="isShow">
			<view class="common_mask">
				<view class=" common_popup"
					style="min-height:90vh;margin:auto;margin-top: 0px;background-color: #FFF;width: 100%;border-radius: 10px;">

					<view class="padding-20" style="width: 100%;justify-content: center;display: flex;">購読申し込み詳細</view>

					<view class="flex margin-left-15">
						<text class="flex-0.5" style="background-color: #24228F;width: 3px;height: 15px;"></text>
						<view class="bold " style="margin-left: 10px;">購入数量</view>
					</view>

					<view style="margin: 20px;background-color: #F7F9FF;height: 40px;border-radius: 10px;">
						<!-- <image mode="aspectFit" src='/static/amount.png' :style="$util.calcImageSize(20)"> </image> -->
						<!-- <input v-model="amount" :placeholder="$lang.TIP_BUY_COUNT" type="number" style="font-size: 14px;padding: 10px;"></input> -->
						<input v-model="quantity" style="font-size: 14px;padding: 10px;" type="number"
							:placeholder="$lang.TIP_BUY_COUNT" />
					</view>





					<view v-if="columns.length>0">
						<view class="flex margin-left-15">
							<text class="flex-0.5" style="background-color: #24228F;width: 3px;height: 15px;"></text>
							<view class="bold" style="margin-left: 10px;">レバレッジを選択する</view>
						</view>
						<!-- 杠杆选择输入框 -->
						<view class="common_input_wrapper"
							style="padding-left: 40rpx;background-color: #f7f9ff;border-radius: 8px;padding: 10px;">
							<view style="width: 60px;">レバー</view>
							<view @click="show = true" style="justify-content: flex-end; display: flex;width: 75%;">
								{{ganggan}}</view>
							<!-- 杠杆选择器 -->
							<u-picker :show="show" :columns="columns" closeOnClickOverlay @confirm="handlConfirm"
								@close="show = false" @cancel="show = false" cancelText="Cancel"
								confirmText="Confirm"></u-picker>
						</view>
					</view>

					<!-- <view class="common_input_wrapper" >
						<image mode="aspectFit" src='/static/leverage.png' :style="$util.calcImageSize(20)"> </image>
						<block v-for="(item,index) in leverList" :key="index">
							<text @click="handleChgangeLever(index)" style="display: inline-block;padding:0 16px;"
								:style="{borderBottom:`2px solid ${index==current? $util.THEME.PRIMARY:'transparent'}`,color:index==current?$util.THEME.PRIMARY:$util.THEME.TEXT}">{{item.name}}</text>
						</block>
					</view> -->

					<!-- <view style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;">
						<view :style="{color:$util.THEME.LABEL}">{{$lang.BUY_AMOUNT}}</view>
						<view :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(buyAmount)}}</view>
					</view> -->

					<view class="flex margin-left-15">
						<text class="flex-0.5" style="background-color: #24228F;width: 3px;height: 15px;"></text>
						<view class="bold " style="margin-left: 10px;">支払いパスワード</view>
					</view>

					<view style="margin: 20px;background-color: #F7F9FF;height: 40px;border-radius: 10px;">
						<!-- <image mode="aspectFit" src='/static/password.png' :style="$util.calcImageSize(20)"> -->
						<!-- </image> -->
						<input v-model="password" :placeholder="$lang.TIP_BUY_PWD" type="password"
							style="font-size: 14px;padding: 10px;"></input>
					</view>
					<view
						style="background-color: #f8f8f8;width: 90%;margin-left: 20px;border-radius: 10px;height: 80px;">
						<view
							style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;padding-top: 10px;">
							<text :style="{color:$util.THEME.LABEL}">{{$lang.BUY_AMOUNT}}</text>
							<text>{{$util.formatNumber(detail.price)}}</text>
						</view>
						<view style="border: #EAEAEA 1px solid;width: 90%;margin: 10px;margin-left: 20px;"></view>

						<view
							style="display: flex;flex-wrap: nowrap;align-items: center;justify-content: space-around;">
							<text :style="{color:$util.THEME.LABEL}">利用可能な資金 </text>
							<text>{{availBal}}</text>
						</view>
					</view>


					<view style="display: flex;justify-content: space-evenly;margin:20px 0;padding-top: 30px;">
						<view class="common_btn " style="width: 30%;background-color: #24228f;color: #FFF;"
							@click="handleConfirm"> {{$lang.BUY}} </view>
						<view class="common_btn btn_secondary" style="width: 30%;" @click="handleCancel">
							{{$lang.CANCEL}}
						</view>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				list: [],
				detail: {},
				isShow: false, // 显示弹层
				amount: "", // 金额
				quantity: '',
				errorMessage: '',
				quantity1: "",
				show: false,
				columns: [],
				ganggan: '1',
				password: '',
				leverList: [], // 杠杆值数组
				current: 0,
				availBal: 0,
			}
		},
		onShow() {

			this.getList()
			this.available()
		},
		computed: {
			curLever() {
				return this.leverList[this.current];
			},
			buyAmount() {
				return !this.curLever ? 0 : this.detail.price * this.quantity / Number(this.curLever.index);
			},

		},

		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},

			open() {
				// console.log('open');
			},
			close() {
				this.show = false
				// console.log('close');
			},
			handleChgangeLever(val) {
				this.current = val;
			},
			manages() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/trade/largeLog'
				});
			},
			sl_input(e) {
				const inputValue = e.target.value;
				// 匹配整百的数字，例如 100, 200, 300 等  
				const regex = /^(\d{1,})(00)?$/;
				const hundredRegex = new RegExp(`^${Math.floor(inputValue / 100)}00$`);

				if (hundredRegex.test(inputValue) || inputValue === "") {
					this.quantity = inputValue; // 如果输入的是整百数字或者空字符串，则保留  
					this.errorMessage = ""; // 清除错误信息  
				} else {
					let quantity = this.quantity.slice(0, -1 * (this.quantity.length - 1)); // 移除最后一个字符（通常是非法字符）
					if (this.quantity < 100) {
						// console.log(1111)
						this.$nextTick(() => {
							this.quantity = this.quantity * 100;
						})
						return
					} else {
						// console.log(2222,this.quantity.length,this.quantity,quantity)
						this.$nextTick(() => {
							this.quantity = quantity * Math.pow(10, this.quantity.length - 1);
						})
						return
					}
					// this.errorMessage = '请输入整百数字';
				}
			},

			async handleDetail(id) {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				this.isShow = true;
				const result = await this.$http.get(this.$http.API_URL.TRADE_LARGE_DETAIL, {
					id
				});
				console.log('result:', result);
				this.detail = result.data.data;
				uni.hideLoading();
			},

			about() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/trade/largeLog'
				});
			},
			handleCancel() {
				this.isShow = false;
				this.quantity = "";
				this.password = "";
				this.current = 0;
			},
			handleConfirm() {
				if (this.checkForm()) {
					this.buy();
				}
			},
			checkForm() {
				if (this.quantity == '') {
					uni.$u.toast(this.$lang.TIP_BUY_COUNT);
					return false;
				}
				if (this.password == '') {
					uni.$u.toast(this.$lang.TIP_BUY_PWD);
					return false;
				}
				return true;
			},

			handlConfirm(e) {
				console.log('confirm', e);
				this.show = false;
				this.ganggan = e.value[0];
			},
			
			async buy() {
				const result = await this.$http.post(this.$http.API_URL.TRADE_LARGE_ORDER, {
					id: this.detail.id,
					num: this.quantity,
					pay_pass: this.password,
					ganggan: this.ganggan,
				});
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					uni.navigateTo({
						url: this.$util.PAGE_URL.TRADE_LARGE_LOG,
					});
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				});
				const result = await this.$http.get(this.$http.API_URL.TRADE_LARGE_LIST, {});
				this.list = result.data.data;
				uni.hideLoading();
			},
			async available() {
				uni.showLoading({
					title: this.$lang.LOADING,
				});
				const result = await this.$http.get(this.$http.API_URL.USER_FASTINFO, {});
				this.availBal = this.$util.formatNumber(result.data.data.money);


				if (result.data.data.ganggan.length>0) {
					this.ganggan=result.data.data.ganggan[0]
					this.columns = [result.data.data.ganggan];
				}
				console.log(222,this.columns.length,this.columns)

				uni.hideLoading();
			},
		},
	}
</script>