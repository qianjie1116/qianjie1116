<!-- 新股申购 -->
<template>
	<view>
		<view style="position: relative;">
			<!-- <CustomHeader :title="$lang.TRADE_IPO" @action="handleBack()"></CustomHeader> -->
			<image src="/static/ipo.png" mode="widthFix" style="width: 100%;"></image>
			<view class="flex" style="position: absolute;bottom: 75%;color: #FFF;width: 100%;">
				<image src="/static/baisejiantou.png" mode="widthFix"
					style="width: 25px;height: 25px;margin-left: 15px;" @click="home()"></image>
				<view style="font-size: 18px;width: 100%;justify-content: center;display: flex;">IPO</view>
				<!-- <view style="width: 80px;margin-right: 10px;" @click="handleChangeTab(0)">申请记录</view> -->
			</view>
			<view>
				<view class="bold" style="position: absolute;bottom: 10%;margin: 30px;color: #fff;font-size: 20px;">IPO株を購入する</view>
			</view>
			<view style="width: 105%;justify-content: flex-end; display: flex; ">
				<image src="/static/ipo1.png" mode="widthFix"
					style="position: absolute;bottom: -15%;width: 30%;margin: 20px;"></image>
			</view>
		</view>

		<view style="display: flex;align-items: center;justify-content:space-around;margin-top: 20px;">
			<view @click="handleChangeTab(0)" class="common_btn btn_secondary" style="padding:2px 4px;">
				{{$util.BTNS_IPO[1]}}
			</view>
			<view @click="handleChangeTab(1)" class="common_btn btn_secondary" style="padding:2px 4px;">
				{{$util.BTNS_IPO[2]}}
			</view>
		</view>

		<view>
			<EmptyData v-if="list.length<=0"></EmptyData>
			<template v-if="current == 0">
				<block v-for="(item,index) in list" :key="index">
					<view class="display bg-white radius20 margin-10 padding-20">
						<view class="flex-2">
							<view class="bold">{{item.goods.name}}</view>
							<view class="hui1 margin-top-10">{{item.goods.code}}</view>
						</view>
						<view class="font-size-18 flex-1 margin-right-15">
							{{$util.formatNumber(item.price)}}
						</view>
						<view class="color-white  radius10 flex-1 text-center" style="background-color: #24228f;padding: 8px 8px;" @click="buy(item.id)">
							購入
						</view>
					</view>
					
				</block>
			</template>

			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view style="border-bottom: 2rpx solid #e0e0e0;padding-bottom:20rpx;">
						<view class="display approve">
							
							<view class="subscription-times">購読時間<text>{{item.shengou_date}}</text> </view>
						</view>

						<view class="display" style="margin-top: 10rpx;">
							<view class="display price">購読
								価格<text>{{$util.formatNumber(item.price)}}</text>
							</view>
							<view class="display price">
								株価収益率<text>{{$util.formatNumber(item.shiying)}}</text>
							</view>
						</view>
						<view class="display price">
							循環<text>{{$util.formatNumber(item.fa_amount)}}</text>
						</view>
					</view>
				</block>
			</template>
		</view>
		<view>
				<u-modal :show="show" title="" @cancel="cancel" @confirm="position(buyid)" :showCancelButton='true' content='申請を確認しますか？' cancelText="キャンセル" confirmText="確認する">
				</u-modal>
			</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				current: 0,
				list: [],
				confirmation:"",
				show: false,
				buyid:""
			};
		},
		onLoad(item) {},
		onShow() {
			this.getList();
		},

		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			buy(id){
				this.show=true;
				this.buyid=id
			},
			async position(id) {
				this.purchase(id)
				this.show = false;
				
				// let list = await this.$http.post('api/goods-shengou/password', {
				// 	password:this.password,
				// 	id: id,
				// 	// price: this.price
				// })
				
				// if (list.data) {
				// 	this.show_mima = false;
				// 	this.show = true;
					
				// } else {
				// 	this.show_mima = false;
				// 	uni.$u.toast(list.data.message);
				// }
				// 
				// this.confirmation = id
				
				
				// console.log(this.confirmation, '11111111111');
			},
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm() {
				this.purchase(confirmation)
				this.show = false;
			},
			// 点击申购
			async purchase(confirmation) {
				let list = await this.$http.post('api/goods-shengou/doOrder', {
					num: this.value,
					id: confirmation,
					// price: this.price
				})
				if (list.data.code == 0) {
					uni.showLoading({
						title: "購読が進行中です。 しばらくお待ちください....",
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/trade/ipoLog'
						});
						uni.hideLoading();
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			handleChangeTab(val) {
				if (val == 0) {
					this.applyPurchase();
				} else if (val == 1) {
					this.luckyNumber();
				}
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},

			to_skip(id) {
				uni.navigateTo({
					url: `/pages/index/components/newShares/nullElement/nullElement?id=${id}`
				});
				// console.log(gid, fa_price, '携带');
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.post(this.$http.API_URL.TRADE_IPO_LIST, {
					type: this.current + 1, // 传参 1或2
				})
				this.list = result.data.data;
				uni.hideLoading();
			},

			//구독기록 订阅记录
			applyPurchase() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.TRADE_IPO_LOG
				});
			},
			//우승기록 获胜记录
			luckyNumber() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/luckyNumber/luckyNumber'
				});
			},
		}
	}
</script>