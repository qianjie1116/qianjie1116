<template>
	<view>
		<view class="flex" style="background-color: #01024d;height: 90px;">
			<image src="/static/baisejiantou.png" mode="widthFix" style="width: 25px;height: 25px;margin-left: 15px;"
				@click="handleBack()"></image>
			<view class="flex justify-center" style="color: #fff;font-size: 16px;width: 100%;">購読記録</view>
		</view>

		<view style="background-color: #f3f4f8;width: 100%;height: 30px;border-radius: 10px;margin-top: -20px;"></view>
		<view>
			<view v-for="(item,index) in list" :key="index">
				<view
					style="background-color: #fff;width: 90%;height: 200px; margin-left: 20px;border-radius: 10px;margin-top: 10px;">
					<view >
						<view class="padding-10 ">
							<view class="did-not" style="font-size: 18px;">
								{{item.goods.name}}
								<text>購入完了</text>
							</view>

						</view>
						<view class="margin-left-10 ">
							<view style="color: #8F8F8F;">購入価格 </view>
							<text style="font-size: 18px;color: #ea3544;">{{item.price}}</text>
						</view>
					</view>
					<view class="margin-left-10 margin-top-5">
						<view class="flex">
							<view style="flex: 85%;color: #8F8F8F;">枚数</view>
							<view style="flex: 10%;">{{item.num}}</view>
						</view>
						<view class="flex margin-top-5">
							<view style="flex: 60%;color: #8F8F8F;">買収金額</view>
							<view style="flex: 18%;">{{item.amount}}</view>
						</view>
					</view>
					<view>
						<view class="flex margin-left-10 margin-top-5">
							<view style="flex: 90%;color: #8F8F8F;">レバレッジ</view>
							<view style="flex: 10%;">X{{item.double}}</view>
						</view>
					</view>

					<view class="flex margin-left-10 margin-top-5">
						<view style="flex: 50%;color: #8F8F8F;">購入時間</view>
						<view style="flex: 45%;">{{item.created_at}}</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				list: [],
			};
		},
		methods: {
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			async shengou(e) {
				let list = await this.$http.post('api/goods-bigbill/user-order-log', {
					// language: this.$i18n.locale
				})
				this.list = list.data.data
				// console.log(list.data.data)
			},
		},
		onLoad(option) {
			this.shengou()
		}
	}
</script>

<style lang="scss">
	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	//깊은북쪽상하이
	.area {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	//깊은
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #f85252;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #f85252;
		font-size: 24rpx;
		vertical-align: middle;
	}

	//북쪽
	.north {
		width: 30rpx;
		height: 30rpx;
		background: #ea6248;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.north-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #ea6248;
		background: rgba(234, 98, 72, .1);
	}

	//상하이
	.shanghai {
		width: 30rpx;
		height: 30rpx;
		background: #aa3bde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.shanghai-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #aa3bde;
		background: rgba(170, 59, 222, .1);
	}

	//公共css 结束

	.college-bg {
		padding: 20rpx;
		height: 80rpx;
		background-color: #014b8d;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.did-not {
		margin-bottom: 10rpx;

		text {
			color: #ea3544;
			font-size: 28rpx;
			margin-left: 10rpx;
		}
	}

	.quantity {
		font-size: 24rpx;

		.display {
			width: 48%;
			margin: 10rpx 0;
		}

		.red-mark {
			color: #f85252;
		}
	}
</style>