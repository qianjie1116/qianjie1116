<!-- 申购 记录 -->
<template>
	<view>
		<view class="flex" style="background-color: #01024d;height: 90px;">
			<image src="/static/baisejiantou.png" mode="widthFix" style="width: 25px;height: 25px;margin-left: 15px;"
				@click="handleBack()"></image>
			<view class="flex justify-center" style="color: #fff;font-size: 16px;width: 100%;">購読記録</view>
		</view>

		<view style="background-color: #f3f4f8;width: 100%;height: 30px;border-radius: 10px;margin-top: -20px;"></view>
		<!-- <view class="flex bold" style="width: 100%;margin-left: 50px;"> -->
		<!-- <view id="app">
			<view class="text-container">
			<view class="text"  :class="{ 'underlined': selectedText === 'text1' }"   @click="setSelectedText('text1')" style="flex: 20%;font-size: 18px;">购买记录</view> -->


		<!-- <view class="text" :class="{ 'underlined': selectedText === 'text2' }" @click="setSelectedText('text2')"   style="flex: 20%;font-size: 18px;">历史记录</view>
			<div class="underline" :style="{ left: underlinePosition + 'px' }"></div>  
			</view>
		</view> -->
		<!-- </view> -->



		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view style="margin: 4px 10px;background-color: #FFF;padding: 20px;border-radius: 10px;">
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
					<view style="font-size: 18px;">{{item.goods.name}}</view>
					<!-- 		<text v-if="item.status==0">未中签</text>
								<text v-if="item.status==1">申购中</text>
								<text v-if="item.status==2">申购中签</text>
								<text v-if="item.status==3">已구독하다金额</text>
								<text v-if="item.status==4">中签弃奖</text>
								<text v-if="item.status==5">已上市</text> -->
					<view style="font-size: 14px;color:#ea3544;">{{item.message}}</view>
				</view>
				<view style="align-items: center;padding-bottom: 6px;">
					<view style="" :style="{color:$util.THEME.TIP}">申請金額</view>
					<view>
						<view :style="{color:$util.THEME.PRIMARY}" style="font-size: 18px;margin-top: 5px;">
							{{$util.formatNumber(item.price)}}
						</view>
					</view>


					<view class="flex margin-top-15" v-if="item.status>1&&item.success>0">
						<view style="" :style="{color:$util.THEME.TIP}" >当選数量</view>
						<view style="flex:35%;text-align: right;">
							{{$util.formatNumber(item.success)}}
						</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;" v-if="item.status>1&&item.success>0">
					<view :style="{color:$util.THEME.TIP}">当選総額</view>
					<view style="font-size: 16px;">{{$util.formatNumber(item.success*item.price)}}</view>
				</view>
				
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;" v-if="item.status>1&&item.success>0">
					<view :style="{color:$util.THEME.TIP}">購読金額</view>
					<view style="font-size: 16px;">{{$util.formatNumber(item.freeze)}}</view>
				</view>
				
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;" v-if="item.status>1&&item.success>0">
					<view :style="{color:$util.THEME.TIP}">残りの出資金額</view>
					<view style="font-size: 16px;">{{$util.formatNumber(item.success*item.price-item.freeze)}}</view>
				</view>
				
				
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
					<view style="color: #c1afc1;">購入時間</view>
					<view>{{item.created_at}}</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;">
					<view style="color: #c1afc1;">取引コード</view>
					<view>{{item.order_sn}}</view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';

	export default {
		components: {
			CustomHeader,
			EmptyData,

		},
		data() {
			return {
				list: [],
				selectedText: 'text1', // 默认选中的文字  
				text1Position: 0, // 文字1的位置（可以根据实际情况动态计算）  
				text2Position: 100, // 文字2的位置（可以根据实际情况动态计算）

			};
		},
		onLoad(option) {
			this.shengou();
		},
		computed: {
			underlinePosition() {
				return this.selectedText === 'text1' ? this.text1Position : this.text2Position;
			},
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			setSelectedText(text) {
				this.selectedText = text;
			},


			// 新股申购记录
			async shengou(e) {
				let list = await this.$http.post('api/goods-shengou/user-apply-log', {
					// status: null,
					// language: this.$i18n.locale
				})
				this.list = list.data.data
				// console.log(list.data.data)
			},
		},
	}
</script>