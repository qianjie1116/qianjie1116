<!-- 登入  注册 -->
<template>
	<view>

		<view style="background-image: url('/static/beijingtu.png');height: 300px;background-size: cover;
	background-repeat: no-repeat;
	background-position: center center;">
		</view>
		<view style="margin-top: -400px;">
			<view style="width: 100%;justify-content: center;display: flex;">
				<image src="../../static/logo2.png" mode="widthFix"
					style="width: 100px;height: 100px; margin-top: 130px;"></image>
			</view>
			<view>
				<view class="margin-top-20 font-size-19 bold color-white text-center">ログイン</view>
			</view>

			<view style="background-color: #fff;margin-top:35px;width: 92%;margin-left: 15px;border-radius: 10px;">
				<view class="flex">
					<view style="background-color: #24228F;width: 3px;margin-left: 20px;">.</view>
					<view class="font-size-17 bold" style="margin: 15px 10px;">アカウント</view>
				</view>

				<view class="common_input_wrapper"
					style="background-color:#F7F9FF ;width: 80%;height: 30px;border-radius: 10px;margin-top: 1px;">
					<!-- <image mode="aspectFit" src="/static/user.png" :style="$util.calcImageSize(20)"> -->
					</image>
					<input v-model="user" type="number" :placeholder="$lang.USER_NAME" maxlength="11"
						style="font-size: 14px; width: 82%;"></input>
				</view>
				<view class="flex">
					<view style="background-color: #24228F;width: 3px;margin-left: 20px;">.</view>
					<view class="font-size-17 bold" style="margin: 0px 10px;">ログインパスワード</view>
				</view>

				<view class="common_input_wrapper"
					style="background-color: #F7F9FF;width: 80%;height: 30px;border-radius: 10px;">
					<!-- <image mode="aspectFit" src="/static/password.png" :style="$util.calcImageSize(20)"> -->
					</image>
					<input v-model="password" maxlength="6"  type="password" :placeholder="$lang.PASSWORD"
						style="font-size: 14px;width: 82%;"></input>
				</view>

				<view v-if="!isSignIn" class="flex ">
					<view style="background-color: #24228F;width: 3px;margin-left: 20px;">.</view>
					<view class="font-size-17 bold" style="margin: 0px 10px;">パスワード(確認用)</view>
				</view>
				<view v-if="!isSignIn" class="common_input_wrapper"
					style="background-color: #F7F9FF;width: 80%;height: 30px;border-radius: 10px;">
					<!-- <image mode="aspectFit" src="/static/password.png" :style="$util.calcImageSize(20)"> -->
					<!-- </image> -->
					<input v-model="password2" maxlength="6"  type="password" :placeholder="$lang.PASSWORD_CONFIRM"></input>
				</view>
				
				<view v-if="!isSignIn" class="flex ">
					<view style="background-color: #24228F;width: 3px;margin-left: 20px;">.</view>
					<view class="font-size-17 bold" style="margin: 0px 10px;">メール</view>
				</view>
				<view v-if="!isSignIn" class="common_input_wrapper"
					style="background-color: #F7F9FF;width: 80%;height: 30px;border-radius: 10px;">
					<!-- <image mode="aspectFit" src="/static/password.png" :style="$util.calcImageSize(20)"> -->
					<!-- </image> -->
					<input v-model="email"  type="text" style="width: 90%;"  :placeholder="$lang.USER_YOUXIANG"></input>
				</view>
				
				
				
				<view v-if="!isSignIn" class="flex ">
					<view style="background-color: #24228F;width: 3px;margin-left: 20px;">.</view>
					<view class="font-size-17 bold" style="margin: 0px 10px;">招待コードを入力してください</view>
				</view>
				<view v-if="!isSignIn" class="common_input_wrapper"
					style="background-color: #F7F9FF;width: 80%;height: 30px;border-radius: 10px;">
					<!-- <image mode="aspectFit" src="/static/code.png" :style="$util.calcImageSize(20)"> -->
					</image>
					<input v-model="code" style="width: 90%;" type="text" :placeholder="$lang.INVITATION_CODE"></input>
				</view>
				
				

				<view style="width: 80%;position: relative;height: 24px;line-height: 24px;margin-left: 20px;">
					<u-checkbox-group v-if="isSignIn" :checked="checked">
						<u-checkbox :activeColor="$util.THEME.PRIMARY" :label="$lang.TIP_REMEMBER_PWD"
							:labelColor="$util.THEME.TEXT" ></u-checkbox>
					</u-checkbox-group>

					<!-- <view style="display: flex;align-items: center;position: absolute;right: 0;top: 0;" @click="handleChange()">
				<text style="font-size: 14px;margin-right: 4px;"
					:style="{color:$util.THEME.TEXT}">{{isSignIn?$lang.SIGN_UP:$lang.SIGN_IN}}</text>
				<view class="arrow rotate_45" :style="$util.calcImageSize(10)"></view>
			</view> -->

				</view>
				<view v-if="isSignIn" class="common_btn btn_primary"
					style="margin: 20px;background-color: #24228F;color: #fff;"
					@click="handleConfirm()">
					{{isSignIn?$lang.SIGN_IN:$lang.SIGN_UP}}
				</view>
				<view v-if="!isSignIn" class="common_btn btn_primary"
					style="margin: 20px;background-color: #24228F;color: #fff;" @click="handleConfirm()">
					{{isSignIn?$lang.SIGN_IN:$lang.SIGN_UP}}
				</view>
				<view
					style="margin: 20px;background-color: #fff;color: #fff;border: #24228F 1px solid;border-radius: 5px;"
					@click="handleChange()">
					<text style="font-size: 16px;justify-content: center;display: flex;margin-top: 5px;"
						:style="{color:$util.THEME.TEXT}">{{isSignIn?$lang.SIGN_UP:$lang.SIGN_IN}}</text>
					<!-- <view class="arrow rotate_45" :style="$util.calcImageSize(10)"></view> -->
				</view>
				<view>
					<button style="width: 90%;margin-top: 200px;"></button>
				</view>


			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				user: "",
				password: '',
				password2: '',
				email:'',
				code: '',
				isSignIn: true,
				checked: false,

			};
		},
		onShow() {
			let userinput = uni.getStorageSync('userinput');
			let passinput = uni.getStorageSync('passinput');
			console.log(userinput);

			if (userinput) {
				this.user = userinput
			}
			if (passinput) {
				this.password = passinput
			}
		},
		methods: {

			handleChange() {
				this.isSignIn = !this.isSignIn;
				// this.user = "";
				// this.password = "";
				// this.password2 = "";
				// this.code = "";
			},
			handleConfirm() {
				console.log(2222)
				if (this.checkForm()) {
					if (this.isSignIn) {
						this.signIn();
					} else {
						this.register();
					}
				}
			},
			home() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			checkForm() {
				if (this.user == '') {
					uni.$u.toast(this.$lang.USER_NAME);
					return false;
				}
				if (this.password == '') {
					uni.$u.toast(this.$lang.PASSWORD);
					return false;
				}
				if (!this.isSignIn && this.password2 == '') {
					uni.$u.toast(this.$lang.PASSWORD_CONFIRM);
					return false;
				}
				if (!this.isSignIn && this.email == '') {
					uni.$u.toast(this.$lang.USER_YOUXIANG);
					return false;
				}
				if (!this.isSignIn && this.password2 != this.password) {
					uni.$u.toast(this.$lang.TIP_PWD_NOEQUAL);
					return false;
				}
				if (!this.isSignIn && !this.code) {
					uni.$u.toast(this.$lang.INVITATION_CODE);
					return false;
				}
				return true;
			},

			async signIn() {
				// uni.showLoading({
				// 	title: this.$lang.TIP_SIGNIN_ING,
				// })
				const result = await this.$http.post(this.$http.API_URL.SIGN_IN, {
					username: this.user,
					password: this.password,
					email:this.email,
				})
				if (result.data.code == 0) {
					uni.hideLoading();
					const token = result.data.data.token.access_token
					uni.setStorageSync('token', token);
					uni.$u.toast(this.$lang.TIP_SUCCESS_SIGNIN);
					if (this.checked) {
						console.log(1111);

						uni.setStorageSync('userinput', this.user);
						uni.setStorageSync('passinput', this.password);
					}
					setTimeout(() => {

						uni.switchTab({
							url: this.$util.PAGE_URL.HOME,
						});
						this.$router.go(0)
					}, 500)
				} else {
					uni.hideLoading();
					uni.$u.toast(result.data.message);
				}
			},
			async register() {
				uni.showLoading({
					title: this.$lang.TIP_SIGNUP_ING,
				})
				const result = await this.$http.post(this.$http.API_URL.SIGN_UP, {
					mobile: this.user,
					password: this.password,
					confirmpass: this.password,
					invite: this.code,
					code: 123456,
					email:this.email,
				    
				})
				if (result.data.code == 0) {
					uni.hideLoading();
					uni.$u.toast(this.$lang.TIP_SUCCESS_REGISTER);
					this.signIn();
				} else {
					uni.hideLoading();
					uni.$u.toast(result.data.message);
				}
			},
		}
	}
</script>