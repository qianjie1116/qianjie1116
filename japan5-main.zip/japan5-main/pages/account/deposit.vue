<!-- 银转证  存款 -->
<template>
	<view>
		<view style="position: relative;">
			<image src="/static/chongzhi.png" mode="widthFix" style="width: 100%;height: 100px;"></image>
		</view>
		<view class="flex">
			<view class="flex-4">
				
			<image src="/static/baisejiantou.png" mode="widthFix" style="width: 24px;height: 25px;position: absolute;bottom: 92%;margin-left: 15px;"  ></image>
			</view>
			<view style="width: 100%;justify-content: center;display: flex;height: 20px;position: absolute;bottom: 92%;color: #fff;font-size: 18px;"@click="home2()">入金</view>
		</view>
		<view>
		<image src="/static/chongzhi2.png" mode="widthFix" style="width: 40%;height: 20px;position: absolute;bottom: 78%;margin: 20px;"></image>
		</view>
		<view style="width: 100%;justify-content: flex-end; display: flex; ">
		<image src="/static/chongzhi3.png" mode="widthFix" style="width: 30%;height: 20px;position: absolute;bottom: 72%;"></image>
		</view>
		<view style="display: flex;align-items: center;flex-direction: column;margin-top: 30px;">
			<view style="font-size: 28px;font-weight: 900;" :style="{color:$util.THEME.PRIMARY}">
				{{$util.formatNumber(userInfo.money)}}
			</view>
			<view style="padding:20px;" :style="{color:$util.THEME.TIP}">{{$lang.TIP_AMOUNT_AVAIL}}</view>
			<view class="common_btn btn_primary" style="width: 80%;margin:auto; background-color: #23218f; height: 40px;line-height: 40px;" @click="handleCustomer()">
				{{$lang.TIP_LINK_SERVICE}}
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				userInfo: {},
			};
		},
		onLoad(option) {
			this.getInfo()
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
		home2() {
			uni.switchTab({
				url: '/pages/account/center'
			});
		},

			async handleCustomer() {
				let list = await this.$http.get('api/app/config', {})
				let url = list.data.data[8].value
			
				// window.open(this.list, '_blank');
					if (window.android) {
						window.android.callAndroid("open," + url)
						return;
					}
					if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
						.nativeExt) {
						window.webkit.messageHandlers.nativeExt.postMessage({
							msg: 'open,' + url
						})
						return;
					}
			
					var u = navigator.userAgent;
					var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
					if (isiOS) {
						window.location.href = url;
						return;
					}
					window.open(url)
				
				
			},
			async getInfo() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_FASTINFO, {})
				if (result.data.code == 0) {
					this.userInfo = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		},
	}
</script>