<!-- 펀드 비밀번호 -->
<template>
	<view >
		<view class="flex" style="background-color: #01024d;height: 90px;">
			<image src="/static/baisejiantou.png" mode="widthFix" style="width: 25px;height: 25px;margin-left: 15px;" @click="handleBack()"></image>
			<view class="flex justify-center" style="color: #fff;font-size: 16px;width: 100%;">出入金パスワード</view>
		</view>
		<view style="background-color: #f3f4f8;width: 100%;height: 30px;border-radius: 10px;margin-top: -20px;"></view>
	
		<view
			style="display: flex;flex-direction: column;padding-top:3vh;background-color: #fff;width: 90%;border-radius: 10px;margin-left: 20px;">
			<view class="flex" style="background-color: #F7F9FF;height: 45px;border-radius: 10px;width: 90%;margin: 10px;">
				<view style="font-size: 10px;margin-left: 5px;">現在のパスワード</view>
				<text class="flex-0.5" style="background-color: #808080;width: 2px;height: 15px;margin-left: 5px;">.</text>
				<input style="margin-left: 5px; font-size: 10px;" v-model="value" maxlength="6" type="password" placeholder="入力してください"></input>
			</view>
			<view class="flex" style="background-color: #F7F9FF;height: 45px;border-radius: 10px;width: 90%;margin: 10px;">
				<view style="font-size: 10px;margin-left: 5px;">新しいパスワード</view>
				<text class="flex-0.5" style="background-color: #808080;width: 2px;height: 15px;margin-left: 5px;">.</text>
				<input style="margin-left: 5px; font-size: 10px;" v-model="value2" maxlength="6" type="password" placeholder="入力してください"></input>
			</view>
			<view class="flex" style="background-color: #F7F9FF;height: 45px;border-radius: 10px;width: 90%;margin: 10px;">
				<view style="font-size: 10px;margin-left: 5px;">パスワードを認証する</view>
				<text class="flex-0.5" style="background-color: #808080;width: 2px;height: 15px;margin-left: 5px;">.</text>
				<input style="margin-left: 5px; font-size: 10px;" v-model="value3" maxlength="6" type="password" placeholder="入力してください"></input>
			</view>
			<view class="flex justify-center" style="width:95%;margin: 10px;background-color: #24228f;color: #fff;height: 45px;border-radius: 10px;" @click="transactionPassword">確認</view>
		</view>
	</view>
	

</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				value:'',
				value2: "",
				value3: "",
			};
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			//修改交易密码
			async transactionPassword() {
				const result = await this.$http.post(this.$http.API_URL.PAY_PASSWORD, {
					oldpass: this.value,
					newpass: this.value2,
					confirmpass: this.value3,
				})
				if (result.data.code == 0) {
					uni.$u.toast('修正されました。');
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		}
	}
</script>