<template>
	<view>
		<view class="flex" style="background-color: #01024d;height: 90px;">
			<image src="/static/baisejiantou.png" mode="widthFix" style="width: 25px;height: 25px;margin-left: 15px;" @click="handleBack()"></image>
			<view class="flex justify-center" style="color: #fff;font-size: 16px;width: 100%;">取引履歴</view>
		</view>
		<view style="background-color: #f3f4f8;width: 100%;height: 30px;border-radius: 10px;margin-top: -20px;"></view>

		<Tbas :btns="$util.BTNS_TRADE_LOG" @action="handleChangeTab"></Tbas>
		<view style="min-height: 66vh;margin-top: 10px;">
			<template v-if="current == 0">
				<LogTrade></LogTrade>
			</template>

			<template v-if="current == 1">
				<LogDeposit></LogDeposit>
			</template>

			<template v-if="current == 2">
				<LogWithdraw></LogWithdraw>
			</template>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import Tbas from '@/components/Tbas.vue';
	import LogTrade from '@/components/LogTrade.vue';
	import LogDeposit from '@/components/LogDeposit.vue';
	import LogWithdraw from '@/components/LogWithdraw.vue';
	export default {
		components: {
			CustomHeader,
			Tbas,
			LogTrade,
			LogDeposit,
			LogWithdraw,
		},
		data() {
			return {
				current: 0,
				// btns: [this.$lang.LOG_TRADE, this.$lang.LOG_DEPOSIT, this.$lang.LOG_WITHDRAW],
			};
		},
		onLoad(item) {
			console.log(item);
			this.current = Number(item.index) || 0;
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			handleChangeTab(val) {
				clearInterval(this.timer);
				this.current = val;
			},
		},
	}
</script>