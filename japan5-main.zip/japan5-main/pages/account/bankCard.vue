<!-- 绑定银行卡 -->
<template>
	<view >
		<view class="flex" style="background-color: #01024d;height: 90px;">
			<image src="/static/baisejiantou.png" mode="widthFix" style="width: 25px;height: 25px;margin-left: 15px;" @click="handleBack()"></image>
			<view class="flex justify-center" style="color: #fff;font-size: 16px;width: 100%;">銀行口座の情報</view>
		</view>
		<view style="background-color: #f3f4f8;width: 100%;height: 30px;border-radius: 10px;margin-top: -20px;"></view>
			
	<view style="background-color: #fff;width: 95%;border-radius: 10px;margin-left: 10px;">
		<view style="display: flex;flex-direction: column;justify-content: center;align-items: center;padding-top:3vh;">
			<view class="flex" style="background-color: #F7F9FF;height: 45px;border-radius: 10px;width: 90%;margin: 10px;">
				<view style="font-size: 10px;margin-left: 5px;">銀行名</view>
				<text class="flex-0.5" style="background-color: #808080;width: 2px;height: 15px;margin-left: 5px;">.</text>
				<input style="margin-left: 5px; font-size: 10px;" v-model="value" type="text" :placeholder="$lang.REAL_NAME" :clearable='true'></input>
			</view>
			
			<view class="flex" style="background-color: #F7F9FF;height: 45px;border-radius: 10px;width: 90%;margin: 10px;">
				<view style="font-size: 10px;margin-left: 5px;">支店名</view>
				<text class="flex-0.5" style="background-color: #808080;width: 2px;height: 15px;margin-left: 5px;">.</text>
				<input style="margin-left: 5px; font-size: 10px;" v-model="value1" type="text" :placeholder="$lang.BANK_NAME" :clearable='true'></input>
			</view>
			<view class="flex" style="background-color: #F7F9FF;height: 45px;border-radius: 10px;width: 90%;margin: 10px;">
				<view style="font-size: 10px;margin-left: 5px;">支店番号</view>
				<text class="flex-0.5" style="background-color: #808080;width: 2px;height: 15px;margin-left: 5px;">.</text>
				<input style="margin-left: 5px; font-size: 10px;" v-model="value2" type="text" :placeholder="$lang.BANK_CARD" :clearable='true'></input>
			</view>
			<view class="flex" style="background-color: #F7F9FF;height: 45px;border-radius: 10px;width: 90%;margin: 10px;">
				<view style="font-size: 10px;margin-left: 5px;">口座番号</view>
				<text class="flex-0.5" style="background-color: #808080;width: 2px;height: 15px;margin-left: 5px;">.</text>
				<input style="margin-left: 5px; font-size: 10px;" v-model="value3" type="text" :placeholder="$lang.BANK_CARD" :clearable='true'></input>
			</view>
			<view class="flex" style="background-color: #F7F9FF;height: 45px;border-radius: 10px;width: 90%;margin: 10px;">
				<view style="font-size: 10px;margin-left: 5px;">口座種類</view>
				<text class="flex-0.5" style="background-color: #808080;width: 2px;height: 15px;margin-left: 5px;">.</text>
				<input style="margin-left: 5px; font-size: 10px;" v-model="value4" type="text" :placeholder="$lang.BANK_CARD" :clearable='true'></input>
			</view>
			<view class="flex" style="background-color: #F7F9FF;height: 45px;border-radius: 10px;width: 90%;margin: 10px;">
				<view style="font-size: 10px;margin-left: 5px;">口座名義</view>
				<text class="flex-0.5" style="background-color: #808080;width: 2px;height: 15px;margin-left: 5px;">.</text>
				<input style="margin-left: 5px; font-size: 10px;" v-model="value5" type="text" :placeholder="$lang.BANK_CARD" :clearable='true'></input>
			</view>
			</view>

			<template>
				<view class="common_btn" style="width:80%;background-color: #01024d;color: #fff;margin: 20px 30px;" @click="replaceBank()">確認</view>
			</template>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				info: {},
				isRenewal:false,
				value: '',
				value1: '',
				value2: '',
				value3: '',
				value4: '',
				value5: '',
			};
		},
		onLoad() {
			this.gaint_info()
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			renewal() {
				this.isRenewal=true;
			},
			// 换绑银行卡
			async replaceBank() {
				let list = await this.$http.post(this.$http.API_URL.USER_BIND_CARD, {
					//value2和value3反了
					//value2应该是bank_name  
					//value3应该是bank_sub_name
					bank_name: this.value,
					bank_sub_name: this.value1,
					// bank_sub_name: this.value3,
					zd_number: this.value2,
					qy_type: this.value3,
					realname: this.value4,
					card_sn: this.value5,
					
				})
				if (list.data.code == 0) {
					uni.$u.toast('銀行カード情報が正常に送信されました。');
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}

			},
			//用户信息
			async gaint_info() {
				const result = await this.$http.get('api/user/info', {})
				this.info = result.data.data.bank_card_info
				this.value=this.info.bank_name
				this.value1=this.info.bank_sub_name
				this.value2=this.info.zd_number
				this.value3=this.info.qy_type
				this.value4=this.info.realname
				this.value5=this.info.card_sn
				
			},
		},
	}
</script>