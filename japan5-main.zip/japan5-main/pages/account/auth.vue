<template>
	<view style="position: relative;">
		<image src="/static/shiming.png" mode="widthFix" style="width:100%;"></image>
		<!-- <CustomHeader title="本人認証" @action="$u.route({type:'navigateBack'});"></CustomHeader> -->
		<view class="flex" style="position: absolute;bottom: 94%;width: 100%;">
			<image src="/static/baisejiantou.png" mode="widthFix" style="width: 25px;margin-left: 15px;" @click="action()"></image>
			<view style="color: #fff;font-size: 16px;width: 100%;justify-content: center;display: flex;">本人認証</view>
		</view>
		<view>
			<image src="/static/shiming1.png" mode="widthFix"
				style="position: absolute;bottom: 80%;width: 35%;margin: 20px;"></image>
		</view>
		<view style="width: 100%;justify-content: flex-end; display: flex; ">
			<image src="/static/shiming2.png" mode="widthFix"
				style="position: absolute;bottom: 75%;width: 20%;margin: 20px;"></image>
		</view>


		<view style="margin-top:3vh;background-color: #fff;width: 90%;margin: 20px;border-radius: 10px;height: 520px;">
			<view class="flex padding-top-10">
				<view style="background-color: #24228F;width: 3px;margin-left: 20px;">.</view>
				<view class="font-size-17 bold" style="margin: 5px 10px;">名前</view>
			</view>
			<view
				style="width: 70%;padding: 10px 30px;background-color: #f7f9ff;margin-left: 20px;border-radius: 10px;">

				<input v-model="value1" type="text" placeholder="名前を入力してください"></input>
			</view>

			<!-- <image mode="aspectFit" src="/static/card1.png" :style="$util.calcImageSize(20)">
				</image> -->
			<view class="flex padding-top-10">
				<view style="background-color: #24228F;width: 3px;margin-left: 20px;">.</view>
				<view class="font-size-17 bold" style="margin: 5px 10px;">ID番号</view>
			</view>
			<view
				style="width: 70%;padding: 10px 30px;background-color: #f7f9ff;margin-left: 20px;border-radius: 10px;">
				<input v-model="value2" type="text" placeholder="ID番号を入力してください"></input>
			</view>
			<view class="flex padding-top-10">
				<view style="background-color: #24228F;width: 3px;margin-left: 20px;">.</view>
				<view class="font-size-17 bold" style="margin: 5px 10px;">写真をアップロードする</view>
			</view>
			<template v-if="userinfo.is_check!=1">
				<view style="background-color: #f7f9ff;border-radius: 10px;padding: 30px;margin: 10px;">
					<view style="justify-content: center;display: flex;" @click="obverse_btn">
						<image :style="$util.calcImageSize(20)"
							src="/static/xiangji.png"
							 v-if="!formData.obverseUrl"></image>
							
						<image mode="widthFix"
							:src="formData.obverseUrl"
							style="width: 80px;" v-else></image>
								
					</view>
					<view style="width: 100%;justify-content: center;display: flex;margin-top: 5px;">
						<view :style="{color:$util.THEME.PRIMARY}">身分証明の表面</view>
					</view>
				</view>

				<view style="background-color: #f7f9ff;border-radius: 10px;padding: 30px;margin: 10px;">
					<view style="width: 100%;justify-content: center;display: flex;" @click="reverse_btn">
						<image :style="$util.calcImageSize(20)"
							src="/static/xiangji.png"
							v-if="!formData.reverseUrl"></image>
						<image mode="widthFix"
							:src="formData.reverseUrl"
							style="width: 80px;" v-else></image>
					</view>
					<view style="width: 100%;justify-content: center;display: flex; margin-top: 5px;">
						<view :style="{color:$util.THEME.PRIMARY}">身分証明の裏面</view>
					</view>
				</view>

			</template>
		</view>
		<view @click="gain_aouonym()" style="background-color: #24228F;color: #fff;padding: 10px 0;text-align: center;height: 30px;line-height: 30px;position: fixed;bottom: 0;width: 100%;border-top-left-radius: 10px;border-top-right-radius: 10px;">
			今すぐ認証
		</view>
	


	</view>
</template>

<script>
	import {
		pathToBase64
	} from '@/utils/js_sdk.js'
	import Blob from 'blob';
	import md5 from 'js-md5'
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				obverseUrl: '',
				reverseUrl: '',
				// 上传图片
				// 表单
				formData: {
					// 正面
					obverseUrl: '',
					// 反面
					reverseUrl: ''
				},
				//
				value1: '',
				value2: '',
				userinfo: {},
				//倒计时
				second: Math.round(Math.random() * 6),
				timer: null,
			};
		},
		onLoad() {},
		mounted() {
			this.userInfo()
		},
		methods: {
			obverse_btn() {
				if (this.obverseUrl) {

					this.previewImage(this.obverseUrl);
				} else {
					this.select_change('obverse');
				}
				uni.$u.toast('フロントをクリックして追加');
			},
			reverse_btn() {
				if (this.reverseUrl) {
					this.previewImage(this.reverseUrl);
				} else {
					this.select_change('reverse');
				}
				uni.$u.toast('裏をクリックして追加しました。');
			},
			// 上传
			select_change(name) {
				uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
					success: res => {
						const imageFile = res.tempFiles[0];
						const maxSizeInBytes = 200 * 1024; // 200KB

						this.sfz_chagne({
							msg: `${name}Image:ok`,
							name,
							tempFilePath: imageFile.path,
							tempFile: imageFile
						})
					}
				});
			},

			// 预览
			previewImage(current = 0) {
				uni.previewImage({
					current,
					urls: [this.obverseUrl, this.reverseUrl],

				});
			},
			action() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},

			// 删除
			del_btn(name) {
				this.$emit('del', {
					name
				});
			},

			// 认证
			async gain_aouonym() {
				uni.showLoading({
					title: "送信中です。 しばらくお待ちください....",
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/user/real-auth1', {
					real_name: this.value1,
					idno: this.value2,
					front_image: this.formData.obverseUrl,
					back_image: this.formData.reverseUrl,
				})

				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.HOME
						});
						uni.hideLoading();
					}, 1000)
				} else if (list.data.code == 1) {
					uni.$u.toast(list.data.message);
				}
			},
			async userInfo() {
				let list = await this.$http.get(this.$http.API_URL.USER_FASTINFO, {})
				this.value1 = list.data.data.real_name
				this.value2 = list.data.data.idno
				this.userinfo = list.data.data
				this.formData.obverseUrl = list.data.data.front_image
				this.formData.reverseUrl = list.data.data.back_image
				// console.log(list.data.data, '1111111111111');
				uni.hideLoading();
			},

			async upimg(type, tempFilePath) {
				uni.showLoading({
					title: "アップロード中"
				})
				let Request = "Qwd3N5yp"
				let time = parseInt(new Date().getTime() / 1000)
				let str_url = ("/api/app/upload").toLowerCase()


				let mdd = md5("XPFXMedS" + Request + str_url + time)

				uni.uploadFile({
					url: this.$BaseUrl + '/api/app/upload?t=' + time + "&sign=" + mdd, // 仅为示例，非真实的接口地址
					filePath: tempFilePath,
					name: 'file',

					success: (res) => {
						uni.hideLoading()
						var data = JSON.parse(res.data);
						// this.is_url = res.data
						console.log(1111, data)
						if (type == 1) {
							this.formData.obverseUrl = data[0].url;
						} else {
							this.formData.reverseUrl = data[0].url;

						}

					},
					error: (res) => {
						uni.hideLoading()
						console.log(3333, res)
					},
				});
			},
			// 插件上传身份证
			// 上传

			sfz_chagne(e) {
				console.log(222, e)
				var that = this;
				if (e.name == "obverse") {
					this.upimg(1, e.tempFilePath)

				} else if (e.name == "reverse") {
					this.upimg(2, e.tempFilePath)

				}
			},
			// 删除
			del_btn(e) {
				if (e.name == 'obverse') {
					this.formData.obverseUrl = '';
				} else if (e.name == 'reverse') {
					this.formData.reverseUrl = '';
				}
			},
		},
	};
</script>