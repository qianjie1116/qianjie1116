<!-- 실시간 이체 -->
<template>
	<view>
		<view style="position: relative;">
			<image src="/static/tixian.png" mode="widthFix" style="width: 100%;"></image>
		</view>
		<view>
			<image src="/static/baisejiantou.png" mode="widthFix" style="width: 25px;height: 25px; position: absolute;bottom: 93%;margin-left: 15px;"
				@click="handleBack()"></image>
		</view>
		<view>
			<view
				style="width: 100%;position: absolute;bottom: 93%;font-size: 18px;color: #fff;justify-content: center;display: flex;"@click="handleBack()">
				出金</view>
		</view>
		<view style="width: 100%;justify-content: flex-end; display: flex; ">
			<image src="/static/tixian2.png" mode="widthFix" style="width: 100px;position: absolute;bottom: 75%;">
			</image>
		</view>
		<view>
			<view style="position: absolute;bottom: 75%;font-size: 14px;color: #fff;margin: 30px;">引き出し可能な資金</view>
		</view>
		<view>
			<view style="position: absolute;bottom: 70%;font-size: 30px;color: #fff;margin: 30px;">
				{{$util.formatNumber(userInfo.money)}}</view>
		</view>

		<view
			style="padding:20px;margin-top: -160px;position: relative;border-radius: 10px;background-color: #fff;width: 80%;margin-left: 20px;">
			<!-- <view style="text-align:center;font-size: 16px;" :style="{color:$util.THEME.TIP}"> 실시간이체 </view> -->
			<!-- <view style="font-size: 32px;font-weight: 700;text-align: center;margin-top: 10px;"
				:style="{color:$util.THEME.PRIMARY}">
				{{$util.formatNumber(userInfo.money)}}
			</view> -->

			<!-- <view style="text-align: center;margin-top: 10px;" :style="{color:$util.THEME.TIP}">{{$lang.TIP_AMOUNT_AVAIL}}</view> -->
			<view class="flex">
				<text class="flex-0.5" style="background-color: #24228F;width: 3px;height: 15px;">.</text>
				<view class="bold margin-left-10">出金金額</view>
			</view>
			<view class="common_input_wrapper" style="border-radius: 5px; background-color: #F7F9FF;">
				<!-- <image mode="aspectFit" src='/static/money.png' :style="$util.calcImageSize(20)">
				</image> -->
				<input v-model="amount" :placeholder="$lang.TIP_AMOUNT_WITHDRAW" type="number"></input>
				<!-- <view @click="handleAllAmount(userInfo.money)" class="btn_small">{{$lang.TIP_AMOUNT_ALL}}</view> -->
			</view>
			<view class="flex">
				<text class="flex-0.5" style="background-color: #24228F;width: 3px;height: 15px;">.</text>
				<view class="bold margin-left-10">支払いパスワード</view>
			</view>

			<view class="common_input_wrapper" style="border-radius: 5px; background-color: #F7F9FF;">
				<!-- <image mode="aspectFit" src='/static/password.png' :style="$util.calcImageSize(20)">
				</image> -->
				<input v-model="password" :placeholder="$lang.TIP_WITHDRAW_PWD" type="password"></input>
			</view>
		</view>
		<view style="background-color: #fff;margin: 20px;width: 90%;border-radius: 10px; margin-bottom: 100px;">
			<view class="flex padding-top-15 margin-left-20">
				<text class="flex-0.5" style="background-color: #24228F;width: 3px;height: 15px;">.</text>
				<view class="bold margin-left-10">出金指示</view>
			</view>
			<view style="padding: 20px;" :style="{color:$util.THEME.TIP}">
				<block v-for="(item,index) in $util.TIP_WITHDRAW_CONDITION">
					<view style="padding-bottom: 6px;" :style="{color:index!==4?$util.THEME.LABEL:$util.THEME.TIP}">
						{{item}}</view>
				</block>
			</view>
		</view>
		<view @click="handleWithdraw()" style="background-color: #24228F;color: #fff;padding: 10px 0;text-align: center;height: 30px;line-height: 30px;position: fixed;bottom: 0;width: 100%;border-top-left-radius: 10px;border-top-right-radius: 10px;">
			{{$lang.WITHDRAW}}{{$lang.CONFIRM}}
		</view>
		</view>
		
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				amount: '',
				password: '',
				userInfo: {},
			};
		},
		onShow() {
			this.getInfo()
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},

			handleAllAmount(val) {
				this.amount = val
			},
			async handleWithdraw() {
				uni.showLoading({
					title: this.$lang.TIP_WITHDRAWING,
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				const result = await this.$http.post(this.$http.API_URL.APP_WITHDRAW, {
					type: 1,
					total: this.amount,
					pay_pass: this.password,
					remakes: "",
				})
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
						uni.hideLoading();
					}, 500)
				} else {
					uni.hideLoading();
					uni.$u.toast(result.data.message);
				}
			},
			async getInfo() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_FASTINFO, {})
				if (result.data.code == 0) {
					this.userInfo = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		},
	}
</script>