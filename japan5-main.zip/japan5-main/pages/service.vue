<!-- 客服 -->
<template>
	<view>


		<!-- <view class="college-content"> -->
		<!-- <web-view :fullscreen="full" class="webview" :style="webviewStyles" :webview-styles="webviewStyles"
				:src='list'></web-view> -->
		<!-- 	<web-view :style="webviewStyles" :webview-styles="webview" :fullscreen="full" :src='list'></web-view>
		</view> -->
		<!-- <template>
			<web-view :src="list"></web-view>
		</template> -->
		<image :src="lineimg"  mode="widthFix" style="margin-left: 20%;width: 60%;margin-top: 20px;" ></image>
		<view class="padding-20">
			<view class="text-center font-size-16">QRコードでLINEフレンドを追加</view>
					<view class="text-center font-size-14 hui">LINEアプリで友達タブを開き、友達追加アイコンをタップします。
右上隅にある「QRコード」を選択してから、このQRコードをスキャンしてください。</view>
		</view>
		 
		
		<u-button type="primary" @click="saveImg()" text="QRコードの保存" style="width: 90%;margin-left: 5%;" size="large"></u-button>
		<u-button type="success" @click="link()" text="LINEを開く" style="width: 90%;margin-left: 5%;margin-top:20px" size="large"></u-button>
		
		<view class="padding-20">
			 <view class="text-center font-size-14 red" >"LINE宅配便」ボタンが正常にジャンプされない場合は、下のボタンをクリックしてモバイルブラウザにコピーして開きます。</view>
		</view>
		
		<u-button type="error" @click="fuzhi()" text="LINEリンクのコピー" style="width: 90%;margin-left: 5%;margin:20px;" size="large"></u-button>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: "",
				full: false,
				webviewStyles: {
					height: '91vh',
					width: "100%",
				},
				webview: {
					height: '91vh',
					width: "100%",
				},
				lineimg:"/static/line.png"
			};
		},
		mounted() {
			this.get_url()
		},
		methods: {
			saveImg() {
				var oA = document.createElement("a");
				oA.download = ''; // 设置下载的文件名，默认是'下载'
				oA.href = this.lineimg;
				document.body.appendChild(oA);
				oA.click();
				oA.remove(); // 下载之后把创建的元素删除
			},
			home() {
				uni.switchTab({
					url: this.$util.PAGE_URL.HOME
				});
			},
			fuzhi(){
					
				let info=this.list
				// #ifndef H5
				//uni.setClipboardData方法就是讲内容复制到粘贴板
				uni.setClipboardData({
					data: info,//要被复制的内容
					success:() => {//复制成功的回调函数
						uni.showToast({//提示
							title:'コピーが完了しました。 貼り付けてブラウザで開きます。' 
						})
					}
				});
				// #endif
				
				 // #ifdef H5 
					let textarea = document.createElement("textarea")
					textarea.value = info
					textarea.readOnly = "readOnly"
					document.body.appendChild(textarea)
					textarea.select() // 选中文本内容
					textarea.setSelectionRange(0, info.length) 
					uni.showToast({//提示
						title:'コピーが完了しました。 貼り付けてブラウザで開きます。' 
					})
					result = document.execCommand("copy") 
					textarea.remove()    
				// #endif
							
			},
			link(){
				window.open(this.list, '_blank');
			},
			async get_url() {
				let list = await this.$http.get(this.$http.API_URL.APP_CONFIG, {})
				this.list = list.data.data[8].value
				
			},
			async kefu() {
			        let list = await this.$http.get('api/app/config', {})
			        let url = list.data.data[8].value
			      
			        // window.open(this.list, '_blank');
			          if (window.android) {
			            window.android.callAndroid("open," + url)
			            return;
			          }
			          if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
			            .nativeExt) {
			            window.webkit.messageHandlers.nativeExt.postMessage({
			              msg: 'open,' + url
			            })
			            return;
			          }
			      
			          var u = navigator.userAgent;
			          var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
			          if (isiOS) {
			            window.location.href = url;
			            return;
			          }
			          window.open(url)
			        
			      },
		},
		
	}
</script>

<style lang="scss">
	::v-deep .uni-page-head {
		background: #007AFF !important;
		color: #fff !important;
	}

	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 80rpx;
		background: #007AFF;
		// background: #ea3544;
		display: flex;
		justify-content: space-between;
		align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	iframe {
		width: 600px !important;
	}

	.college-content {
		width: 100%;
		height: 100%;
	}

	/deep/ .webview {
		width: 100% !important;
		height: 100% !important;
	}
</style>