# japan5

# Update Log 2024.07.12
- stock/overview：下拉刷新。定時器與ws雙啓動。定時器只負責info數據，即kline接口執行一次。
- stock/buy:下拉刷新。定時器與ws雙啓動。
- trade:下拉刷新。