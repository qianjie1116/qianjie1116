<!-- 个人交易 交易信息 -->
<template>
	<view class="" style="padding:0 10px;">
		<view class="flex  ">
			<!-- <view style="border-radius: 0 16rpx 16rpx 0;width: 5px;height: 30px;"></view> -->
			<!-- <view class="margin-left-10 bold font-size-16" :style="{color:$util.THEME.TEXT}">205-01-{{info.uid}}</view> -->
			<!-- <view class="margin-left-5 hui font-size-10 ">[CMA]{{info.real_name}}</view> -->
			<!-- <view class="left-auto margin-right-10 flex gap5" @click="gp_show=true">
				{{gp_select[0][gp_index]}}
				<u-icon name="arrow-down" :bold="true"></u-icon>
			</view> -->
		</view>
		<!-- <view style="display: flex;align-items: center;justify-content: space-between;padding:0 10px 10px 10px;">
			<view style="font-size: 24px;font-weight: 700;" :style="{color:$util.THEME.PRIMARY}">
				{{$util.formatNumber(info.money)}}
			</view>
			<view class="common_btn btn_primary" style="width: 20%;" @click="handleDeposit">{{$lang.DEPOSIT}}</view>
		</view> -->
		<view class="flex">
			<view style="background-color: #fff;width: 50%;margin-left: 10px;height: 80px;border-radius: 10px;">
				<view style="margin-top: 15px;" class="flex justify-center">
					<image src="/static/mairu.png" mode="widthFix" style="width: 25px;height: 25px;"></image>
				</view>

				<view class="font-size-10 text-center">購入合計額</view>
				<view class="margin-left-20 flex margin-top-5">
					<view style="color: chocolate;font-size: 10px;text-align: center;width: 100%;">
						{{$util.formatNumber(info.frozen)}}
					</view>
				</view>
			</view>

			<view style="background-color: #fff;width: 50%;margin-left: 10px;height: 80px;border-radius: 10px;">
				<view style="margin-top: 15px;" class="flex justify-center">
					<image src="/static/pgsy.png" mode="widthFix" style="width: 25px;height: 25px;"></image>
				</view>

				<view class="font-size-10 text-center">利点を評価</view>
				<view class="margin-left-20 flex margin-top-5">
					<view style="color: chocolate;font-size: 10px;text-align: center;width: 100%;">
						{{$util.formatNumber(info.holdYingli)}}
					</view>
				</view>
			</view>

			<!-- 	<view style="background-color: #fff;width: 30%;margin-left: 10px;height: 80px;border-radius: 10px;">
				<view style="margin-top: 15px;" class="flex justify-center">
					<image src="/static/jine.png" mode="widthFix" style="width: 28px;height: 28px;"></image>
				</view>

				<view class="font-size-10 text-center">評価額</view>
				<view class="margin-left-20 flex margin-top-5">
					<view style="color: chocolate;font-size: 10px;text-align: center;width: 100%;">{{$util.formatNumber(info.guzhi)}}
					</view>
				</view>
			</view> -->
		</view>

		<view class="flex margin-top-10">
			<!-- <view style="background-color: #fff;width: 30%;margin-left: 10px;height: 80px;border-radius: 10px;">
				<view style="margin-top: 15px;" class="flex justify-center">
					<image src="/static/shouyi.png" mode="widthFix" style="width: 25px;height: 25px;"></image>
				</view>

				<view class="font-size-10 text-center">利益率</view>
				<view class="margin-left-20 flex margin-top-5">
					<view style="color: chocolate;font-size: 10px;text-align: center;width: 100%;">{{info.huibao}}%</view>
				</view>
			</view> -->

			<view style="background-color: #fff;width: 50%;margin-left: 10px;height: 80px;border-radius: 10px;">
				<view style="margin-top: 15px;" class="flex justify-center">
					<image src="/static/zichan.png" mode="widthFix" style="width: 25px;height: 25px;"></image>
				</view>

				<view class="font-size-10 text-center">総資産</view>
				<view class="margin-left-20 flex margin-top-5">
					<view style="color: chocolate;font-size: 10px;text-align: center;width: 100%;">
						{{$util.formatNumber(info.totalZichan)}}
					</view>
				</view>
			</view>

			<view style="background-color: #fff;width: 50%;margin-left: 10px;height: 80px;border-radius: 10px;">
				<view style="margin-top: 15px;" class="flex justify-center">
					<image src="/static/lirun.png" mode="widthFix" style="width: 25px;height: 25px;"></image>
				</view>

				<view class="font-size-10 text-center">利益総額</view>
				<view class=" flex margin-top-5">
					<view style="color: chocolate;font-size: 10px;text-align: center;width: 100%;">
						{{$util.formatNumber(info.totalYingli)}}
					</view>
				</view>
			</view>
		</view>


	</view>
</template>

<script>
	export default {
		name: "TradeInfo",
		props: {
			info: {
				type: Object,
				default: {}
			}
		},
	}
</script>