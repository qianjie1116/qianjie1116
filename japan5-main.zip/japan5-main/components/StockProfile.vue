<!-- 股票概况 -->
<template>
	<view style="margin:0 20px;padding-bottom: 10px; border-bottom: 1px solid #999;">
		<view v-for="(item,index) in info" :key="index" style="display: flex;align-items: center;">
			<view style="flex:30%;padding-left: 20px;" :style="{color:$util.THEME.LABEL}">{{item.label}}
			</view>
			<view style="flex:70%;text-align: right;padding-right: 20px;" :style="{color:$util.THEME.TEXT}">{{item.value}}</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "StockProfile",
		props: ['params'],
		data() {
			return {
				info: [],
			};
		},
		created() {
			this.getData();
		},
		methods: {
			async getData() {
				console.log(this.params);
				uni.showLoading({
					mask: true,
					title: this.$lang.LOADING,
				})
				const result = await this.$http.post(this.$http.API_URL.PRODUCT_INFO_TOW, {
					code: this.params.code,
					stock_id: this.params.id
				})
				if (result.data.code == 0) {
					const temp = result.data.data[0].top1;
					this.info =[{
						label: '企業ランキング',
						value: `コスダック ${temp.marketcap_rank} 上`
					}, {
						label: '株式数',
						value: `${this.$util.formatNumber(temp.sharesout)} 週`
					}, {
						label: '産業群',
						value: `${this.$util.formatNumber(temp.sector)}`
					}, {
						label: '52週最高',
						value: `${this.$util.formatNumber(temp.year_high)}`
					}, {
						label: '評価額',
						value: `${this.$util.formatNumber(temp.marketcap)} 億`
					}, {
						label: '外国人の割合',
						value: `${this.$util.formatNumber(temp.foreigners_pie)}%`
					}, {
						label: 'セブ産業群',
						value: `${this.$util.formatNumber(temp.industry)}`
					}, {
						label: '52週間の最低',
						value: `${this.$util.formatNumber(temp.year_low)}`
					}]
					uni.hideLoading()
				}
			}
		}
	}
</script>