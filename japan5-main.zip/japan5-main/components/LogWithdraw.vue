<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view class="line " style="margin-bottom:10px;padding:10px 20px;font-size: 14px;background-color: #fff;border-radius: 10px;width: 80%;margin-left: 20px;">
				<view style="display: flex;align-items: center;line-height: 1.5;margin-bottom:6px;padding: 4px 10px;">
					<view style="flex:30%;" :style="{color:$util.THEME.LABEL}">出金</view>
					
					<!-- <view style="flex:5%;text-align: center;" :style="{color:$util.THEME.RISE}">
						{{item.desc_type}}
					</view> -->
				</view>
				<view style="align-items: center; margin-top: -10px;margin-left: 5px;">
					<view :style="{color:$util.THEME.PRIMARY}" style="flex:40%;font-size: 18px;font-weight: 700;">
						{{$util.formatNumber(item.money)}}
					</view>
				</view>
				

				<view style="display: flex;align-items: center;line-height: 1.5;margin-bottom:6px;padding: 8px 10px;">
					<view style="flex:80%;" :style="{color:$util.THEME.LABEL}">注文番号</view>
					<view style="flex:100%;" >
						{{item.order_sn}}
					</view>
				</view>
				<view style="display: flex;align-items: center;line-height: 1.5;margin-bottom:6px;padding: 4px 10px;">
					<view style="flex:90%;" :style="{color:$util.THEME.LABEL}">日時</view>
					<view style="flex:100%;" >
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;line-height: 1.5;margin-bottom:6px;padding: 4px 10px;">
					<view style="flex:30%;" :style="{color:$util.THEME.LABEL}">拒否理由 :</view>
					<view style="flex:70%;" >
						{{item.reason}}
					</view>
				</view>
				<view style="display: flex;align-items: center;line-height: 1.5;margin-bottom:6px;padding: 4px 10px;">
					<!-- <view style="flex:3%;">
						<image :src="item.icon" :style="$util.calcImageSize(12)"></image>
					</view> -->
					<view style="flex:97%;" :style="{color:item.color}">{{item.text}}</view>
				</view>
				<view style="display: flex;align-items: center;line-height: 1.5;">
					<u-button text="キャンセル" type="error" @click="qx(item.id)"
						v-if="item.status==0"></u-button>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogWithdraw",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		mounted() {
			this.getList()
		},
		methods: {
			qx(id) {
				var that = this;
				uni.showModal({
					title: "本当に引き出しをキャンセルしますか？",
					cancelText: "キャンセル",
					confirmText: "確認",
					success: function(res) {
						if (res.confirm) {
							that.qx_post(id)
						} else if (res.cancel) {
							console.log('ユーザーはキャンセルをクリックします');
						}
					}
				})
			},
			async qx_post(id) {
				let list = await this.$http.post('api/app/qx', {
					id: id
				});
				console.log(list)
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.withdrawal()
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			// async qx_post(id) {
			// 	uni.showLoading({
			// 		title: '処理',
			// 	})
			// 	const result = await this.$http.post(this.$http.API_URL.APP_QX, {
			// 		id: id
			// 	});
			// 	if (result.data.code == 0) {
			// 		uni.$u.toast(result.data.message);
			// 		uni.hideLoading()
			// 		this.getList()
			// 	} else {
			// 		uni.$u.toast(result.data.message);
			// 		uni.hideLoading()
			// 	}
			// },
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_WITHDRAW, {})
				console.log(result.data.data);
				if (result.data.code == 0) {
					result.data.data.forEach((item, index) => {
						this.list.push({
							...item,
							...this.$util.TRADE_LOG_STATUS[item.status]
						})
					});
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		}
	}
</script>

<style>

</style>