<!-- 行业对比 -->
<template>
	<view style="margin:0 20px;padding: 10px 0; border-bottom: 1px solid #999;">
		<view style="display: flex;align-items: center;justify-content: space-between;"
			:style="{color:$util.THEME.LABEL}">
			<text>業種内比較</text>
			<text>自動車部品 {{count}} 中</text>
		</view>
		<view style="padding:10px;">
			<view v-for="(item,index) in info" :key="index"
				style="display: flex;align-items: center;flex-wrap: nowrap;">
				<view style="flex: 25%;" :style="{color:$util.THEME.TEXT}">{{item.label}}
				</view>
				<view style="flex: 30%;text-align: right;padding-right: 16px;"
					:style="$util.calcStyleRiseFall(item.value>0)">{{item.value}}{{index==0?'억':index==3||index==4?'船':'%'}}
				</view>
				<view style="flex: 30%;text-align: right;padding-right: 16px;"
					:style="$util.calcStyleRiseFall(item.value2>0)">{{item.value2}}{{index==0?'억':index==3||index==4?'船':'%'}}
				</view>
				<view style="flex: 15%;text-align: right;padding-right: 6px;" :style="{color:$util.THEME.TEXT}">
					{{item.value3}}위
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: "MarketComparison",
		props: ['params'],
		data() {
			return {
				info: [],
				count:0,
			};
		},
		created() {
			this.getData();
		},
		methods: {
			async getData() {
				const result = await this.$http.post(this.$http.API_URL.PRODUCT_INFO_TOW, {
					code: this.params.code,
					stock_id: this.params.id
				})
				console.log('result:', result);
				if (result.data.code == 0) {
					const temp = result.data.data[0].top8;
					this.count  =temp.count;
					this.info =[{
						label: '評価額',
						value: temp.marketcap,
						value2:temp.marketcap_avg,
						value3:temp.marketcap_rank,
					},{label: '純利益増加率',
						value: temp.net_income_growth,
						value2:temp.net_income_growth_avg,
						value3:temp.net_income_growth_rank,
					},{label: '負債比率',
						value: temp.debt_ratio,
						value2:temp.debt_ratio_avg,
						value3:temp.debt_ratio_rank,
					},{label: 'PER',
						value: temp.per,
						value2:temp.per_avg,
						value3:temp.per_rank,
					},{label: 'PBR',
						value: temp.pbr,
						value2:temp.pbr_avg,
						value3:temp.pbr_rank,
					},{label: 'ROE',
						value: temp.roe,
						value2:temp.roe_avg,
						value3:temp.roe_rank,
					}]					
				}
			},
		}
	}
</script>

<style>

</style>