<!-- 用于纵向导航，如：个人中心 -->
<template>
	<view style="background-color: #fff;width: 95%;margin-left: 10px;border-radius: 10px;">
		<block v-for="(item,index) in list" :key="index">
			<view class="" style="display: flex;align-items: center;padding-left: 20px;margin:10px;margin-bottom: 10px;height: 50px;"
				@click="actionEvent(item,index)">
				<view style="flex: 10%;">
					<image style="width: 20px; height: 20px;" mode="aspectFit" :src="`/static/${item.icon}.png`">
					</image>
				</view>
				<text style="flex: 70%;font-weight: 700;font-size: 15px;"
					:style="{color:$util.THEME.TEXT}">{{item.name}}</text>
				<view style="flex: 12%;">
					<view class="arrow rotate_45" :style="$util.calcImageSize(10)"></view>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "NavList",
		props: ['list'],
		data() {
			return {};
		},
		methods: {
			actionEvent(item, index) {
				if (item.mode) {
					uni.navigateTo({
						url: item.url,
					})
				} else {
					this.$emit('action', item);
				}
			},
		}
	}
</script>

<style>

</style>