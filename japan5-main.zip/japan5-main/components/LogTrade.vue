<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view style="margin-bottom:10px;padding:10px 20px;font-size: 14px;background-color: #fff;width: 80%;border-radius: 10px;margin: 20px;">
				<view style="align-items: center;line-height: 1.5;margin-bottom:6px;padding: 4px 10px;">
					<view style="flex:30%;" :style="{color:$util.THEME.LABEL}">金額</view>
					<view style="flex:70%;font-size: 18px;font-weight: 700;margin-top: 10px;" :style="{color:$util.THEME.PRIMARY}">
						{{$util.formatNumber(item.money)}}
					</view>
				</view>

				<view style="display: flex;align-items: center;line-height: 1.5;margin-bottom:6px;padding: 4px 10px;">
					<view style="flex:90%;" :style="{color:$util.THEME.LABEL}">変更前:</view>
					<view style="" :style="{color:$util.THEME.TEXT}">
						{{$util.formatNumber(item.before)}}
					</view>
				</view>
				<view style="display: flex;align-items: center;line-height: 1.5;margin-bottom:6px;padding: 4px 10px;">
					<view style="flex:90%;" :style="{color:$util.THEME.LABEL}">変更後:</view>
					<view style="" :style="{color:$util.THEME.TEXT}">
						{{$util.formatNumber(item.after)}}
					</view>
				</view>
				
				<view style="display: flex;align-items: center;line-height: 1.5;margin-bottom:6px;padding: 4px 10px;">
					<view style="flex:90%;" :style="{color:$util.THEME.LABEL}">日時:</view>
					<view style="flex: 100%;" >
						{{item.created_at}}
					</view>
				</view>
				<view style="align-items: center;line-height: 1.5;margin-bottom:6px;padding: 4px 10px;">
					<view style="flex:90%;" :style="{color:$util.THEME.LABEL}">詳細：</view>
					<view style="" >
						{{item.desc}}
					</view>
				</view>
				
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogTrade",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		mounted() {
			this.getList()
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_FINANCE, {})
				if (result.data.code == 0) {
					this.list = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		}
	}
</script>

<style>

</style>