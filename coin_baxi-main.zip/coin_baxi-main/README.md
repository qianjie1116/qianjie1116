# tpl_coin


## Fork ko_kpsstock

![LOGO](https://github.com/github1413/tpl_coin/raw/main/static/logo.png)

# UI
```
https://lanhuapp.com/link/#/invite?sid=lx0YTLNh
英文为主  多语言 無需RTL B-stable的API，支持websocket

前端所有的number_code  替换成code
/api/user/assets      资产页面  type 2资产   1合约账户

ui設計圖，貨幣詳情3，暫時不要。

無需寫 充值銀行轉賬1，充值銀行轉賬2，充值銀行轉賬3

資產 行上數據 api/user/finance  type ,name(傳number_code)


```
# 卡死時，注釋項目相關實時渲染，如圖表、滾動等。打包前check，並解注釋。

# 功能列表

- ✅ launch:启动页
- ✅ pact:隐私协议
- ✅ access:登入注册
- ✅ about:关于我们
- ✅ share:分享 <!-- 設計圖：我的分享，邀請鏈接和複製。 -->
- ✅ address: 提现地址管理
- ✅ password:变更登入密码、变更支付密码
- ✅ auth:  实名认证
- ✅ home:  移除xau
- ✅ search: ws
- ✅ market/index:Market [Coin、Track]
- ✅ notify:公告頁面，公告詳情頁面 (首頁公告滾動,獲取當前列表數據最近一條，點擊進入公告詳情頁面)
- ✅ coin/index: 默認`BTC`,點擊切換按鈕，彈出選擇其他Coin。
- ✅ coin/detail: coin detail
- ✅ coin/record:
- - ✅ current:
- - ✅ history: 这里加个手续费
- ✅ cantract/index: 默認`BTC`,點擊切換按鈕，彈出選擇其他Coin。
- ✅ cantract/detail:
- ✅ cantract/record:未使用。<!-- 委托是0 持有仓位传的是status是1   历史记录是2 -->
- assets/index:[資產賬戶|合約賬戶]
- assets/record:資產賬戶`每條`數據的交易記錄。
- ✅ deposit:充值默認USDT。
- ✅ withdraw:提现 。
<!--
 我的提現，體現地址，選擇貨幣，只有ERC20-USDT   和TRC20-USDT
 所以这里（提現1，提現2）选择usdt取款只有这一种  点击之后就只能选择这一种    然后下面钱包就是选择ERC20钱包的地址和TRC20钱包的地址
 -->
- ✅ transfer:划转。
- ✅ trade/ipo:IPO交易
- 
<!-- - bankCard:绑定银行卡。移除原状态切换逻辑，即当前页面直接修改。 -->

<!-- - tradeLog:交易记录
- account/center:个人中心 -->

<!-- - position:持仓 -->

```
	isConnected: false, // 是否链接socket
	// websocket 断线重连
reconnectWebSocket() {
	// 连接中，并且非手动关闭
	if (this.isConnected) return;
	console.log(`reconnect!`, this.isConnected);
	this.socket = null;
	console.log(`reconnect! socket:`, this.socket);
	this.connect();
},

this.isConnected = true; // 已连接
this.socket.onOpen((res) => {
	console.info("socket onOpen:", res)
});

this.socket.onClose((res) => {
	// code:1000(手动关闭) 1006(异常关闭) 
	console.log(`onClose:`, res);
	this.isConnected = false;
	if (res.code !== 1000) {
		this.reconnectWebSocket();
	}
});

this.socket.onError((err) => {
	console.log(`onError:`, err);
	this.isConnected = false;
	this.reconnectWebSocket();
});
	
```

# Update Log 2024.07.28
- websocket添加断线重连。

# Update Log 2024.07.16
- 全局缓存一个眼睛状态并同步到全局眼睛状态。

# Update Log 2027.07.06
- 修复token过期，跳转`access`页面前，清理缓存。在清理前后，添加设置语言的缓存，避免语言重置为默认值。
- 修复token过期，页面跳转重载时，`launch`及`home`页面语言同步问题。

# Update Log 2024.07.02
- auth:添加数据缓存。

# Update Log 2024.06.26
- 隐藏多语言
```
弹层无法遮蔽tabbar解决方案：
uni.hideTabBar(); // 隐藏tabBar
uni.showTabBar(); // 显示tabBar
```

# Update Log 2024.06.17
- 将项目中的`金额`与`数量`分辨使用各自的格式化方案，以兼容不同币种，以及处理小数位数。
- 按照国际化定义语言导出对象key，便于处理国际化的时间及金额。
- 根据当前选择语言，格式化软件中所有日期时间格式。(后端只需要传时间戳，或将后端返回数据转为时间戳，再统一格式化)

# Update Log 2024.05.22
- 更新`auth`照片上传逻辑。
- 变更 `avatar`头像上传逻辑，移除u-upload。

# Update Log 2024.05.15
- uniapp内置`scroll-view`不支持桌面端鼠标移动。
