<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<header class="common_header" style="background-color: #FFFFFF;">
			<view class="left"  @click="$util.goBack()">
				<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
			</view>
			<view class="center" style="padding-left: 0;text-align: center;">
				<text :style="{color:$theme.SECOND}">{{$lang.DEPOSIT_TITLE}}</text>
			</view>
			<view class="right" @click="linkRecord()">
				<image src="/static/icon_record.png" mode="aspectFit" :style="$theme.setImageSize(32)">
				</image>
			</view>
		</header>

		<view style="padding-bottom: 200rpx;">
			<view class="common_block" style="padding:40rpx;border-radius: 24rpx;">
				<view style="display: flex;align-items: center;" @tap="chooseCoin()">
					<view style="font-size: 28rpx;" :style="{color:$theme.SECOND}">{{curMode}}</view>
					<view style="margin-left: auto;">
						<view style="display: flex;align-items: center;">
							<template v-if="isCoin">
								<view :style="setStyle()">{{$lang.DEPOSIT_COIN}}</view>
							</template>
							<image src="/static/arrow_right.png" mode="aspectFit" style="padding-left: 20rpx;"
								:style="$theme.setImageSize(20)"></image>
						</view>
					</view>
				</view>
			</view>
			<template v-if="isCoin">
				<view style="display: flex;align-items: center;padding:40rpx;padding-bottom: 20rpx;">
					<view style="font: 28rpx;font-weight: 700;padding-right: 20rpx;">{{$lang.DEPOSIT_ADDRESS}}</view>
					<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">USDT</view>
					<view style="margin-left: auto;color:#6D41FF;font-size: 24rpx;" @tap="handleCopy()"> Copy </view>
				</view>
				<view class="common_block" style="padding:40rpx;border-radius: 24rpx;">
					<view style="text-align: center;font-size: 24rpx;" :style="{color:$theme.LOG_VALUE}"> {{curAddress}}
					</view>
				</view>
			</template>
			<template v-else>
				<view style="display: flex;align-items: center;padding:40rpx;padding-bottom: 20rpx;">
					<view style="font: 28rpx;font-weight: 700;padding-right: 20rpx;">{{$lang.WITHDRAW_BANK_CODE}}</view>
				</view>
				<view class="common_block" style="padding:40rpx;border-radius: 24rpx;">
					<view style="text-align: center;" :style="{color:$theme.LOG_VALUE}"> {{bankCode}}</view>
				</view>
			</template>

			<template v-if="isNextStep">
				<view style="font: 28rpx;font-weight: 700;padding-left:40rpx;line-height: 3;">
					{{$lang.DEPOSIT_AMOUNT}}
				</view>
				<view class="common_input_wrapper"
					style="background-color:#FFFFFF;border-radius: 16rpx;padding-left:40rpx;margin:0 20rpx 20rpx 20rpx;">
					<input v-model="amount" type="digit" :placeholder="$lang.DEPOSIT_ENTER_AMOUNT"
						:placeholder-style="$theme.setPlaceholder()"></input>
				</view>

				<view style="font: 28rpx;font-weight: 700;padding-left:40rpx;line-height: 3;">
					{{$lang.DEPOSTI_UPLOAD}}
				</view>

				<view
					style="display: flex;align-items: center;justify-content: center;padding: 24px;background-color: #FFFFFF;border-radius: 8rpx;margin: 20rpx;">
					<image :src="!obverseUrl?`/static/icon_upload.png`:obverseUrl" @click="selectImg()"
						style="margin:20rpx;width:440rpx;height:240rpx;">
					</image>
				</view>
				<view class="padding-15 color-red">
					<view >{{$lang.ZHUYI_TIXIAN}}:</view>
					<view>{{$lang.TIXIAN_ZHUSHI}}</view>
				</view>
				
			</template>
		</view>
		
		


		<view style="position: fixed;bottom: 10rpx;left: 0;right: 0;">
			<template v-if="isNextStep">
				<view class="common_btn" style="margin:40rpx auto;width: 80%;" @click="handleSubmit()">
					{{$lang.COMMON_CONFIRM}}
				</view>
			</template>
			<template v-else>
				<view class="common_btn" style="margin:40rpx auto;width: 80%;" @click="handleNext()">
					{{$lang.COMMON_NEXT_STEP}}
				</view>
			</template>
		</view>

		<!-- Coin  選擇器 -->
		<u-picker :show="isShowCoinList" :columns="[coinList]" @change="changeCoin" @cancel="isShowCoinList=false"
			@confirm="confirmCoin" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" visibleItemCount="9"></u-picker>
	</view>
</template>

<script>
	import md5 from '@/common/md5.min.js';
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isShowCoinList: false, // 是否顯示 coin選擇器
				curMode: 'USDT（ERC20）', // 当前选中充值模式
				curAddress: '', // 当前选中coin的address
				isNextStep: false, // 是否点击过下一步
				amount: '', // 输入金额
				obverseUrl: null, // 上传凭证
			};
		},
		computed: {
			coinList() {
				return ['USDT（ERC20）', 'USDT（TRC20）', 'BTC（BTC）', 'ETH（ETH）']
			},
			// 如果选择非银行
			isCoin() {
				return !this.curMode.includes('Bank');
			},
		},
		onShow() {
			this.isAnimat = true;
			this.getCoinfg();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			linkRecord() {
				uni.navigateTo({
					url: this.$paths.DEPOSIT_RECORD
				})
			},
			// 下一步
			handleNext() {
				this.isNextStep = true;
			},

			// 提交
			async handleSubmit() {
				if (!this.amount || this.amount <= 0) {
					uni.showToast({
						title: this.$lang.DEPOSIT_ENTER_AMOUNT,
						icon: 'none'
					});
					return false;
				}
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/app/recharge`, {
					money: this.amount,
					type: this.curMode,
					image: this.obverseUrl || '',
					desc: '',
				});
				if (!result) return false;
				console.log('result:', result);
				uni.showToast({
					// title: result,
					icon: 'success'
				});
				setTimeout(() => {
					this.curAddress = '';
					this.curMode = this.coinList[0];
					this.isNextStep = false;
					this.amount = '';
					this.obverseUrl = '';
					this.linkRecord();
				}, 1000);
			},

			// copy address
			async handleCopy() {
				const result = await uni.setClipboardData({
					data: this.curAddress, //要被复制的内容
				});
				if (result[1].confirm) {
					uni.showToast({
						title: this.$lang.COMMON_COPY_SUCCESS,
						duration: 2000,
						icon: 'success'
					})
				}
			},

			// 選擇一種coin
			chooseCoin() {
				this.isShowCoinList = true;
			},
			changeCoin(e) {
				console.log(`changeMode e:`, e);
			},
			// coin選擇器確認事件
			confirmCoin(e) {
				console.log(`confirmMode e:`, e);
				this.curMode = e.value[0];
				this.isShowCoinList = false;
				this.getCoinfg();
				// 重置一些值
				this.isNextStep = false;
			},
			async getCoinfg() {
				const result = await this.$http.post(`api/app/config`);
				if (!result) return false;
				console.log(`result:`, result);
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				if (this.curMode.includes('ERC')) {
					this.curAddress = temp.get('erc20') || '';
				} else if (this.curMode.includes('TRC')) {
					this.curAddress = temp.get('trc20') || '';
				} else if (this.curMode.includes('BTC')) {
					this.curAddress = temp.get('btc') || '';
				} else if (this.curMode.includes('ETH')) {
					this.curAddress = temp.get('eth') || '';
				}
			},

			// 点击上传
			async selectImg() {
				const result = await uni.chooseImage({
					count: 1,
					sizeType: ['compressed'],
					sourceType: ['album'],
				});
				console.log('result:', result);
				const imageFile = result[1].tempFiles[0];
				console.log('imageFile:', imageFile);
				this.upimg(imageFile.path);
			},
			// 上传图片
			async upimg(tempFilePath) {
				uni.showLoading({
					title: this.$lang.API_STATUS_UPLOAD,
				})
				let Request = "Qwd3N5yp"
				let time = parseInt(new Date().getTime() / 1000)
				let str_url = ("/api/app/upload").toLowerCase()
				let mdd = md5("XPFXMedS" + Request + str_url + time);

				const result = await uni.uploadFile({
					url: this.$http.BASE_URL + '/api/app/upload?t=' + time + "&sign=" + mdd,
					filePath: tempFilePath,
					name: 'file',
				});
				console.log('result:', result);
				uni.hideLoading();
				if (result[1].statusCode == 200) {
					const temp = JSON.parse(result[1].data);
					console.log('temp:', temp);
					this.obverseUrl = temp[0].url;
				}
				console.log(`obverseUrl`, this.obverseUrl);
				// this.setStorageData();
			},
			setStyle() {
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA('#6D41FF', 30),
					color: '#6D41FF',
					borderRadius: `8rpx`,
					minWidth: `60rpx`,
					padding: `6rpx 16rpx`,
					fontSize: `22rpx`,
					textAlign: `center`,
				}
			},
		}
	}
</script>


<style lang="scss" scoped>
	.common_header {
		padding: 40rpx;
		display: flex;
		align-items: center;
		padding-top: 30px;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 500;
			padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: left;
		}
	}
</style>