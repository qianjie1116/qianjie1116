<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;min-height: 100vh;">
		<!-- <HeaderSecond title="" :color="$theme.SECOND"></HeaderSecond>
		<view style="font-size: 36rpx;font-weight: 700;padding-left: 44rpx;" :style="{color:$theme.SECOND}">
			{{$lang.SEARCH_TITLE}}
		</view> -->

		<view class="common_header">
			<view class="custom_header_left"  @click="$util.goBack()" style="padding-right: 20rpx;">
				<view class="arrow rotate_225" :style="{borderColr:$theme.SECOND,...$theme.setImageSize(20)}"></view>
			</view>
			<view class="custom_header_center">
				<view class="common_input_wrapper"
					style="margin:0;padding: 6rpx 0 6rpx 40rpx;border-radius: 32rpx;background-color: #F2F4F5;">
					<input v-model="keyword" type="text" :placeholder="$lang.TIP_SEARCH"
						:placeholder-style="$theme.setPlaceholder()" style="width: 90%;"></input>
					<image src="/static/search.png" mode="aspectFit" style="margin-left: auto;"
						:style="$theme.setImageSize(40)" @tap="handleSearch"></image>
				</view>
			</view>
			<!-- 			<view class="custom_header_center" style="border-radius: 32rpx;background-color: #F2F4F5;height: 64rpx;">
				<u-search shape="" :placeholder="$lang.TIP_SEARCH" v-model="keyword" :showAction="false" height="48rpx"
					:searchIconColor="$theme.SECOND" searchIconSize="20" bgColor="" @clear="keyword=''"
					:actionText="$lang.SEARCH_TITLE" @search="searchButton" @custom="searchButton"
					color="#121212"></u-search>
			</view> -->
		</view>

		<view style="padding:0 40rpx;">
			<TitleSecond :title="$lang.SEARCH_HISTORY">
				<image mode="aspectFit" src="/static/delete.png" :style="$theme.setImageSize(44)"
					style="margin-left: auto;" @click="clearKeywords()"></image>
			</TitleSecond>
		</view>

		<view style="display: flex;align-items: center;margin:0 10px;flex-wrap: wrap;">
			<template v-if="keywords.length>0">
				<block v-for="(item,index) in keywords" :key="index">
					<view
						style="padding:4px 10px;margin:4px;border-radius: 32rpx;background-color:#F3F3F3;color:#333333;"
						@click="selectedItem(item)">{{item}}</view>
				</block>
			</template>
		</view>

		<view style="padding-bottom: 80rpx;">
			<template v-if="!list || list.length<=0">
				<view style="text-align: center;line-height:4;color:#999999">{{$lang.API_EMPTY_DATA}}</view>
				<CoinHotPicks></CoinHotPicks>
			</template>
			<template v-else>
				<SearchList :list="list"></SearchList>
			</template>
		</view>
	</view>
</template>
<script>
	import TitleSecond from '@/components/title/TitleSecond.vue';
	import SearchList from './components/SearchList.vue';
	import CoinHotPicks from './components/CoinHotPicks.vue'
	export default {
		components: {
			TitleSecond,
			SearchList,
			CoinHotPicks,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				keyword: "", // 当前关键词
				keywords: [], // 搜索词条组
				list: [], // 搜索结果
				curPage: 1,
				limit: 20,
			};
		},
		onLoad() {
			this.keywords = uni.getStorageSync("keywords") || [];
			if (!this.list || this.list.length <= 0) {

			}
		},
		onShow() {
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		// 下拉刷新
		onPullDownRefresh() {
			this.handleSearch();
			uni.stopPullDownRefresh();
		},
		methods: {
			// 清空搜索记录
			clearKeywords() {
				uni.clearStorageSync("keywords");
				this.keywords = []; // 手动清理缓存数据
				this.list = []; // 查询结果重置
			},

			// 选中一项搜索历史词条 
			selectedItem(item) {
				this.keyword = item;
				this.handleSearch();
			},

			//搜索
			async handleSearch() {
				if (this.keyword == '' || this.keyword.length < 3) {
					uni.showToast({
						title: this.$lang.TIP_SEARCH,
						icon: 'none'
					})
					return false;
				}
				uni.showToast({
					title: this.$lang.LOADING_SEATCH,
					icon: 'none',
				});
				uni.showLoading({
					title: this.$lang.LOADING_SEATCH,
				});
				const result = await this.$http.get(`api/product/list`, {
					key: this.keyword,
					page: this.curPage,
					limit: this.limit,
					gp_index: 0
				})
				console.log(result);
				if (!result) return false;
				this.list = result.length <= 0 ? [] : result.map(item => {
					if (item.gid && item.gid > 0) {
						return {
							id: item.gid,
							logo: item.logo || '',
							name: item.name || '',
							code: item.code || '',
							price: item.current_price || 0,
							rate: item.rate || 0,
							type_id: item.project_type_id || 0,
						}
					}
				});
				console.log('search result:', this.list)
				if (this.keywords.indexOf(this.keyword) < 0) {
					this.keywords.push(this.keyword);
					uni.setStorageSync("keywords", this.keywords)
				}
			},
		}
	}
</script>


<style lang="scss" scoped>
	/deep/.u-search__content__input {
		background-color: transparent !important;
	}

	.common_header {
		padding: 40rpx;
		display: flex;
		align-items: center;
		padding-top: 30px;
		/* background-image: linear-gradient(180deg, #F5B71C, transparent); */
	}

	.custom_header_left {
		/* flex: 10%; */
		margin-right: auto;
	}

	.custom_header_left>image {
		width: 24px;
		height: 24px;
	}

	.custom_header_center {
		display: block;
		color: #333333;
		font-size: 32rpx;
		flex: 80%;
		// text-align: center;
		font-weight: 100;
	}

	.custom_header_right {
		margin-left: auto;
	}
</style>