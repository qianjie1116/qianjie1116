<template>
	<view style="margin-top: 50px;">
		<view class="charts-box">
			<qiun-data-charts type="candle" :opts="opts" :chartData="chartData" :ontouch="true"
				@getIndex="getIndex" />
		</view>
			<u-popup :show="show" @close="show=false" @open="open" mode="center">
				<view class="padding-20 bg-white">
					
					<view class="margin-bottom-5">开盘价:</view>
					<u--input placeholder="请输入开盘价" border="surround" v-model="open"></u--input>
					
					<view class="margin-top-10 margin-bottom-5">收盘价:</view>
					<u--input  placeholder="请输入收盘价" border="surround" v-model="close"></u--input>
					<view class="margin-top-10 margin-bottom-5">最高价:</view>
					<u--input  placeholder="请输入最高价" border="surround" v-model="high" ></u--input>
					<view class="margin-top-10 margin-bottom-5">最低价:</view>
					<u--input  placeholder="请输入最低价" border="surround" v-model="low" ></u--input>
					<u-button class="margin-top-10"  type="primary" text="提交" @click="submit"></u-button>
				</view>
			</u-popup>
		</view>
		
	</view>

</template>

<script>
	import kline_opt from '@/common/kline.js';
	export default {
		data() {
			return {
				show: false,
				chartData: {},
				id:"",
				open:"",
				low:"",
				close:"",
				high:"",
				click_index:"",
				click_count:0,
				opts:{},
				klines:"",
				KongpanData:""
			};
		},
		
		onLoad(op) {
			this.opts=kline_opt.kline_opt()
			this.id=op.id
			this.getData()
		},
		methods: {
			async submit() {
				
				const result = await this.$http.post(`api/app/kongpan_submit`,
				{id:this.data_id,
				open:this.open,
				high:this.high,
				close:this.close,
				low:this.low,
				});
				console.log('result:', result);
				if (!result) return false;
				this.show=false;
				this.getData()
			},
			
			async getData() {
				
				const result = await this.$http.post(`api/app/kongpan`,{id:this.id});
				console.log('result:', result);
				if (!result) return false;
				this.klines=result.kline
				this.KongpanData=result.KongpanData
				
				
				let res = {
					categories: result.time,
					series: [{
						name: "",
						data: result.kline
					}]
				};
				this.chartData = JSON.parse(JSON.stringify(res));
			},
			getIndex(e) {
				console.log(e,e.currentIndex.index)
				if(e.currentIndex.index<0){
					return
				}
				
				if(e.currentIndex.index==this.click_index){
					if(e.currentIndex.index==0){
						uni.$u.toast('第一个为实时数据用于参照，不允许修改');
						return
					}
					this.click_count++
					if(this.click_count==1){
						this.show=true
						this.open=this.klines[e.currentIndex.index][0]
						this.close=this.klines[e.currentIndex.index][1]
						this.low=this.klines[e.currentIndex.index][2]
						this.high=this.klines[e.currentIndex.index][3]
						this.data_id=this.KongpanData[e.currentIndex.index-1].id
						console.log(this.data_id);

					}else if(this.click_count>1){
						this.click_count=0;
					}
					
				}else{
					this.click_index=e.currentIndex.index
					this.click_count=0
				}

			},
		}
	};
</script>

<style scoped>
	page {
		width:100%;
	}
	
	/deep/.u-popup__content{
		width: 60%;
	}
	
	/deep/uni-canvas {
		/* width: 900px !important; */
	}
	/* 请根据实际需求修改父元素尺寸，组件自动识别宽高 */
	.charts-box {
		width: 100%;
		height: 800px;
	}
	
	
</style>