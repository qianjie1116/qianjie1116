<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="margin:20rpx 10rpx;padding: 20rpx; background-color: #FFFFFF;border-radius: 8rpx;">
					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.SECOND}" style="font-size: 36rpx;">{{item.goods.name}}</view>
						<template v-if="item.message &&item.message.length>0">
							<view :style="setStyle()"> {{item.message}} </view>
						</template>
					</view>

					<view
						style="display: flex;align-items: center;margin-bottom: 16rpx;line-height: 1.8;margin-top: 16rpx;">
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_IPO_RECORD_PRICE}}
							</view>
							<view style="font-size: 36rpx;" :style="{color:$theme.PRIMARY}">
								{{$util.formatMoney(item.price)+` ${$lang.CURRENCY_UNIT}`}}
							</view>
						</view>
						<view style="flex:1 0 10%;"></view>
						<view style="flex: 1 0 45%; border-bottom: 1px solid #F3F3F3;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_IPO_RECORD_APPLY_AMOUNT}}
							</view>
							<view style="font-size: 36rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatNumber(item.apply_amount)+` ${$lang.QUANTITY_UNIT}`}}
							</view>
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;margin-top:4px;">
						<view :style="{color:$theme.LOG_LABEL}">{{$lang.TRADE_IPO_RECORD_CREATETIME}}</view>
						<view :style="{color:$theme.TIP}">{{item.created_at}}</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "TradeIPORecord",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList();
		},
		methods: {
			setStyle() {
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(this.$theme.PRIMARY, 9),
					color: this.$theme.PRIMARY,
					borderRadius: `12rpx`,
					minWidth: `60rpx`,
					padding: `6rpx 16rpx`,
					fontSize: `24rpx`,
					textAlign: `center`,
				}
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-shengou/user-order-log`);
				console.log(result);
				this.list = result || [];
			},
		},
	}
</script>