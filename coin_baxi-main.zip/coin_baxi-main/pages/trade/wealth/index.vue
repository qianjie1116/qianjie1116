<template>
	<view style="background-image: linear-gradient(180deg, #9edaf2, transparent);height: 350px;">
		<!-- <view style="background-image: url(/static/waik.png);
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;height: 300px;top: 0;"></view> -->
		<view style="display: flex;align-items: center;padding: 60rpx 40rpx 20rpx 40rpx; " >
			<view class="flex-1" @click="$util.goBack()">
				<view class="arrow rotate_225" :style="$theme.setImageSize(20)"></view>
			</view>
			<text class="flex-1" style="color:#121212;">{{$lang.LICAI_LICAI}}</text>
			<view style="margin-left: auto;" @click="linkRecord()">
				<image mode="aspectFit" src="/static/icon_record.png" :style="$theme.setImageSize(40)"></image>
			</view>
		</view>
		
		<view style="width: 100%;justify-content: center;display: flex;margin-top: 40px;">
			<image src="/static/waitu.gif" mode="widthFix" style="width: 40%;"></image>
		</view>
		
		<view class="flex" style="padding: 0px 30px; justify-content: space-between; color: #aaabac;">
			<view class="font-size-12">Product name</view>
			<view class="font-size-12">Interest rate</view>
		</view>
	



		<view style="padding: 0px 15px;">
			<template v-if="list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view style="padding:30rpx;background-color: #ffffff;margin:30rpx 0;border-radius:24rpx;"
						@click="handleInfo(item)">
						<!-- <view style="display: flex;align-items: center;">
							<view style="flex:1 0 70%;color:#121212;font-size: 36rpx;">
								{{item.name}}
							</view>
							<template v-if="item.is_new==1">
								<view style="margin-left: auto;">
									<view
										style="background-color:#00B45A4D;color:#00B45A;border-radius:12rpx;padding:4rpx 10rpx;font-size:24rpx;text-align:center;">
										{{$lang.TRADE_WEALTH_NEW_USERS}}
									</view>
								</view>
							</template>
						</view> -->
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 2;">
							<view style="font-size: 18px;">{{item.name}}</view>
							<view style="color:#09bdab;font-size: 28rpx;">{{item.fudu}}%</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#666666;">{{$lang.LICAI_ZHOUQI}}</view>
							<view style="color:#333333;font-size: 28rpx;">{{item.zhouqi +$lang.TRADE_WEALTH_CYCLE_UNIT}}
							</view>
						</view>
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view style="color:#666666;">{{$lang.LICAI_ZUIDIMAIRU}}</view>
							<view style="color:#333333;font-size: 28rpx;">{{item.min_price}}</view>
						</view>
					</view>
				</block>
			</template>
		</view>
		<template v-if="isShow">
			<WealthBuy :info="infos" @action="handleClose"></WealthBuy>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import WealthBuy from './components/WealthBuy.vue';
	export default {
		components: {
			EmptyData,
			WealthBuy,
		},
		data() {
			return {
				list: [],
				isShow: false,
				info: {}, // 选中一条数据
			};
		},
		computed: {
			setInfo() {
				
				if (this.info && this.info.userinfo) {
					console.log(this.info, this.info.userinfo);
					return {
						teamNum: this.info.team_num, // 团队人数
						// level_mx 后端直接返回是否达标结果
						l1Pass: this.info.level_mx.if_l1, // L1团队人数是否达标
						l1PassMoney: this.info.level_mx.if_l1_licai_money, // L1理财金额是否达标
						l2Pass: this.info.level_mx.if_l2, // L2团队人数是否达标						
						holdMoneyPass: this.info.level_mx.if_licai_money, // 自身持有金额是否达标
						// 距 下一等级
						// 自身持有金额(目标)
						holdMoney: this.$util.formatMoney(this.info.level_mx.level_up_info.licai_money, 0),
						l1TeamNum: this.info.level_mx.level_up_info.l1, // L1 团队人数(目标)
						// L1 理财金额(目标)
						l1Money: this.$util.formatMoney(this.info.level_mx.level_up_info.l1_licai_money, 0),
						l2TeamNum: this.info.level_mx.level_up_info.l2, // L2 团队人数(目标)
						// L2 理财金额(目标)
						l2Money: this.$util.formatMoney(this.info.level_mx.level_up_info.l2_licai_money, 0),
						// 用户的当前等级数据
						// 当前自身持有金额
						curHoldMoney: this.$util.formatMoney(this.info.level_mx.licai_money, 0),
						curL1TeanNum: this.info.level_mx.l1, // 当前L1团队人数
						// 当前L1团队总金额
						curL1Money: this.$util.formatMoney(this.info.level_mx.l1_licai_money, 0),
						curL2TeanNum: this.info.level_mx.l2, // 当前L2团队人数
						// 当前L2团队总金额					
						curL2Money: this.$util.formatMoney(this.info.level_mx.l2_licai_money, 0),
						curLevel: this.info.userinfo.level, // 用户的当前等级
					}
				}
			}
		},
		onShow() {
			this.getList();
		},
		onLoad() {
			this.getLevelInfo();
		},
		
		onHide() {},
		methods: {
			linkDesc() {
				uni.navigateTo({
					url: this.$paths.LEVEL_DESC
				})
			},
			
			// 跳转到记录
			linkRecord() {
				uni.navigateTo({
					url: this.$paths.TRADE_WEALTH_RECORD
				})
			},
			// 购买弹层关闭
			handleClose(val) {
				this.isShow = false;
			},
			// 选中一条数据
			handleInfo(item) {
				console.log(item);
				this.infos = item;
				this.isShow = true;
			},
			//用户信息
			async getLevelInfo() {
				const result = await this.$http.get(`api/user/tuandui`);
				console.log('info result：', result);
				if (!result) return false;
				this.info = result;
				
			},
			open(e) {
				// console.log('open', e)
			},

			// 获取列表数据
			async getList() {
				const result = await this.$http.get(`api/jijin/list`);
				console.log(`result:`, result);
				if (!result) return false;
				this.list = result;
			}
		}
	}
</script>

<style>
</style>