<template>
	<view
		style="margin:20rpx 30rpx;border-radius: 4px;display: flex;align-items: center;background-color: #FFFFFF;padding:0 20px;">
		<image src="/static/horn.png" mode="aspectFit" :style="$theme.setImageSize(30)"></image>
		<template v-if="info">
			<u-notice-bar :text="info" speed="80" @click="linkDetail"  :color="$theme.SECOND" bgColor="#FFFFFF" direction="column"
				icon=""></u-notice-bar>
		</template>
		<!-- <image src="/static/close.png" mode="aspectFit" :style="$theme.setImageSize(30)" @click="actionEvent()"></image> -->
	</view>
</template>

<script>
	export default {
		name: 'NotifyPrimary',
		data() {
			return {
				info: null,
				list:""
			}
		},
		computed: {
			title() {
				if (this.info) {
					console.log(111, this.info);
					const temp = this.info.biaoti || this.$lang.LAUNCH_TITLE;
					return temp;

				}
			},

			linkNotify() {
				if (this.info) {
					const val = this.list.id;
					return "/pages/webview?id="+val
				}
			}
		},
		created() {
			this.getList();
		},
		methods: {
			linkDetail(val) {
				console.log(val);
				uni.navigateTo({
					url:"/pages/webview?id="+this.list[val].id
				})
			},
			async getList() {
				
				const result = await this.$http.get(`api/Article/list`, {
					type: 1,
				});
				
				console.log(`result:`, result);
				if (!result) return false;
				const temp = result.length > 0 ? result : null;
				console.log(1111,temp);
				this.list=temp;
				this.info =temp.map(item => item.title);
				console.log(this.info);

				// if (temp && temp.length > 0) {
				// 	// 排序 獲取當前最新公告
				// 	const tempSort = temp.sort((a, b) => new Date(b.created_at).getTime() -
				// 		new Date(a.created_at).getTime());
				// 	this.info = !tempSort || tempSort.length <= 0 ? null : tempSort[0];
				// 	console.log(this.info);
				// }
			}
		}
	}
</script>

<style>
</style>