<!-- 绑定银行卡 -->
<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="background-color: #FFFFFF;">
		<HeaderSecond title="" :color="$theme.SECOND"></HeaderSecond>

		<view style="font-size: 36rpx;font-weight: 700;padding-left: 44rpx;" :style="{color:$theme.SECOND}">
			{{$lang.BIND_BANK_CARD_TITLE}}
		</view>

		<view style="margin: 20px;padding: 10px;">
			<TitlePrimary :title="$lang.BIND_BANK_CARD_REAL_NAME"> </TitlePrimary>
			<view class="common_input_wrapper" style="margin-bottom: 20px;">
				<image mode="aspectFit" src="/static/user.png" :style="$theme.setImageSize(40)">
				</image>
				<input v-model="info.realName" type="text" :placeholder="$lang.BIND_BANK_CARD_REAL_NAME"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
			</view>

			<TitlePrimary :title="$lang.BIND_BANK_CARD_BANK_NAME"> </TitlePrimary>
			<view class="common_input_wrapper" style="margin-bottom: 20px;">
				<image mode="aspectFit" src="/static/bank.png" :style="$theme.setImageSize(40)">
				</image>
				<input v-model="info.bankName" type="text" :placeholder="$lang.BIND_BANK_CARD_BANK_NAME"
					:placeholder-style="$theme.setPlaceholder()" style="width: 80%;"></input>
			</view>

			<TitlePrimary :title="$lang.BIND_BANK_CARD_ID"> </TitlePrimary>
			<view class="common_input_wrapper" style="margin-bottom: 20px;">
				<image mode="aspectFit" src="/static/bank_card_id.png" :style="$theme.setImageSize(40)">
				</image>
				<input v-model="info.cardSN" type="text" :placeholder="$lang.BIND_BANK_CARD_ID"
					:placeholder-style="$theme.setPlaceholder()"></input>
			</view>
		</view>
		<view style="position: fixed;bottom: 40rpx;left: 0;right: 0;">
			<view class="common_btn" style="margin:60rpx auto;width: 80%;" @click="handleSubmit()">
				{{$lang.BTN_CONFIRM}}
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TitlePrimary from '@/components/title/TitlePrimary.vue';
	import TitlePrimaryRTL from '@/components/title/TitlePrimaryRTL.vue';
	export default {
		components: {
			HeaderSecond,
			TitlePrimary,
			TitlePrimaryRTL,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				info: {},
			};
		},
		computed: {
			isRtl() {
				return this.$util.isRtl();
			},
		},
		onLoad() {

		},
		onShow() {
			this.getAccountInfo()
			this.isAnimat = true;
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 检查表单
			checkForm() {
				if (this.info.realName == '') {
					uni.showToast({
						title: this.$lang.TIP_BIND_BANK_CARD_REAL_NAME,
						icon: 'none'
					});
					return false;
				}
				if (this.info.bankName == '') {
					uni.showToast({
						title: this.$lang.TIP_BANK_NAME,
						icon: 'none'
					});
					return false;
				}
				if (this.info.cardSN == '') {
					uni.showToast({
						title: this.$lang.TIP_BANK_CARD,
						icon: 'none'
					});
					return false;
				}
				return true;
			},
			// 提交事件
			handleSubmit() {
				if (this.checkForm()) {
					this.bindCard();
				}
			},
			// 换绑银行卡
			async bindCard() {
				uni.showToast({
					title: this.$lang.API_DATA_SUBMIT,
					icon: 'loading',
				});
				const result = await this.$http.post(`api/user/bindBankCard`, {
					realname: this.info.realName,
					bank_name: this.info.bankName,
					card_sn: this.info.cardSN,
				})
				console.log(result);
				if (!result) return false;
				uni.showToast({
					title: this.API_POST_SUCCESS,
					icon: 'success',
				});
				setTimeout(() => {
					uni.switchTab({
						url: this.$paths.ACCOUNT_CENTER
					});
				}, 1000)
			},

			//用户信息
			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/info`);
				if (!result) return false;
				// 未有真实姓名，跳转到实名认证
				if (!result.real_name) {
					uni.navigateTo({
						url: this.$paths.ACCOUNT_AUTH,
					})
				}
				if (result.bank_card_info) {
					this.info = {
						realName: result.bank_card_info.realname || '',
						bankName: result.bank_card_info.bank_name || '',
						cardSN: result.bank_card_info.card_sn || '',
					}
				}
			},
		},
	}
</script>