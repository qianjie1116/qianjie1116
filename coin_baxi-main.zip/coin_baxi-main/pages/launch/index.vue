<template>
	<view class="launch">

		<view style="display: flex;align-items: center;justify-content: center;padding-top: 15vh;">
			<image src="/static/launch_logo.png" mode="aspectFit" :style="$theme.setImageSize(300)"></image>
		</view>

		<view style="margin-top: 20px;text-align: center;font-size: 36rpx;font-family: 700;"
			:style="{color:$theme.SECOND}">
			{{$lang.LAUNCH_TITLE}}
		</view>

		<!-- 		<view style="display: flex;align-items: center;justify-content: center;">
			<image src='/static/launch_logo.png' mode="aspectFit" :style="$theme.setImageSize(200,150)">
			</image>
		</view> -->
		<!-- 		<view style="display: flex;align-items: center;justify-content: center;">
			<view style="margin-top: 20px;text-align: center;font-size: 36rpx;font-family: 700;color:#333333;">
				{{$lang.LAUNCH_TITLE}}
			</view>
		</view> -->

		<ProgressSecond></ProgressSecond>
	</view>
</template>

<script>
	import ProgressSecond from './components/ProgressSecond.vue';
	export default {
		components: {
			ProgressSecond,
		},
		onLoad() {
			this.$util.setAppLang();
			// 每次切换语言后，都调用setTabbar将底部导航重新排序
			this.$util.switchTabBar();
		}
	}
</script>

<style lang="scss" scoped>
	.launch {
		width: 100%;
		height: 100vh;
		padding-top: 0;
		// background-image: url('/static/launch_bg.png');
		background-repeat: no-repeat;
		background-position: 0 0;
		background-size: cover;
		background-image: linear-gradient(135deg, #F5F6FB, #F5F6FB);
		position: relative;
	}
</style>