<template>
	<view style="min-height: 100vh;background-color: #fff;">
		<HeaderSecond :title="$lang.Qiquan_result" :color="$theme.SECOND"></HeaderSecond>

		<view style="width: 100%;" class="flex justify-center">
			<view
				style="background-color: #000;border-radius: 50%;width: 100px;height: 100px;color: #fff;margin-top: 15%;font-size: 40px;" v-if="info.miao>0"
				class="flex justify-center align-center text-center">
				{{countdown }}
			</view>
			<view v-else class="flex justify-center align-center text-center" style="margin-top: 15%;">
				<image src="/static/qiquan_result.png" mode="widthFix" style="width: 200px;"></image>
			</view>
		</view>
		<view class="flex justify-center margin-top-10 gap10" style="color: #666666;"  v-if="info.miao>0">
			<image src="/static/shalou.gif" mode="widthFix" style="width: 30px;height: 30px;"></image>
			{{$lang.Qiquan_progress}}
		</view>
		<view v-else style="color: #333333;" class="flex justify-center margin-top-10">
			{{$lang.Qiquan_success}}
		</view>
		<view class="padding-30">
			<view class="flex flex-b">
				<view class="font-size-16">{{$lang.Qiquan_name_coin}}</view>
				<view class="bold font-size-16">{{info.name}}</view>
			</view>
			<view class="flex flex-b margin-top-10">
				<view class="font-size-16">{{$lang.Qiquan_type}}</view>
				<view class="bold font-size-16" :style="info.direct==1?'color:#FF533B':'color:#00B45A'">{{info.direct==1?$lang.Qiquan_die:$lang.Qiquan_zhang}}</view>
			</view>
			<view class="flex flex-b margin-top-10">
				<view class="font-size-16">{{$lang.Qiquan_BUY_PRICE}}</view>
				<view class="bold font-size-16">{{info.price}}</view>
			</view>
			<view class="flex flex-b margin-top-10" v-if="info.miao>0">
				<view class="font-size-16">{{$lang.Qiquan_now_PRICE}}</view>
				<view class="bold font-size-16">{{info.current_price}}</view>
			</view>
			
			<view class="flex flex-b margin-top-10" v-else>
				<view class="font-size-16">{{$lang.Qiquan_endprice}}</view>
				<view class="bold font-size-16">{{info.end_price}}</view>
			</view>
			
			
			
			<!-- <view class="flex flex-b margin-top-10">
				<view class="font-size-16">{{$lang.Qiquan_ordersn}}</view>
				<view class="bold font-size-16">{{info.price}}</view>
			</view> -->
			<view class="flex flex-b margin-top-10">
				<view class="font-size-16">{{$lang.Qiquan_Amount}}</view>
				<view class="bold font-size-16">{{info.amount}}</view>
			</view>
			<view class="flex flex-b margin-top-10" v-if="info.miao>0">
				<view class="font-size-16">{{$lang.Qiquan_Expected}}</view>
				<view class="bold font-size-16" :style="(info.current_price-info.end_price)>0?'color:#00B45A':'color:#FF533B'" v-if="info.direct==1">{{(info.current_price-info.end_price)>0?$lang.Qiquan_ying:$lang.Qiquan_shu}}</view>
				<view class="bold font-size-16" :style="(info.current_price-info.end_price)<0?'color:#00B45A':'color:#FF533B'" v-else>{{(info.current_price-info.end_price)<0?$lang.Qiquan_ying:$lang.Qiquan_shu}}</view>
			</view>
			
			<view class="flex flex-b margin-top-10" v-else>
				<view class="font-size-16">{{$lang.Qiquan_pl}}</view>
				<view class="bold font-size-16" :style="info.sy==1?'color:#00B45A':'color:#FF533B'">{{info.sy==1?$lang.Qiquan_ying:$lang.Qiquan_shu}}</view>
			</view>
			
			<view class="flex flex-b margin-top-10" v-if="info.miao==0">
				<view class="font-size-16">{{$lang.Qiquan_pl_Money}}</view>
				<view class="bold font-size-16" :style="info.sy==1?'color:#00B45A':'color:#FF533B'">{{info.yingli?info.yingli:-1*info.amount}}</view>
			</view>
			
			
			<view class="flex flex-b margin-top-10">
				<view class="font-size-16">{{$lang.Qiquan_buytime}}</view>
				<view class="bold font-size-16">{{info.created_at}}</view>
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				id: "",
				countdown: 60,
				timer: null,
				info:""
			};
		},

		onLoad(opt) {
			console.log(opt);
			this.id = opt.id
			this.countdown=opt.miao
			this.getQiquanOrder()
			
			// this.curTab = opt.tag || 0; // buy(long) or sell(short)
		},
		onHide() {
			this.isAnimat = false;
			if (this.socket) this.disconnect();
		},
		onUnload() {
			if (this.socket) this.disconnect();
		},
		deactivated() {
			if (this.socket) this.disconnect();
		},
		methods: {

			startCountdown() {
				var that=this;
				this.timer = setInterval(() => {
					if (this.countdown > 0) {
						this.countdown--;
					} else {
						clearInterval(this.timer);
						uni.showLoading({
							title:"Waiting..."
						})
						setTimeout(function() {
							that.getQiquanOrder()
						}, 1500);
					}
				}, 1000); // 每1000毫秒（1秒）减少一次  
			},
			stopCountdown() {
				clearInterval(this.timer); // 停止倒计时  
			},
			
			async getQiquanOrder() {
				const result = await this.$http.post(`api/qiquan/getQiquanOrder`, {
					id: this.id,
				});
				console.log(`assets:`, result);
				if (!result) return false;
				uni.hideLoading()
				this.connect()
				this.info=result;
				if(this.info.miao==0){
				}else{
					this.countdown=this.info.miao
					this.startCountdown();
				}
			},
			


			// 获取账户 資產 信息 (每次切換買賣時，都調用一次該函數)
			async getAccountAssets() {
				const result = await this.$http.post(`api/user/assets`, {
					type: 1, // 合約賬戶
					name: 'USDT',
				});
				console.log(`assets:`, result);
				if (!result) return false;
				this.userInfo = result[0];
			},

			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/fastInfo`);
				if (!result) return false;
				// 处理杠杆，后端数据返回不一致。
				this.leverList = this.$util.leverList(result.ganggan);
				console.log('leverList:', this.leverList);
			},


			// websocket链接
			connect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_COIN_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.info(`success res:`, res);
					},
					fail: (res) => {
						console.info(`fail res:`, res);
					}
				});
				console.log(`socket:`, this.socket);
				if (this.socket) {
					this.socket.onOpen((res) => {
						console.info("socket onOpen:", res)
					});
					uni.onSocketError((res) => {
						console.info("onSocketError:" + res)
					});
					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);
						if (this.info.code == data.market && data.lastPrice > 0) {
							// console.log('data:', data);
							this.info.current_price = data.lastPrice || 0;
							// this.info.rate_num = data.rate_num || 0;
							// this.info.vol = data.vol || 0;
						}

					});
				}
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
			},
		},
	}
</script>

<style lang="scss" scoped>
	.common_header {
		padding: 40rpx;
		display: flex;
		align-items: center;
		padding-top: 30px;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 500;
			padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: left;
		}
	}
</style>