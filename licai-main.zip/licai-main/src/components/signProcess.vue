<template>
	<ul :class="[customClass, 'sign-process', wrapClass,scroll]">
		<li v-for="(item, index) in formatData" :key="index" :class="[itemClass, 'sign-process__item']">
			<div class="sign-process__item__content">
				<template v-if="item.isPlaceholder">
					<div class="sign-process__item__content__middle" />
				</template>
				<template v-else>
					<div class="sign-process__item__content__bottom"><span>{{item.day}}</span>{{$t('utils.day')}}</div>
					<div class="sign-process__item__content__top">
						<div class="moneyMark">{{item.value}}</div>
						<div class="get_bag">
							<img src="../views/images/sign/bag.png" alt="">
						</div>
						<!-- <img :src="require('../assets/images/'+ item.type + '_over.png')" v-if="item.getstatus == 2" alt="" />
						<img :src="require('../assets/images/'+ item.type + '.png')" v-else alt="" /> -->
						<div class="get_gift no_get" v-if="item.getstatus == 1" @click="getAward($event,item.id)">{{$t('sign.sign')}}</div>
						<div class="get_gift over" v-if="item.getstatus == 2">{{$t('sign.signed')}}</div>
						<div class="get_gift no_get" v-if="item.getstatus == 0">{{$t('sign.signing')}}</div>
					</div>
					<!-- <div :class="[{'sign-process__item__content__middle--active': active >= item.day}, 'sign-process__item__content__middle']" /> -->
				</template>
			</div>
			<!-- <div class="tail" v-if="formatData.length - 1 !== index" /> -->
		</li>
	</ul>
</template>

<script>
    import Fetch from '../utils/fetch';
	export default {
		name: "SignProcess",
		props: {
			customClass: String,
			active: {
				type: Number,
				default: -1
			},
			data: {
				type: Array,
				default () {
					return []
				}
			},
			maxNum: {
				type: Number,
				default: 5
			}
		},
		data() {
			return {}
		},
		computed: {
			formatData() {
				const length = this.data.length
				const diff = this.maxNum - length

				if (diff > 0) {
					return [...this.data, ...new Array(diff).fill({
						isPlaceholder: true
					})]
				}

				return this.data
			},
			scroll(){
				return {
					'scroll': this.data.length > this.maxNum
				}
			},
			wrapClass() {
				return {
					'sign-process--flex': this.data.length <= this.maxNum,
				}
			},
			itemClass() {
				return {
					'sign-process__item--flex': this.data.length <= this.maxNum,
					'sign-process__item--20': this.data.length > this.maxNum,
				}
			}
		},
		created() {},
		mounted() {},
		methods: {
            getAward(ev,id){
                console.log(id);
                Fetch('/housing/signin/receive',{
                    reward_id: parseInt(id)
                }).then(r=>{
                    this.$parent.init();
                })
            }
        }
	}
</script>

<style lang="less" scoped>
	ul,
	li {
		list-style: none;
		margin: 0px;
		padding: 0px;
	}

	.sign-process::-webkit-scrollbar {
		display: none;
	}
	.scroll{
		overflow-x: scroll !important;
	}

	.sign-process {
		font-size: 12px;
		width: 100%;
		overflow-x: hidden;
		overflow-y: hidden;
		white-space: nowrap;
		height: 100px;
		
		.sign-process__item{
			display: inline-block;
			width: 62.5px;
			margin-right: 15px;
			
			.sign-process__item__content__bottom{
				text-align: center;
				margin-bottom: 10px;
			}
			
			.sign-process__item__content__top{
				background-color: #f0f0f2;
				border-radius: 5px;
				overflow: hidden;
				
				.moneyMark{
					text-align: center;
					color: #f65246;
					font-weight: bold;
					line-height: 16px;
					padding-top: 4px;
				}
				
				.get_gift{
					line-height: 18px;
					text-align: center;
					
					&.over{
						color: #fff;
						background-image: linear-gradient(to right,#ff5252,#ff8244);
					}
					
					&.no_get{
						color: #a8a8a8;
						background: #d5d5d5;
					}
				}
				
				.get_bag{
					height: 40px;
					display: flex;
					align-items: center;
					justify-content: center;
					img{
						width: 36px;
						height: 28px;
					}
				}
			}
		}
		
	}
</style>
