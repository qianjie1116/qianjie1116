// 配置全局访问接口地址
// let commonUrl = "//h5test.ag-lotre.com";
let commonUrl = "https://www.marriottfm.top";//优选社区源码网 yxymk.net yxymk.com yxymk.net
 
let baseUrl = {
    commonUrl
}
 
export default baseUrl