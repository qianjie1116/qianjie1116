<template>
  <div class="basic_wrap">
    <div class="red_top_bg">
      <div class="back_left" @click="$router.back()"></div>
      <div class="big_tit">{{ data.title }}</div>
    </div>
    <div class="item-main">
      <div class="item_img"><img :src="data.img" /></div>
      <div class="items_3">
        <div class="item">
          <div class="item_div1">
            <img v-if="data.cover" :src="data.cover" alt="" />
            <img v-else src="../../views/images/new/btc.png" alt="" />
            <span>{{ data.title }}</span>
            <!-- <p>每日可赚100.00</p> -->
          </div>
          <div class="item-body">
            <div class="item_div2">
              <div class="item_rate">
                <p>{{ data.rate }}%</p>
                <p>{{ $t("utils.dailyIncome") }}</p>
              </div>
              <!-- <div class="item_day">
							<p>{{data.day}}{{$t('utils.day')}}</p>
							<p>{{$t('utils.cycle')}}</p>
						</div> -->
              <!-- <template v-if="timeLeft > 0"> -->

              <!-- </template> -->
              <div class="item_min">
                <p>{{ data.min }}</p>
                <p>{{ $t("utils.startingAmount") }}</p>
              </div>
              <!-- <div style="width: 33%">
                <van-count-down :time="timeLeft" />
                <p style="color: #999; font-size: 14px">
                  {{ $t("utils.cycle") }}
                </p>
              </div> -->
            </div>
            <div class="item_div4">
              <div class="flex_bd">
                <div class="item-per">
                  <span
                    >{{ $t("utils.scale") }}:{{ $t("utils.moneyMark")
                    }}{{ data.total }}</span
                  >
                </div>

                <!-- <template v-if="timeLeft <= 0"> -->
                  <div class="item-progress">
                    <div class="flex_bd">
                      <van-progress
                        track-color="#b8b8b8"
                        color="#eb4718"
                        :percentage="data.percent"
                      />
                    </div>
                    <span class="item-pv">{{ data.percent }}%</span>
                  </div>
                <!-- </template> -->
              </div>
              <div class="item_btn">
                <button v-if="data.percent < 100" type="button" @click="buy(i)">
                  {{ $t("utils.invest") }}
                </button>
                <button
                  class="item_btn_over"
                  v-if="data.percent >= 100"
                  type="button"
                >
                  {{ $t("utils.investOver") }}
                </button>
              </div>
            </div>
          </div>
        </div>
        <div class="item_content" v-html="data.content"></div>
      </div>
    </div>
    <van-dialog
      v-model="show_tz"
      theme="round-button"
      @confirm="confirm"
      :confirmButtonText="$t('utils.confirm')"
    >
      <div class="close-x" @click="show_tz = false">
        <van-icon name="cross" />
      </div>
      <div class="show-body">
        <div class="sw-cell">
          <div class="sw-label">{{ data.title }}</div>
          <div class="sw-bar">
            <div class="flex_bd">
              <van-field
                v-model="number"
                type="number"
                :placeholder="$t('item.inputAmount')"
              />
            </div>

            <div class="ut">PHP</div>
          </div>
        </div>
        <div class="sw-grid">
          <div class="flex_bd">
            <div class="sw-row">
              <div class="sw-info">{{ $t("utils.yuji_sy") }}</div>
              <div class="sw-val">
                {{ ((data.rate * number) / 100).toFixed(5) }}
              </div>
            </div>
            <div class="sw-row">
              <div class="sw-val text-green">{{ data.rate }}% [ PHP ]</div>
              <div class="sw-info">{{ $t("utils.cankao_info") }}</div>
            </div>
          </div>
          <!-- <div class="sw-right">
            <div class="sw-label">PHP</div>
            <div class="sw-lg">{{ data.day }}{{ $t("utils.day") }}</div>
            <div class="sw-info">{{ $t("utils.cycle") }}</div>
          </div> -->
        </div>
        <div class="sw-end">
          <div class="flex_bd">
            {{ $t("utils.tz_auto") }}
          </div>
          <van-switch
            v-model="checked"
            @change="changeAuto"
            active-color="#ff6034"
            inactive-color="#dcdee0"
            size="24px"
          />
        </div>
      </div>
      <!-- <div class="items_3">
			<div class="item">
				<div class="item_div1">
					<p>
						{{data.title}}
					</p>
				</div>
				<div class="item_div2">
					<div class="item_rate">
						<p>{{data.rate}}%</p>
						<p>{{$t('utils.dailyIncome')}}</p>
					</div>
					<div class="item_day">
						<p>{{data.day}}{{$t('utils.day')}}</p>
						<p>{{$t('utils.cycle')}}</p>
					</div>
					<div class="item_min">
						<p>{{$t('utils.moneyMark')}}{{data.min}}</p>
						<p>{{$t('utils.startingAmount')}}</p>
					</div>
				</div>
			</div>
		</div>
		<van-field v-model="number" type="number" :placeholder="$t('item.inputAmount')"/> -->
    </van-dialog>
  </div>
</template>

<script>
import Fetch from "../../utils/fetch";
import Vue from "vue";
import { Progress, Dialog, Field, Switch, CountDown } from "vant";
Vue.use(Progress).use(Dialog).use(Field).use(Switch).use(CountDown);
export default {
  name: "itemDetail",
  data() {
    return {
      data: {},
      auto_close: [],
      show_tz: false,
      number: "",
      checked: true,
      timeLeft: 0,
    };
  },
  created() {
    this.$parent.footer("item", false);
  },
  mounted() {
    this.start();
  },
  methods: {
    start() {
      Fetch("/index/item_detail", {
        id: this.$router.history.current.params.code,
      }).then((res) => {
        this.data = res.data;
        console.log(`data:`, this.data);
        const temp = 15 * 60 * 1000;
        this.timeLeft = this.data.startTiem || temp;
      });
      Fetch("/index/item_auto").then((r) => {
        for (var i = 0; i < r.data.ids.length; i++) {
          this.auto_close.push(parseInt(r.data.ids[i]));
        }
      });
    },
    changeAuto(e) {
      console.log(e);
      Fetch("/index/item_auto_c", {
        pid: this.sku.id,
        tz_auto: this.checked ? 1 : 0,
      })
        .then((r) => {})
        .catch((err) => {
          this.psd_val = "";
        });
    },
    buy(item) {
      if (this.auto_close.indexOf(this.data.id) != -1) {
        this.checked = false;
      } else {
        this.checked = true;
      }
      this.show_tz = true;
    },
    confirm() {
      if (!this.number) {
        this.$toast({
          className: "toastName",
          message: this.$t("item.inputAmount"),
        });
        return false;
      }
      Fetch("/index/item_apply", {
        id: this.data.id,
        money: this.number,
      })
        .then((r) => {
          this.$router.push("/order");
        })
        .catch((err) => {
          this.number = "";
        });
    },
  },
};
</script>

<style lang="less" scoped>
/deep/ .van-cell {
  padding: 0px 26px;
}
/deep/ .van-count-down {
  color: #323233;
  font-size: 14px;
  line-height: 14px;
  font-weight: 700;
}
.red_top_bg {
  position: fixed;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  z-index: 10;
}

.back_left {
  background: url(../../views/images/item/back_b.png) no-repeat center center;
}

.big_tit {
  left: 40px;
  width: 90%;
  transform: none;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.item_img {
  img {
    width: 100%;
  }
}

.items_3 {
  .item {
    background: #ffffff;
    margin-bottom: 15px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    .item_div1 {
      display: flex;
      align-items: center;
      border-bottom: 1px solid #ececec;
      background-color: #f5f5f5;
      padding: 10px 15px;
      span {
        font-size: 16px;
      }
      img {
        width: 28px;
        height: 28px;
        margin-right: 10px;
      }
      p:nth-child(1) {
        // width: 90%;
        font-weight: bold;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      p:nth-child(2) {
        color: #999;
      }
    }

    .item_div2 {
      display: flex;
      justify-content: space-between;
      text-align: center;
      padding: 0 12px;
      font-size: 14px;
      .item_div_sub {
        width: 33.33%;

        p {
          padding: 5px 0;
        }
      }

      .item_rate {
        p:nth-child(1) {
          font-weight: bold;
          color: #ff0000;
        }

        p:nth-child(2) {
          color: #999;
        }
      }

      .item_day {
        p:nth-child(1) {
          font-weight: bold;
        }

        p:nth-child(2) {
          color: #999;
        }
      }

      .item_min {
        p:nth-child(1) {
          font-weight: bold;
        }

        p:nth-child(2) {
          color: #999;
        }
      }
    }

    .item_div3 {
      color: #999;
      padding: 5px 10px;
    }
    .flex_bd {
      flex: 1;
      margin: 0;
    }

    .item_div4 {
      padding: 0 15px;
      margin-top: 15px;
      .item-per {
        color: #999999;
        margin-bottom: 10px;
      }
      .flex_bd {
        flex: 1;
      }
    }
    .item_btn {
      left: 15px;
      right: 15px;
      position: absolute;
      bottom: 15px;
      button {
        width: 100%;
        color: #e93827;
        padding: 12px 5px;
        border-radius: 5px;
        border: 1px solid #e93827;
        background: #ffffff;
      }
      .item_btn_over {
        color: #999;
        border: 1px solid #999;
      }
    }
  }
  .item_content {
    background: #ffffff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    border-radius: 10px;
    padding: 10px;
    line-height: 20px;
  }
}
.item-main {
  padding: 15px;
  margin-top: 44px;
}
.item_img {
  margin-bottom: 15px;
  font-size: 0;
}
.item-progress {
  display: flex;
  align-items: center;
  background-color: #e9e9e9;
  padding: 2px 5px;
  border-radius: 40px;
  /deep/ .van-progress__pivot {
    display: none;
  }
  .item-pv {
    display: block;
    line-height: 1;
    color: #e82637;
    margin-left: 10px;
  }
}
.item-body {
  padding: 15px 0;
}
.show-body {
  padding: 20px;
  font-size: 14px;
  .sw-label {
    margin-bottom: 10px;
  }
  .sw-bar {
    display: flex;
    align-items: center;
    background-color: #f5f5f5;
    padding: 10px;
    border-radius: 4px;
    .flex_bd {
      color: #999999;
    }
  }
}
.sw-grid {
  display: flex;
  align-items: flex-end;
  margin-top: 20px;
  .sw-row:first-child {
    margin-bottom: 20px;
  }
  .sw-row > div:first-child {
    margin-bottom: 10px;
  }

  .sw-info {
    color: #999;
  }
  .sw-val.text-green {
    font-size: 16px;
  }
}
.sw-right {
  text-align: center;
  .sw-lg {
    font-size: 24px;
    margin-bottom: 10px;
  }
}

.flex_bd {
  flex: 1;
}
</style>
