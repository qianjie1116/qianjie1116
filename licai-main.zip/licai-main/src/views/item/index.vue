<template>
  <div class="basic_wrap">
    <div class="red_top_bg">
      <div class="back_left" @click="$router.back()"></div>
      <div class="big_tit">{{ $t("home.item") }}</div>
      <div class="msg" @click="$router.push('/notice')">
        <img src="../images/invest/msg.png" />
      </div>
    </div>
    <!-- <div class="item_wrap">
			<div class="tabs">
				<div class="tabs-head">
					<div class="tabs-head-scroll">
						<div class="tab-item" :class="active==index?'tab-item-active':''" v-for="(item,index) in tabs1"
							@click="sort(index)">
							<div class="tab-icon">
								<img :src="item.icon" alt="">
							</div>
							<div class="tab-title">
								{{item.title}}
							</div>
						</div>
					</div>
				</div>
				<van-tabs v-model="active" @click="sort">
			  		<van-tab v-for="index in tabs" :title="index"></van-tab>
			  	</van-tabs>
			</div> -->
    <div class="items_3 item_margin">
      <van-empty v-if="listLength == 0" :description="$t('item.noData')" />
      <div v-for="i in list" :key="i.id" class="item">
        <div class="item_div1" @click="$router.push('/item/' + i.id)">
          <img v-if="i.cover" class="icon round" :src="i.cover" alt="" />
          <img v-else class="icon round" src="../images/invest/bi.png" alt="" />
          <p>
            {{ i[lang] }}
          </p>
        </div>
        <div class="item_div2" @click="$router.push('/item/' + i.id)">
          <div class="item_rate">
            <p>{{ i.rate }}%</p>
            <p>{{ $t("utils.dailyIncome") }}</p>
          </div>
          <!-- <div class="item_day">
            <p>{{ i.day }}{{ $t("utils.day") }}</p>
            <p>{{ $t("utils.cycle") }}</p>
          </div> -->
          <div>
            <van-count-down :time="i.timeLeft" />
            <p style="color: #999; font-size: 14px">
              {{ $t("utils.cycle") }}
            </p>
          </div>
          <div class="item_min">
            <p>{{ i.min }}</p>
            <p>{{ $t("utils.startingAmount") }}</p>
          </div>
        </div>
        <div class="item_div3">
          <span>{{ $t("utils.scale") }}:{{ i.total }}</span>
          <!-- <span>   按日收益，到期还本</span> -->
        </div>
        <div class="item_div4">
          <template v-if="i.timeLeft <= 0">
            <div class="item_progress">
              <div class="progress_bd">
                <van-progress
                  :percentage="i.percent"
                  stroke-width="4.5"
                  track-color="#b8b8b8"
                  color="#eb4718"
                  :show-pivot="false"
                />
              </div>
              <span>{{ i.percent }}%</span>
            </div>
          </template>
          <div class="item_btn" style="margin-left: auto">
            <button v-if="i.percent < 100" type="button" @click="buy(i)">
              {{ $t("utils.invest") }}
            </button>
            <button v-if="i.percent >= 100" class="item_btn_over" type="button">
              {{ $t("utils.investOver") }}
            </button>
          </div>
        </div>
      </div>
    </div>
    <van-dialog
      v-model="show_tz"
      theme="round-button"
      @confirm="confirm"
      :confirmButtonText="$t('utils.confirm')"
      closeOnClickOverlay
    >
      <div class="close-x" @click="show_tz = false">
        <van-icon name="cross" />
      </div>
      <div class="show-body">
        <div class="sw-cell">
          <div class="sw-label">{{ sku[lang] }}</div>
          <div class="sw-bar">
            <div class="flex_bd">
              <van-field
                v-model="number"
                type="number"
                :placeholder="$t('item.inputAmount')"
              />
            </div>
            <div class="ut">PHP</div>
          </div>
        </div>
        <div class="sw-grid">
          <div class="flex_bd">
            <div class="sw-row">
              <div class="sw-info">{{ $t("utils.yuji_sy") }}</div>
              <div class="sw-val">
                {{ ((sku.rate * number) / 100).toFixed(5) }}
              </div>
            </div>
            <div class="sw-row">
              <div class="sw-val text-green">{{ sku.rate }}% [ PHP ]</div>
              <div class="sw-info">{{ $t("utils.cankao_info") }}</div>
            </div>
          </div>
          <!-- <div class="sw-right">
            <div class="sw-label">PHP</div>
            <div class="sw-lg">{{ sku.day }}{{ $t("utils.day") }}</div>
            <div class="sw-info">{{ $t("utils.cycle") }}</div>
          </div> -->
        </div>
        <div class="sw-end">
          <div class="flex_bd">
            {{ $t("utils.tz_auto") }}
          </div>
          <van-switch
            v-model="checked"
            @change="changeAuto"
            active-color="#ff6034"
            inactive-color="#dcdee0"
            size="24px"
          />
        </div>
      </div>
      <!-- <div class="items_3">
					<div class="item">
						<div class="item_div1">
							<img src="../images/invest/bi.png" class="icon" alt="">
							<p>
								{{ sku[lang] }}
							</p>
						</div>
						<div class="item_div2">
							<div class="item_rate">
								<p>{{sku.rate}}%</p>
								<p>{{$t('utils.dailyIncome')}}</p>
							</div>
							<div class="item_day">
								<p>{{sku.day}}{{$t('utils.day')}}</p>
								<p>{{$t('utils.cycle')}}</p>
							</div>
							<div class="item_min">
								<p>{{$t('utils.moneyMark')}}{{sku.min}}</p>
								<p>{{$t('utils.startingAmount')}}</p>
							</div>
						</div>
					</div>
				</div> -->
    </van-dialog>
  </div>
  <!-- </div> -->
</template>
<script>
import Fetch from "../../utils/fetch";
import Api from "../../interface/index";
import Vue from "vue";
import {
  Tab,
  Tabs,
  Progress,
  Empty,
  Dialog,
  Field,
  Sticky,
  Switch,
  CountDown,
} from "vant";
Vue.use(Tab)
  .use(Tabs)
  .use(Progress)
  .use(Empty)
  .use(Dialog)
  .use(Field)
  .use(Sticky)
  .use(Switch)
  .use(CountDown);
export default {
  name: "item",
  data() {
    return {
      lang: this.$i18n.locale || "zh_cn",
      tabs: [
        this.$t("item.all"),
        this.$t("item.tab1"),
        this.$t("item.tab2"),
        this.$t("item.tab3"),
        this.$t("item.tab4"),
        this.$t("item.tab5"),
      ],
      tabs1: [
        {
          icon: require("../images/invest/icon1.png"),
          title: this.$t("item.all"),
        },
        {
          icon: require("../images/invest/icon2.png"),
          title: this.$t("item.tab1"),
        },
        {
          icon: require("../images/invest/icon3.png"),
          title: this.$t("item.tab2"),
        },
        {
          icon: require("../images/invest/icon4.png"),
          title: this.$t("item.tab3"),
        },
        {
          icon: require("../images/invest/icon1.png"),
          title: this.$t("item.tab4"),
        },
        {
          icon: require("../images/invest/icon2.png"),
          title: this.$t("item.tab5"),
        },
      ],
      active: 0,
      auto_close: [],
      data: [],
      listLength: 0,
      show_tz: false,
      number: "",
      sku: [],
      checked: true,
      list: [], // 列表数据
    };
  },
  created() {
    this.$parent.footer("item");
  },
  mounted() {
    var type = 0;
    if (this.$router.history.current.query.type) {
      this.active = parseInt(this.$router.history.current.query.type);
    }
    this.start(type);
  },
  methods: {
    // 转时间戳
    convertToTimestamp(dateString) {
      const date = new Date(dateString);
      return date.getTime();
    },

    start(type) {
      Fetch("/index/item_search", {
        name: "",
        index_type: type,
      }).then((r) => {
        this.data = r.data;
        this.listLength = r.data.list.length;
        console.log(`???`, this.data.list);
        let temp = [];
        this.data.list.forEach((item) => {
          let result = 0;
          console.log(item.starttime);
          // 启动倒计时的时间
          const start = !item.starttime
            ? null
            : this.convertToTimestamp(item.starttime);
          // 默认倒计时值 。即开始后的15分钟
          const target = !item.duringtime ? null : item.duringtime * 60 * 1000;
          // 当前时间
          const curTime = this.convertToTimestamp(item.systemtime);

          // 当前时间 >= 开始时间 && 当前时间 <开始时间+延时
          if (
            start &&
            target &&
            curTime >= start &&
            curTime <= start + target
          ) {
            result = target - (curTime - start);
          } else {
            result = 0;
          }
          temp.push({
            ...item,
            timeLeft: result,
          });
          console.log(item);
        });
        this.list = temp;
      });
      Fetch("/index/item_auto").then((r) => {
        for (var i = 0; i < r.data.ids.length; i++) {
          this.auto_close.push(parseInt(r.data.ids[i]));
        }
      });
    },
    sort(type) {
      this.active = type;
      this.start(type);
    },
    changeAuto(e) {
      console.log(e);
      Fetch("/index/item_auto_c", {
        pid: this.sku.id,
        tz_auto: this.checked ? 1 : 0,
      })
        .then((r) => {})
        .catch((err) => {
          this.psd_val = "";
        });
    },
    buy(item) {
      this.sku = item;
      if (this.auto_close.indexOf(item.id) != -1) {
        this.checked = false;
      } else {
        this.checked = true;
      }
      this.show_tz = true;
    },
    confirm() {
      if (!this.number) {
        this.$toast({
          className: "toastName",
          message: this.$t("item.inputAmount"),
        });
        return false;
      }
      Fetch("/index/item_apply", {
        id: this.sku.id,
        money: this.number,
      })
        .then((r) => {
          this.$router.push("/order");
        })
        .catch((err) => {
          // this.psd_val = '';
        });
    },
  },
};
</script>

<style lang="less" scoped>
/deep/ .van-cell {
  padding: 15px 26px;
}
/deep/ .van-count-down {
  color: #323233;
  font-size: 14px;
  line-height: 14px;
  font-weight: 700;
}
.tabs {
  background-color: #fff;
  padding: 16px 0 10px 0;
  border-bottom: 1px solid #ececec;
  position: fixed;
  width: 100%;
}

.tabs-head {
  height: 73px;
  overflow: hidden;
  position: relative;

  .tabs-head-scroll {
    width: 100%;
    height: 80px;
    overflow: scroll;
    white-space: nowrap;

    .tab-item {
      display: inline-block;
      text-align: center;
      width: 25%;
      // margin-right: 28px;

      .tab-icon {
        height: 51px;

        img {
          height: 100%;
        }
      }

      .tab-title {
        padding: 5px 0;
        color: #666666;
      }
    }

    .tab-item-active {
      .tab-title {
        color: #333333;
      }
    }
  }
}

.red_top_bg {
  position: fixed;
  top: 0;
  z-index: 10;
  background-image: linear-gradient(to right, #ff5252, #ff8244);

  .msg {
    position: absolute;
    top: 15px;
    right: 15px;
    height: 18px;

    img {
      height: 100%;
    }
  }
}

.basic_wrap {
  position: relative;
}

.item_wrap {
  width: 100%;
  padding: 44px 0 0 0;

  .tabs {
    z-index: 100;
  }
}

.item_margin {
  margin-top: 60px !important;
}

.items_3 {
  margin: 10px 15px;

  .item {
    background: #ffffff;
  }
}

.items_3 {
  .item {
    margin-bottom: 20px;
    border-radius: 10px;
    overflow: hidden;
    border: 1px solid #ebebeb;
    box-shadow: 2px 2px 5px rgba(115, 115, 115, 0.35);

    // div{
    // 	margin: 5px 0;
    // }
    .item_div1 {
      display: flex;
      align-items: center;
      border-bottom: 1px solid #ececec;
      padding: 4px 10px;
      background-color: #f5f5f5;

      p:nth-child(2) {
        // width: 90%;
        font-weight: bold;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-size: 15px;
      }

      p:nth-child(3) {
        color: #999;
      }

      .icon {
        width: 32px;
        height: 32px;
        margin-right: 8px;
      }
    }

    .item_div2 {
      display: flex;
      justify-content: space-between;
      text-align: center;
      padding: 12px;
      font-size: 14px;

      .sub {
        width: 33.33%;

        p {
          padding: 5px 0;
        }
      }

      .item_rate {
        p:nth-child(1) {
          font-weight: bold;
          color: #ff0000;
          font-size: 15px;
        }

        p:nth-child(2) {
          color: #999;
          font-size: 12px;
        }
      }

      .item_day {
        p:nth-child(1) {
          font-weight: bold;
          font-size: 15px;
        }

        p:nth-child(2) {
          color: #999;
          font-size: 12px;
        }
      }

      .item_min {
        p:nth-child(1) {
          font-weight: bold;
          font-size: 15px;
        }

        p:nth-child(2) {
          color: #999;
          font-size: 12px;
        }
      }
    }

    .item_div3 {
      color: #999;
      padding: 0 12px;
    }

    .item_div4 {
      padding: 0 12px 10px;
      display: flex;
      align-items: center;
      justify-content: space-between;

      .item_progress {
        width: 71%;
        display: flex;
        align-items: center;
        justify-content: space-between;
        background-color: #e9e9e9;
        padding: 0 4px;
        border-radius: 12px;

        .progress_bd {
          width: 75%;
        }

        span {
          color: #e82637;
        }
      }

      .item_btn {
        width: 24%;
        text-align: right;

        button {
          min-width: 65px;
          color: #f44844;
          padding: 6px;
          border-radius: 5px;
          font-size: 13px;
          border: 1px solid #e82637;
        }

        .item_btn_over {
          color: #999;
          border: 1px solid #999;
        }
      }
    }
  }
}

/deep/ .van-tabs__line {
  height: 2px;
  background-color: #1989fa;
}

/deep/ .van-tab--active {
  color: #1989fa;
}

.show-body {
  padding: 20px;
  font-size: 14px;

  .sw-label {
    margin-bottom: 10px;
  }

  .sw-bar {
    display: flex;
    align-items: center;
    background-color: #f5f5f5;
    padding: 10px;
    border-radius: 4px;

    .flex_bd {
      color: #999999;
    }
  }
}

.sw-bar .van-cell {
  padding: 0;
  background-color: transparent;
}

.sw-grid {
  display: flex;
  align-items: flex-end;
  margin-top: 20px;

  .sw-row:first-child {
    margin-bottom: 20px;
  }

  .sw-row > div:first-child {
    margin-bottom: 10px;
  }

  .sw-info {
    color: #999;
  }

  .sw-val.text-green {
    font-size: 16px;
  }
}

.sw-right {
  text-align: center;

  .sw-lg {
    font-size: 24px;
    margin-bottom: 10px;
  }
}

.flex_bd {
  flex: 1;
}
</style>
