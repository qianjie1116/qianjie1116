<template>
  <div class="home_wrap">
    <div class="index_top_bg">
      <div class="language" @click="$router.push('/language')">
        <img :src="require('../images/language/' + lang + '.png')" />
        <span>{{ $t("lang.curtext") }}</span>
      </div>
      <!-- <div class="search_box" @click="$router.push('/search')">
		        <i class="fdj"></i>
		        <input type="text" readonly :placeholder="$t('index.search')" class="search_inp">
		        <div class="clear_inp"></div>
		    </div> -->
      <div class="msg" @click="$router.push('/notice')">
        <span class="iconfont icon-xiaoxi"></span>
      </div>
    </div>
    <!-- 优选社区源码网 yxymk.net yxymk.com yxymk.net -->
    <!-- <van-swipe :autoplay="2500" :width="290" class="swiper-container" @change="onChange">
			<van-swipe-item v-for="(image, index) in data.banner" :key="index">
				<router-link :to="image.url">
					<img :src="image[lang]">
				</router-link>
			</van-swipe-item>
			<div ref="dian" slot="indicator" class="custom-indicator">
				<div v-for="(img, x) in data.banner" :key="x" :class="x===0?'selected':''" />
			</div>
		</van-swipe> -->

    <div
      style="
        display: flex;
        align-items: center;
        font-size: 14px;
        margin-top: 8vh;
      "
    >
      <div style="margin-left: 10px; width: 48%; text-align: center">
        <div class="home_common home3">
          <p style="color: #fff">
            {{ $t("user.totalBalance") }}
            <!-- <van-icon name="eye-o" @click="eye = 0" /> -->
          </p>
          <p style="color: #fff; font-size: 16px">
            {{ !userInfo ? "" : userInfo.all_money }}PHP
          </p>
        </div>
      </div>
      <div style="margin: 10px 10px 10px 10px; width: 48%; text-align: center">
        <div class="home_common home3">
          <p style="color: #fff">
            {{ $t("user.availableBalance") }}
            <!-- <van-icon name="eye-o" @click="eye = 0" /> -->
          </p>
          <p style="color: #fff; font-size: 16px">
            {{ !userInfo ? "" : userInfo.ti_money }}PHP
          </p>
        </div>
      </div>
    </div>

    <template v-if="data">
      <div class="index-banner">
        <swiper ref="mySwiper" :options="swiperOption">
          <swiper-slide v-for="(image, index) in data.banner" :key="index">
            <router-link :to="image.url">
              <img :src="image[lang]" />
            </router-link>
          </swiper-slide>
        </swiper>
        <div class="swiper-pagination"></div>
      </div>
    </template>

    <div
      style="
        /* display: flex;
        align-items: center;
        justify-content: space-between; */
        font-size: 14px;
        margin: 10px;
        width: 100%;
      "
    >
      <div
        style="
          width: 30%;
          text-align: center;
          display: inline-block;
          margin-right: 10px;
        "
        @click="$router.push('/sign')"
      >
        <div class="home_common home1">
          <p style="color: #fff; font-size: large; line-height: 3.2">
            {{ $t("index.sign") }}
          </p>
        </div>
      </div>
      <div
        style="
          width: 30%;
          text-align: center;
          display: inline-block;
          margin-right: 10px;
        "
        @click="$router.push('/notice')"
      >
        <div class="home_common home4">
          <p style="color: #fff; font-size: large; line-height: 3.2">
            {{ $t("notice.message") }}
          </p>
        </div>
      </div>
      <div
        style="width: 30%; text-align: center; display: inline-block"
        @click="$router.push('/about')"
      >
        <div class="home_common home2">
          <p style="color: #fff; font-size: large; line-height: 3.2">
            {{ $t("index.aboutUs") }}
          </p>
        </div>
      </div>
    </div>

    <!-- <div v-show="loading" class="work_box" style="padding: 10px 20px">
      <div class="item" @click="$router.push('/sign')">
        <div class="item_img">
          <img src="../images/new/index-1.png" alt="" />
        </div>
        <p class="item_title">{{ $t("index.sign") }}</p>
      </div> -->

    <!-- <div class="item" @click="$router.push('/myTeam')">
        <div class="item_img">
          <img src="../images/new/index-2.png" alt="" />
        </div>
        <p class="item_title">{{ $t("index.invite") }}</p>
      </div>
      <div class="item" @click="$router.push('/invest')">
        <div class="item_img">
          <img src="../images/new/index-3.png" alt="" />
        </div>
        <p class="item_title">{{ $t("index.recharge") }}</p>
      </div>
      <div class="item" @click="$router.push('/cash')">
        <div class="item_img">
          <img src="../images/new/index-4.png" alt="" />
        </div>
        <p class="item_title">{{ $t("index.withdraw") }}</p>
      </div>
      <div class="item" @click="$router.push('/about/8')">
        <div class="item_img">
          <img src="../images/new/index-5.png" alt="" />
        </div>
        <p class="item_title">{{ $t("index.risk") }}</p>
      </div>
      <div class="item" @click="$router.push('/about/13')">
        <div class="item_img">
          <img src="../images/new/index-6.png" alt="" />
        </div>
        <p class="item_title">{{ $t("index.secret") }}</p>
      </div> -->
    <!-- <div class="item" @click="$router.push('/notice')">
        <div class="item_img">
          <img src="../images/about/icon1.png" alt="" />
        </div>
        <p class="item_title">{{ $t("notice.message") }}</p>
      </div>
      <div class="item" @click="$router.push('/about')">
        <div class="item_img">
          <img src="../images/new/index-8.png" alt="" />
        </div>
        <p class="item_title">{{ $t("index.aboutUs") }}</p>
      </div>
    </div> -->
    <div v-show="!loading" class="work_box query">
      <div v-for="i in 10" class="item">
        <div class="item_img" />
        <p class="item_title" />
      </div>
    </div>

    <template v-if="data">
      <div class="items-main">
        <!-- <div v-if="data.item1.show" class="items_panel items_1">
          <div class="items_header">
            <span class="tt-lg">{{ $t("item.tab1") }}</span>
            <span class="tit_tip">{{ $t("index.novice_tip") }}</span>
            <router-link class="tt-link" to="/item?type=1">
              <span class="tit_more">{{ $t("index.more") }}</span>
            </router-link>
          </div>
          <div v-for="i in data.item1.list" :key="i.id" class="item">
            <div
              class="item_tit flex_center"
              @click="$router.push('/item/' + i.id)"
            >
              <img v-if="i.cover" class="round" :src="i.cover" alt="" />
              <img
                v-else
                class="round"
                src="../../views/images/new/bch.png"
                alt=""
              />
              <div class="item-head">
                <span class="span-title">{{ i[lang] }}</span>
                <span class="iconfont icon-rt"></span>
              </div>
            </div>
            <div
              class="circle-cell wow bounce animated infinite duration"
              data-wow-delay="1s"
            >
              <van-circle
                v-model="i.rate"
                rate="30"
                speed="100"
                size="80px"
                layer-color="#e8e9ec"
                stroke-width="80"
                color="#ec5232"
              />
              <div class="item_rate" @click="$router.push('/item/' + i.id)">
                <p>{{ i.rate }}%</p>
              </div>
            </div>
            <div class="item_desc" @click="$router.push('/item/' + i.id)">
              <p>{{ $t("utils.cycle") }}:{{ i.day }}{{ $t("utils.day") }}</p>
              <p>{{ $t("utils.startingAmount") }}:{{ i.min }}</p>
            </div>
            <div class="item_btn">
              <button v-if="i.percent < 100" type="button" @click="buy(i)">
                {{ $t("utils.invest") }}
              </button>
              <button
                v-if="i.percent >= 100"
                class="item_btn_over"
                type="button"
              >
                {{ $t("utils.investOver") }}
              </button>
            </div>
          </div>
        </div>
        <div class="ads_box">
          <div class="ads_img" v-for="ad in data.ad2">
            <router-link :to="ad.url">
              <img :src="ad[lang]" alt="" />
            </router-link>
          </div> -->
        <!-- <div class="ads_img">
					<router-link to=""><img src="../../views/images/index/ad-left.png" alt=""></router-link>
				</div>
				<div class="ads_img">
					<router-link to=""><img src="../../views/images/index/ad-right.png" alt=""></router-link>
				</div>-->
        <!-- </div> -->
        <!-- <div v-if="data.item2.show" class="items_panel items_2">
          <div class="items_header">
            <span class="tt-lg">{{ $t("item.tab2") }}</span>
            <span class="tit_tip">{{ $t("index.hot_tip") }}</span>
            <router-link class="tt-link" to="/item?type=2">
              <span class="tit_more">{{ $t("index.more") }}</span>
            </router-link>
          </div>
          <div class="bs-panel">
            <div v-for="i in data.item2.list" :key="i.id" class="item">
              <div class="item_tit" @click="$router.push('/item/' + i.id)">
                <p>
                  {{ i[lang] }}
                </p>
                <p>{{ i["desc_" + lang] }}</p>
              </div>
              <div class="item_rate">
                <p>{{ i.rate }}%</p>
                <p>{{ $t("utils.dailyIncome") }}</p>
              </div>
              <div class="item_btn">
                <button v-if="i.percent < 100" type="button" @click="buy(i)">
                  {{ $t("utils.invest") }}
                </button>
                <button
                  v-if="i.percent >= 100"
                  class="item_btn_over"
                  type="button"
                >
                  {{ $t("utils.investOver") }}
                </button>
              </div>
            </div>
          </div>
        </div> -->
        <div class="ads_box">
          <div class="ads_img" v-for="ad in data.ad3">
            <router-link :to="ad.url">
              <img :src="ad[lang]" alt="" />
            </router-link>
          </div>
          <!--<div class="ads_img">
					<router-link to=""><img src="../../views/images/index/ad-left-2.png" alt=""></router-link>
				</div>
				<div class="ads_img">
					<router-link to=""><img src="../../views/images/index/ad-right-2.png" alt=""></router-link>
				</div>-->
        </div>
        <div v-if="data.item3.show" class="items_panel items_3">
          <div v-for="i in list" :key="i.id" class="item">
            <div class="item_div1" @click="$router.push('/item/' + i.id)">
              <img v-if="i.cover" class="round" :src="i.cover" alt="" />
              <img
                v-else
                class="round"
                src="../../views/images/new/btc.png"
                alt=""
              />
              <span>{{ i[lang] }}</span>
              <!-- <p>每日可赚100.00</p> -->
            </div>
            <div class="item-body">
              <div
                class="item_div2"
                style="padding: 0 12px"
                @click="$router.push('/item/' + i.id)"
              >
                <div>
                  <!-- 这里的图需要换成每个产品的图，等后端加字段。by 24.09.25 -->
                  <img :src="i.img" style="width: 64px; height: 32px" alt="" />
                </div>
                <div class="item_rate">
                  <p>{{ i.rate }}%</p>
                  <p>{{ $t("utils.dailyIncome") }}</p>
                </div>
                <!-- <div class="item_day">
                  <p>{{ i.day }}{{ $t("utils.day") }}</p>
                  <p>{{ $t("utils.cycle") }}</p>
                </div> -->
                <div class="item_min">
                  <p>{{ i.min }}</p>
                  <p>{{ $t("utils.startingAmount") }}</p>
                </div>
                <!-- <div>
                  <van-count-down :time="i.timeLeft" />
                  <p style="color: #999; font-size: 14px">
                    {{ $t("utils.cycle") }}
                  </p>
                </div> -->
              </div>
              <div class="item_div4">
                <div class="flex_bd">
                  <div class="item-per">
                    <span>{{ $t("utils.scale") }}:{{ i.total }}</span>
                  </div>
                  <!-- <template v-if="i.timeLeft <= 0"> -->
                  <div class="item-progress">
                    <div class="flex_bd">
                      <van-progress
                        track-color="#b8b8b8"
                        color="#eb4718"
                        :percentage="i.percent"
                      />
                    </div>
                    <span class="item-pv">{{ i.percent }}</span>
                  </div>
                  <!-- </template> -->
                </div>
                <div class="item_btn">
                  <button
                    v-if="i.percent < 100"
                    type="button"
                    @click="$router.push('/item/' + i.id)"
                  >
                    {{ $t("utils.invest") }}
                  </button>
                  <button
                    v-if="i.percent >= 100"
                    class="item_btn_over"
                    type="button"
                  >
                    {{ $t("utils.investOver") }}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </template>
    <van-dialog
      v-model="show_tz"
      theme="round-button"
      @confirm="confirm"
      :confirmButtonText="$t('utils.confirm')"
    >
      <div class="close-x" @click="show_tz = false">
        <van-icon name="cross" />
      </div>
      <div class="show-body">
        <div class="sw-cell">
          <div class="sw-label">{{ sku[lang] }}</div>
          <div class="sw-bar">
            <div class="flex_bd">
              <van-field
                v-model="number"
                type="number"
                :placeholder="$t('item.inputAmount')"
              />
            </div>
            <div class="ut">PHP</div>
          </div>
        </div>
        <div class="sw-grid">
          <div class="flex_bd">
            <div class="sw-row">
              <div class="sw-info">{{ $t("utils.yuji_sy") }}</div>
              <div class="sw-val">
                {{ ((sku.rate * number) / 100).toFixed(5) }}
              </div>
            </div>
            <div class="sw-row">
              <div class="sw-val text-green">{{ sku.rate }}% [ PHP ]</div>
              <div class="sw-info">{{ $t("utils.cankao_info") }}</div>
            </div>
          </div>
          <div class="sw-right">
            <div class="sw-label">PHP</div>
            <div class="sw-lg">{{ sku.day }}{{ $t("utils.day") }}</div>
            <div class="sw-info">{{ $t("utils.cycle") }}</div>
          </div>
        </div>
        <div class="sw-end">
          <div class="flex_bd">
            {{ $t("utils.tz_auto") }}
          </div>
          <van-switch
            v-model="checked"
            @change="changeAuto"
            active-color="#ff6034"
            inactive-color="#dcdee0"
            size="24px"
          />
        </div>
      </div>
      <!-- <div class="items_3">
			<div class="item">
				<div class="item_div1">
					<p>
						{{ sku[lang] }}
					</p>
				</div>
				<div class="item_div2">
					<div class="item_rate">
						<p>{{sku.rate}}%</p>
						<p>{{$t('utils.dailyIncome')}}</p>
					</div>
					<div class="item_day">
						<p>{{sku.day}}{{$t('utils.day')}}</p>
						<p>{{$t('utils.cycle')}}</p>
					</div>
					<div class="item_min">
						<p>{{$t('utils.moneyMark')}}{{sku.min}}</p>
						<p>{{$t('utils.startingAmount')}}</p>
					</div>
				</div>
			</div>
		</div> -->
    </van-dialog>

    <van-dialog
      v-model="show_tc"
      theme="round-button"
      @confirm="confirm"
      :confirmButtonText="$t('utils.confirm')"
    >
      <!-- <div class="popup" v-html="tc_content"></div> -->
      <div class="close-x" @click="show_tc = false">
        <van-icon name="cross" />
      </div>
      <div class="show-tc-body">
        <div class="popup" v-html="tc_content"></div>
      </div>
    </van-dialog>
    <div
      v-if="msg_show"
      class="kefu"
      :class="show_kefu ? 'show_kefu' : 'kefu_hide'"
      @click="kefu_to"
    >
      <img class="kefu_img" src="../images/index/down.png" />
    </div>
  </div>
</template>

<script>
import Vue from "vue";
import { WOW } from "wowjs";
import { swiper, swiperSlide } from "vue-awesome-swiper";
import "swiper/dist/css/swiper.css";
import Fetch from "../../utils/fetch";
import Api from "../../interface/index";
import { CountDown } from "vant";
Vue.use(CountDown);
import {
  Swipe,
  SwipeItem,
  Icon,
  Progress,
  Dialog,
  Field,
  Circle,
  Switch,
} from "vant";

Vue.use(Icon).use(Progress).use(Dialog).use(Field).use(Circle).use(Switch);

export default {
  name: "Index",
  components: {
    VanSwipe: Swipe,
    VanSwipeItem: SwipeItem,
    swiper,
    swiperSlide,
  },
  data() {
    return {
      eye: 1,
      userInfo: null,
      lang: this.$i18n.locale || "zh_cn",
      show_kefu: false,
      msg_show: true,
      loading: false,
      icon: [],
      auto_close: [],
      app_url: "",
      data: null,
      show_img: false,
      show_tz: false,
      show_tc: true,
      tc_content: "",
      number: "",
      sku: [],
      swiperOption: {
        centeredSlides: true,
        slidesPerView: "auto",
        loop: true,
        autoplay: {
          delay: 3000,
          stopOnLastSlide: false,
          disableOnInteraction: false,
        },
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
      },
      wowdata: "",
      checked: true,
      list: [], // 列表数据
    };
  },
  created() {
    this.$parent.footer("index");
  },
  watch: {
    wowdata() {
      this.$nextTick(() => {
        // 在dom渲染完后,再执行动画
        if (this.$wow) this.$wow.init();
      });
    },
  },
  mounted() {
    this.$nextTick(() => {
      if (this.$wow) this.$wow.init();
    });
    this.start();
    //代理标识设置
    if (this.$router.history.current.query.agent) {
      localStorage.setItem("agent", this.$router.history.current.query.agent);
    }
    console.log();
    var that = this;
    document.body.addEventListener(
      "scroll",
      function () {
        if (!that.show_kefu) {
          return;
        }
        that.show_kefu = false;
      },
      false
    );
    document.addEventListener(
      "click",
      function (ev) {
        if (ev.target.className != "kefu_img") {
          that.show_kefu = false;
        }
      },
      false
    );
  },
  methods: {
    kefu_to() {
      if (this.show_kefu) {
        this.$router.push("/kefu");
      }
      this.show_kefu = !this.show_kefu;
    },
    hideDown() {
      this.show_img = false;
      this.$store.commit("setShowAdvert", false);
    },
    // goD() {
    //   window.location.href = this.app_url;
    // },
    start() {
      Fetch("/index/int").then((r) => {
        //打包web请注释掉版本更新这段代码
        //-----------------------------------------

        let u = navigator.userAgent;
        let isAndroid = u.indexOf("Android") > -1 || u.indexOf("Linux") > -1;
        let isIOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);
        if (isAndroid) {
          // alert("我是安卓");
          this.app_url = r.data.version.android_app_down_url;
        }
        if (isIOS) {
          // alert("我是苹果");
          this.app_url = r.data.version.ios_app_down_url;
        }

        // if(window.plus){
        // let appVersion1 = plus.runtime.version;
        // let appVersion2 = r.data.version.app_version;
        // //版本号不同则更新APP
        // if(parseInt(appVersion1.split(".").join(""))<parseInt(appVersion2.split(".").join(""))){
        // 	this.$dialog.alert({
        // 	  title: 'APP更新',
        // 	  message: r.data.version.app_instructions,
        // 	}).then(() => {
        // 		let u = navigator.userAgent;
        // 		let isAndroid = u.indexOf("Android") > -1 || u.indexOf("Linux") > -1;
        // 		let isIOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/);
        // 		if (isAndroid) {
        // 		 // alert("我是安卓");
        // 			window.location.href = r.data.version.android_app_down_url;
        // 		}
        // 		if (isIOS) {
        // 		 // alert("我是苹果");
        // 		 window.location.href = r.data.version.ios_app_down_url;
        // 		}
        // 	});
        // }
        // }
        //-----------------------------------------
        this.data = r.data;
        this.loading = true;
        console.log(`???`, this.data.item3.list);
        let temp = [];
        this.data.item3.list.forEach((item) => {
          console.log(item);
          temp.push({
            ...item,
            timeLeft: 15 * 60 * 1000,
          });
          console.log(item);
        });
        this.list = temp;

        if (r.data.popup.show == 1) {
          this.tc_content = r.data.popup.content;
          this.show_tc = true;
        }
      });
      // Fetch("/index/item_auto").then((r) => {
      //   console.log(r);
      //   for (var i = 0; i < r.data.ids.length; i++) {
      //     this.auto_close.push(parseInt(r.data.ids[i]));
      //   }
      // });
      Fetch("/user/info").then((r) => {
        this.userInfo = r.data;
      });
    },
    onChange(index) {
      let els = this.$refs.dian.querySelectorAll("div");
      for (let i = 0; i < els.length; i++) {
        els[i].className = "";
      }
      els[index].className = "selected";
    },
    changeAuto(e) {
      Fetch("/index/item_auto_c", {
        pid: this.sku.id,
        tz_auto: this.checked ? 1 : 0,
      })
        .then((r) => {})
        .catch((err) => {
          this.psd_val = "";
        });
    },
    buy(item) {
      this.sku = item;
      // if (this.auto_close.indexOf(item.id) != -1) {
      //   this.checked = false;
      // } else {
      //   this.checked = true;
      // }
      // this.show_tz = true;
    },
    confirm() {
      // if(!this.number){
      // 	this.$toast(this.$t('item.inputAmount'));
      // 	return false;
      // }
      // Fetch("/index/item_apply", {
      //   id: this.sku.id,
      //   tz_auto: this.checked ? 1 : 0,
      //   money: this.number,
      // })
      //   .then((r) => {
      //     this.$router.push("/order");
      //   })
      //   .catch((err) => {
      //     this.psd_val = "";
      //   });
    },
  },
};
</script>

<style lang="less" scoped>
/deep/ .van-count-down {
  color: #323233;
  font-size: 14px;
  line-height: 14px;
  font-weight: 700;
}
.home_common {
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  line-height: 2.4;
  border-radius: 8px;
}
.home1 {
  background-image: url(../images/home/home1.png);
}
.home2 {
  background-image: url(../images/home/home2.png);
}
.home3 {
  background-image: url(../images/home/home3.png);
}
.home4 {
  background-image: url(../images/home/home4.png);
}
.home5 {
  background-image: url(../images/home/home5.png);
}

.text-green {
  color: #32a388;
}
.show-body {
  padding: 20px;
  font-size: 14px;
  .sw-label {
    margin-bottom: 10px;
  }
  .sw-bar {
    display: flex;
    align-items: center;
    background-color: #f5f5f5;
    padding: 10px;
    border-radius: 4px;
    .flex_bd {
      color: #999999;
    }
  }
}
.sw-grid {
  display: flex;
  align-items: flex-end;
  margin-top: 20px;
  .sw-row:first-child {
    margin-bottom: 20px;
  }
  .sw-row > div:first-child {
    margin-bottom: 10px;
  }

  .sw-info {
    color: #999;
  }
  .sw-val.text-green {
    font-size: 16px;
  }
}
.sw-right {
  text-align: center;
  .sw-lg {
    font-size: 20px;
    margin-bottom: 10px;
  }
}

.flex_bd {
  flex: 1;
}
.item-progress {
  display: flex;
  align-items: center;
  background-color: #e9e9e9;
  padding: 2px 5px;
  border-radius: 40px;
  /deep/ .van-progress__pivot {
    display: none;
  }
  .item-pv {
    display: block;
    line-height: 1;
    color: #e82637;
    margin-left: 10px;
  }
}
.items_header {
  display: flex;
  align-items: center;
  margin-bottom: 15px;
  .tt-lg {
    font-size: 16px;
  }
  .tit_tip {
    font-size: 12px;
    color: #999;
    margin-left: auto;
  }
  .tt-link {
    font-size: 12px;
    color: #999999;
    margin-left: 20px;
  }
}
/deep/ .van-cell {
  padding: 15px 26px;
}
.home_wrap {
  overflow: hidden;
  width: 100%;
  min-height: 100vh;
  background: url(../images/index/header.jpg) center top no-repeat;
  background-size: contain;
}
.index_top_bg {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px 16px;
  z-index: 10;
  .language {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding-right: 6px;
    height: 25px;
    border-radius: 25px;
    background-image: linear-gradient(to right, #ffff80, #ffffff);
    img {
      height: 100%;
    }
  }
  .msg {
    .icon-xiaoxi {
      color: #fff;
      font-size: 18px;
    }
    img {
      height: 100%;
    }
  }
}
.search_box {
  width: 80%;
  height: 29px;
  background-color: #f6f6f6;
  border-radius: 17px;
  margin: 8px 40px 0 40px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  padding: 0 10px 0 14px;

  .fdj {
    width: 16px;
    height: 16px;
    background: url(../images/item/fdj.png) no-repeat center center;
    background-size: 100% 100%;
  }

  .search_inp {
    flex: 1;
    margin: 0 8px;
    font-size: 14px;
    color: #000000;
    line-height: 20px;
    height: 20px;
  }

  .clear_inp {
    width: 20px;
    height: 20px;
    background: url(../images/item/clear.png) no-repeat center center;
    background-size: 100% 100%;
  }
}

.work_box {
  background: #ffffff;
  padding: 17px 8px 4px 8px;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  .item {
    width: 25%;
    text-align: center;
    margin-bottom: 10px;
    .item_img {
      width: 100%;
      border-radius: 5px;
      overflow: hidden;
      img {
        width: 52px;
        height: 52px;
      }
    }

    .item_title {
      width: 100%;
      line-height: 14px;
      font-size: 12px;
      color: #333333;
      text-align: center;
    }
  }
}

.work_box.query {
  .item {
    .item_img {
      border-radius: 5px;
      background: #f0f0f0;
    }

    .item_title {
      width: 100%;
      height: 14px;
      margin-left: 0;
      background: #f0f0f0;
    }
  }
}
.ads_box_1 {
  padding: 0 14px;
  margin-top: 15px;
  text-align: center;
  img {
    width: 100%;
  }
}
.ads_box {
  // background: rgba(255, 255, 255, 1);
  border-radius: 13px;
  display: flex;
  text-align: center;
  margin: 0 -6px;
  margin-bottom: 15px;
  .ads_img {
    flex: 1;
    padding: 0 6px;
  }
  img {
    width: 100%;
    border-radius: 5px;
  }
}
.items-main {
  padding: 15px;
}
.items_panel {
  margin-bottom: 15px;
}
.items_1,
.items_3 {
  .items_tit {
    border-radius: 5px 5px 0 0;
    height: 44px;
    line-height: 44px;
    font-size: 16px;
    color: rgba(0, 0, 0, 0.8);
    background: #ffffff;
    border-bottom: 1px solid #f7f7f7;
    padding: 0 14px;
    display: flex;
    justify-content: space-between;
    .tit_tip {
      display: contents;
      font-size: 12px;
      font-weight: normal;
      color: #b2b2b2;
      margin-left: 10px;
    }
    .tit_more {
      font-size: 12px;
      font-weight: normal;
      color: #b2b2b2;
    }
  }
  .item {
    background-color: #ffffff;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  }
}
.items_1 {
  .item {
    padding: 15px 20px;
    margin: 0 0 15px 0;
    background-image: url(../images/index/cardbg.png);
    background-position: center;
    background-size: cover;
    .item-head {
      flex: 1;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .item_tit {
      text-align: center;
      margin-bottom: 12px;
      .span-title {
        flex: 1;
        text-align: center;
        font-size: 16px;
        font-weight: bold;
      }
      .icon-rt {
        color: #eb483e;
        margin-left: 10px;
        display: flex;
        margin-left: auto;
        animation: rt 1s linear infinite;
      }
      img {
        width: 26px;
        height: 26px;
        margin-right: 10px;
      }
      p {
        text-overflow: ellipsis;
        white-space: nowrap;
        font-weight: bold;
        font-size: 16px;
      }
    }
    .item_rate {
      text-align: center;
      color: #eb483e;
      font-size: 18px;
      font-weight: bold;
    }
    .item_desc {
      display: flex;
      color: #999;
      margin-bottom: 12px;
      p {
        width: 50%;
        text-align: center;
      }
    }
    .item_btn {
      text-align: center;
      button {
        width: 60%;
        min-width: 60px;
        background-image: linear-gradient(to bottom right, #ed540b, #e82637);
        color: #ffffff;
        padding: 12px 0px;
        border-radius: 60px;
        font-size: 14px;
      }
      .item_btn_over {
        background: #999;
      }
    }
  }
}
.items_2 {
  .item {
    display: flex;
    align-items: center;
    width: 100%;
    padding: 0 15px;
    text-align: center;
    border-bottom: 1px solid #ececec;
    div {
      margin: 15px 0;
    }
    .item_rate {
      width: 20%;
      p {
        padding: 5px 0;
      }
      p:nth-child(1) {
        font-weight: bold;
        font-size: 14px;
        color: #f44844;
      }
      p:nth-child(2) {
        color: #999;
      }
    }
    .item_tit {
      text-align: left;
      width: 55%;
      p {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        padding: 5px 0;
      }
      p:nth-child(1) {
        font-weight: bold;
      }
      p:nth-child(2) {
        color: #999;
      }
    }
    .item_btn {
      margin-left: auto;
      button {
        min-width: 60px;
        color: #f44844;
        padding: 8px;
        border-radius: 5px;
        border: 1px solid #f44844;
      }
      .item_btn_over {
        color: #999;
        border: 1px solid #999;
      }
    }
  }
}
.items_3 {
  .item {
    margin-bottom: 15px;
    .item-body {
      padding: 15px 0;
    }
    .item_div1 {
      display: flex;
      align-items: center;
      border-bottom: 1px solid #ececec;
      background-color: #f5f5f5;
      padding: 15px 10px;
      span {
        font-size: 16px;
      }
      img {
        width: 28px;
        height: 28px;
        margin-right: 10px;
      }
      p:nth-child(1) {
        // width: 70%;
        font-weight: bold;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      p:nth-child(2) {
        color: #999;
      }
    }
    .item_div2 {
      display: flex;
      justify-content: space-between;
      text-align: center;
      font-size: 14px;
      .div_sub {
        width: 33.33%;
        p {
          padding: 5px 0;
        }
      }
      .item_rate {
        p:nth-child(1) {
          font-weight: bold;
          color: #f44844;
        }
        p:nth-child(2) {
          color: #999;
        }
      }
      .item_day {
        p:nth-child(1) {
          font-weight: bold;
        }
        p:nth-child(2) {
          color: #999;
        }
      }
      .item_min {
        p:nth-child(1) {
          font-weight: bold;
        }
        p:nth-child(2) {
          color: #999;
        }
      }
    }
    .item_div3 {
      color: #999;
      padding: 5px 10px;
    }
    .item_div4 {
      padding: 5px 10px;
      display: flex;
      align-items: flex-end;
      margin-top: 10px;
      .item-per {
        color: #999999;
        margin-bottom: 14px;
      }
      .flex_bd {
        flex: 1;
      }
      .item_btn {
        button {
          min-width: 75px;
          color: #f44844;
          padding: 8px;
          border-radius: 5px;
          border: 1px solid #f44844;
          margin-left: 10px;
        }
        .item_btn_over {
          color: #999;
          border: 1px solid #999;
        }
      }
    }
  }
}
.circle-cell {
  display: flex;
  justify-content: center;
  position: relative;
  margin-bottom: 10px;
  .item_rate {
    margin: 0 !important;
    text-align: center;
    width: 100%;
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
  }
}

.popup {
  -webkit-box-flex: 1;
  -webkit-flex: 1;
  flex: 1;
  max-height: 60vh;
  padding: 26px 24px;
  overflow-y: auto;
  font-size: 14px;
  line-height: 20px;
}
.bs-panel {
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
  border-radius: 10px;
  background-color: #ffffff;
}
.index-banner {
  position: relative;
}
.index-banner .swiper-slide {
  width: 290px;
  height: 150px;
  transform: scale(0.9);
  a {
    display: block;
    width: 100%;
    height: 100%;
  }

  img {
    border-radius: 6px;
    width: 100%;
    height: 150px;
  }
  &.swiper-slide-active {
    transform: scale(1);
  }
}
.swiper-pagination {
  width: 260px;
  text-align: right;
  left: 50%;
  margin-left: -130px;
  position: absolute;
  bottom: 10px;
  z-index: 22;
}
</style>
<style>
.swiper-pagination-bullet {
  margin: 0 2px;
  opacity: 1;
  border-radius: 4px;
  width: 18px;
  height: 4px;
  background-color: #ffffff;
}
.swiper-pagination-bullet-active {
  background-color: #d43e3f;
}
.sw-bar .van-cell {
  padding: 0;
  background-color: transparent;
}
.animated.infinite {
  -webkit-animation-iteration-count: infinite;
  animation-iteration-count: infinite;
}

.animated.duration {
  -webkit-animation-duration: 2s;
  animation-duration: 2s;
}
@-webkit-keyframes bounce {
  0%,
  20%,
  50%,
  80%,
  100% {
    -webkit-transform: translateY(0);
    transform: translateY(0);
  }

  40% {
    -webkit-transform: translateY(-15px);
    transform: translateY(-15px);
  }

  60% {
    -webkit-transform: translateY(-5px);
    transform: translateY(-5px);
  }
}

@keyframes bounce {
  0%,
  20%,
  50%,
  80%,
  100% {
    -webkit-transform: translateY(0);
    -ms-transform: translateY(0);
    transform: translateY(0);
  }

  40% {
    -webkit-transform: translateY(-15px);
    -ms-transform: translateY(-15px);
    transform: translateY(-15px);
  }

  60% {
    -webkit-transform: translateY(-5px);
    -ms-transform: translateY(-5px);
    transform: translateY(-5px);
  }
}
@keyframes rt {
  0% {
    transform: translateX(0px);
  }
  100% {
    transform: translateX(5px);
  }
}
.close-x {
  color: #999;
  position: absolute;
  right: 12px;
  top: 12px;
}
.close-x .van-icon {
  font-size: 20px;
}
.show-tc-body {
  padding: 40px 30px 20px 30px;
}
.show-title {
  text-align: center;
  font-size: 17px;
  color: #e82637;
  margin-bottom: 20px;
}
.show-cont {
  line-height: 1.8;
  padding: 0 20px;
  font-size: 14px;
}
.show-tc-body p:first-child {
  text-align: center;
  font-size: 17px;
  color: #e82637;
  margin-bottom: 20px;
}
.sw-end {
  display: flex;
  align-items: center;
  margin-top: 20px;
}
</style>
