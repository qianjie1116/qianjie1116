<template>
	<div class="basic_wrap">
		<div class="red_top_bg">
			<div class="back_left" @click="$router.back()"></div>
			<div class="big_tit">{{$t('home.activity')}}</div>
			<div class="msg" @click="$router.push('/notice')">
				<img src="../images/invest/msg.png">
			</div>
		</div>
		<div class="item_wrap">
			<div v-for="i in data.list" :key="i.id" class="item" @click="jump(i)">
				<img :src="i['img_'+lang]">
				<p>{{i['title_'+lang]}}</p>
				<p>{{i.time}}</p>
			</div>
		</div>
		<van-dialog
		v-model="show_ver" 
		theme="round-button"
		@confirm="confirm"
		:confirmButtonText="$t('utils.confirm')"
		>
		<div class="show-body">
			<div class="show-title">锁仓赚币介绍</div>
			<div class="show-cont">
				假如质押<span class="text-red">100SDT</span>利率<span class="text-red">5%</span><br>
				质押结束可获得<span class="text-red">105PHP</span>。<br>
				合同到期偿还本金和利润。
			</div>
		</div>
		</van-dialog>
	</div>
</template>

<script>
	import Fetch from '../../utils/fetch';
	import Api from "../../interface/index";
	export default {
		name: "activity",
		data() {
			return {
				lang: this.$i18n.locale || "zh_cn",
				data: {},
				show_ver:false,
			}
		},
		created() {
			this.$parent.footer('cart');
		},
		mounted() {
			this.start();
		},
		methods: {
			start() {
				Fetch('/index/activity_list').then(r => {
					this.data = r.data;
				})
			},
			jump(activity) {
				if (activity.url == "") {
					this.$router.push("/activity/" + activity.id);
				} else {
					this.$router.push(activity.url);
				}
			}
		},
	}
</script>

<style lang="less" scoped>
	.red_top_bg {
		position: fixed;
		top: 0;
		z-index: 10;
		background-image: linear-gradient(to right, #ff5252, #ff8244);

		.msg {
			position: absolute;
			top: 15px;
			right: 15px;
			height: 18px;

			img {
				height: 100%;
			}
		}
	}

	.basic_wrap {
		position: relative;
	}

	.big_tit {
		color: #fff;
	}

	.item_wrap {
		width: 100%;
		padding: 44px 0 0;

		.item {
			background: #FFFFFF;
			padding: 10px 15px;
			margin-bottom: 10px;
			border-bottom: 1px solid #ececec;
			border-top: 1px solid #ececec;

			img {
				width: 100%;
				border-radius: 5px;
			}

			p:nth-child(2) {
				padding: 10px 0;
				font-weight: bold;
				font-size: 15px;
			}

			p:nth-child(3) {
				color: #999;
			}
		}
	}
	.show-body{
		padding: 40px 30px 20px 30px;
	}
	.show-title{
		text-align: center;
		font-size: 17px;
		color: #e82637;
		margin-bottom: 20px;
	}
	.show-cont{
		line-height: 1.8;
		padding: 0 20px;
		font-size: 14px;
	}
	
	
	
</style>
