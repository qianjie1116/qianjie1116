<template>
	<div class="withdraw_wrap">
		<div class="red_top_bg">
			<div class="back_left" @click="$router.go(-1)"></div>
			<div class="big_tit">{{$t('cash.withdraw')}}</div>
		</div>
		<div class="balance" v-if="eye==1">
			<p>
				{{$t('invest.availableBalance')}}
				<van-icon name="eye" @click="eye=0" />
			</p>
			<p>
				{{data.ti_money}}
			</p>
		</div>
		<div class="balance" v-if="eye==0">
			<p>
				{{$t('invest.availableBalance')}}
				<van-icon name="closed-eye" @click="eye=1" />
			</p>
			<p>
				******
			</p>
		</div>
		<div class="wrap_box wrap1">
			<div class="choose_bank" @click="show=true">
				<div>
					<span>{{$t('cash.wallet')}}</span>
				</div>
				<div>
					<span>{{bank_name}}</span>
					<van-icon name="arrow" color="#999" />
				</div>
			</div>
			<!-- <van-action-sheet v-model="show" :actions="actions" cancel-text=""
				:description="this.$t('cash.chooseWallet')" close-on-click-action @select="onSelect">
			</van-action-sheet> -->
			<van-action-sheet v-model="show" cancel-text="" :description="this.$t('cash.chooseWallet')"
				close-on-click-action>
				<div class="content">
					<div class="action-item" v-for="item in actions" @click="onSelect(item)">
						<div class="item-icon">
							<img v-if="item.logo" :src="item.logo" alt="111">
							<img v-else src="../images/user/cash/bi.png" alt="222">
						</div>
						<div class="item-name">
							{{item.name}}
						</div>
						<div class="item-arrow">
							<van-icon name="arrow" color="#999" />
						</div>
					</div>
				</div>
			</van-action-sheet>
			<div class="withdraw_wrap">
				<p>{{$t('cash.amount')}}</p>
				<div class="flex_bd">
					<input v-model="form.money" type="number" step="0.01" class="inp"
						:placeholder="$t('cash.withdrawableAmount') +data.ti_money"
						@input="changeAmount">
				</div>
				<p>PHP</p>
			</div>


			<div class="withdraw_wrap">
				<p>{{$t('cash.charge')}}</p>
				<div class="flex_bd">
					<input  type="number" step="0.01" class="inp" disabled :value="fee*form.money*0.01">
				</div>
				<p>PHP</p>
			</div>

			<!-- <div class="withdraw_end">
				<p>{{chargeTip}}</p>
				<span>{{actualAmount}}</span>
			</div> -->
			<p class="canal_tips">{{$t('cash.arrivalTime')}}</p>
		</div>
		<div class="basic_btn" @click="write_psd = true;submitType = 1;">{{$t('utils.submit')}}</div>
		<van-popup v-model="write_psd" round position="bottom">
			<div class="psw_box">
				<div class="psw_content">
					<div class="psw_tips">{{$t('cash.tips')}}</div>
					<van-password-input :value="psd_val" :mask="true" :focused="showKeyboard"
						@focus="showKeyboard = true" />
					<div class="basic_btn psw_complete">{{$t('utils.complete')}}</div>
				</div>
				<div class="keybord_box">
					<div class="keybord">
						<div class="key_item" v-for="i in Keyboard" @click="onInput(i.number)">
							<div class="key_inner">{{i.number}}</div>
							<div class="key_letter">{{i.letter}}</div>
						</div>
						<div class="key_item no_bg" @click="write_psd = false">
							<div class="key_inner">{{$t('utils.cancel')}}</div>
						</div>
						<div class="key_item" @click="onInput(0)">
							<div class="key_inner">0</div>
							<div class="key_letter">abc</div>
						</div>
						<div class="key_item no_bg x" @click="onDelete">
							<div class="key_inner">{{$t('utils.delete')}}</div>
						</div>
					</div>
				</div>
			</div>
		</van-popup>
		<div v-show="setPwd" class="real_name_mask">
			<div class="real_box">
				<div class="tit" />
				<p class="tips">
					{{$t('cash.setPwdFirst')}}
				</p>
				<div class="basic_btn" @click="setIniPwd">
					{{$t('cash.setNow')}}
				</div>
			</div>
		</div>
	</div>
	</div>
</template>

<script>
	import Vue from 'vue';
	import Fetch from '../../utils/fetch'
	import {
		DropdownMenu,
		DropdownItem,
		Popup,
		PasswordInput,
		NumberKeyboard,
		Icon,
		ActionSheet
	} from 'vant';
	Vue.use(PasswordInput).use(NumberKeyboard).use(Popup).use(DropdownMenu).use(DropdownItem).use(Icon).use(ActionSheet);

	export default {
		name: "cost",
		data() {
			return {
				data: {},
				showKeyboard: true,
				write_psd: false,
				psd_val: '',
				chargeTip: '',
				charge: 0,
				form: {
					money: '',
					password: '',
					bank_id: 0,
				},
				eye: 1,
				show: false,
				bank_name: this.$t('cash.chooseWallet'),
				actions: [],
				setPwd: false,
				submitType: 1,
				type: 1,
				rate: 1,
				mark: "$",
				actualAmount: '',
				Keyboard: [{
					number: 1,
					letter: ""
				}, {
					number: 2,
					letter: "abc"
				}, {
					number: 3,
					letter: "def"
				}, {
					number: 4,
					letter: "ghi"
				}, {
					number: 5,
					letter: "jkl"
				}, {
					number: 6,
					letter: "mno"
				}, {
					number: 7,
					letter: "pqrs"
				}, {
					number: 8,
					letter: "tuc"
				}, {
					number: 9,
					letter: "wxyz"
				}],
				fee:0
			};
		},
		created() {
			this.$parent.footer('user', false);
		},
		mounted() {
			this.start();
		},
		methods: {
			onSelect(item) {
				this.chargeTip = "";
				this.actualAmount = "";
				this.form.money = "";
				this.show = false;
				this.bank_name = item.name;
				this.form.bank_id = item.value;
				this.charge = item.charge;
				this.type = item.type;
				this.rate = item.rate;
				this.mark = item.mark;
				if (item.charge > 0) {
					if(this.type == 1)
					{
						
						this.chargeTip = this.$t('cash.charge') + item.charge;
					}else{
						
						this.chargeTip = this.$t('cash.charge') + item.charge + "%";
					}
				} else {
					this.chargeTip = "";
				}
				if (item.value == 0) {
					this.$router.push('/addcountUsdt')
				}
			},
			changeAmount() {
				this.chargeTip = "";
				var rateTip = "";
				var num = 2;
				console.log(this.type);
				// if(this.rate!=1){
				if (this.type == 1) {
					
					
					this.actualAmount = "=" +  (this.form.money  - (this.charge*1).toFixed(2)) + this.mark;
					rateTip = "(=" + (1* this.charge).toFixed(2) + this.mark + ")";
					/*if (this.rate > 10000) {
						num = 8;
					} else if (this.rate > 1000) {
						num = 6;
					} else if (this.rate > 10) {
						num = 4;
					}
					this.actualAmount = "≈" + (this.form.money / this.rate).toFixed(num) + this.mark;
					rateTip = "(≈" + (this.form.money * this.charge / 100 / this.rate).toFixed(num) + this.mark + ")";*/
				}
				 
				 else {
					this.actualAmount = "≈" + this.mark + (this.form.money / this.rate).toFixed(0);
					rateTip = "(≈" + this.mark + (this.form.money * this.charge / this.rate / 100).toFixed(0) + ")";
				}
				// }
				if (this.charge > 0) {
					if(this.type == 1)
					{
						
						this.chargeTip = this.$t('cash.charge') + ":≈$" + (this.rate * this.charge).toFixed(num) +
							rateTip;
					}else{
						
						this.chargeTip = this.$t('cash.charge') + ":$" + (this.form.money * this.charge / 100).toFixed(num) +
							rateTip;
					}
				}
			},
			onInput(key) {
				this.psd_val = (this.psd_val + key).slice(0, 6);
				if (this.psd_val.length == 6) {
					this.write_psd = false;
					this.form.password = this.psd_val;
					if (this.submitType == 1) {
						this.submit();
					} else {
						this.setIniPwdSubmit();
					}

				}
			},
			onDelete() {
				this.psd_val = this.psd_val.slice(0, this.psd_val.length - 1);
			},
			subAll() {
				this.form.money = this.data.money;
			},
			start() {
				Fetch('/user/my_bank').then((r) => {
					this.data = r.data;
					this.setPwd = r.data.intPwd;
					var bankvalue = [];
					r.data.bank.forEach(item => {
						var length = item.account.length;
						var account = item.account + "";
						if(item.type==4)
						{
							item.bank = this.$t('cash.bank');
						}
						var itemAccount = account.substr(length - 4, length)
						bankvalue.push({
							name: item.bank + "(****" + itemAccount + ")",
							value: item.id,
							charge: item.charge,
							logo: item.logo,
							rate: item.rate,
							type: item.type,
							mark: item.mark
						})
						this.fee=r.data.fee
					})
					bankvalue.push({
						name: this.$t('cash.addWallet'),
						value: 0,
						color: "#FF0000",
					})
					this.actions = bankvalue;

				});
			},
			submit() {
				this.psd_val = "";
				if (!this.form.money) {
					this.$toast({
						className:"toastName",
						message: this.$t('cash.withdrawalAmountEmpty')
					});
					return false;
				}
				if (this.form.money < 0) {
					this.$toast({
						className:"toastName",
						message: this.$t('cash.withdrawalAmountNotAllow')
					});
					return false;
				}
				if (parseInt(this.form.money) > parseInt(this.data.money)) {
					this.$toast({
						className:"toastName",
						message: this.$t('cash.withdrawalAmountHigh')
					});
					return false;
				}
				if (this.form.bank_id == 0 || this.form.bank_id == -1) {
					this.$toast({
						className:"toastName",
						message: this.$t('cash.withdrawalAccountEmpty')
					});
					return false;
				}
				if (!this.form.password) {
					this.$toast({
						className:"toastName",
						message: this.$t('cash.withdrawalPasswordEmpty')
					});
					return false;
				}
				Fetch('/user/cost_apply', {
					money: this.form.money,
					bank_id: this.form.bank_id,
					passwd: this.form.password
				}).then(() => {
					this.$toast({
						className:"toastName",
						message: this.$t('cash.success')
					});
					this.$router.replace('/user')
				});
			},
			setIniPwdSubmit() {
				this.psd_val = "";
				Fetch('/user/setIniPwd', {
					password: this.form.password
				}).then(() => {
					this.setPwd = false;
				});
			},
			setIniPwd() {
				this.submitType = 2;
				this.write_psd = true;
			}
		}
	};
</script>

<style lang="less" scoped>
	/deep/ .van-action-sheet__item {
		text-align: left;
	}

	/deep/ .van-popup--bottom {
		border-radius: 0;
	}

	.action-item {
		display: flex;
		align-items: center;
		height: 40px;
		padding: 10px 18px;
		border-bottom: 1px solid #dddddd;

		.item-icon {
			width: 15px;
			margin-right: 4px;

			img {
				width: 100%;
			}
		}

		.item-name {
			font-size: 12px;
			color: #333333;
			flex: 1;
		}
	}

	.action-item:last-child {
		justify-content: center;
		padding: 0;
		width: 57%;
		overflow: hidden;
		margin: 20px auto;
		text-align: center;
		border-bottom: 0;
		line-height: 35px;
		height: 35px;
		border-radius: 20px;

		.item-icon {
			display: none;
		}

		.item-arrow {
			display: none;
		}

		.item-name {
			color: #fff;
			background-image: linear-gradient(to right, #ed550a 0%, #e82637 67%, #e82637);
		}
	}

	.red_top_bg {
		height: 168px;
		background-image: url(../images/user/moneybag/bg.png);
		position: fixed;
		background-position: center;
		background-repeat: no-repeat;
		background-size: 100% 100%;
	}

	.balance {
		background: rgba(255, 255, 255, 1);
		border-radius: 6px;
		padding: 15px 0px 25px;
		box-shadow: 2px 2px 5px rgba(115, 115, 115, .35);
		position: absolute;
		top: 74px;
		left: 15px;
		right: 15px;
		text-align: center;

		p:nth-child(1) {
			font-size: 12px;
			color: #999999;
			margin-bottom: 10px;
			display: flex;
			align-items: center;
			justify-content: center;

			.van-icon {
				font-size: 20px;
				margin-left: 4px;
				color: #c2c2c2;
			}
		}

		p:nth-child(2) {
			color: #ff5551;
			font-size: 24px;
			font-weight: bold;
		}
	}

	.wrap1 {
		margin-top: 182px;
		box-shadow: none;
		background: none;
		padding: 0 15px;

		.choose_bank {
			width: 100%;
			background: #FFFFFF;
			border-radius: 5px;
			padding: 16px 12px;
			display: flex;
			justify-content: flex-start;
			align-items: center;
			box-shadow: 2px 2px 5px rgba(115, 115, 115, .35);

			div:nth-child(1) {
				width: 32%;
				font-size: 12px;
				color: #333333;
			}

			div:nth-child(2) {
				width: 68%;
				text-align: right;
				font-size: 12px;
				color: #999999;

				.van-icon {
					margin-left: 8px;
				}
			}
		}

		.withdraw_wrap {
			width: 100%;
			background: #ffffff;
			border-radius: 5px;
			padding: 16px 12px;
			margin-top: 10px;
			display: flex;
			box-shadow: 2px 2px 5px rgba(115, 115, 115, .35);
			align-self: center;

			.flex_bd {
				flex: 1;

				input {
					height: 12px;
					width: 100%;
					text-align: right;
					line-height: 1;
					appearance: none;
					font-size: 12px;
				}
			}

			p:nth-child(3) {
				color: #666666;
				margin-left: 12px;
			}
		}

		.van-action-sheet__description {
			background-color: #e92b32;
			font-size: 12px;
			color: #fff;
			line-height: 20px;
			padding: 10px 15px;
		}

		.van-action-sheet__description::after {
			display: none;
		}
	}

	.canal_tips {
		padding: 10px 0 20px;
		line-height: 17px;
		font-size: 12px;
		color: #f12211;
	}

	.basic_btn {
		width: 213px;
		height: 35px;
		line-height: 35px;
		font-size: 12px;
		margin: 0 auto;
	}


	/deep/ .van-hairline--left::after {
		border: 1px solid #ECECEC;
	}
	
	.van-password-input .van-password-input__security{
		height: 46px;
		justify-content: space-between;
	}
	
	.van-password-input .van-password-input__security::after{
		display: none;
	}
	
	.van-password-input__security li{
		width: 46px;
		border: 1px solid #d5d5d5;
		flex: unset;
		background-color: #f5f5f5;
	}

	.van-password-input .van-password-input__security::after {
		border-radius: 0;
	}

	.keybord_box {
		background-color: #c3c7cc;
		padding: 9px 6px 3px;

		.keybord {
			margin: 24px auto 0 atuo;
			display: flex;
			justify-content: space-between;
			flex-wrap: wrap;
			text-align: center;

			.key_item {
				width: 32.33%;
				height: 50px;
				margin-bottom: 6px;
				background: rgba(255, 255, 255, 1);
				border-radius: 3px;
				padding: 6px;
				box-shadow:  0 0 4px rgba(68, 68, 68, .35);

				.key_inner {
					font-size: 25px;
					font-weight: bold;
				}

				.key_letter {
					font-size: 12px;
					color: #212121;
					text-transform: uppercase;
				}
			}

			.no_bg {
				.key_inner {
					font-size: 22px;
					line-height: 38px;
				}
			}

			.x {
				color: #e82637;
			}
		}
	}

	.withdraw_end {
		margin-top: 10px;
		display: flex;
		align-items: center;
		justify-content: space-between;
		line-height: 15px;
		font-size: 12px;

		p {
			color: #333333;
		}

		span {
			color: #666666;
		}
	}
	
	.psw_tips{
		font-size: 12px;
		color: #666666;
		text-align: center;
		margin-bottom: 20px;
	}
	
	.psw_content{
		padding: 22px 15px 38px;
		
		.psw_complete{
			margin: 20px auto 0 auto;
		}
		
		.van-password-input{
			margin: 0;
		}
	}
	[type="number"]{
		appearance:none;
		-webkit-appearance:none;
	}
</style>
