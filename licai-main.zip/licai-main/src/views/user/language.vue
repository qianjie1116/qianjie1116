<template>
	<div class="basic_wrap">
		<div class="red_top_bg">
		    <div class="back_left" @click="$router.go(-1)"></div>
		    <div class="big_tit">{{$t('safe.language')}}</div>
		</div>
		<div class="wrap_box">
			<div class="item" @click="changeLang('zh_cn',$event)">
				<div class="left flex_center">
					<div><img src="../images/language/zh_cn.png"></div>
					<div class="info">中国</div>
				</div>
				<div class="arrow"><van-icon name="arrow" /></div>
			</div>
		</div>

		<div class="wrap_box">
			<div class="item" @click="changeLang('en_us',$event)">
				<div class="left flex_center">
					<div><img src="../images/language/en_us.png"></div>
					<div class="info">English</div>
				</div>
				<div class="arrow"><van-icon name="arrow" /></div>
			</div>
		</div>
		<div class="wrap_box">
			<div class="item" @click="changeLang('ja_jp',$event)">
				<div class="left flex_center">
					<div><img src="../images/language/ja_jp.png"></div>
					<div class="info">日本</div>
				</div>
				<div class="arrow"><van-icon name="arrow" /></div>
			</div>
		</div>
		<div class="wrap_box">
			<div class="item" @click="changeLang('ko_kr',$event)">
				<div class="left flex_center">
					<div><img src="../images/language/ko_kr.png"></div>
					<div class="info">Brasil</div>
				</div>
				<div class="arrow"><van-icon name="arrow" /></div>
			</div>
		</div>
		<div class="wrap_box">
			<div class="item" @click="changeLang('vi_vn',$event)">
				<div class="left flex_center">
					<div><img src="../images/language/vi_vn.png"></div>
					<div class="info">Việt Nam</div>
				</div>
				<div class="arrow"><van-icon name="arrow" /></div>
			</div>
		</div>
		<div class="wrap_box">
			<div class="item" @click="changeLang('th_th',$event)">
				<div class="left flex_center">
					<div><img src="../images/language/th_th.png"></div>
					<div class="info">Malaysia</div>
				</div>
				<div class="arrow"><van-icon name="arrow" /></div>
			</div>
		</div>
		<div class="wrap_box">
			<div class="item" @click="changeLang('ms_my',$event)">
				<div class="left flex_center">
					<div><img src="../images/language/ms_my.png"></div>
					<div class="info">ประเทศไทย</div>
				</div>
				<div class="arrow"><van-icon name="arrow" /></div>
			</div>
		</div>
		<div class="wrap_box">
			<div class="item" @click="changeLang('zh_hk',$event)">
				<div class="left flex_center">
					<div><img src="../images/language/zh_hk.png"></div>
					<div class="info">Indonesia</div>
				</div>
				<div class="arrow"><van-icon name="arrow" /></div>
			</div>
		</div>
	</div>
</template>

<script>
	import Fetch from '../../utils/fetch'
	import bsHeader from '../../components/bsHeader.vue'
	import {
		Toast
	} from 'vant'
	export default {
		name: "language",
		components: {
			bsHeader
		},
		data() {
			return {
				lang:this.$i18n.locale||"zh_cn",
			};
		},
		created() {
		},
		mounted() {
		},
		methods: {
			    changeLang(lang,event) {
					Toast.loading({
						// mask: true,
						duration: 200
					})
					this.lang = lang;
					this.$i18n.locale = lang;
					localStorage.setItem("lang", lang);
					this.$router.go(-1);
			    },
		}
	};
</script>

<style lang="less" scoped>
	.wrap_box{
		display: flex;
		flex-direction: column;
		align-items: center;
		box-shadow: 0 0 0 transparent;
		.item{
			height: 50px;
			width: 95%;
			padding: 16px 0;
			border-bottom: 1px solid #ECECEC;
			font-size: 14px;
			color: rgba(0,0,0,.8);
			line-height: 20px;
			display: flex;
			justify-content: space-between;
			.right{
				width: 20px;
				height: 20px;
				background: url(../images/user/arrow.png) no-repeat center center;
				background-size: 100% 100%;
			}
			.right_info{
				color: rgba(0,0,0,.6);
			}
			.info{
				margin-left: 10px;
			}
			.tips{
				color: rgba(0,0,0,.6);
				margin-left: auto;
				margin-right: 4px;
				font-weight: normal;
			}
			.left{
				img{
					width: 33px;
					margin-top: 5px;
					border-radius: 40px;
					font-size: 0;
				}
			}
		}
	}
	.arrow{
		opacity: .47;
	}
</style>
