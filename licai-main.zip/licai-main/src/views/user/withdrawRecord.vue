<template>
    <div class="basic_wrap">
        <div class="red_top_bg">
            <div class="back_left" @click="$router.back()"></div>
            <div class="big_tit">{{$t('moneybag.withdrawRecord')}}</div>
        </div>
		<div class="user_yw">
			<p>{{$t('moneybag.accountBalance')}}</p>
			<p>{{$t('utils.moneyMark')}}{{funds}}</p>
			<div class="user_zrzc">
				<span @click="$router.push('/invest')">{{$t('moneybag.recharge')}}</span>
				<span @click="$router.push('/cash')">{{$t('moneybag.withdraw')}}</span>
			</div>
		</div>
        <div class="detail_box">
			<van-empty :description="$t('item.noData')" v-if="listShow" />
            <div class="item" v-for="item in data">
                <div class="de_wrap">
                    <p class="tit">{{item[lang]}}</p>
                    <p class="time">{{item.time}}</p>
                </div>
                <div class="price" :class="item.type =='1'?'':'del'" v-html="item.type =='1'?$t('utils.moneyMark')+item.money : '-'+$t('utils.moneyMark')+item.money"></div>
            </div>
        </div>
    </div>
</template>

<script>
    import Vue from 'vue';
    import Fetch from '../../utils/fetch'
    import {
        DropdownMenu,
        DropdownItem
    } from 'vant';

    import { Empty } from 'vant';

    Vue.use(Empty);
    Vue.use(DropdownMenu).use(DropdownItem);

    export default {
        name: "withdrawRecord",
        data() {
            return {
				lang:this.$i18n.locale||"zh_cn",
                data: [],
                list: {},
                account: 0,
                option: [],
                listShow:false,
                funds: 0,
                userName:''
            };
        },
        created() {
            this.$parent.footer('user', false);
        },
        mounted() {
            Fetch('/user/funds',{
                reason_id: 2
            }).then(r => {
                this.option.push({
                    text: this.$t('moneybag.types'),
                    value: 0
                })
                
                this.showError(r.data.list.length);
                this.data = r.data.list;
                this.funds = r.data.money;
                this.userName = r.data.username;
            })
        },
        methods: {
            showError(len){
                len == 0 ? this.listShow = true : this.listShow = false
            }
        }
    };
</script>

<style lang="less" scoped>
    .red_top_bg {
        height: 168px;
        background-image: url(../images/user/moneybag/bg.png);
        position: fixed;
    	background-position: center;
    	background-repeat: no-repeat;
    	background-size: 100% 100%;
    }
    .user_yw{
    	text-align: center;
    	position: absolute;
    	top: 74px;
    	background: #FFFFFF;
    	left: 15px;
    	right: 15px;
    	border-radius: 5px;
    	padding: 15px;
    	box-shadow:  2px 2px 5px rgba(115, 115, 115, 0.35);
    	p:nth-child(1){
    		font-size: 12px;
    		color: #999999;
    		margin-bottom: 10px;
    	}
    	p:nth-child(2){
    		font-size: 24px;
    		color: #ff5551;
    		font-weight: bold;
    	}
    }
    .user_zrzc{
    	text-align: center;
    	display: flex;
    	justify-content: space-between;
    	text-align: center;
    	margin-top: 17px;
    	span{
    		width: 135px;
    		
    		color: #FFFFFF;
    		margin: 0px 12px;
    		padding: 10px;
    		font-size: 12px;
    		line-height: 15px;
    		color: #fff;
    		border-radius: 5px;
    	}
    	
    	span:nth-child(1) {
    		background: #ff5451;
    	}
    	
    	span:nth-child(2) {
    		background: #04c382;
    	}
    }
    
    .detail_box {
        background: rgba(255, 255, 255, 1);
        margin-top: 224px;
        .item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 12px 15px;
            border-bottom: 1px solid #ECECEC;
    
            .de_wrap {
                flex: 2;
    
                .tit {
                    font-size: 12px;
                    color: #333333;
                    line-height: 18px;
                    font-weight: bold;
                }
    
                .time {
                    font-size: 12px;
                    color: #999999;
                    line-height: 18px;
                }
            }
    
            .price {
                flex: 1;
                font-size: 12px;
                line-height: 28px;
                font-weight: bold;
                text-align: right;
                color: #e82637;
                white-space: nowrap;
                &.del {
                    color: #3FAF3E;
                }
            }
        }
    }
</style>
