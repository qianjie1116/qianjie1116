<template>
  <div class="basic_wrap">
    <div class="red_top_bg">
      <div class="back_left" @click="$router.back()"></div>
      <div class="big_tit" style="text-align: center">
        {{ data.info.zh_cn }}
      </div>
    </div>
    <div class="msg_box" style="padding: 20px">
      <p
        style="
          font-size: 32px;
          font-weight: 600;
          padding-top: 40px;
          text-align: center;
        "
      >
        {{ data.bx_all_money }}PHP
      </p>
      <p style="text-align: center">Principal Interest</p>
      <div
        style="
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding-top: 40px;
        "
      >
        <div style="text-align: center; font-weight: 500">
          <p style="font-size: 20px">{{ data.info.rate }}%</p>
          <p style="padding-top: 4px; font-size: 11px">Yield</p>
        </div>
        <div style="text-align: center; font-weight: 500">
          <p style="font-size: 20px">{{ data.info.money }}PHP</p>
          <p style="padding-top: 4px; font-size: 11px">Interest Income</p>
        </div>
        <div style="text-align: center; font-weight: 500">
          <p style="font-size: 20px">{{ data.ok_apr_money }}PHP</p>
          <p style="padding-top: 4px; font-size: 11px">Total Subscriptions</p>
        </div>
      </div>
      <p style="line-height: 1.6; padding-top: 20px">
        Subscriptions Time: {{ ` ` + data.info.time }}
      </p>
      <p style="line-height: 1.6">
        Expiration Time: {{ ` ` + data.info.time2 }}
      </p>
    </div>
    <p
      style="padding: 10px 20px; color: #999; font-size: 14px; line-height: 1.6"
    >
      Earnings are calculated by the minute, and the principal and interest will
      be returned upon maturity.
    </p>
    <!-- list 本金money2
收益是money1
时间是time2
0是未返还
1是已返还 -->

    <div style="padding: 20px">
      <div
        v-for="(item, index) in data.list"
        :key="index"
        style="padding-bottom: 10px"
      >
        <div
          style="
            display: flex;
            align-items: center;
            justify-content: space-between;
            line-height: 1.6;
          "
        >
          <p style="font-size: 16px">{{ item.money2 }}PHP</p>
          <p style="font-size: 14px;" :style="{ color: item.status == 0 ? '#666' : 'green' }">
            {{ item.status == 0 ? "unreturned" : "returned" }}
          </p>
        </div>
        <div
          style="
            display: flex;
            align-items: center;
            justify-content: space-between;
            line-height: 1.6;
          "
        >
          <p style="color: #666">{{ item.money1 }}PHP</p>
          <p style="color: #666">{{ item.time2 }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Fetch from "../../utils/fetch";
// import {VueEditor} from 'vue2-editor'

export default {
  name: "orderDetail",
  data() {
    return {
      data: {},
    };
  },
  created() {
    this.$parent.footer("order", false);
  },
  mounted() {
    this.start();
  },
  methods: {
    start() {
      console.log(this.$router);
      Fetch("/user/order_info", {
        id: this.$router.history.current.params.id,
      }).then((res) => {
        this.data = res.data;
      });
    },
  },
};
</script>

<style lang="less" scoped>
.red_top_bg {
  position: fixed;
  top: 0;
  left: 50%;
  transform: translateX(-50%);
  z-index: 10;
}

.big_tit {
  left: 40px;
  width: 90%;
  color: #fff;
  transform: none;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.msg_box {
  width: 100%;
  font-size: 13px;
  margin-bottom: 6px;
  color: #333;
  border-top: 1px solid #ebe9e9;
  border-bottom: 1px solid #ebe9e9;
  padding: 12px 15px;
  background-image: linear-gradient(to right, #ff5252, #ff8044);
  background-size: 100% 320px;
  background-repeat: no-repeat;
  color: #fff;
}
</style>
