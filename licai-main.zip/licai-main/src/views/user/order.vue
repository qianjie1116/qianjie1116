<template>
  <div class="basic_wrap">
    <div class="red_top_bg">
      <div class="back_left" @click="$router.back()"></div>
      <div class="big_tit">{{ $t("user.myInvestment") }}</div>
    </div>
    <div class="total-main">
      <div class="total-bar">
        <div style="display: flex; font-size: 14px; font-weight: 700">
          <div
            style="flex: 1"
            :style="inv == 0 ? 'color:red' : ''"
            @click="
              inv = 0;
              start();
            "
          >
            {{ $t("orders.unfinish") }}
          </div>

          <div
            style="flex: 1"
            :style="inv == 1 ? 'color:red' : ''"
            @click="
              inv = 1;
              start();
            "
          >
            {{ $t("orders.finish") }}
          </div>
        </div>
      </div>
      <div class="money_box">
        <div class="item">
          <div class="m-card">
            <p class="info">{{ $t("user.uncollectedPrincipal") }}</p>
            <p class="money_num" v-html="data.on_money"></p>
          </div>
        </div>
        <div class="item">
          <div class="m-card">
            <p class="info">{{ $t("user.uncollectedInterest") }}</p>
            <p class="money_num" v-html="data.on_apr_money"></p>
          </div>
        </div>
        <div class="item">
          <div class="m-card">
            <p class="info">{{ $t("user.cumulativeIncome") }}</p>
            <p class="money_num" v-html="data.ok_apr_money"></p>
            <!---<p class="money_num" v-html="'<span>'+$t('utils.moneyMark')+'</span>'+data.ok_apr_money"></p>-->
          </div>
        </div>
      </div>
      <h3 class="notes_tit">{{ $t("orders.record") }}</h3>
      <van-empty :description="$t('orders.noOrders')" v-if="empty" />
      <div class="scrollBox">
        <div
          class="notes_box"
          v-if="!empty"
          v-for="i in data.list"
          @click="linDetail(i)"
        >
          <div class="timer">
            <span class="time">{{ i.time }}</span>
            <span class="tag ing" v-if="i.status == 0">{{
              $t("orders.unfinish")
            }}</span>
            <span class="tag finish" v-if="i.status == 1">{{
              $t("orders.finish")
            }}</span>
          </div>
          <div class="items-flex">
            <div class="item-ico">
              <img v-if="i.cover" class="round" :src="i.cover" alt="" />
              <img v-else class="round" src="../images/new/bch.png" alt="" />
            </div>
            <div class="flex_bd">
              <div class="item_div1">
                <p>
                  {{ i[lang] }}
                </p>
              </div>
              <div class="item_div2">
                <div class="item_min">
                  <p>{{ i.money }}</p>
                  <p>{{ $t("utils.investmentAmount") }}</p>
                </div>
                <div class="item_rate">
                  <p>{{ ((i.money * i.rate) / 100).toFixed(2) }}</p>
                  <p>{{ $t("utils.income") }}</p>
                </div>
                <div class="item_day" v-if="i.status == 1">
                  <p>{{ i.day }}{{ $t("utils.day") }}</p>
                  <p>{{ $t("utils.cycle") }}</p>
                </div>
                <div class="item_day" v-if="i.status == 0">
                  <p style="padding: 2px 0">
                    <van-count-down
                      :time="i.left_time * 1000"
                      style="font-size: 12px; line-height: 16px"
                    >
                      <template #default="timeData">
                        <span class="block">{{ timeData.days }}</span>
                        <span class="colon">:</span>
                        <span class="block">{{ timeData.hours }}</span>
                        <span class="colon">:</span>
                        <span class="block">{{ timeData.minutes }}</span>
                        <span class="colon">:</span>
                        <span class="block">{{ timeData.seconds }}</span>
                      </template>
                    </van-count-down>
                  </p>
                  <p>
                    <span class="iconfont icon-shijian text-red"></span>
                    {{ $t("utils.cycle") }}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Vue from "vue";
import { Empty, CountDown } from "vant";

import Fetch from "../../utils/fetch";
Vue.use(Empty);
Vue.use(CountDown);

export default {
  name: "order",
  data() {
    return {
      lang: this.$i18n.locale || "zh_cn",
      data: {},
      usdt_to_usd: "",
      p: "",
      usdt_to_change: "",
      empty: false,
      time: 30 * 60 * 60 * 1000,
      inv: 0,
    };
  },
  created() {
    this.$parent.footer("order");
  },
  mounted() {
    this.start();
  },
  methods: {
    linDetail(i) {
      console.log(`i:`, i);
      this.$router.push("/order/" + i.id);
    },
    start() {
      Fetch("/user/order", { inv: this.inv }).then((r) => {
        this.data = r.data;
        this.usdt_to_change = r.data.usdt_to_change;
        this.usdt_to_usd = r.data.usdt_to_usd;
        this.p = (this.usdt_to_change / this.usdt_to_usd).toFixed(3);
        r.data.list.length == 0 ? (this.empty = true) : (this.empty = false);
      });
    },
    wan(str) {
      var num = parseFloat(str);
      if (num > 99999) {
        return `${(num / 10000).toFixed(2)}`;
      } else {
        return str || 0;
      }
    },
    lookHT(id) {
      this.$router.push("/contract/" + id);
    },
  },
};
</script>

<style lang="less" scoped>
.total-main {
  overflow: hidden;
}
.basic_wrap {
  padding-top: 44px;
}
.red_top_bg {
  top: 0;
  width: 100%;
  position: fixed;
  z-index: 15;
}

.money_box {
  background-color: #f7f7f7;
  display: flex;
  justify-content: space-around;
  padding: 15px 5px;
  .item {
    width: 33.33%;
    padding: 0 6px;
    text-align: center;
    .money_num {
      font-size: 14px;
      line-height: 25px;
      font-weight: bold;
      white-space: normal;
      word-break: normal;
      text-align: center;
      color: #ef5040;
    }

    .info {
      font-size: 14px;
      line-height: 20px;
      margin-top: 5px;
      color: #ccc;
    }
  }
}

.notes_tit {
  width: 100%;
  line-height: 44px;
  height: 44px;
  font-size: 14px;
  color: #000000;
  padding: 0 14px;
  background: #fafafa;
  z-index: 2;
}

.notes_box {
  width: 100%;
  padding-bottom: 2px;
  background: rgba(255, 255, 255, 1);
  box-shadow: -2px 2px 9px 2px rgba(160, 160, 160, 0.15);
  margin-bottom: 15px;
  .timer {
    background-color: #f5f5f5;
    padding: 10px 14px;
    font-size: 12px;
    color: rgba(0, 0, 0, 0.6);
    display: flex;
    justify-content: space-between;
    align-items: center;
    .time {
      color: #999999;
    }
    .tag {
      font-style: normal;
      padding: 8px 12px;
      border-radius: 5px;
      text-align: center;
      color: #ffffff;
      min-width: 60px;
    }

    .ing {
      background: #ff5c4f;
    }

    .finish {
      font-style: normal;
      background: #04c382;
    }
  }

  .item_div1 {
    display: flex;
    justify-content: space-between;
    margin-bottom: 10px;
    font-size: 15px;
    p:nth-child(1) {
      width: 100%;
      font-weight: bold;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
  }

  .item_div2 {
    display: flex;
    justify-content: space-between;
    text-align: center;
    > div {
      flex: 1;
      p {
        padding: 5px 0;
      }
    }

    .item_rate {
      p:nth-child(1) {
        font-weight: bold;
        font-size: 14px;
        color: #e82637;
      }

      p:nth-child(2) {
        color: #999;
      }
    }

    .item_day {
      width: 110px;
      text-align: center;
      flex: unset;
      p:nth-child(1) {
        font-weight: bold;
        font-size: 14px;
      }

      p:nth-child(2) {
        color: #999;
      }
    }

    .item_min {
      margin-left: -15px;
      p:nth-child(1) {
        font-weight: bold;
        font-size: 14px;
      }

      p:nth-child(2) {
        color: #999;
      }
    }
  }
}
.items-flex {
  display: flex;
  padding: 15px;
  .flex_bd {
    flex: 1;
    min-width: 0;
  }
}
.item-ico {
  font-size: 0;
  margin-right: 10px;
  margin-top: -4px;
}
.item-ico img {
  width: 28px;
  height: 28px;
}
.m-card {
  background-color: #ffffff;
  text-align: center;
  border-radius: 10px;
  box-shadow: 0 1px 8px rgba(0, 0, 0, 0.1);
  padding: 10px 0;
}
.total-bar {
  background-color: #ffffff;
  text-align: center;
  box-shadow: 0 1px 8px rgba(0, 0, 0, 0.1);
  padding: 15px 0;
  .tot-desc {
    color: #999;
    font-size: 12px;
  }
  .icon-time-circle {
    font-size: 14px;
  }
  .tot-cell {
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 10px;
  }
}
.item_day {
  /deep/ .van-count-down {
    display: flex;
    align-items: center;
  }
}
.colon {
  margin: 0 1px;
  color: #999;
}
.block {
  display: inline-block;
  width: 22px;
  color: #333;
  font-size: 12px;
  border-radius: 4px;
  text-align: center;
  background-color: #e5e5e5;
}
</style>
<style>
.tot-cell .icon-up {
  display: inline-block;
  animation: movetip 1s infinite;
}
.tot-cell .icon-down {
  display: inline-block;
  animation: movetip2 1s infinite;
}
.color {
  animation: color 2s infinite;
}
@keyframes movetip {
  from {
    transform: translateY(0);
  }
  to {
    transform: translateY(-5px);
  }
}
@keyframes movetip2 {
  from {
    transform: translateY(0);
  }
  to {
    transform: translateY(5px);
  }
}
@keyframes color {
  0% {
    color: #000;
  }
  50% {
    color: #e82637;
  }
  100% {
    color: #04c382;
  }
}
</style>
