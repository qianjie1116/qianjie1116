<template>
  <div class="user_wrap">
    <div class="top_header">
      <div class="red_top_bg">
        <div class="big_tit">{{ $t("home.my") }}</div>
        <div class="sign" @click="$router.push('/sign')">
          <img src="../images/user/sign.png" />
        </div>
      </div>
      <div class="user_detail">
        <div class="user_header">
          <img :src="data.user_icon" alt="" />
        </div>
        <div class="user_name">
          <div class="user_all">
            <p class="user_nickname">
              {{ data.name ? data.name : data.mobile }}
            </p>
          </div>
        </div>
      </div>
      <div class="user_vip">
        <div class="vip-box">
          <div class="vip-badge"></div>
          {{ data.vip_name }}
        </div>
        <!-- <p>{{$t('user.welcome')}}</p> -->
		<div style="margin-top: 10px;font-weight: 700;font-size: 15px;">
			<p>{{ $t("account.buynum") }} {{ data.buy_num }}</p>
		</div>
		
      </div>
    </div>
    <div class="money">
      <div
        style="
          display: flex;
          align-items: center;
          text-align: center;
          line-height: 1.6;
          font-size: 14px;
        "
      >
        <div style="flex: 0 0 50%">
          <div style="color: #999992">
            {{ $t("user.totalBalance") }}
            <!-- <van-icon name="eye-o" @click="eye = 0" /> -->
          </div>
          <div style="color: #ef5040">
            {{ data.all_money }}
          </div>
        </div>
        <div style="flex: 0 0 50%">
          <div style="color: #999992">
            {{ $t("user.availableBalance") }}
            <!-- <van-icon name="eye-o" @click="eye = 0" /> -->
          </div>
          <div style="color: #ef5040">
            {{ data.ti_money }}
          </div>
        </div>
      </div>

      <div class="money-bd">
        <span @click="$router.push('/invest')">{{ $t("user.recharge") }}</span>
        <span @click="$router.push('/cash')">{{ $t("user.withdraw") }}</span>
      <!-- <span @click="$router.push('/kefu')">{{
          $t("user.onlineService")
        }}</span> -->
      </div>
    </div>

    <!-- <div class="user_block">
      <div class="user_grid clear" v-if="eye == 1">
        <div class="user_grid__item">
          <div class="user_grid__card user_balance">
            <div>
              {{ $t("user.totalBalance") }}
              <van-icon name="eye-o" @click="eye = 0" />
            </div>
            <div>
              {{ data.all_money }}
            </div>
          </div>
        </div>

        <div class="user_grid__item">
          <div class="user_grid__card user_money">
            <p>{{ $t("user.uncollectedPrincipal") }}</p>
            <p>{{ data.wait_money }}</p>
          </div>
        </div>
        <div class="user_grid__item">
          <div class="user_grid__card user_money">
            <p>{{ $t("user.uncollectedInterest") }}</p>
            <p>{{ data.wait_lixi }}</p>
          </div>
        </div>
        <div class="user_grid__item">
          <div class="user_grid__card user_money">
            <p>{{ $t("user.cumulativeIncome") }}</p>
            <p>{{ data.all_lixi }}</p>
          </div>
        </div>

        <div class="user_grid__item">
          <div class="user_grid__card user_money">
            <p>{{ $t("account.buynum") }}</p>
            <p>{{ data.buy_num }}</p>
          </div>
        </div>
      </div>
      <div class="user_grid clear" v-if="eye == 0">
        <div class="user_grid__item">
          <div class="user_grid__card user_money">
            <p>{{ $t("user.uncollectedPrincipal") }}</p>
            <p>******</p>
          </div>
        </div>
        <div class="user_grid__item">
          <div class="user_grid__card user_money">
            <p>{{ $t("user.uncollectedInterest") }}</p>
            <p>******</p>
          </div>
        </div>
        <div class="user_grid__item">
          <div class="user_grid__card user_money">
            <p>{{ $t("user.cumulativeIncome") }}</p>
            <p>******</p>
          </div>
        </div>
        <div class="user_grid__item">
          <div class="user_grid__card user_balance">
            <div>
              {{ $t("user.totalBalance") }}
              <van-icon name="closed-eye" @click="eye = 1" />
            </div>
            <div>******</div>
          </div>
        </div>
      </div>
      <div @click="$router.push('/kefu')" class="user_kf">
        <img src="../images/user/kf.png" alt="" />
        <p>{{ $t("user.onlineService") }}</p>
      </div>
    </div> -->
    <!-- <div class="user_yw">
			<div @click="$router.push('/order')">
				<img src="../images/user/order.png" alt="" />
				<p>{{$t('user.myInvestment')}}</p>
			</div>
			<div @click="$router.push('/moneybag')">
				<img src="../images/user/details.png" alt="" />
				<p>{{$t('user.transactionDetails')}}</p>
			</div>
			<div @click="$router.push('/kefu')">
				<img src="../images/user/kf.png" alt="" />
				<p>{{$t('user.onlineService')}}</p>
			</div>
		</div> -->

    <div class="list">
      <van-cell
        v-if="data.is_auth == '1'"
        :value="$t('safe.verifiedIdentity')"
      >
      <!--  is-link
        @click="$router.push('/authSuccess')" -->
        <template #title>
          <img src="../images/user/account/icon1.png" alt="" />
          <span class="custom-title">{{ $t("authEmail.authentication") }}</span>
        </template>
      </van-cell>

      <van-cell
        v-if="data.is_auth == '0'"
        is-link
        @click="$router.push('/authEmail')"
      >
        <template #title>
          <img src="../images/user/account/icon1.png" alt="" />
          <span class="custom-title">{{ $t("authEmail.authentication") }}</span>
        </template>
      </van-cell>
      <van-cell is-link @click="$router.push('/account')">
        <template #title>
          <img src="../images/user/account/icon2.png" alt="" />
          <span class="custom-title">{{ $t("safe.paymentOptions") }}</span>
        </template>
      </van-cell>
      <van-cell is-link @click="$router.push('/setpwd')">
        <template #title>
          <img src="../images/user/account/icon4.png" alt="" />
          <span class="custom-title">{{ $t("safe.signInPassword") }}</span>
        </template>
      </van-cell>
      <van-cell is-link @click="$router.push('/setpaypwd')">
        <template #title>
          <img src="../images/user/account/icon5.png" alt="" />
          <span class="custom-title">{{ $t("safe.paymentPassword") }}</span>
        </template>
      </van-cell>
      <van-cell is-link @click="$router.push('/moneybag')">
        <template #title>
          <img src="../images/user/moneybag.png" alt="" />
          <span class="custom-title">{{ $t("user.myWallet") }}</span>
        </template>
      </van-cell>
      <van-cell is-link @click="$router.push('/rechargeRecord')">
        <template #title>
          <img src="../images/user/cz.png" alt="" />
          <span class="custom-title">{{ $t("user.rechargeRecord") }}</span>
        </template>
      </van-cell>
      <van-cell is-link @click="$router.push('/withdrawRecord')">
        <template #title>
          <img src="../images/user/tx.png" alt="" />
          <span class="custom-title">{{ $t("user.withdrawalRecord") }}</span>
        </template>
      </van-cell>
     <!-- <van-cell is-link @click="$router.push('/myTeam')">
        <template #title>
          <img src="../images/user/team.png" alt="" />
          <span class="custom-title">{{ $t("index.invite") }}</span>
        </template>
      </van-cell> -->
      <van-cell is-link @click="$router.push('/language')">
        <template #title>
          <img src="../images/user/account/icon3.png" alt="" />
          <span class="custom-title">{{ $t("safe.language") }}</span>
        </template>
      </van-cell>
      <van-cell is-link @click="$router.push('/about/12')">
        <template #title>
          <img src="../images/user/account/icon6.png" alt="" />
          <span class="custom-title">{{ $t("index.agreement") }}</span>
        </template>
      </van-cell>
      <van-cell is-link @click="$router.push('/about/13')">
        <template #title>
          <img src="../images/user/account/icon7.png" alt="" />
          <span class="custom-title">{{ $t("index.secret") }}</span>
        </template>
      </van-cell>

      <div
        class="history_coupon basic_btn flex_center"
        style="margin: 48px auto"
        @click="logout"
      >
        <span>{{ $t("safe.signOut") }}</span>
      </div>

      <!-- <van-cell is-link @click="$router.push('/safe')">
        <template #title>
          <img src="../images/user/setting.png" alt="" />
          <span class="custom-title">{{ $t("user.setting") }}</span>
        </template>
      </van-cell> -->
    </div>
  </div>
</template>

<script>
import Vue from "vue";
import qs from "qs";
import Fetch from "../../utils/fetch";
import Api from "../../interface/index";
import { Icon, Cell, CellGroup } from "vant";

Vue.use(Cell).use(CellGroup).use(Icon);

export default {
  name: "user",
  components: {},
  data() {
    return {
      data: {},
      eye: 1,
      checked: true,
    };
  },
  created() {
    this.$parent.footer("user");
  },
  mounted() {
    this.start();
  },
  methods: {
    start() {
      Fetch("/user/info").then((r) => {
        this.data = r.data;
      });
    },
    logout() {
      localStorage.removeItem("token");
      this.$router.replace("/");
    },
  },
};
</script>

<style lang="less" scoped>
.red_top_bg {
  position: relative;
  background: unset;

  .sign {
    position: absolute;
    top: 15px;
    right: 15px;
    height: 20px;

    img {
      height: 100%;
    }
  }
}

.user_block {
  padding: 10px 15px;

  .user_kf {
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 5px;
    background-image: linear-gradient(to right, #ff5252, #ff8244);
    box-shadow: 2px 2px 5px rgba(115, 115, 115, 0.35);
    color: #fff;
    font-size: 12px;
    padding: 10px;

    img {
      width: 27px;
      height: 27px;
      margin-right: 8px;
    }
  }

  .user_grid {
    margin: 0 -7.5px;

    .user_grid__item {
      float: left;
      width: 50%;
      padding: 0 7.5px;
      box-sizing: border-box;

      .user_grid__card {
        border: 1px solid #eeeeee;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 2px 2px 5px rgba(115, 115, 115, 0.35);
        margin-bottom: 10px;
        text-align: center;
        padding: 12px;
      }

      .user_money {
        p:nth-child(1) {
          font-size: 12px;
          color: #999992;
        }

        p:nth-child(2) {
          font-size: 12px;
          color: #ef5040;
          margin-top: 8px;
        }
      }

      .user_balance {
        div:nth-child(1) {
          font-size: 12px;
          color: #999992;
        }

        div:nth-child(2) {
          font-size: 12px;
          color: #ef5040;
          margin-top: 8px;
        }
      }
    }
  }
}

.user_wrap {
  max-width: 100%;
  overflow: hidden;
  padding-bottom: 20px;
}

.top_header {
  position: relative;
  width: 100%;
  height: 190px;
  background-image: url(../images/user/user_bg.jpg);
  background-position: center;
  background-repeat: no-repeat;
  background-size: 100% 100%;

  .user_detail {
    width: 100%;
    padding: 20px 15px 0;

    .user_header {
      width: 48px;
      height: 48px;
      overflow: hidden;
      margin: 0 auto;
      border-radius: 50%;

      img {
        width: 100%;
        height: 100%;
        border: 2px solid #ffffff;
        border-radius: 30px;
      }
    }

    .user_name {
      margin-top: 5px;
      color: #ffffff;
      text-align: center;

      .user_all {
        .user_nickname {
          line-height: 22px;
          font-size: 15px;
          font-weight: bold;
        }
      }
    }
  }

  .user_vip {
    color: #ffffff;
    text-align: center;
    padding: 8px 15px;

    .vip-box {
      position: relative;
      text-align: center;
      font-size: 12px;
      min-width: 45px;
      padding: 0 14px;
      line-height: 15px;
      border-radius: 8px;
      display: inline-block;
      background-image: linear-gradient(to right, #ffa51e, #ffe462);

      .vip-badge {
        position: absolute;
        left: -8px;
        top: -2.5px;
        width: 20px;
        height: 20px;
        background-image: url(../images/user/badge.png);
        background-position: center;
        background-repeat: no-repeat;
        background-size: 100% 100%;
      }
    }
  }

  .user_balance {
    text-align: center;

    div {
      margin: 10px 0;
    }

    div:nth-child(1) {
      font-size: 14px;
      color: #d3d5d6;
    }

    div:nth-child(2) {
      font-weight: bold;
      font-size: 18px;
      color: #ffffff;
    }
  }

  .user_money {
    display: flex;
    justify-content: space-between;
    text-align: center;

    p {
      margin: 10px 0;
    }

    div {
      width: 33.33%;
    }

    p:nth-child(1) {
      font-size: 14px;
      color: #d3d5d6;
    }

    p:nth-child(2) {
      font-size: 14px;
      color: #ffffff;
    }
  }
}

.kong {
  width: 100%;
  height: 35px;
  background: #ffffff;
}

.user_yw {
  display: flex;
  justify-content: space-between;
  text-align: center;
  width: 96%;
  position: relative;
  // top: -83px;
  background: #ffffff;
  left: 2%;
  border-radius: 5px 5px 0 0;
  padding: 15px 0;

  div {
    width: 33.33%;
  }

  p {
    margin-top: 8px;
  }

  img {
    width: 30px;
    height: 30px;
  }
}

.money {
  background: #ffffff;
  padding: 15px 15px 20px;
  border-bottom: 1px solid #eeeeee;
  border-top: 1px solid #eeeeee;

  .money-hd {
    text-align: center;

    p:nth-child(1) {
      color: #999;
      margin-bottom: 10px;
    }

    p:nth-child(2) {
      font-size: 14px;
      color: #ff5252;
      font-weight: bold;
    }
  }

  .money-bd {
    text-align: center;
    margin-top: 13px;

    span {
      padding: 3.5px 7px;
      border-radius: 5px;
      margin: 0 8px;
      width: 140px;
      line-height: 2;
      font-size: 18px;
      display: inline-block;
      color: #ffffff;
    }

    span:nth-child(1),
    span:nth-child(3) {
      background: #ff5451;
    }

    span:nth-child(2) {
      background: #04c382;
    }
  }
}

.list {
  margin-top: 10px;

  .van-cell {
    padding: 8px 15px;
    .van-cell__title {
      display: flex;
      align-items: center;
      color: #333333;
      font-size: 12px;

      img {
        height: 17px;
        width: 17px;
        margin-right: 6px;
        vertical-align: middle;
      }
    }
  }

  .van-cell::after {
    left: 0;
    right: 0;
    border-bottom: 1px solid #ebe9e9;
  }
}
</style>
