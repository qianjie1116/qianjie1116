<template>
    <div class="basic_wrap">
       <!-- <div class="login_bg">
            <div class="back_left" @click="$router.back()"></div>
            <div class="big_tit">{{$t('login.login')}}</div>
			<div class="language" @click="$router.push('/language')">
				<img :src="require('../images/language/'+lang+'.png')">
			</div>
        </div> -->
		<div class="user-top">
			<img src="../images/login/avatar.png" alt="">
			<div class="user-name">LOGO</div>
		</div>
		<div class="login-main">
        <form class="form">
            <div class="cut_login">
                <router-link class="cur" to="/login"
                    >{{$t('login.signIn')}}
                    <div class="line"></div>
                </router-link>
                <router-link to="/register"
                    >{{$t('login.signUp')}}
                    <div class="line"></div>
                </router-link>
            </div>
            <div class="item mt">
				<span class="icon"
				    ><img src="../images/login/phone.png" alt=""
				/></span>
                <input
                    type="text"
                    class="inp"
                    v-model.trim="data.username"
                    :placeholder="$t('login.phoneNumber')"
                />
				<van-popover
				  v-model="showPopover"
				  trigger="click"
				  placement="bottom"
				  :offset="[0, 0]"
				  :actions="actions"
				  @select="onSelect"
				>
				  <template #reference>
					<div class="lan-label">
						<img :src="lan_ico" alt=""><span>{{lan_num}}</span>
					</div>
				  </template>
				</van-popover>
            </div>
			
            <div class="item">
                <span class="icon"
                    ><img src="../images/login/lock.png" alt=""
                /></span>
                <input
                    :type="password"
                    class="inp"
                    v-model.trim="data.password"
                    :placeholder="$t('login.password')"
                />
                <div
                    class="eye_bi"
                    @click="showPwd"
                    :class="password == 'text' ? 'eye' : ''"
                ></div>
            </div>
			<div
			    type="submit"
			    class="basic_btn sbtn"
			    :class="
			        data.username == '' || data.password == '' ? 'no_touch' : ''
			    "
			    @click="submit"
			>
			    {{$t('login.signInBtn')}}
			</div>
            <div class="item_reset_pwd">
				<van-checkbox v-model="checked" shape="square" icon-size="14px">{{$t('login.remember')}}</van-checkbox>
                <router-link class="reset_pwd" to="/forgetpwd">{{$t('login.forget')}}</router-link
                >
            </div>
        </form>
        </div>
        <div
            v-if="msg_show"
            class="kefu-link"
            :class="show_kefu ? '' : 'kefu_hide'"
            @click="kefu_to"
        >
            <img class="kefu_img" src="../../views/images/user/kefu-ico.png" />
        </div>
		<van-dialog
		v-model="show_ver" 
		theme="round-button"
		@confirm="confirm"
		:confirmButtonText="$t('utils.confirm')"
		:cancelButtonText="$t('utils.cancel')"
		>
		<div class="show-body">
			{{$t('您认证邮箱后再投资！')}}
		</div>
		</van-dialog>
    </div>
</template>

<script>
import Vue from 'vue'
import Fetch from "../../utils/fetch"
import {CountDown, Checkbox,Popover} from 'vant'
Vue.use(Checkbox)
Vue.use(Popover)

export default {
    name: "login",
    data() {
        return {
			lang:this.$i18n.locale||"zh_cn",
            password: "password",
            show_kefu: false,
            msg_show: true,
			checked: true,
			showPopover:false,
			actions: [
				{ text: '+86' ,icon: require('../images/language/zh_cn.png') ,},
				{ text: '+1' ,icon: require('../images/language/en_us.png') ,},
				{ text: '+81' ,icon: require('../images/language/ja_jp.png') ,},
				{ text: '+55' ,icon: require('../images/language/ko_kr.png') ,},
				{ text: '+84' ,icon: require('../images/language/vi_vn.png') ,},
				{ text: '+60' ,icon: require('../images/language/ms_my.png') ,},
				{ text: '+66' ,icon: require('../images/language/zh_hk.png') ,},
			],
			lan_num:'+86',
			lan_ico:require('../images/language/zh_cn.png'),
            data: {
                username: "",
                password: "",
            },
			show_ver:true,
        };
    },
    created() {
		this.data.username = localStorage.getItem('login_username');
		this.data.password = localStorage.getItem('login_password');
        this.$parent.footer("user", false);
    },
    mounted() {
        var that = this;
        document.body.addEventListener(
            "scroll",
            function() {
                if (!that.show_kefu) {
                    return;
                }
                that.show_kefu = false;
            },
            false
        );
        document.addEventListener(
            "click",
            function(ev) {
                if (ev.target.className != "kefu_img") {
                    that.show_kefu = false;
                }
            },
            false
        );
    },
    methods: {
        kefu_to() {
            if (this.show_kefu) {
                this.$router.push("/kefu");
            }
            this.show_kefu = !this.show_kefu;
        },
        showPwd() {
            if (this.password == "password") {
                this.password = "text";
            } else {
                this.password = "password";
            }
        },
		onSelect(action) {
			console.log(action)
			this.lan_ico = action.icon
			this.lan_num = action.text
			let lang 
			if (action.text == "+86") {
				lang = "zh_cn"
			}
			if (action.text == "+1") {
				lang = "en_us"
			}
			if (action.text == "+81") {
				lang = "ja_jp"
			}
			if (action.text == "+55") {
				lang = "ko_kr"
			}
			if (action.text == "+84") {
				lang = "vi_vn"
			}
			if (action.text == "+60") {
				lang = "ms_my"
			}
			if (action.text == "+66") {
				lang = "zh_hk"
			}
			this.$i18n.locale = lang;
			localStorage.setItem("lang", lang);
		},
        submit() {
            if (!this.data.username) {
                this.$toast(this.$t('login.phoneEmpty'));
                return;
            }

            if (!this.data.password) {
                this.$toast(this.$t('login.passwordEmpty'));
                return;
            }

            // var regex = /^[A-Za-z0-9]{1,20}$/;
            // if (!regex.test(this.data.username)) {
            //     this.$toast(this.$t('login.phoneError'));
            //     return;
            // }
			
			if(this.checked){
				localStorage.setItem('login_username', this.data.username);
				localStorage.setItem('login_password', this.data.password);
			}
			
			if(!this.checked){
				localStorage.removeItem('login_username');
				localStorage.removeItem('login_password');
			}

            Fetch("/index/login", {
                username: this.data.username,
                password: this.data.password
            })
                .then((res) => {
					if(res.data.token){
					    localStorage.setItem('token', res.data.token);
					}
                    this.$toast({
                        background: "#07c160",
                        message: this.$t('login.signInSuccess'),
                    });
                })
                .then(() => {
                    this.$router.replace({
                        path:
                            this.$router.history.current.query.redirect || "/",
                    });
                });
        },
    },
};
</script>

<style lang="less" scoped>
	.user-top{
		text-align: center;
		padding: 80px 0 40px 0;
		color: #ffffff;
		img{
			width: 60px;
			height: 60px;
			border-radius: 44px;
		}
		.user-name{
			font-size: 16px;
			margin-top: 10px;
		}
	}
	.basic_wrap{
		background: url(../images/login/login_bg.png) no-repeat center top;
		background-size: contain;
		
	}
.login_bg {
    width: 100%;
    overflow: hidden;
	.language{
		position: absolute;
		top: 4px;
		right: 0;
		height: 36px;
		img{
			height: 100%;
		}
	}
}
.login-main{
	padding: 0 25px;
}
.basic_wrap .form {
    background: rgba(255, 255, 255, 1);
    box-shadow: 0px 4px 9px 2px rgba(160, 160, 160, 0.15);
    border-radius: 13px;
    padding: 31px 24px 24px 24px;
}

.cut_login {
    width: 207px;
    line-height: 25px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    text-align: center;
    margin: 0 auto;

    a {
        width: 50%;
        padding-bottom: 10px;
        color: #ceced0;
        position: relative;

        .line {
            width: 100%;
            height: 1px;
            position: absolute;
            left: 0;
            bottom: 0;
            background-color: #f2f2f2;
        }
    }

    a.cur {
        color: #f12211;

        .line {
            height: 2px;
            background-image: linear-gradient(to right, #f12211, #f18a11);
        }
    }
}

.mt {
    margin-top: 20px;
}

.item {
    height:48px;
	padding: 0 15px;
    border: 1px solid #dfdfdf;
    font-size: 14px;
    display: flex;
    justify-content: flex-start;
    align-items: center;
	margin-bottom: 15px;
    .icon {
        min-width: 20px;
        height: 20px;

        img {
            width: 100%;
            height: 100%;
        }
    }

    input {
        height: 20px;
        margin-left: 7px;
        flex: 1;
    }
}

.item_reset_pwd {
    font-size: 14px;
    color: #3d96ff;
    text-align: right;
    margin-top: 10px;
    line-height: 20px;
}
.van-checkbox{
	margin-top: 20px;
}
/deep/ .van-checkbox__icon--checked .van-icon {
    color: #fff;
    background-color: #ff5a50;
    border-color: #ff5a50;
}
/deep/ .van-checkbox__label{
	color: #ff5a50;
}
.reset_pwd{
	color: #333;
	margin-top: -20px;
	display: block;
}

.basic_btn {
    margin:30px auto 0 auto;
}
.lan-label{
	display: flex;
	align-items: center;
	white-space: nowrap;
	height: 48px;
}
.lan-label span{
	color: #999;
	display: inline-block;
	margin-left: 6px;
}
.lan-label img{
	width: 22px;
	height: 22px;
}
.kefu-link{
	padding: 20px;
	text-align: center;
}
.kefu-link img{
	width: 35px;
}
.show-body{
	padding: 30px 30px 15px 30px;
	text-align: center;
}

</style>
<style>
	.van-popover{
		width: 80px;
	}
	.van-popover .van-popover__action-text::after{
		left: -100px;
	}
	.van-popover__action-icon{
		border: 1px solid #ececec;
		border-radius: 30px;
	}
	.van-popover__action{
		padding: 0 10px;
	}
	
</style>
