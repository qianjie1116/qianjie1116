<template>
  <div class="recharge_wrap">
    <div class="red_top_bg">
      <div class="back_left" @click="$router.go(-1)"></div>
      <div class="big_tit">{{ $t("invest.recharge") }}</div>
    </div>
    <div class="balance" v-if="eye == 1">
      <p>
        {{ $t("invest.availableBalance") }}
        <van-icon name="eye" @click="eye = 0" />
      </p>
      <p>
        {{ balance }}
      </p>
    </div>
    <div class="balance" v-if="eye == 0">
      <p>
        {{ $t("invest.availableBalance") }}
        <van-icon name="closed-eye" @click="eye = 1" />
      </p>
      <p>******</p>
    </div>
    <form class="form">
      <div class="recharge_wrap">
        <!-- <p>{{$t('invest.rechargeAmount')}}</p> -->
        <div class="form-cell">
          <div class="flex_bd">
            <input
              v-model.trim="data.money"
              type="number"
              step="0.01"
              class="inp"
              :placeholder="$t('invest.rechargeAmount')"
              @input="changeAmount"
            />
          </div>
          <span class="unit">
            <img src="../images/user/recharge4.png" alt="" />
            {{ $t("utils.moneyMark") }}
          </span>
        </div>
        <div>
          <span>{{ actualAmount }}</span>
        </div>
      </div>
      <div class="basic_btn sbtn" @click="$router.push('/kefu')">
        {{ $t("account.kefu") }}
      </div>
     <!-- <div class="recharge_fs">
        <div class="tit">
          {{ $t("invest.paymentMethod") }}
        </div>
        <div class="recharge_cells">
          <div
            v-for="(v, k) in config.payment"
            :key="k"
            class="item"
            @click="choose_type(k + 1, v)"
          >
            <div class="re_icon"><img :src="v.logo" /></div>
            <div class="re_name">
              {{ v.name }}
            </div>
            <div class="check" :class="k + 1 == data.choose ? 'checked' : ''" />
          </div>
        </div>
      </div> -->
    </form>
    <!-- <div class="basic_btn sbtn" @click="submit">
      {{ $t("invest.next") }}
    </div> -->

    <!-- 上传凭证 -->
    <div class="qrcode">
      <div>{{ $t("account.zjz") }}</div>
      <div class="qrcode_img" >
        <van-uploader
          v-model="fileList"
          multiple
          :max-count="1"
          class="upload"
          :max-size="2 * 1024 * 1024"
          @oversize="onOversize"
          :after-read="afterRead"
          :before-read="beforeRead"
        >
        </van-uploader>
      </div>
    </div>
	<div class="basic_btn sbtn" style="margin-top: 30px;z-index: 9999;" @click.stop="submit">
	 {{$t('utils.submit')}}
	</div>
  </div>
</template>

<script>
import Vue from "vue";
import { CountDown, Checkbox, RadioGroup, Icon, Radio, Uploader } from "vant";
import { jsBridge } from "../../utils/jsbridge-mini.js";
import Fetch from "../../utils/fetch";
import Api from "../../interface/index";
import axios from "axios";

Vue.use(RadioGroup);
Vue.use(Radio);
Vue.use(CountDown).use(Checkbox).use(Icon);
Vue.use(Uploader);

export default {
  name: "invest",
  data() {
    return {
      time: 0,
      eye: 1,
      balance: 0.0,
      data: {
        choose: "",
        channel: "",
        money: "",
        id: "",
      },
      payment: [],
      config: {},
      actualAmount: "",
      fileList: [],
      img: "",
    };
  },
  created() {
    this.$parent.footer("user", false);
  },
  mounted() {
    this.start();
  },
  methods: {
    onOversize(file) {
      this.$toast(this.$t("account.within2megabytes"));
    },
    beforeRead(file) {
      if (
        file.type !== "image/jpeg" &&
        file.type !== "image/jpg" &&
        file.type !== "image/png"
      ) {
        this.$toast(this.$t("account.supportPicture"));
        return false;
      }
      return true;
    },
    afterRead(file) {
      let formData = new FormData();
      formData.append("language", this.$i18n.locale || "zh_cn");
      formData.append("file", file.file);
      formData.append("id", this.$router.history.current.params.id);
      formData.append("token", localStorage.getItem("token"));
      // Toast.loading({
      //   forbidClick: true,
      //   duration: 20000,
      // });
      axios
        .post(Api.commonUrl + "/api/index/bank_link_upload", formData)
        .then((r) => {
          // Toast.clear();
          if (r.data.code === 1) {
            this.img = r.data.data;
          } else {
            if (r.data.info) {
              this.$toast(r.data.info);
            } else {
              this.$toast(this.$t("account.uploadFail"));
            }
          }
        });
    },
	
    start() {
      Fetch("/user/recharge", {
        ...this.data,
      }).then((r) => {
        this.balance = r.data.money;
        this.config = r.data;
        this.config.min_recharge = parseInt(this.config.min_recharge);
        this.choose_type(1, r.data.payment[0]);
      });
    },
    checkLimit() {
      const key = "invest_button";
      const ttl = 60;
      let now = Date.parse(new Date()) / 1000;
      let val = localStorage.getItem(key);
      if (!val) {
        val = JSON.stringify({
          ttl: now + ttl,
        });
        localStorage.setItem(key, val);
        return true;
      } else {
        val = JSON.parse(val);
        if (val["ttl"] > now) {
          return false;
        } else {
          val = JSON.stringify({
            ttl: now + ttl,
          });
          localStorage.setItem(key, val);
          return true;
        }
      }
    },
    choose_type(k, payment) {
      this.data.choose = k;
      this.data.channel = payment.type;
      this.data.id = payment.id;
      this.payment = payment;
      this.changeAmount();
    },
	
    submit() {
   
      if (!this.data.money || this.data.money < this.config.min_recharge) {
        this.$toast({
          className: "toastName",
          message:
            this.$t("invest.rechargeAmountLow") +
            this.$t("utils.moneyMark") +
            this.config.min_recharge +
            this.$t("invest.rechargeAmountLow1"),
        });
        return false;
      }
      if (!this.data.channel) {
        this.$toast({
          className: "toastName",
          message: this.$t("invest.paymentMethodEmpty"),
        });
        return false;
      }
	    if (!this.img) {
	      this.$toast({
	        className: "toastName",
	        message: this.$t("account.img"),
	      });
	      return;
	    }
      if (!this.checkLimit()) {
      	this.$toast(this.$t('invest.overtop'));
      	return false;
      }

      console.log(this.data.channel);
     
        let that = this;
		console.log('执行到这里了')
        console.log(this.data.money);
        Fetch("/user/recharge_type", {
          money: this.data.money,
          id: this.data.id,
		  img:this.img,
        }).then((r) => {
          var re = r.data;
          console.log('55555555',re);
          if (re.code == 0) {
            this.$router.replace(re.data.qr_code);
            window.location.href = re.data.qr_code;
          } else {
            // alert(re.message);
			this.$router.replace("/rechargeRecord");
          }
        });
        return;
      } 
  },
};
</script>

<style lang="less" scoped>
/deep/ .van-uploader__input-wrapper {
  width: 100%;
}
/deep/ .van-uploader__wrapper {
  width: 100%;
  height: 100%;
}
/deep/ .van-uploader__upload {
  width: 100%;
  height: 100%;
  margin: 0;
}
/deep/ .van-uploader__preview {
  margin: 0;
}
/deep/ .van-uploader__preview-image {
  width: 100%;
  height: 100%;
}

/deep/.van-image__img{
	max-height: 180px;
}

.qrcode {
  padding-top: 30px;
  padding-bottom: 0px;
  text-align: center;

  div {
    color: #999;
    font-size: 14px;
    margin-bottom: 10px;
  }

  .upload {
    width: 100%;
    height: 100%;
  }

  .qrcode_img {
    width: 250px;
    height: 180px;
    margin: 0 auto;
    background: linear-gradient(to left, #999, #999) left top no-repeat,
      linear-gradient(to bottom, #999, #999) left top no-repeat,
      linear-gradient(to left, #999, #999) right top no-repeat,
      linear-gradient(to bottom, #999, #999) right top no-repeat,
      linear-gradient(to left, #999, #999) left bottom no-repeat,
      linear-gradient(to bottom, #999, #999) left bottom no-repeat,
      linear-gradient(to left, #999, #999) right bottom no-repeat,
      linear-gradient(to left, #999, #999) right bottom no-repeat;
    background-size: 1px 20px, 20px 1px, 1px 20px, 20px 1px;

    span {
      line-height: 220px;
    }

    img {
      width: 240px;
      height: 240px;
      position: relative;
      top: -255px;
    }
  }
}
.red_top_bg {
  height: 168px;
  background-image: url(../images/user/moneybag/bg.png);
  position: fixed;
  background-position: center;
  background-repeat: no-repeat;
  background-size: 100% 100%;
}

.top_right {
  position: absolute;
  font-size: 13px;
  line-height: 18px;
  color: #ffffff;
  top: 36px;
  right: 14px;
}

.balance {
  background: rgba(255, 255, 255, 1);
  border-radius: 6px;
  padding: 15px 0px 25px;
  box-shadow: 2px 2px 5px rgba(115, 115, 115, 0.35);
  position: absolute;
  top: 74px;
  left: 15px;
  right: 15px;
  text-align: center;

  p:nth-child(1) {
    font-size: 12px;
    color: #999999;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    justify-content: center;

    .van-icon {
      font-size: 20px;
      margin-left: 4px;
      color: #c2c2c2;
    }
  }

  p:nth-child(2) {
    color: #ff5551;
    font-size: 24px;
    font-weight: bold;
  }
}

.recharge_cells {
  background-color: #fff;
  padding: 0 15px;
}

.recharge_box {
  width: 100%;
  height: 48px;
  background: rgba(255, 255, 255, 1);
  border-radius: 6px;
  margin-top: 12px;
  padding: 16px 11px;

  input {
    height: 18px;
    width: 100%;
    line-height: 18px;
    font-size: 14px;
  }
}

.form {
  margin-top: 182px;

  .recharge_wrap {
    padding: 0 15px;

    .form-cell {
      padding: 10px;
      background: rgba(255, 255, 255, 1);
      border-radius: 5px;
      box-shadow: 2px 2px 5px rgba(115, 115, 115, 0.35);
      display: flex;
      align-items: center;
      background-color: #fff;

      .flex_bd {
        flex: 1;

        input {
          height: 25px;
          width: 100%;
          line-height: 25px;
          font-size: 14px;
        }
      }

      .unit {
        color: #666666;
        display: flex;
        align-items: center;
        font-size: 12px;

        img {
          width: 16px;
          height: 16px;
          margin-right: 5px;
        }
      }
    }

    div:nth-child(2) {
      text-align: right;
      color: #666666;
      margin-top: 8px;
    }
  }

  .tit {
    border-bottom: 1px solid #ebe9e9;
    font-size: 16px;
    padding: 15px;
    color: #333333;
  }

  .item {
    height: 40px;
    border-bottom: 1px solid #ececec;
    display: flex;
    justify-content: flex-start;
    align-items: center;

    &:last-child {
      border-bottom: none;
    }

    .check {
      width: 16px;
      height: 16px;
      margin-left: 4px;
      background: url(../images/user/c2.png) no-repeat center center;
      background-size: 100% 100%;

      &.checked {
        background: url(../images/user/c1.png) no-repeat center center;
        background-size: 100% 100%;
      }
    }

    .re_icon {
      width: 20px;
      height: 20px;
      margin-right: 5px;

      img {
        width: 20px;
        height: 20px;
      }
    }

    .re_name {
      font-size: 12px;
      flex: 1;
      line-height: 22px;
      color: #333333;
      margin-left: 4px;
    }

    .wx {
      background: url(../images/user/recharge3.png) no-repeat center center;
      background-size: 100% 100%;
    }

    .alipay {
      background: url(../images/user/recharge2.png) no-repeat center center;
      background-size: 100% 100%;
    }

    .usdt {
      background: url(../images/user/recharge1.png) no-repeat center center;
      background-size: 100% 100%;
    }

    .alipay_app {
      background: url(../images/user/recharge2.png) no-repeat center center;
      background-size: 100% 100%;
    }

    .bank {
      background: url(../images/user/recharge4.png) no-repeat center center;
      background-size: 100% 100%;
    }
  }
}

.sbtn {
  width: 213px;
  height: 35px;
  line-height: 35px;
  font-size: 12px;
  margin: 17px auto;
}
</style>
