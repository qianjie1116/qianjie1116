<template>
	<div class="basic_wrap">
		<div class="red_top_bg">
			<div class="back_left" @click="$router.go(-1)"></div>
			<div class="big_tit">{{$t('safe.setting')}}</div>
		</div>
		<div class="wrap_box">
			<div class="item">
				<img src="../images/user/account/icon1.png" alt="">
				<div class="left">
					<span class="icon icon_id"></span>
					<span class="info">{{$t('authEmail.authentication')}}</span>
				</div>
				<div class="right_info" v-if="data.is_auth == '1'">{{$t('safe.verifiedIdentity')}}</div>
				<router-link to="/authEmail" class="right_info auth" v-if="data.is_auth == '0'">{{$t('safe.toVerify')}}
					<div class="right icon_right"></div>
				</router-link>
			</div>
			<router-link to="/account" class="item">
				<img src="../images/user/account/icon2.png" alt="">
				<div class="left">
					<span class="icon icon_login"></span>
					<span class="info">{{$t('safe.paymentOptions')}}</span>
				</div>
				<div class="right icon_right"></div>
			</router-link>
			<router-link to="/language" class="item">
				<img src="../images/user/account/icon3.png" alt="">
				<div class="left">
					<span class="icon icon_login"></span>
					<span class="info">{{$t('safe.language')}}</span>
				</div>
				<div class="right icon_right"></div>
			</router-link>
			<router-link to="/setpwd" class="item">
				<img src="../images/user/account/icon4.png" alt="">
				<div class="left">
					<span class="icon icon_login"></span>
					<span class="info">{{$t('safe.signInPassword')}}</span>
				</div>
				<div class="right icon_right"></div>
			</router-link>
			<router-link to="/setpaypwd" class="item">
				<img src="../images/user/account/icon5.png" alt="">
				<div class="left">
					<span class="icon icon_pay"></span>
					<span class="info">{{$t('safe.paymentPassword')}}</span>
				</div>
				<div class="right icon_right"></div>
			</router-link>
			<router-link to="/about/12" class="item">
				<img src="../images/user/account/icon6.png" alt="">
				<div class="left">
					<span class="icon icon_greement"></span>
					<span class="info">{{$t('index.agreement')}}</span>
				</div>
				<div class="right icon_right"></div>
			</router-link>
			<router-link to="/about/13" class="item">
				<img src="../images/user/account/icon7.png" alt="">
				<div class="left">
					<span class="icon icon_policy"></span>
					<span class="info">{{$t('index.secret')}}</span>
				</div>
				<div class="right icon_right"></div>
			</router-link>
		</div>

		<div class="history_coupon basic_btn flex_center" @click="logout">
			<span>{{$t('safe.signOut')}}</span>
		</div>
	</div>
</template>

<script>
	import Fetch from '../../utils/fetch'
	import bsHeader from '../../components/bsHeader.vue'
	export default {
		name: "safe",
		components: {
			bsHeader
		},
		data() {
			return {
				data: {},
				appVer: "",
				wgtVer: "",
			};
		},
		created() {
			this.$parent.footer('user', false);
		},
		mounted() {
			this.start();
			this.getVersion();
		},
		methods: {
			start() {
				Fetch('/user/info').then((r) => {
					this.data = r.data;
				});
			},
			logout() {
				localStorage.removeItem('token');
				this.$router.replace("/");
			},
		}
	};
</script>

<style lang="less" scoped>
	.big_tit {
		color: #fff;
	}

	.wrap_box {
		display: flex;
		flex-direction: column;
		align-items: center;

		.item {
			height: 40px;
			width: 100%;
			padding: 10px 15px;
			border-bottom: 1px solid #ECECEC;
			font-size: 14px;
			color: rgba(0, 0, 0, .8);
			line-height: 20px;
			display: flex;
			align-items: center;

			img {
				width: 17px;
				height: 17px;
				margin-right: 8px;
			}

			.left {
				flex: 1;
			}

			.right {
				width: 20px;
				height: 20px;
				background: url(../images/user/arrow.png) no-repeat center center;
				background-size: 100% 100%;
			}

			.right_info {
				color: rgba(0, 0, 0, .6);
			}

			.tips {
				color: rgba(0, 0, 0, .6);
				margin-left: auto;
				margin-right: 4px;
				font-weight: normal;
			}
		}
	}

	.history_coupon {
		margin: 30px auto 0 auto;
		width: 80%;
		height: 36px;
		text-align: center;
		span {
			font-size: 14px;
			height: 20px;
			line-height: 20px;
			position: relative;
			&::after {
				content: '';
				position: absolute;
				top: 3px;
				right: -25px;
				width: 12px;
				height: 13px;
				background: url(../images/user/more.png) no-repeat center center;
				background-size: 100% 100%;
			}
		}
	}

	.flex_center {
		display: flex;
		justify-content: center;
		align-items: center;
	}

	.auth {
		display: flex;
		align-items: center;
		justify-content: flex-start;
	}
</style>
