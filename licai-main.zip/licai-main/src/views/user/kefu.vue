<template>
	<div class="kefu_v">
		<iframe :src="kefu_link"></iframe>
	</div>
</template>

<script>
	import Fetch from '../../utils/fetch'

	export default {
		name: "index",
		components: {},
		data() {
			return {
				kefu_link: ''
			};
		},
		created() {
			this.$parent.footer('user');
		},
		mounted() {
			this.start();
		},
		methods: {
			start() {

				// Fetch('/user/info').then((r) => {
				// 	this.data = r.data;
				// 	console.log(r.data);
				// 	this.kefu_link = u+'&visiter_name='+r.data.mobile+'&visiter_id='+r.data.uid+'&avatar='+r.data.user_icon
				// });
				Fetch('/index/webconfig', {type: 'web'}).then(res => {
				    this.kefu_link = res.data.kefu_link;
				})
			},
		}
	};
</script>

<style lang="less" scoped>
	.kefu_v {
		position: fixed;
		width: 100%;
		height: 100%;
		-webkit-overflow-scrolling: touch;
		overflow-y: scroll;

		iframe {
			padding-bottom: 55px;
			width: 100%;
			height: 100%;
		}
	}
</style>
