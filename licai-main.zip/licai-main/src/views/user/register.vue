<template>
  <div class="basic_wrap">
    <!-- <div class="lan-box">
      <van-popover
        v-model="showPopover"
        trigger="click"
        placement="bottom-start"
        :offset="[0, 0]"
        :actions="actions"
        @select="onSelect"
      >
        <template #reference>
          <div class="lan-label">
            <img :src="lan_ico" alt="" />
            <span>{{ lan_num }}</span>
          </div>
        </template>
      </van-popover>
    </div> -->
    <div class="user-top">
      <img src="../images/login/logo.png" alt="" />
      <div class="user-name">Marriott</div>
    </div>
    <!-- <div class="login_bg">
      <div
        class="back_left"
        @click="$router.back()"
      />
      <div class="big_tit">
        {{$t('register.register')}}
      </div>
    </div> -->
    <div class="login-main">
      <form class="form">
        <div class="cut_login">
          <router-link to="/login">
            {{ $t("register.signIn") }}
            <div class="line" />
          </router-link>
          <router-link class="cur" to="/register">
            {{ $t("register.signUp") }}
            <div class="line" />
          </router-link>
        </div>
        <div class="item mt" style="padding-left: 10px">
          <span class="icon">
            <img src="../images/login/phone.png" alt="" />
          </span>
          <input
            v-model.trim="data.mobile"
            type="text"
            class="inp"
            :placeholder="$t('register.phoneNumber')"
          />
        </div>

        <div class="item mt" style="padding-left: 10px">
          <span class="icon">
            <img src="../images/login/email.png" alt="" />
          </span>
          <input
            v-model.trim="data.account"
            type="text"
            class="inp"
            :placeholder="$t('register.account')"
          />
        </div>

        <!-- <div class="item">
				<span class="icon">
					<img src="../images/login/p1.png" alt="">
				</span>
				<input type="text" class="inp" v-model.trim="data.name" placeholder="请输入用户名" />
			</div> -->
        <div class="item" style="padding-left: 10px">
          <span class="icon">
            <img src="../images/login/lock.png" alt="" />
          </span>
          <input
            v-model.trim="data.password"
            :type="password"
            class="inp"
            :placeholder="$t('register.password')"
          />
          <div
            class="eye_bi"
            :class="password == 'text' ? 'eye' : ''"
            @click="showPwd"
          />
        </div>
        <div class="item" style="padding-left: 10px">
          <span class="icon">
            <img src="../images/login/lock.png" alt="" />
          </span>
          <input
            v-model.trim="data.spassword"
            :type="password"
            class="inp"
            :placeholder="$t('register.password')"
          />
          <div
            class="eye_bi"
            :class="password == 'text' ? 'eye' : ''"
            @click="showPwd"
          />
        </div>

        <div class="item" style="padding-left: 10px">
          <span class="icon">
            <img src="../images/login/lock.png" alt="" />
          </span>
          <input
            v-model.trim="data.yzm"
            type="text"
            class="inp"
            :placeholder="$t('register.yzm')"
          />

          <IdentifyCode
            :identify-code="identifyCode"
            :content-width="74"
            :content-height="40"
            @click="refreshCode"
            style="margin-top: 2px"
          ></IdentifyCode>
        </div>

        <!-- 			<div class="item">
				<input type="password" class="inp" v-model.trim="data.paypwd" placeholder="请输入支付密码" />
			</div>
			<div class="item">
				<input type="password" class="inp" v-model.trim="data.confirm_paypwd" placeholder="请再次输入支付密码" />
			</div> -->
        <div v-if="show_sms > 0" class="item">
          <input
            v-model.trim="data.code"
            type="text"
            class="inp"
            :placeholder="$t('register.code')"
          />
          <van-count-down
            :time="time"
            class="btn get_captcha"
            @finish="timeCall"
          >
            <template v-slot="timeData">
              <span @click="sendcode">{{
                timeData.seconds > 0
                  ? timeData.seconds
                  : $t("register.sendCode")
              }}</span>
            </template>
          </van-count-down>
        </div>
        <div class="item">
          <span class="icon">
            <img src="../images/login/p2.png" class="people" alt="" />
          </span>
          <input
            v-model.trim="data.inviteCode"
            type="text"
            class="inp"
            :placeholder="$t('register.referralCode')"
          />
        </div>
        <div
          class="basic_btn sbtn"
          :class="
            data.mobile == '' || data.password == '' //||data.code == ''
              ? 'no_touch'
              : ''
          "
          @click="submit"
        >
          {{ $t("register.signUpBtn") }}
        </div>
      </form>
    </div>

    <van-dialog
      v-model="statement"
      confirm-button-color="#fb661e"
      :close-on-click-overlay="true"
      @click="privacyStatementHide"
    >
    </van-dialog>
    <van-dialog
      v-model="agreement"
      confirm-button-color="#fb661e"
      :close-on-click-overlay="true"
      @click="agreementHider"
    >
    </van-dialog>
    <div
      v-if="msg_show"
      class="kefu-link"
      :class="show_kefu ? '' : 'kefu_hide'"
      @click="kefu_to"
    >
      <img class="kefu_img" src="../../views/images/user/kefu-ico.png" />
    </div>
  </div>
</template>

<script>
import Vue from "vue";
import { CountDown, Checkbox, Dialog } from "vant";
import Fetch from "../../utils/fetch";
import IdentifyCode from "vue-identifycode"; // 引入包

Vue.use(CountDown).use(Checkbox).use(Dialog).use(IdentifyCode);

export default {
  name: "Register",
  components: { IdentifyCode },
  data() {
    return {
      time: 0,
      agreement: false,
      statement: false,
      show_kefu: false,
      msg_show: true,
      show_sms: 0,
      password: "password",
      data: {
        password: "",
        spassword: "",
        mobile: "",
        t_mobile: "",
        code: "",
        agent: 10000,
        account: "",
        inviteCode: "",
      },
      showPopover: false,
      actions: [
        { text: "中国", icon: require("../images/language/zh_cn.png") },
        { text: "English", icon: require("../images/language/en_us.png") },
        { text: "日本", icon: require("../images/language/ja_jp.png") },
        { text: "Brasil", icon: require("../images/language/ko_kr.png") },
        { text: "Việt Nam", icon: require("../images/language/vi_vn.png") },
        { text: "Malaysia", icon: require("../images/language/th_th.png") },
        { text: "ประเทศไทย", icon: require("../images/language/ms_my.png") },
        { text: "Indonesia", icon: require("../images/language/zh_hk.png") },
      ],
      lan_num: "中国",
      lan_ico: require("../images/language/zh_cn.png"),
      config: {},
      identifyCode: "",
    };
  },
  created() {
    this.$parent.footer("user", false);
    this.getparams();
    // 安卓返回IMEI，苹果返回UID值
    /*BSL.PhoneID('callName');
		window.callName = this.methodName;
		// 获取手机OAID
		BSL.GetOAID('getExternalInfo');
		window.getExternalInfo = this.getExternalInfoData; */
  },
  mounted() {
    if (this.$route.query.agent) {
      localStorage.setItem("agent", this.$route.query.agent);
      this.data.agent = this.$route.query.agent;
    } else {
      if (localStorage.getItem("agent")) {
        this.data.agent = localStorage.getItem("agent");
      }
    }
    var that = this;
    document.body.addEventListener(
      "scroll",
      function () {
        if (!that.show_kefu) {
          return;
        }
        that.show_kefu = false;
      },
      false
    );
    document.addEventListener(
      "click",
      function (ev) {
        if (ev.target.className != "kefu_img") {
          that.show_kefu = false;
        }
      },
      false
    );
    Fetch("/index/webconfig", {
      type: "web",
    }).then((res) => {
      this.config = res.data;
      this.show_sms = res.data.sms_verify;
    });
    this.identifyCode = this.createCode();
  },
  methods: {
    createCode() {
      let code = "";
      const codeLength = 4; // 验证码的长度
      // eslint-disable-next-line no-array-constructor
      const random = new Array(
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        "A",
        "B",
        "C",
        "D",
        "E",
        "F",
        "G",
        "H",
        "J",
        "K",
        "L",
        "M",
        "N",
        "P",
        "Q",
        "R",
        "S",
        "T",
        "U",
        "V",
        "W",
        "X",
        "Y",
        "Z"
      ); // 随机数
      for (let i = 0; i < codeLength; i++) {
        // 循环操作
        const index = Math.floor(Math.random() * 32); // 取得随机数的索引（0~35）
        code += random[index]; // 根据索引取得随机数加到code上
      }
      return code;
    },
    refreshCode() {
      this.identifyCode = this.createCode();
    },
    onSelect(action) {
      console.log(action);
      this.lan_ico = action.icon;
      this.lan_num = action.text;
      let lang;
      if (action.text == "中国") {
        lang = "zh_cn";
      }
      if (action.text == "English") {
        lang = "en_us";
      }
      if (action.text == "日本") {
        lang = "ja_jp";
      }
      if (action.text == "Brasil") {
        lang = "ko_kr";
      }
      if (action.text == "Việt Nam") {
        lang = "vi_vn";
      }
      if (action.text == "Malaysia") {
        lang = "th_th";
      }
      if (action.text == "ประเทศไทย") {
        lang = "ms_my";
      }
      if (action.text == "Indonesia") {
        lang = "zh_hk";
      }
      this.$i18n.locale = lang;
      localStorage.setItem("lang", lang);
    },
    kefu_to() {
      if (this.show_kefu) {
        this.$router.push("/kefu");
      }
      this.show_kefu = !this.show_kefu;
    },
    showPwd() {
      if (this.password == "password") {
        this.password = "text";
      } else {
        this.password = "password";
      }
    },
    methodName(r) {
      this.data.imei = r;
    },
    getExternalInfoData(info) {
      var info = JSON.parse(info);
      console.log(info);
      if (info.code == 0) {
        this.data.oaid = info.oaid;
      }
    },
    getparams() {
      var m = this.$route.query.m;
      this.data.t_mobile = m;
    },
    timeCall() {
      this.is_send = false;
      this.time = 0;
    },
    sendcode() {
      if (this.is_send) {
        return;
      }

      if (!this.data.mobile) {
        this.$toast(this.$t("register.phoneEmpty"));
        return;
      }

      this.is_send = true;

      Fetch("/index/register_code", {
        mobile: this.data.mobile,
      })
        .then(() => {
          this.time = 60 * 1000;
          this.$toast({
            background: "#07c160",
            message: this.$t("register.sendSuccess"),
          });
        })
        .catch(() => {
          this.is_send = false;
        });
    },
    submit() {
      if (!this.data.mobile) {
        this.$toast({
          className: "toastName",
          message: this.$t("register.phoneEmpty"),
        });
        return false;
      }
      if (!this.data.account) {
        this.$toast({
          className: "toastName",
          message: this.$t("register.accountEmpty"),
        });
        return false;
      }
      if (!this.data.password) {
        this.$toast({
          className: "toastName",
          message: this.$t("register.passwordEmpty"),
        });
        return false;
      }

      if (!this.data.spassword) {
        this.$toast({
          className: "toastName",
          message: this.$t("register.passwordEmpty"),
        });
        return false;
      }
      if (this.data.password != this.data.spassword) {
        this.$toast({
          className: "toastName",
          message: this.$t("register.passwordError"),
        });
        return false;
      }
      console.log(`??`, this.identifyCode);
      if (
        !this.identifyCode ||
        !this.data.yzm ||
        this.identifyCode.toLowerCase() != this.data.yzm.toLowerCase()
      ) {
        this.$toast({
          className: "toastName",
          message: this.$t("register.yzm_err"),
        });
        return;
      }
      //   && this.config.sms_verify
      console.log(`this.data.code`, this.data.inviteCode);
      if (!this.data.inviteCode || this.data.inviteCode == "") {
        this.$toast({
          className: "toastName",
          message: this.$t("register.codeEmpty"),
        });
        return false;
      }

      Fetch("/index/register", {
        ...this.data,
      }).then((res) => {
        if (res.data.token) {
          localStorage.setItem("token", res.data.token);
        }
        this.$toast({
          className: "toastName",
          message: this.$t("register.signUpSuccess"),
        });
        this.$router.replace("/");
      });
    },
    userAgreement() {
      this.agreement = true;
    },
    agreementHider() {
      this.agreement = false;
    },
    privacyStatement() {
      this.statement = true;
    },
    privacyStatementHide() {
      this.statement = false;
    },
  },
};
</script>

<style lang="less" scoped>
.user-top {
  text-align: center;
  padding: 70px 0 30px 0;
  color: #ffffff;

  img {
    width: 60px;
    height: 60px;
    border-radius: 60px;
    border: 2px solid #ffffff;
  }

  .user-name {
    font-size: 16px;
    margin-top: 10px;
  }
}
.code {
  position: absolute;
  right: 1px;
  top: 1px;
  display: inline-block;
}
.basic_wrap {
  position: relative;
  background-image: url(../images/login/bg.jpg);
  background-position: 0 0;
  background-repeat: no-repeat;
  background-size: cover;
  min-height: 100vh;

  .lan-box {
    position: absolute;
    top: 10px;
    left: 25px;
  }
}

.login_bg {
  width: 100%;
  overflow: hidden;

  .language {
    position: absolute;
    top: 4px;
    right: 0;
    height: 36px;

    img {
      height: 100%;
    }
  }
}

.login-main {
  padding: 0 25px;
}

.basic_wrap .form {
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 4px 9px 2px rgba(160, 160, 160, 0.15);
  border-radius: 13px;
  padding: 31px 24px 24px 24px;
}

.cut_login {
  width: 207px;
  line-height: 25px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 18px;
  text-align: center;
  margin: 0 auto;

  a {
    width: 50%;
    padding-bottom: 10px;
    color: #ceced0;
    position: relative;

    .line {
      width: 100%;
      height: 1px;
      position: absolute;
      left: 0;
      bottom: 0;
      background-color: #f2f2f2;
    }
  }

  a.cur {
    color: #f12211;

    .line {
      height: 2px;
      background-image: linear-gradient(to right, #f12211, #f18a11);
    }
  }
}

.mt {
  margin-top: 20px;
}

.item {
  height: 48px;
  padding: 0 15px;
  border: 1px solid #dfdfdf;
  font-size: 14px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  margin-bottom: 15px;

  .icon {
    width: 20px;
    min-width: 20px;
    text-align: center;
    height: 20px;

    img {
      width: 20px;
      height: 20px;
    }
  }

  input {
    height: 20px;
    margin-left: 7px;
    flex: 1;
  }
}

.item_reset_pwd {
  font-size: 14px;
  color: #3d96ff;
  text-align: right;
  margin-top: 10px;
  line-height: 20px;
}

.van-checkbox {
  margin-top: 20px;
}

/deep/ .van-checkbox__icon--checked .van-icon {
  color: #fff;
  background-color: #ff5a50;
  border-color: #ff5a50;
}

/deep/ .van-checkbox__label {
  color: #ff5a50;
}

.reset_pwd {
  color: #333;
  margin-top: -20px;
  display: block;
}

.basic_btn {
  margin: 30px auto 0 auto;
}

.lan-label {
  display: flex;
  align-items: center;
  white-space: nowrap;
  height: 48px;
  min-width: 24px;
  height: 25px;
  padding-right: 8px;
  border-radius: 25px;
  background-image: linear-gradient(to right, #ffff80, #ffffff);
}

.lan-label span {
  display: inline-block;
  margin-left: 3px;
}

.lan-label img {
  width: 22px;
  height: 22px;
}

.kefu-link {
  padding: 20px;
  text-align: center;
}

.kefu-link img {
  width: 35px;
}

.show-body {
  padding: 30px 30px 15px 30px;
  text-align: center;
}
</style>
<style>
.van-popover {
  width: 120px;
}

.van-popover__action {
  height: 40px;
  line-height: 40px;
}

.van-popover .van-popover__action-text::after {
  left: -100px;
}

.van-popover__action-icon {
  border: 1px solid #ececec;
  border-radius: 30px;
}

.van-popover__action {
  padding: 0 10px;
}
</style>
