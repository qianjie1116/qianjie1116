<template>
  <div class="bg">
    <div>
      <div class="back_left" @click="$router.back()"></div>
      <div class="big_tit">{{ $t("safe.verifiedIdentity") }}</div>
    </div>

    <div
      style="
        background-color: #fff;
        width: auto;
        margin: 20px;
        margin-top: 100px;
        padding: 20px;
        border-radius: 5px;
        box-shadow: 2px 2px 5px rgba(115, 115, 115, 0.35);
      "
    >
      <div
        style="
          display: flex;
          align-items: center;
          justify-content: space-between;
          line-height: 3;
          font-size: 14px;
        "
      >
        <p style="color: #999">{{ $t("account.realname") }}</p>
        <p></p>
      </div>
      <div
        style="
          display: flex;
          align-items: center;
          justify-content: space-between;
          line-height: 3;
          font-size: 14px;
        "
      >
        <p style="color: #999">{{ $t("account.zjzid") }}</p>
        <p></p>
      </div>
    </div>
  </div>
</template>

<script>
import Fetch from "../../utils/fetch";
export default {
  name: "authSuccess",
  data() {
    return {
      data: "111",
    };
  },
  created() {
    this.$parent.footer("user", false);
    Fetch("/user/info").then((r) => {
        console.log(r);
        this.data = r.data;
      });
  },
};
</script>

<style scoped>
.bg {
  background-image: linear-gradient(to bottom, #ff5252, #ff8044);
  background-size: cover;
  background-repeat: no-repeat;
  width: 100%;
  min-height: 100vh;
}
</style>
