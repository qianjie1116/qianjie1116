<template>
  <div class="basic_wrap">
    <div class="red_top_bg">
      <div class="back_left" @click="$router.back()"></div>
    </div>
    <form class="form" @submit.prevent="submit">
      <div class="tittle_verified">
        {{ $t("authEmail.authentication") }}
      </div>
      <div class="">
        {{ $t("authEmail.tip") }}
        {{ data.mobile }}
      </div>
      <div class="qrcode">
        <div>{{ $t("account.zjz") }}</div>
        <div class="qrcode_img">
          <!-- <span>QR code</span> -->
          <van-uploader
            v-model="fileList"
            multiple
            :max-count="1"
            class="upload"
            :max-size="2 * 1024 * 1024"
            @oversize="onOversize"
            :after-read="afterRead"
            :before-read="beforeRead"
          >
          </van-uploader>
        </div>
      </div>
      <div class="item">
        <input
          v-model.trim="realname"
          type="text"
          class="inp"
          :placeholder="$t('account.realname')"
        />
      </div>

      <div class="item">
        <input
          v-model.trim="idcard"
          type="text"
          class="inp"
          :placeholder="$t('account.zjzid')"
        />
      </div>

      <div class="item">
        <input
          v-model.trim="yzm"
          type="text"
          class="inp"
          :placeholder="$t('register.yzm')"
        />
        <span @click.stop="refreshCode">
          <IdentifyCode
            :identify-code="identifyCode"
            :content-width="74"
            :content-height="40"
            style="margin-top: 2px"
          ></IdentifyCode>
        </span>
      </div>

      <button type="submit" class="basic_btn sbtn">
        {{ $t("authEmail.submit") }}
      </button>
    </form>
  </div>
</template>

<script>
import Vue from "vue";
import { CountDown, Checkbox, Uploader, Toast } from "vant";
import Fetch from "../../utils/fetch";
import bsHeader from "../../components/bsHeader.vue";
import axios from "axios";
import Api from "../../interface/index";
import IdentifyCode from "vue-identifycode"; // 引入包

Vue.use(CountDown).use(Uploader).use(Toast).use(IdentifyCode).use(Checkbox);
export default {
  name: "setpwd",
  components: {
    bsHeader,
    IdentifyCode,
  },
  data() {
    return {
      data: {},
      time: 0,
      code: "",
      fileList: [],
      realname: "",
      idcard: "",
      yzm: "",
      idcard_img: "",
      identifyCode: "",
    };
  },
  created() {
    this.$parent.footer("user", false);
  },
  mounted() {
    this.start();
    this.identifyCode = this.createCode();
  },
  methods: {
    createCode() {
      let code = "";
      const codeLength = 4; // 验证码的长度
      // eslint-disable-next-line no-array-constructor
      const random = new Array(
        2,
        3,
        4,
        5,
        6,
        7,
        8,
        9,
        "A",
        "B",
        "C",
        "D",
        "E",
        "F",
        "G",
        "H",
        "J",
        "K",
        "L",
        "M",
        "N",
        "P",
        "Q",
        "R",
        "S",
        "T",
        "U",
        "V",
        "W",
        "X",
        "Y",
        "Z"
      ); // 随机数
      for (let i = 0; i < codeLength; i++) {
        // 循环操作
        const index = Math.floor(Math.random() * 32); // 取得随机数的索引（0~35）
        code += random[index]; // 根据索引取得随机数加到code上
      }
      return code;
    },
    refreshCode() {
      console.log(333);

      this.identifyCode = this.createCode();
    },
    onOversize(file) {
      this.$toast(this.$t("account.within2megabytes"));
    },
    beforeRead(file) {
      if (
        file.type !== "image/jpeg" &&
        file.type !== "image/jpg" &&
        file.type !== "image/png"
      ) {
        this.$toast(this.$t("account.supportPicture"));
        return false;
      }
      return true;
    },
    afterRead(file) {
      let formData = new FormData();
      formData.append("language", this.$i18n.locale || "zh_cn");
      formData.append("file", file.file);
      formData.append("id", this.$router.history.current.params.id);
      formData.append("token", localStorage.getItem("token"));
      Toast.loading({
        forbidClick: true,
        duration: 20000,
      });
      axios
        .post(Api.commonUrl + "/api/index/bank_link_upload", formData)
        .then((r) => {
          Toast.clear();
          if (r.data.code === 1) {
            this.idcard_img = r.data.data;
          } else {
            if (r.data.info) {
              this.$toast(r.data.info);
            } else {
              this.$toast(this.$t("account.uploadFail"));
            }
          }
        });
    },
    start() {
      Fetch("/user/info").then((r) => {
        this.data = r.data;
      });
    },
    timeCall() {
      this.is_send = false;
      this.time = 0;
    },
    sendcode() {
      if (this.is_send) {
        return;
      }
      this.is_send = true;

      Fetch("/index/auth_email_code")
        .then(() => {
          this.time = 60 * 1000;
          this.$toast({
            background: "#07c160",
            message: this.$t("authEmail.sendsuccess"),
          });
        })
        .catch(() => {
          this.is_send = false;
        });
    },
    submit() {
      console.log(2222);

      if (!this.realname) {
        this.$toast({
          className: "toastName",
          message: this.$t("account.realname"),
        });
        return;
      }

      if (!this.idcard) {
        this.$toast({
          className: "toastName",
          message: this.$t("account.zjzid"),
        });
        return;
      }

      if (!this.idcard_img) {
        this.$toast({
          className: "toastName",
          message: this.$t("account.idcard_img"),
        });
        return;
      }

      if (this.identifyCode.toLowerCase() != this.yzm.toLowerCase()) {
        this.$toast({
          className: "toastName",
          message: this.$t("register.yzm_err"),
        });
        return;
      }

      Fetch("/user/real", {
        realname: this.realname,
        idcard: this.idcard,
        idcard_img: this.idcard_img,
      }).then((res) => {
        console.log(`real:`, res);
        // this.$toast({
        //   background: "#07c160",
        //   message: this.$t("authEmail.success"),
        // });
        // if (this.$route.query.redirect) {
        //   this.$router.replace(
        //     this.$route.query.redirect + "&money=" + this.$route.query.money
        //   );
        // } else {
          this.$router.replace("/user");
        // }
      });
    },
  },
};
</script>

<style lang="less" scoped>
.back_left {
  background: url(../../views/images/item/back_b.png) no-repeat center center;
}

.big_tit {
  color: #000000;
}

.tittle_verified {
  margin-top: 40px;
  margin-bottom: 20px;
  font-size: 26px;
}

.form {
  width: 100%;
  margin-top: 32px;
  padding: 0 20px;

  .item {
    width: 100%;
    height: 45px;
    border-radius: 2px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.1);
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 40px 0;

    input {
      flex: 1;
      padding: 0 10px;
      height: 22px;
      font-size: 16px;
      line-height: 22px;
    }

    .right_icon {
      width: 13px;
      height: 13px;
      background: url(../images/item/clear.png) no-repeat center center;
      background-size: 100% 100%;
      margin-right: 12px;
    }
  }
}

.basic_btn {
  width: 100%;
  margin-top: 10px;
}

/deep/ .van-dropdown-menu__bar {
  box-shadow: none;
  // position: relative;
  // z-index: 10;
  // height: 34px;
  // border: 1px solid #D9D9D9;
  // border-radius: 4px;
  // text-align: left;
}
/deep/ .van-button--primary {
  background-color: transparent;
  border: none;
  width: 100%;
  height: 100%;
}
/deep/ .van-uploader__input-wrapper {
  width: 100%;
}
/deep/ .van-uploader__wrapper {
  width: 100%;
  height: 100%;
}
/deep/ .van-uploader__upload {
  width: 100%;
  height: 100%;
  margin: 0;
}
/deep/ .van-uploader__preview {
  margin: 0;
}
/deep/ .van-uploader__preview-image {
  width: 100%;
  height: 100%;
}

.qrcode {
  padding-top: 30px;
  padding-bottom: 0px;
  text-align: center;

  div {
    color: #999;
    font-size: 14px;
    margin-bottom: 10px;
  }

  .upload {
    width: 100%;
    height: 100%;
  }

  .qrcode_img {
    width: 250px;
    height: 180px;
    margin: 0 auto;
    background: linear-gradient(to left, #999, #999) left top no-repeat,
      linear-gradient(to bottom, #999, #999) left top no-repeat,
      linear-gradient(to left, #999, #999) right top no-repeat,
      linear-gradient(to bottom, #999, #999) right top no-repeat,
      linear-gradient(to left, #999, #999) left bottom no-repeat,
      linear-gradient(to bottom, #999, #999) left bottom no-repeat,
      linear-gradient(to left, #999, #999) right bottom no-repeat,
      linear-gradient(to left, #999, #999) right bottom no-repeat;
    background-size: 1px 20px, 20px 1px, 1px 20px, 20px 1px;

    span {
      line-height: 220px;
    }

    img {
      width: 240px;
      height: 240px;
      position: relative;
      top: -255px;
    }
  }
}
</style>
