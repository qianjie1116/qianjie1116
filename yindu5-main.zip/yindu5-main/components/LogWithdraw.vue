<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view class="line common_block" style="margin:0 10px 20px 10px;padding:10px;">
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$util.THEME.TIP}">Amount</view>
					<view :style="{color:$util.THEME.PRIMARY}" style="flex:40%;font-size: 18px;font-weight: 700;">
						{{$util.formatNumber(item.money)}}
					</view>
					<view style="margin-left: auto;text-align: center;" :style="{color:$util.THEME.RISE}">
						{{item.desc_type}}
					</view>
				</view>

				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view :style="{color:$util.THEME.TIP}">Order Number:</view>
					<view :style="{color:$util.THEME.TEXT}">
						{{item.order_sn}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view :style="{color:$util.THEME.TIP}">Date Time:</view>
					<view :style="{color:$util.THEME.TEXT}">
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view :style="{color:$util.THEME.TIP}">Reason:</view>
					<view :style="{color:$util.THEME.TEXT}">
						{{item.reason}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:3%;">
						<image :src="item.icon" :style="$util.calcImageSize(12)"></image>
					</view>
					<view style="flex:97%;" :style="{color:item.color}">{{item.text}}</view>
				</view>
				<!-- <view style="display: flex;align-items: center;">
					<u-button text="Cancel" type="error" @click="handleCancel(item.id)" v-if="item.status==0"></u-button>
				</view> -->
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogWithdraw",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		mounted() {
			this.getList()
		},
		methods: {
			handleCancel(id){
				let _this = this;
				uni.showModal({
					title: "Are you sure you want to cancel the withdrawal??",
					cancelText: "cancellation",
					confirmText: "check",
					success: function(res) {
						if (res.confirm) {
							_this.qx_post(id);
						} else if (res.cancel) {
							console.log('User clicks Cancel.');
						}
					}
				})
			},
			async qx_post(id) {
				uni.showLoading({
					title: 'process',
				})
				const result = await this.$http.post(this.$http.API_URL.APP_QX, {
					id: id
				});
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
					this.getList()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				this.list =[]; // 每次请求前，清空数组。
				const result = await this.$http.get(this.$http.API_URL.USER_WITHDRAW, {})
				if (result.data.code == 0) {
					result.data.data.forEach((item, index) => {
						this.list.push({
							...item,
							...this.$util.TRADE_LOG_STATUS[item.status]
						})
					});
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		}
	}
</script>

<style>

</style>