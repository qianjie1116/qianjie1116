<!-- 公司简介 -->
<template>
	<view style="margin:0 20px;padding: 10px 0; border-bottom: 1px solid #999;">
		<view style="display: flex;align-items: center;justify-content: space-between;"
			:style="{color:$util.THEME.LABEL}">
			<view>Company Overview</view>
			<view @click="handleChangeShow()">{{isShow?'간략히':'더보기'}}</view>
		</view>
		<view style="display: flex;align-items: center;justify-content: space-around;padding:10px;">
			<view :style="{color:$util.THEME.TEXT}" style="font-size: 16px;font-weight: 700;">{{info.cname}}</view>
			<view :style="{color:$util.THEME.SECONDARY}" style="font-size: 20px;font-weight: 900;">{{info.code}}</view>
		</view>
		<view style="white-space:pre-wrap;" :style="{color:$util.THEME.LABEL}">{{desc}}</view>
	</view>
</template>

<script>
	export default {
		name: "CompanyProfile",
		props: ['params'],
		data() {
			return {
				info: {},
				desc: '',
				isShow: false,
			};
		},
		created() {
			this.getData();
		},
		methods: {
			handleChangeShow() {
				this.isShow = !this.isShow;
				this.desc = this.calcDesc(this.info.description);
			},
			calcDesc(val) {
				const shortText = val.length <= 30 ? val : `${val.slice(0,30)} ...`;
				return this.isShow ? val : shortText;
			},
			async getData() {
				uni.showLoading({
					mask: true,
					title: this.$lang.LOADING,
				})
				const result = await this.$http.post(this.$http.API_URL.PRODUCT_INFO_TOW, {
					code: this.params.code,
					stock_id: this.params.id
				})
				if (result.data.code == 0) {
					this.info = result.data.data[0].top2;
					this.desc = this.calcDesc(this.info.description);
					uni.hideLoading()
				}
			}
		}
	}
</script>

<style>

</style>