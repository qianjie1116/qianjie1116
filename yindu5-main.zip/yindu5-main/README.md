# MOIPOTOP

![LOGO](https://github.com/github1413/moipotop/raw/main/static/logo.png)

# Update Log 2024.06.11
- 大宗产品，用户购买，无需审核，直接购买成功。
- 大宗交易，所有用户需输入密码才能进入查看。
- 后台统一设置一个进入大宗交易的密码。用户输入了这个密码才能进入操作。
- 密码由客户自行联系业务员索要，不走软件客服。
- 密码设置方式：总后台有权限设置。
