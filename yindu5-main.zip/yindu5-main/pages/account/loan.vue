<template>
	<view>
		<view class="header_wrapper_10">
			<CustomHeader title="Loan services" @action="handleBack()"></CustomHeader>
		</view>

		<view class="college-content" style="margin-top: 15px;">
			<view class="hui2">
				Lending Institution
			</view>
			<view class="cipher" @click="show=true">
				<input maxlength="11" placeholder="Please select a lending Institution" v-model="dk_name"></input>
			</view>
			<view class="hui2">
				Loan Amount
			</view>
			<view class="cipher">
				<input maxlength="12" placeholder="Please enter the minimum loan amount" type="text"
					v-model="x_amount"></input>
			</view>

			<!-- <view class="hui2">
				Loan maximum amount
			</view>
			<view class="cipher">
				<input maxlength="12" placeholder="Please enter the maximum loan amount" type="text"
					v-model="d_amount"></input>
			</view> -->
		</view>

		<view class="purchase" @click="submit">
			Confirm
		</view>
		<u-picker :show="show" :columns="columns" confirmText="Confirm" cancelText="Cancel" @confirm="jigou_click"
			@cancel="show=false"></u-picker>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				userInfo: {}, // 用户信息
				show: false,
				columns: [
					['Citibank']
				],
				money: "",
				top_index: 0,
				bid: "",
				dk_name: "",
				x_amount: "",
				d_amount: ""
			}
		},
		onShow() {
			this.getUserInfo();
		},
		onLoad() {},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},

			jigou_click(item) {
				console.log(item);
				console.log(item.indexs[0]);
				this.bid = item.indexs[0] * 1 + 1
				this.dk_name = item.value[0]
				this.show = false
			},

			async getUserInfo() {
				const result = await this.$http.get(`api/user/info`, {});
				console.log(result);
				this.userInfo = result.data.data;
			},

			async submit() {
				if (!this.bid) {
					return uni.$u.toast('Please select a lending institution');
				}
				if (!this.x_amount) {
					return uni.$u.toast('Please enter the minimum loan amount');
				}
				// if (!this.d_amount) {
				// 	return uni.$u.toast('Please enter the maximum loan amount');
				// }

				let list = await this.$http.post('api/daikuan/shenqing', {
					bid: this.bid,
					x_amount: this.x_amount,
					// d_amount: this.d_amount,
					xinyong: this.userInfo.xinyong,
				})
				if (list.data.code == 1) {
					uni.$u.toast(list.data.message);
					setTimeout(() => {
						uni.navigateTo({
							url: this.$util.PAGE_URL.ACCOUNT_CREDIT_SCORE
						});
					}, 1000)
				} else {
					return uni.$u.toast(list.data.data);
				}
			},
		},
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 100rpx;
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		display: flex;
		justify-content: space-between;
		// align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		margin-top: -30rpx;
		border-radius: 30rpx 30rpx 0 0;
		background: #fff;
		padding: 30rpx;

		.cipher {
			padding: 20rpx;
			margin: 30rpx 0;
			background: #f5f5f5;
			border-radius: 10rpx;

		}

	}

	/deep/.uni-input-placeholder {
		color: #C0C4CC;
		font-size: 28rpx;
	}

	.purchase {
		// background-image: linear-gradient(to right, #1a73e8, #014b8d);
		background-color: #f6e77f;
		margin: 60rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #000;
		font-weight: 600;
	}
</style>