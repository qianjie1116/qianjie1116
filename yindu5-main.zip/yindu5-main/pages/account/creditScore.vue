<template>
	<view>
		<view class="header_wrapper_10">
			<CustomHeader title="Credit Score" @action="handleBack()"></CustomHeader>
		</view>

		<view style="padding-top: 20px;text-align: center;">
			<view style="font-size: 32px;font-weight: 700;margin-top: 10px;" :style="{color:$util.THEME.TEXT_DARK}">
				{{$util.formatNumber(userInfo.xinyong)}}
			</view>

			<view style="margin-top: 10px;" :style="{color:$util.THEME.TIP}">
				Your credit score</view>
		</view>

		<view style="display: flex;align-items: center;justify-content:space-around;margin-top: 20px;">
			<view class="common_btn btn_primary" :style="{color:$util.THEME.TEXT}" @click="handleLinkLoan()"
				style="margin:0 10px;width: 45vw;"> I want to borrow money</view>
			<view class="common_btn btn_secondary" :style="{color:$util.THEME.PRIMARY}" @click="handlLinkService()"
				style="margin:0 10px;width: 45vw;"> I want to repay</view>
		</view>

		<!-- 检索订单 -->

		<view style="margin-top: 20px;">
			<EmptyData v-if="list && list.length<=0"></EmptyData>
			<block v-for="(item,index) in list" :key="index">
				<view class="common_block" style="margin:0 10px 10px 10px;padding:10px;">
					<view style="display: flex;flex-wrap: nowrap;align-items: center;">
						<view style="flex:40%" :style="{color:$util.THEME.TIP}">Loan min amount</view>
						<view style="flex: 60%;text-align: right;">{{$util.formatNumber(item.x_amount)}}</view>
					</view>
					<view style="display: flex;flex-wrap: nowrap;align-items: center;">
						<view style="flex:40%" :style="{color:$util.THEME.TIP}">Loan max amount</view>
						<view style="flex: 60%;text-align: right;">{{$util.formatNumber(item.d_amount)}}</view>
					</view>
					<view style="display: flex;flex-wrap: nowrap;align-items: center;">
						<view style="flex:40%" :style="{color:$util.THEME.TIP}">Status</view>
						<view style="flex: 60%;text-align: right;font-size: 13px;"
							:style="{color:$util.setStatusColorLoan(item.state)}">
							{{$util.setStatusTextLoan(item.state)}}
						</view>
					</view>
					<view style="display: flex;flex-wrap: nowrap;align-items: center;" :style="{color:$util.THEME.TIP}">
						<view style="flex:40%">Datetime</view>
						<view style="flex: 60%;text-align: right;">{{item.created_at.slice(0,10)}}</view>
					</view>
				</view>
			</block>
		</view>
		
		<u-modal :show="show" title="" @cancel="cancel" @confirm="confirm()" :showCancelButton='true'
			content='Do you want to repay?' :cancelText="$lang.CANCEL" :confirmText="$lang.CONFIRM">
		</u-modal>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				userInfo: {}, // 用户信息
				show: false,
				list: [],
			}
		},
		onShow() {
			this.getUserInfo();
			this.getLoanLog();
		},
		onLoad() {},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1, //返回层数，2则上上页
				});
			},
			handleLinkLoan(){
				// 检查信用分是否达标
				if(this.userInfo.xinyong<100){
					uni.$u.toast('Sorry, your credit score is insufficient');
					return false;
				}
				uni.navigateTo({
					url:this.$util.PAGE_URL.ACCOUNT_LOAN
				})
			},
			handlLinkService() {
				this.show = true;

			},
			//点击取消
			cancel() {
				this.show = false;
			},
			// 点击确认
			confirm() {
				this.show = false;
				this.kefu()
			},
			async kefu() {
				let list = await this.$http.get(this.$http.API_URL.APP_CONFIG, {})
				let url = list.data.data[8].value
			
				// window.open(this.list, '_blank');
					if (window.android) {
						window.android.callAndroid("open," + url)
						return;
					}
					if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
						.nativeExt) {
						window.webkit.messageHandlers.nativeExt.postMessage({
							msg: 'open,' + url
						})
						return;
					}
			
					var u = navigator.userAgent;
					var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
					if (isiOS) {
						window.location.href = url;
						return;
					}
					window.open(url)
				
			},
			async getUserInfo() {
				const result = await this.$http.get(`api/user/info`, {});
				console.log(result);
				this.userInfo = result.data.data;
			},

			async getLoanLog() {
				const result = await this.$http.get(`api/daikuan/log/`, {});
				console.log(result);
				if (result.data.code == 0) {
					this.list = result.data.data;
				}
			},
		},
	}
</script>

<style lang="scss">
	.college-bg {
		padding: 60rpx 30rpx 0;
		height: 100rpx;
		background-image: linear-gradient(to right, #1a73e8, #014b8d);
		display: flex;
		justify-content: space-between;
		// align-items: center;
		text-align: center;

		image {
			width: 20rpx;
			height: 40rpx;
		}

		.college-text {

			color: #fff;
			font-weight: 800;
			font-size: 36rpx;
		}

	}

	.college-content {
		margin-top: -30rpx;
		border-radius: 30rpx 30rpx 0 0;
		background: #fff;
		padding: 30rpx;

		.cipher {
			padding: 20rpx;
			margin: 30rpx 0;
			background: #f5f5f5;
			border-radius: 10rpx;

		}

	}

	/deep/.uni-input-placeholder {
		color: #C0C4CC;
		font-size: 28rpx;
	}

	.purchase {
		// background-image: linear-gradient(to right, #1a73e8, #014b8d);
		background-color: #f6e77f;
		margin: 60rpx 30rpx;
		border-radius: 10rpx;
		padding: 20rpx 0;
		text-align: center;
		color: #000;
		font-weight: 600;
	}
</style>