<!-- 银转证  存款 -->
<template>
	<view>
		<view class="header_wrapper_10">
			<CustomHeader :title="$lang.DEPOSIT" @action="handleBack()"></CustomHeader>
		</view>
		<view style="display: flex;align-items: center;flex-direction: column;margin-top: 30px;">
			<view :style="{color:$util.THEME.TIP}">Available Funds</view>
			<view style="font-size: 28px;font-weight: 900;" :style="{color:$util.THEME.TEXT_DARK}">
				{{$util.formatNumber(userInfo.money)}}
			</view>
			<view style="padding:20px;" :style="{color:$util.THEME.TIP}">{{$lang.TIP_AMOUNT_AVAIL}}</view>
		</view>
		
		<view style="margin:20rpx;">
			<view style="font-size: 16px;font-weight: 700;margin-left: 20px;">Recharge Amount(RS)</view>
			<view class="common_input_wrapper" style="margin: 10px;">
				<!-- <image mode="aspectFit" src='/static/money.png' :style="$util.calcImageSize(20)">
				</image> -->
				<input v-model="amount" placeholder="Please enter the recharge amount" type="number"></input>
				<!-- <view @click="handleAllAmount(userInfo.money)" class="btn_small">{{$lang.TIP_AMOUNT_ALL}}</view> -->
			</view>
			
			<view style="font-size: 16px;font-weight: 700;margin-left: 20px;">Recharge Instructions</view>
			<view style="margin-left: 20px;line-height: 1.5;margin-bottom: 20px;" :style="{color:$util.THEME.TIP}">The general limit for bank cards is Rs 10,000, and online payment is applicable to amounts below RS.</view>
					
			<view class="common_btn btn_primary" style="width: 60%;margin:auto;" @click="handleCustomer()">
				Contact customer service
			</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				userInfo: {},
				amount:'', // 充值金额
			};
		},
		onLoad(option) {
			this.getInfo()
		},
		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			async handleCustomer() {
					let list = await this.$http.get(this.$http.API_URL.APP_CONFIG, {})
					let url = list.data.data[8].value
				
					// window.open(this.list, '_blank');
						if (window.android) {
							window.android.callAndroid("open," + url)
							return;
						}
						if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
							.nativeExt) {
							window.webkit.messageHandlers.nativeExt.postMessage({
								msg: 'open,' + url
							})
							return;
						}
				
						var u = navigator.userAgent;
						var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
						if (isiOS) {
							window.location.href = url;
							return;
						}
						window.open(url)
					
			},
			async getInfo() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.get(this.$http.API_URL.USER_INFO, {})
				if (result.data.code == 0) {
					this.userInfo = result.data.data;
					uni.hideLoading()
				} else {
					uni.$u.toast(result.data.message);
					uni.hideLoading()
				}
			},
		},
	}
</script>