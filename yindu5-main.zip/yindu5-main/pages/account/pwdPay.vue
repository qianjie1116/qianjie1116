<!-- 펀드 비밀번호 -->
<template>
	<view >
		<view class="header_wrapper_10">
			<CustomHeader title="Reset Payment Password" @action="handleBack()"></CustomHeader>
		</view>
		<view class="common_block"
			style="display: flex;flex-direction: column;justify-content: center;align-items: center;margin-top:6vh;">
			<view class="common_input_wrapper">
				<image mode="aspectFit" src="/static/password.png" :style="$util.calcImageSize(20)">
				</image>
				<input v-model="value" type="password" :placeholder="$lang.OLD_PWD" :placeholderStyle="$util.setStylePlaceholder()"></input>
			</view>
			<view class="common_input_wrapper">
				<image mode="aspectFit" src="/static/password.png" :style="$util.calcImageSize(20)">
				</image>
				<input v-model="value2" type="password" :placeholder="$lang.NEW_PWD" :placeholderStyle="$util.setStylePlaceholder()"></input>
			</view>

			<view class="common_input_wrapper">
				<image mode="aspectFit" src="/static/password.png" :style="$util.calcImageSize(20)">
				</image>
				<input v-model="value3" type="password" :placeholder="$lang.NEW_PWD2" :placeholderStyle="$util.setStylePlaceholder()"></input>
			</view>

			<view class="common_btn btn_primary" style="width:50%;margin: 20px 0;" @click="transactionPassword">{{$lang.CONFIRM}}</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				value:'',
				value2: "",
				value3: "",
			};
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: this.$util.PAGE_URL.ACCOUNT_CENTER
				});
			},
			//修改交易密码
			async transactionPassword() {
				const result = await this.$http.post(this.$http.API_URL.PAY_PASSWORD, {
					oldpass: this.value,
					newpass: this.value2,
					confirmpass: this.value3,
				})
				if (result.data.code == 0) {
					uni.$u.toast('It is changed.');
					setTimeout(() => {
						uni.switchTab({
							url: this.$util.PAGE_URL.ACCOUNT_CENTER
						});
					}, 1000)
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		}
	}
</script>