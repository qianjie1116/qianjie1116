<!-- 主页 -->
<template>
	<view style="position: relative;">
		<view class="bg_home_header">
			<Header></Header>
		</view>
		<view style="position: absolute;top:60px;left: 50%;transform: translateX(-50%);">
			<image src="/static/home_banner.png" mode="widthFix" style="width: 343px;height: 164px;"></image>
		</view>
		<view style="">
			<view class="common_block">
				<ButtonGroup :btns="$util.BTNS_CONFIG_HOME" :col="33.33" @action="linkLarge"></ButtonGroup>
			</view>
			<!-- 指数 -->
			<template v-if="list.length>0">
				<view style="display: flex;align-items: center;justify-content: space-between;margin:0 4px;">
					<block v-for="(item,index) in list" :key="index">
						<view :class="item.PERCCHANGE>0?'green':'red'"
							style="margin:4px;padding:4px;flex:33.33%;border-radius: 6px;text-align: center;">
							<!-- <view class="name" style="font-size: 11px;">{{item.indxnm}}</view> -->
							<view class="name" style="font-size: 11px;">{{item.name}}</view>
							<view class="price">{{item.pricecurrent}}</view>
							<view>
								<image :src="item.PERCCHANGE>0?'/static/lv.png':'/static/hong.png'" mode="aspectFit"
									style="width: 100px;height: 45px;"></image>
							</view>
							<view class="per">[{{item.PERCCHANGE}}%]</view>
						</view>
					</block>
				</view>
			</template>
			<GoodsList ref="goods"></GoodsList>
		</view>

		<template v-if="isShow">
			<view class="common_mask">
				<view class="common_block common_popup" style="min-height:35vh;margin:auto">
					<view class="popup_header" style="color:#121212">Please Enter Password</view>

					<view style="display: flex;align-items: center;justify-content: center;">
						<view class="common_input_wrapper">
							<input v-model="password" placeholder="Please Enter Password" type="password"
								:placeholder-style="$util.setStylePlaceholder()"></input>
						</view>
					</view>

					<view style="text-align: right;padding-right: 60rpx;font-size: 24rpx;"
						:style="{color:$util.THEME.TIP}">
						Request the Password From The Assistant
					</view>

					<view style="display: flex;justify-content: space-evenly;margin:20px 0;">
						<view class="common_btn btn_primary" style="width: 30%;" @click="handleConfirm"> Submit
						</view>
						<view class="common_btn btn_secondary" style="width: 30%;" @click="handleCancel">
							{{$lang.CANCEL}}
						</view>
					</view>
				</view>
			</view>
		</template>

	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import GoodsList from '@/components/GoodsList.vue';
	export default {
		components: {
			Header,
			ButtonGroup,
			EmptyData,
			GoodsList,
		},
		data() {
			return {
				timer: null,
				page: 1,
				gp_index: 0,
				list: [],
				listTitles: ['BANKEX', 'S&P BSE 100', 'Next 50'],
				isShow: false, // 大宗需弹层输入密码查看 /by 2024.06.11
				largePath: '', // 大宗的路由
				password: '', // 大宗的页面进入前 弹层输入密码
			}
		},

		onLoad() {},

		onShow() {
			this.getDataList();
			this.startTimer();
			if (this.$refs.goods) {
				this.$refs.goods.getList();
			}
		},
		onHide() {
			clearInterval(this.timer);
		},

		// onReachBottom() {
		// 	this.page = this.page + 1;
		// 	this.$refs.goods.getList(this.page);
		// },
		onUnload() {
			uni.$off('onSuccess');
		},
		methods: {
			// 按钮组，点击大宗交易
			linkLarge(val) {
				console.log('linkLarge:', val);
				this.largePath = val;
				this.isShow = true;
			},

			// 弹层取消按钮事件
			handleCancel() {
				this.isShow = false;
			},
			// 弹层确认按钮事件
			async handleConfirm() {
				// 判断输入密码不为空。后端对比密码，返回结果
				if (this.password == '') {
					uni.showToast({
						title: 'Please Enter Password',
						icon: 'none'
					});
					return false;
				}

				// 获取后台设置的大宗查看密码
				const result = await this.$http.get(`api/app/config`);
				console.log(result.data);
				if (result && result.data.code == 0) {
					const temp = Object.values(result.data.data).reduce((map, item) => {
						map.set(item.key, item.value);
						return map;
					}, new Map());

					console.log(temp.get('big_pwd'));
					// 根据返回结果，处理是否跳转到大宗交易
					if (this.password == temp.get('big_pwd')) {
						this.isShow = false;
						uni.navigateTo({
							url: this.largePath
						});
					} else {
						uni.showToast({
							title: 'The password you entered is incorrect',
							icon: 'none'
						});
					}
				} else {
					uni.showToast({
						title: result.data.message,
						icon: 'none'
					});
				}
			},

			handleIPO() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.TRADE_IPO
				});
			},
			startTimer() {
				this.timer = setInterval(() => {
					// this.$refs.free.getList();
					this.getDataList();
					this.$refs.goods.getList();
				}, 10000);
			},
			// 指数数据
			async getDataList() {
				const result = await this.$http.post('api/goods/zhishu', {})
				if (result.data.code == 0) {
					this.list = result.data.data && result.data.data.length > 3 ? result.data.data.slice(0, 3) : result
						.data.data;
					// console.log(this.list);
				}
			},
			// 银转证
			async silver() {
				this.kefu()
			},
			async kefu() {
				let list = await this.$http.get(this.$http.API_URL.APP_CONFIG, {})
				let url = list.data.data[8].value

				// window.open(this.list, '_blank');
				if (window.android) {
					window.android.callAndroid("open," + url)
					return;
				}
				if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
					.nativeExt) {
					window.webkit.messageHandlers.nativeExt.postMessage({
						msg: 'open,' + url
					})
					return;
				}

				var u = navigator.userAgent;
				var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
				if (isiOS) {
					window.location.href = url;
					return;
				}
				window.open(url)

			},
		},
	}
</script>

<style>
	.green {
		background: #d8efff;
		color: #16a139;
	}

	.red {
		background: linear-gradient(180deg, rgba(253, 67, 49, .06), rgba(255, 120, 95, .06));
		color: #fd4331;
	}
</style>