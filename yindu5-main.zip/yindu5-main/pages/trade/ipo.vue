<!-- 新股申购 -->
<template>
	<view>
		<view class="header_wrapper_10">
			<CustomHeader title="IPO" @action="handleBack()"></CustomHeader>
		</view>
		<view class="common_block gap10"
			style="display: flex;align-items: center;justify-content:space-around;margin-top: 20px;padding: 10px;">
			<view class="common_btn btn_primary flex-1" style="padding:2px 4px;text-align: center;" @click="handleTradeLog()">Application record</view>
			<view class="common_btn btn_secondary flex-1" style="padding:2px 4px;text-align: center;" @click="luckyNumber()" >Pass record</view>
		</view>

		<view style="margin: 10px;border-top-left-radius: 15px;border-top-right-radius: 15px;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<template v-if="current == 0">
				<block v-for="(item,index) in list" :key="index">
					<view style="border-bottom: 0.01rem solid #e0e0e0;padding: 10px;">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$util.THEME.TEXT}" style="font-size: 18px;">{{item.goods.name}}</view>
							<view @click="to_skip(item.id)" class="common_btn btn_primary"
								style="padding:2px 10px;transform: scale(0.75);">Apply</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$util.THEME.TIP}">Subscription amount</view>
							<view :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(item.price)}}</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$util.THEME.TIP}">Price/Earnings Ratio</view>
							<view :style="{color:$util.THEME.PRIMARY}">{{item.shiying}}</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$util.THEME.TIP}">Opening Date</view>
							<view :style="{color:$util.THEME.TIP}">{{item.shengou_date}}</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$util.THEME.TIP}"> Closing Date</view>
							<view :style="{color:$util.THEME.TIP}">{{item.rj_date}}</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$util.THEME.TIP}">Allotment Date</view>
							<view :style="{color:$util.THEME.TIP}">{{item.gb_date}}</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$util.THEME.TIP}"> Listing Date</view>
							<view :style="{color:$util.THEME.TIP}">{{item.online_date}}</view>
						</view>
					</view>
				</block>
			</template>

			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view style="border-bottom: 2rpx solid #e0e0e0;padding-bottom:20rpx;">
						<view class="display approve">
							<view>
								<view class="corporation">{{item.goods.name}}</view>
								
							</view>
							<view class="subscription-times">Subscription time<text>{{item.shengou_date}}</text> </view>
						</view>

						<view class="display" style="margin-top: 10rpx;">
							<view class="display price">Subscription price<text>{{$util.formatNumber(item.price)}}</text>
							</view>
							<view class="display price">
								Price/Earnings Ratio<text>{{$util.formatNumber(item.shiying)}}</text>
							</view>
						</view>
						<view class="display price">
							cycle<text>{{$util.formatNumber(item.fa_amount)}}</text>
						</view>
					</view>
				</block>
			</template>		
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		components: {
			CustomHeader,
			EmptyData,
		},
		data() {
			return {
				current: 0,
				list: [],
			};
		},
		onLoad(item) {},
		onShow() {
			this.getList();
		},

		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},

			to_skip(id) {
				uni.navigateTo({
					url: `/pages/index/components/newShares/nullElement/nullElement?id=${id}`
				});
				// console.log(gid, fa_price, '携带');
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.post(this.$http.API_URL.TRADE_IPO_LIST, {
					type: this.current + 1, // 传参 1或2
				})
				this.list = result.data.data;
				uni.hideLoading();
			},

			//구독기록 订阅记录
			handleTradeLog() {
				uni.navigateTo({
					url: this.$util.PAGE_URL.TRADE_IPO_LOG
				});
			},
			//우승기록 获胜记录
			luckyNumber() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/luckyNumber/luckyNumber'
				});
			},
		}
	}
</script>