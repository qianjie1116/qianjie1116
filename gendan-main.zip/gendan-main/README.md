# B-stable
`B-stable`更改
![LOGO](https://github.com/github1413/B-stable/raw/main/static/logo.png)


# UI
```
https://lanhuapp.com/link/#/invite?sid=lXcuH2Sa
```

- FOF 主页面
- - 两个基金产品数据：
- - 基金成员构成列表：
- - 基金提交：

市场中`货币`使用:`WS_COIN_URL`,详情跳转`coin`文件夹
市场中列外几项：`WS_Zonghe_URL`,详情跳转``文件夹


# Update Log 2024.07.21
- 添加各国国旗svg文件

# Update Log 2024.06.25
- 新增等级页面及等级说明页面。
- 个人中心改下
- 充值页面。不跳转客服，下面加一个上传截图的，请求充值的接口。

# Update Log 2024.06.24
<!-- 
个人中心加邀请码  读取字段code，点击就复制好邀请链接   
邀请链接为   域名+/pages/account/access?code=xxxx
 -->
- 注册页面自动填写code，如果链接含有code，默认到页面的注册状态下

# Update Log 2024.06.23
- `Coin`完善卖出逻辑。<!--  fangxiang=1是市价,2限价 -->
- `Team`团队，放在`Level`页面， tab[L1 L2]

# Update Log 2024.06.22
- `API` 请求替换为原来的方式。
- 添加`account/level`等级页面,`levelDesc`等级说明页面。
- 添加`Wealth`。<!-- - 4.理财参考ui重构 -->
- `Coin`的卖出：与买入使用同一页面，卖出不含杠杆。
# Update Log 2024.06.21
- `market/index`:市场。[Coin Track]
- 添加`XAU`,直指页面`/pages/stock/overview?code=xau`,
- 添加`Coin`的详情和购买页面，详情页面卖出，以弹层处理。
- - `Coin`的K线采用`websocket`返回数据，分钟视图下，按照每分钟更新。
- 没有实名，需要吧前段实名的入口去掉

<!-- - `stock/overview` 变更:
- - 支持 `websocket` 和`http`; -->
- - 有一个选择，选择市价、限价交易。选择限价，显示金额输入框。
- - 市价就是实时价；限价就是用户输入金额提交。
 ```
 project_type_id:1 
	显示买入卖出按钮。调用 this.connect();
 project_type_id:2  
	只显示买入按钮。调用 this.onSetTimeout();
 ```
<!-- 
- 2.详情里的socket对接  pyject_type_id=1的调用socket   等于2的就像以前不断请求
- 3.详情页ui改下
- 单股详情：k维持不变。 type1的时候详细信息用socket ，type2的时候用http -->
