// 页面URL 硬编码 通常用于指定跳转
export const LAUNCH = `/pages/launch`; // 启动页
export const ACCOUNT_ACCESS = `/pages/account/access`; // 登入、注册
export const HOME = `/pages/home`; // 主页

export const SERVICE = `/pages/service`; // 客服 正常使用此行
// export const SERVICE = `/pages/servicePush`; // 客服 上架过审使用此行
export const ABOUT_US = `/pages/about`; // 关于、隐私协议、用户协议、版本更新
export const SEARCH = `/pages/search`; // 搜索 
export const NOTIFICATION = `/pages/notification`; // 通知 

export const ACCOUNT_WITHDRAW = `/pages/account/withdraw`; // 提款
export const ACCOUNT_DEPOSIT = `/pages/account/deposit`; // 存款

export const ACCOUNT_CENTER = `/pages/account/center`; // 个人中心
export const ACCOUNT_PWD = `/pages/account/pwd`; // 登入密码
export const ACCOUNT_ZHIFUPWD = `/pages/Introduction/Paymentpwd`; // 支付密码
export const ACCOUNT_GERENXINXI = `/pages/Introduction/personaldata`; // 个人信息
export const ACCOUNT_BIANJIZILIAO = `/pages/Introduction/EditProfile`; // 编辑个人资料
export const ACCOUNT_GUANLITIXIAN = `/pages/Introduction/Managewithdrawals`; // 管理提现地址
export const ACCOUNT_GUANLICHONGZHI = `/pages/Introduction/Managewithdrawals`; // 管理充值地址
export const ACCOUNT_SHIMINGRENZHENG = `/pages/Introduction/Verified`; // 实名认证




export const ACCOUNT_TRADE = `/pages/account/trade`; // 个人持仓
export const ACCOUNT_TRADE_DETAIL = `/pages/account/tradeDetail`; // 个人持仓 单coin持仓详情
export const ACCOUNT_TRADE_LOG = `/pages/account/tradeLog`; // 账户交易记录
export const ACCOUNT_PRVITE_PACT = `/pages/account/pact`; // 隐私协议
export const ACCOUNT_BING_BANK = `/pages/account/bangk`; // 绑卡
export const ACCOUNT_BING_BANK_ADD = `/pages/account/bangkAdd`; // 绑卡

export const TRADE_IPO = `/pages/trade/ipo/index`; // ipo交易
export const TRADE_WEALTH = `/pages/trade/wealth/index`; // Wealth 理财
export const TRADE_WEALTH_RECORD = `/pages/trade/wealth/wealthRecord`; // Wealth 记录
export const TRADE_WEALTH_JIAOYI = `/pages/trading/jiaoyi`; // 交易

export const MARKET = `/pages/jiaoyi/jiaoyi`; // 市场

export const STOCK_OVERVIEW = `/pages/stock/overview`; // 单股概况
export const STOCK_BUY = `/pages/stock/buy`; // 单股买入

export const REMITTANCE = `/pages/remittance/index`; // 汇款

export const TRADE_WEALTH_PROMOTION = `/pages/Promotion`; // 推广中心

// coin
export const COIN_INDEX = `/pages/coin/index`;
export const COIN_DETAIL = `/pages/coin/detail`;

// others
export const OTHERS_INDEX = `/pages/others/index`;
export const OTHERS_DETAIL = `/pages/others/detail`;

// 等级页面
export const ACCOUNT_LEVEL = `/pages/account/level`;
// 等级说明页面
export const LEVEL_DESC = `/pages/levelDesc?cate_id=21`;

// 跟单交易
export const TRADE_COPY_INDEX = `/pages/trade/copy/index`;
export const TRADE_COPY_DETAIL = `/pages/trade/copy/detail`;
export const TRADE_COPY_FOF = `/pages/trade/copy/fof`;

export const TRADE_IPO_DETAIL = `/pages/trade/ipo/detail`; // IPO 详情