// 模拟数据

const THREE_HOUR = 1000 * 60 * 60 * 3; // 3 小时
const DAY = 1000 * 60 * 60 * 24; // 24 小时
const THREE_DAY = 1000 * 60 * 60 * 24 * 3; // 3*24 3天
const FIVE_DAY = 1000 * 60 * 60 * 24 * 5; // 5天
const FIVETEEN_DAY = 1000 * 60 * 60 * 24 * 15; // 15天
const THIRTY_DAY = 1000 * 60 * 60 * 24 * 30; // 30天 thirty
const NINTY_DAY = 1000 * 60 * 60 * 24 * 90; //  90天

const formatMonthDay = (timeString) => {
	// console.log('原值:', timeString);
	const curLang = uni.getStorageSync('lang') || 'en-US';
	// console.log('当前语言', curLang);
	const opt = {
		year: 'numeric',
		month: 'numeric',
		day: 'numeric',
		// hour: 'numeric',
		// minute: 'numeric',
		// second: 'numeric',
		// hour12: false, // 以24小时制处理
	};
	const result = new Intl.DateTimeFormat(curLang, opt).format(timeString);
	// console.log('格式化：', result);
	return result;
};

const formatYear = (timeString) => {
	// console.log('原值:', timeString);
	const curLang = uni.getStorageSync('lang') || 'en-US';
	// console.log('当前语言', curLang);
	const opt = {
		year: 'numeric',
		month: 'numeric',
		// day: 'numeric',
	};
	const result = new Intl.DateTimeFormat(curLang, opt).format(timeString);
	// console.log('格式化：', result);
	return result;
};

// 生成随机数
export const genRandomNumber = (min, max, isFloat) => {
	let rand = Math.random() * (max - min) + min;
	return isFloat ? parseFloat(rand.toFixed(2)) : Math.floor(rand);
}

/*
	7d 30d 90d 180d all
	月度盈亏：每个月一个数字。最后一个元素为当月，倒推12个月。
	周：持仓盈亏，平仓盈亏。最近7天，七个元素，每个元素，两个数值(持，平)。
	持仓时间：24H 7d 3w 1m 6m 
		24H: 
	交易量：24H 7d 3w 1m 6m
*/

// all 默认一年
export const genYears = () => {
	const temp = new Date().getTime(); // 当前时间戳
	let result = [];
	for (let i = 0; i < 7; i++) {
		result.push(temp - NINTY_DAY * i);
	}
	result = result.sort((a, b) => a - b).map(item => formatYear(new Date(item)));
	console.log(result);
	return result;
};

// 180天 18天一个，共是个
export const genMonthSix = () => {
	const temp = new Date().getTime(); // 当前时间戳
	let result = [];
	for (let i = 0; i < 7; i++) {
		result.push(temp - THIRTY_DAY * i);
	}
	result = result.sort((a, b) => a - b).map(item => formatMonthDay(new Date(item)));
	console.log(result);
	return result;
}

// 90天 九天一个元素，共10元素
export const genMonthThree = () => {
	const temp = new Date().getTime(); // 当前时间戳
	let result = [];
	for (let i = 0; i < 7; i++) {
		result.push(temp - FIVETEEN_DAY * i);
	}
	result = result.sort((a, b) => a - b).map(item => formatMonthDay(new Date(item)));
	console.log(result);
	return result;
};

// 30天
export const genMonthOne = () => {
	const temp = new Date().getTime(); // 当前时间戳
	let result = [];
	for (let i = 0; i < 7; i++) {
		result.push(temp - FIVE_DAY * i);
	}
	result = result.sort((a, b) => a - b).map(item => formatMonthDay(new Date(item)));
	console.log(result);
	return result;
}

// 3weeks 3*7=21，分为七个元素
export const genWeekThree = () => {
	const temp = new Date().getTime(); // 当前时间戳
	let result = [];
	for (let i = 0; i < 7; i++) {
		result.push(temp - THREE_DAY * i);
	}
	// ['7/14', '7/15', '7/16', '7/17', '7/18', '7/19', '7/20']
	result = result.sort((a, b) => a - b).map(item => formatMonthDay(new Date(item)));
	console.log(result);
	return result;
}

// 获取当前时间，倒推 7天，7个元素
export const genWeekOne = () => {
	const temp = new Date().getTime(); // 当前时间戳
	let result = [];
	for (let i = 0; i < 7; i++) {
		result.push(temp - DAY * i);
	}
	// ['7/14', '7/15', '7/16', '7/17', '7/18', '7/19', '7/20']
	result = result.sort((a, b) => a - b).map(item => formatMonthDay(new Date(item)));
	console.log(result);
	return result;
};

// 获取当前时间，倒推24H 分为八个时段
export const genDate24H = () => {
	const temp = new Date().getTime(); // 当前时间戳
	console.log(`temp:`, temp);
	// 当前时间-3小时 = 一个元素
	let result = [];
	for (let i = 1; i < 9; i++) {
		result.push(temp - THREE_HOUR * i);
	}
	// [2, 5, 8, 11, 14, 17, 20, 23]
	result = result.map(item => new Date(item).getHours()).sort((a, b) => a - b);
	console.log(`result:`, result);
	return result;
}



// 生成EA交易数据
export const genEAList = () => {
	let result = [];
	for (let i = 0; i <= 5; i++) {
		result.push({
			id: i + 1,
			code: genRandomNumber(100000, 999999, false),
			name: `구매내역_${i}`,
			rate: genRandomNumber(1, 999, true),
			price: genRandomNumber(1000, 99999, true),
			shengou_date: '2024.04.26',
			maxValue: genRandomNumber(100000, 999999, false),
			currentValue: genRandomNumber(100000, 888888, false),
		})
	}
	return result;
}

// 生成折价交易数据
export const genDiscountList = () => {
	let result = [];
	for (let i = 0; i <= 5; i++) {
		result.push({
			id: i + 1,
			goods: {
				code: genRandomNumber(100000, 999999, false),
				name: `구매내역_${i}`,
				rate: genRandomNumber(1, 999, true),
			},
			price: genRandomNumber(1000, 99999, true),
			shengou_date: '2024.04.26',
		})
	}
	return result;
}

// 生成IPO 产品列表数据
export const genIPOList = () => {
	let result = [];
	for (let i = 0; i <= 5; i++) {
		result.push({
			id: i + 1,
			goods: {
				code: genRandomNumber(10000, 99999, false),
				name: `구매내역_${i}`,
			},
			price: genRandomNumber(1000, 99999, true),
			shiying: genRandomNumber(1000, 99999, true),
			shengou_date: '2024.04.26',
		})
	}
	return result;
}


// 生成IPO订单列表数据
export const genIPOOrderList = () => {
	const temp = ['깊은', '북쪽', '상하이'];
	let result = [];
	for (let i = 0; i <= 5; i++) {
		result.push({
			id: i + 1,
			goods: {
				code: genRandomNumber(10000, 99999, false),
				name: `구매내역_${i}`,
				locate: temp[genRandomNumber(0, 2, false)]
			},
			price: genRandomNumber(1000, 99999, true),
			shiying: genRandomNumber(1000, 99999, true),
			shengou_date: '2024.04.26',
			fa_amount: genRandomNumber(1000, 99999, true),
		})
	}
	return result;
}

// 生成 IPO申购成功订单列表
export const genIPOSuccessLog = () => {
	let result = [];
	for (let i = 0; i <= 5; i++) {
		result.push({
			id: i + 1,
			status: genRandomNumber(-1, 2, false),
			goods: {
				code: genRandomNumber(10000, 99999, false),
				name: `구매내역_${i}`,
				locate: temp[genRandomNumber(0, 2, false)]
			},
			price: genRandomNumber(1000, 99999, true),
			shiying: genRandomNumber(1000, 99999, true),
			shengou_date: '2024.04.26',
			apply_amount: genRandomNumber(1000, 99999, true),
			success_num_amount: genRandomNumber(1000, 99999, true),
			success: genRandomNumber(1000, 99999, true),
			created_at: '2024.04.26',
			order_sn: `${genRandomNumber(100000, 9999999, false)}`
		})
	}
	return result;
}