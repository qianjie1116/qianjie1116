import Vue from 'vue';

// 客服跳转
const linkService = async () => {
	// const result = await Vue.prototype.$http.get(`api/app/config`);
	// // console.log('reslut:', result);
	// // console.log('window:', window);
	// // console.log('navigator:', navigator);
	// if (!result) return false;
	// const temp = result.reduce((map, item) => {
	// 	map.set(item.key, item.value);
	// 	return map;
	// }, new Map());

	// let url = temp.get('CustomerLink');

	// if (window.android) {
	// 	window.android.callAndroid("open," + url)
	// 	return false;
	// }
	// if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers
	// 	.nativeExt) {
	// 	window.webkit.messageHandlers.nativeExt.postMessage({
	// 		msg: 'open,' + url
	// 	})
	// 	return false;
	// }
	// let u = navigator.userAgent;
	// let isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
	// if (isiOS) {
	// 	window.location.href = url;
	// 	return false;
	// }
	// window.open(url)
	
	uni.navigateTo({
		url: Vue.prototype.$paths.SERVICE
	});
}

/*
跳转到客服，：
	上架模式：[`line`|`第三方`] 弹出提示框，联系客户经理
	正常模式：`line`(跳轉到外鏈頁面)，`第三方`(跳轉内頁)
*/
const linkCustomerService = () => {
	// 上架模式：[`line`|`第三方`] 弹出提示框，联系客户经理
	// uni.showToast({
	// 	title: Vue.prototype.$lang.SERVICE_CONTACT_MANAGER,
	// 	icon: 'none'
	// });

	// 正常模式：`line`(跳轉到外鏈頁面)
	// linkService();

	// 正常模式：`第三方`(跳轉内頁)
	uni.navigateTo({
		url: Vue.prototype.$paths.SERVICE
	});
}

// 计算设计图上带有透明度的值输出为RGBA
const RGBConvertToRGBA = (hexColor, opacity) => {
	const r = parseInt(hexColor.slice(1, 3), 16);
	const g = parseInt(hexColor.slice(3, 5), 16);
	const b = parseInt(hexColor.slice(5, 7), 16);
	const a = opacity / 100;
	return `rgba(${r},${g},${b},${a})`;
};

// 是否为小数
const hasDecimalPoint = (val) => {
	return val % 1 !== 0;
};

// 数字值格式化
// const formatNumber = (value, fixed = 4) => {
// 	if (isNaN(value)) return '0';
// 	let result = Number(value).toFixed(fixed);
// 	result = result.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
// 	return result;
// };

// 数量值 格式化
const formatNumber = (val, decimal = 0) => {
	// 处理为规范化数字类型
	val = isNaN(val) ? 0 : Number(val);
	return decimal <= 0 ? val : val.toFixed(decimal) * 1;
};

// 涨跌值样式设置
const setStockRiseFall = (val, isbg = false) => {
	return {
		color: isbg ? '#FFFFFF' : val ? Vue.prototype.$theme.RISE : Vue.prototype.$theme.FALL,
		backgroundColor: !isbg ? '' : val ? Vue.prototype.$theme.RISE : Vue.prototype.$theme.FALL,
	}
};

// 负数取绝对值
const formatMathABS = (val) => {
	return Math.abs(val);
}



// 对象嵌套转数组对象。当前用于市场指标返回数据，将其从对象转为数组对象
const ObjectConvertArray = (obj) => {
	return Object.values(obj);
};

// Coin格式化，数据无损输出
const formatCoin = (coin, decimal = '') => {
	coin = isNaN(coin) ? 0 : Number(coin);
	// console.log(`coin:`, coin);
	// 计算小数点后面的位数
	const temp = coin.toString().split('.')[1]?.length || 0;

	const curLocale = 'en-US';
	const result = new Intl.NumberFormat(curLocale, {
		// 如果传入数字包含小数。则启用小数位数
		minimumFractionDigits: decimal > 0 ? decimal : temp, // 小数位数
		maximumFractionDigits: decimal > 0 ? decimal : temp, // 小数位数
	}).format(coin);
	// console.log('格式化：', result);
	return result;
};

// 金额值格式化(参数：金额，小数位数)
const formatMoney = (amount, decimal = 2) => {
	// 处理传入值为数字类型
	amount = isNaN(amount) ? 0 : Number(amount);
	// console.log(amount);
	const curLocale = 'en-US';
	const result = new Intl.NumberFormat(curLocale, {
		style: 'decimal', // 不包含货币符号。currency:包含货币符号
		// 如果传入数字包含小数。则启用小数位数
		minimumFractionDigits: hasDecimalPoint(amount) ? decimal : 0, // 小数位数
		maximumFractionDigits: hasDecimalPoint(amount) ? decimal : 0, // 小数位数
		currency: Vue.prototype.$CURRENCY
	}).format(amount);
	// console.log('格式化：', result);
	return result;
}



// 检查输入值 是否合法，小数是否大于指定位数。返回处理完成的数字类型的值
const checkInputNumber = (val, point = 4) => {
	const defaultPoint = 4; // 默认最大小数位数;
	val = isNaN(val) ? 0 : Number(val);
	if (val <= 0) {
		uni.showToast({
			title: Vue.prototype.$lang.COMMON_TOP_ENTER_NUMBER,
			icon: 'none'
		});
		return false;
	}

	// 计算小数点后面的位数
	const temp = val.toString().split('.')[1]?.length || 0;
	// console.log(`check`, val, temp);
	if (temp > point) {
		uni.showToast({
			title: Vue.prototype.$lang.COMMON_TIP_ENTER_POINT_PREFIX + defaultPoint + Vue.prototype.$lang
				.COMMON_TIP_ENTER_POINT_SUFFIX,
			icon: 'none'
		});
		return false;
	}
	console.log(`check result:`, val);
	return val;
}

export default {
	linkService,
	linkCustomerService,
	RGBConvertToRGBA,
	ObjectConvertArray,
	formatNumber,
	setStockRiseFall,
	formatMathABS,
	formatCoin,
	formatMoney,
	checkInputNumber,

	// 根据当前平台，执行回退方式
	goBack: () => {
		/*#ifdef APP-PLUS*/
		uni.navigateBack({
			delta: 1
		});
		/*#endif*/

		/*#ifdef H5*/
		history.back();
		/*#endif*/
	},

	// 切换底部导航文字多语言
	switchTabBar: () => {
		const TABBAR = [
			Vue.prototype.$lang.TABBAR_HOME,
			Vue.prototype.$lang.TABBAR_FOLLOW,
			Vue.prototype.$lang.HEYUE,
			Vue.prototype.$lang.CONTRACT_POSITIONS,
			Vue.prototype.$lang.TABBAR_ACCOUNT
		];
		// 遍历底部导航，逐一换成当前语言
		for (let i = 0; i <= 5; i++) {
			uni.setTabBarItem({
				index: i,
				text: TABBAR[i],
			})
		}
	},

	// 统一处理杠杆，后端数据返回不一致。
	leverList: (val) => {
		val = val || [];
		// 如果没有数据。就返回默认杠杆 1
		if (!val || val.length <= 0) return [1];

		console.log(val);

		// 数组对象类型 
		// ganggan: [{name: "", index: ""}] 
		// ganggan: [{name: "2", index: "2"}, {name: "4", index: "4"}, ...]
		if (val.length > 0 && typeof(val[0]) === 'object') {
			// val[0].index && val[0].index * 1 > 0
			const tempFilter = val.filter(item => item.index * 1 > 0);
			const temp = tempFilter.map(item => item.index * 1);
			console.log('lever array object:', temp);
			// 数据中，添加1倍杠杆
			return temp[0] * 1 == 1 ? temp : [1, ...temp];
		} else if (Array.isArray(val)) {
			// [1, '2', '4', '5', '10']
			console.log(1, val);
			return val.map(item => item * 1);
		}

		// 字符串类型 ganggan: "2,3,4,5,6,7,8,9,10" 
		if (typeof(val) === 'string') {
			const temp = val.split(',').map(item => item * 1);
			console.log('lever string:', temp);
			// 数据中，添加1倍杠杆
			return temp[0] * 1 == 1 ? temp : [1, ...temp];
		}

	},

	// 设置input的placeholder样式
	setPlaceholder: (color = '', fontsize = '') => {
		return `color:${color == '' ? Vue.prototype.$theme.PLACEHOLDER : color};font-size:${fontsize==''?24:fontsize}rpx`;
	},

	// 设置图片尺寸（自定义size）
	setImageSize: (w = 0, h = 0) => {
		const _w = w > 0 ? w : 20;
		const _h = h > 0 ? h : _w;
		return {
			width: `${_w}rpx`,
			// 若为设置h值，则视为高=宽
			height: `${_h}rpx`,
		};
	},
	// 设置页面背景,返回style对象，动态替换页面背景图
	setPageBG: (url) => {
		return {
			backgroundImage: `url(/static/${url}.png)`,
			backgroundSize: '100% auto',
			backgroundRepeat: 'no-repeat',
			backgroundPosition: '0 -32rpx',
		}
	},

	// 根据传入值，求出进度条元素宽度
	setProgress: (val, max) => {
		// 模拟数据所需，实际数据不会出现
		const result = max - val < 0 ? 0 : (val / max) * 100;
		console.log(result);
		return {
			// backgroundImage: `url(/static/progress.png)`,
			// backgroundSize: 'auto',
			// backgroundRepeat: 'repeat',
			// backgroundPosition: '0 -7px',
			backgroundImage: 'linear-gradient(-90deg, #00aa99, rgba(255,255,255,0.8))',
			width: `${result}%`,
			height: '100%',
			borderRadius: `12px`,
		}
	},

	formatDate: (timeString) => {
		console.log('原值:', timeString);
		const curLang = uni.getStorageSync('lang');
		console.log('当前语言', curLang);
		const opt = {
			year: 'numeric',
			month: 'numeric',
			day: 'numeric',
			hour: 'numeric',
			minute: 'numeric',
			second: 'numeric',
			hour12: false, // 以24小时制处理
		};
		const result = new Intl.DateTimeFormat(curLang, opt).format(timeString);
		console.log('格式化：', result);
		return result;
	},

	formatYearMonthDay: (timeString) => {
		// console.log('原值:', timeString);
		const curLang = uni.getStorageSync('lang') || 'en-US';
		// console.log('当前语言', curLang);
		const opt = {
			// year: '2-digit',24 numeric:2024
			month: '2-digit',
			day: '2-digit',
		};
		const result = new Intl.DateTimeFormat(curLang, opt).format(timeString);
		// console.log('格式化：', result);
		return result;
	},


	formatMonth: (timeString) => {
		// console.log('原值:', timeString);
		const curLang = uni.getStorageSync('lang') || 'en-US';
		// console.log('当前语言', curLang);
		const opt = {
			// year: 'numeric',
			month: '2-digit', // 双位数月份
			// day: 'numeric',
		};
		const result = new Intl.DateTimeFormat(curLang, opt).format(timeString);
		// console.log('格式化：', result);
		return result;
	},

	// 返回格式化的双位月日
	formatMonthDay: (timeString) => {
		// console.log('原值:', timeString);
		const curLang = uni.getStorageSync('lang') || 'en-US';
		// console.log('当前语言', curLang);
		const opt = {
			// year: '2-digit',24 numeric:2024
			month: '2-digit',
			day: '2-digit',
		};
		const result = new Intl.DateTimeFormat(curLang, opt).format(timeString);
		// console.log('格式化：', result);
		return result;
	},

	// 部分页面需要拼接股票完整LOGO的url
	setLogo: (url) => {
		// console.log('url:', url);
		return url.includes('http') ? url : Vue.prototype.$http.BASE_URL + url;
	},
	// 设置 Coin Logo
	setCoinLogo: (url) => {
		return url.includes('http') ? url :
			Vue.prototype.$http.BASE_URL + url;
	},
	setTabSecondActive: (active = true, bg = '') => {
		return {
			color: active ? '#FFFFFF' : '#666',
			backgroundColor: active ? '#00aa99' : bg,
		}
	},
	setTabThird: (active = true) => {
		return {
			color: active ? Vue.prototype.$theme.PRIMARY : Vue.prototype.$theme.TEXT,
			borderBottom: `3px solid ${active ? Vue.prototype.$theme.PRIMARY:'transparent'}`,
		}
	},

	// 设置交易记录中， 提现记录，每条数据状态明文
	setWithdrawLogStatus: (code = 0) => {
		const temp = [{
			text: Vue.prototype.$lang.TRADE_LOG_WITHDRAW_STATUS[0],
			icon: '/static/audit.png',
			color: '#FF6700'
		}, {
			text: Vue.prototype.$lang.TRADE_LOG_WITHDRAW_STATUS[1],
			icon: '/static/success.png',
			color: '#00B45A'
		}, {
			text: Vue.prototype.$lang.TRADE_LOG_WITHDRAW_STATUS[2],
			icon: '/static/failed.png',
			color: '#A400DE'
		}, {
			text: Vue.prototype.$lang.TRADE_LOG_WITHDRAW_STATUS[3],
			icon: '/static/refuse.png',
			color: '#f56a6a'
		}];
		return temp[code];
	},
}