import en from './en.js';
import zh from './zh-hant.js';
import ja from './ja.js';
import ko from './ko.js';
import fy from './fy.js';
import tuer from './tuer.js';

// LANGUAGES

export default {
	en,
	zh,
	ja,
	ko,
	fy,
	tuer
};