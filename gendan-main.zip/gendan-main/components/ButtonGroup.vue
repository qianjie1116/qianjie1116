<template>
	<view class="btns" style="">
		<block v-for="(item,index) in btns" :key="index">
			<view class="item" @click="actionEvent(item.url,index)">
				<image mode="aspectFit" :src="`/static/${item.icon}.png`" :style="$util.setImageSize(80)"></image>
				<text style="padding-top: 6px;">{{item.name}}</text>
			</view>
		</block>
	</view>
</template>

<script>
	export default {
		name: "ButtonGroup",
		data() {
			return {
				sex:""
			};
		},
		// :btns="$util.homeBtns()"
		computed: {
			
			btns() {
				const temp = [
					{
						name: this.$lang.PAGE_TITLE_DEPOSIT,
						url: this.$paths.ACCOUNT_DEPOSIT,
					}, {
						name: this.$lang.PAGE_TITLE_WITHDRAW,
						url: this.$paths.ACCOUNT_WITHDRAW,
					}, {
						name: 'XAU',
						url: `/pages/stock/overview?code=xau`,
					},
					{
						name: this.$lang.LICAI_LICAI,
						url: '/pages/trade/wealth/index',
					}
				];
				return temp.map((item, index) => {
					return {
						...item,
						icon: `top${index+1}`
					}
				});
			}
		},

		methods: {
			actionEvent(url, index) {
				if (url == "/pages/service") {
					this.$util.linkCustomerService();
					return false;
				}
				if (url.includes("wealth")) {
					uni.switchTab({
						url:url
					})
					return false;
				}
				if (url.includes('pages')) {
					uni.navigateTo({
						url: url
					})
				} else {
					this.$emit('action', index);
				}
			},
		}
	}
</script>