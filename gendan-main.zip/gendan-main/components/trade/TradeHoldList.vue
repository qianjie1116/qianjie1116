<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>

		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="padding:30rpx;background-color: #FFFFFF;margin:30rpx 20rpx;border-radius:24rpx;"
					@tap.stop="handleSell(info.id)">
					<view style="display: flex;align-items: center;" >
						<view style="flex:1 0 80%;color:#121212;font-size: 36rpx;">
							{{item.goods_info.name}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color:#666666;">{{$lang.TRADE_WEALTH_HOLD_PRICE}}</view>
						<view style="color:#00AA98;font-size: 28rpx;">{{$util.formatCoin(item.order_buy.price,4)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color:#666666;">{{$lang.TRADE_WEALTH_HOLD_NUM}}</view>
						<view style="color:#333333;font-size: 28rpx;">{{item.order_buy.num}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color:#666666;">{{$lang.TRADE_WEALTH_HOLD_PAY_PRICE}}</view>
						<view style="color:#333333;font-size: 28rpx;">{{$util.formatCoin(item.order_buy.user_pay,4)}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color:#666666;">{{$lang.TRADE_WEALTH_HOLD_PROFIT}}</view>
						<view style="color:#333333;font-size: 28rpx;">{{$util.formatCoin(item.order_buy.yingkui,4)}}
						</view>
					</view>
					<!-- <view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color:#666666;">Overnight Fee</view>
						<view style="color:#333333;font-size: 28rpx;">{{$util.formatCoin(item.order_buy.gy_fee||0,4)}}
						</view>
					</view> -->
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color:#666666;">{{$lang.TRADE_WEALTH_HOLD_SN}}</view>
						<view style="color:#333333;font-size: 28rpx;">{{item.order_sn}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view style="color:#666666;">{{$lang.TRADE_WEALTH_HOLD_CRETIME}}</view>
						<view style="color:#333333;font-size: 28rpx;">{{item.buy_time}}
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeHoldList',
		components: {
			EmptyData
		},
		data() {
			return {
				list: [],
			}
		},
		created() {
			this.getList();
		},
		methods: {
			linkInfo(id) {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_TRADE_DETAIL + `?id=${id}`,
				})
			},
			// actionEvent() {
			// 	this.isShow = false;
			// 	this.$emit('action', 1);
			// },
			// 平仓/卖出
			async handleSell(id) {
				const result = await uni.showModal({
					title: this.$lang.SELL_TIP,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					confirmColor: this.$theme.PRIMARY,
					cancelColor: '#999999',
				});
				console.log('异步弹层:', result);
				if (result[1].confirm) {
					this.confirmSell(id);
				}
			},
			// 平仓功能
			async confirmSell(id) {
				const result = await postStockSell({
					id
				}, this.$lang.STATUS_SUBMIT);
				if (result.code == 0) {
					// this.getData()
					uni.$u.toast(result.message);
				} else {
					uni.$u.toast(result.message);
				}
				this.actionEvent()
			},

			// 获取持有列表数据
			async getList() {
				const result = await this.$http.post(`api/user/order`, {
					status: 1, // 1持仓，2历史
					gp_index: 0,
				});
				if (!result) return false;
				// check data
				const temp = result.filter(item => item.goods_info && item.order_buy);
				this.list = temp;
			},
		}
	}
</script>

<style>
</style>