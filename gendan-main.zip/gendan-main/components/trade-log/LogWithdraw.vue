<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view class="common_block" style="margin-bottom:20px;padding:10px;border-radius: 10px;line-height: 1.6;">
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TIP}">
						{{$lang.LOG_WITHDRAW_AMOUNT}}[{{$lang.CURRENCY_UNIT}}]
					</view>
					<view :style="{color:$theme.PRIMARY}" style="flex:40%;font-size: 18px;font-weight: 700;">
						{{$util.formatNumber(item.money)}}
					</view>
					<view style="flex:20%;text-align: right;" :style="{color:$theme.RISE}">
						{{item.desc_type}}
					</view>
				</view>

				<!-- <view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TIP}">{{$lang.LOG_TRADE_ORDER_SN}}:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$theme.TEXT}">
						{{item.bank_name}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TIP}">{{$lang.LOG_TRADE_ORDER_SN}}:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$theme.TEXT}">
						{{item.bankno}}
					</view>
				</view> -->

				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TIP}">{{$lang.LOG_TRADE_ORDER_SN}}:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$theme.TEXT}">
						{{item.order_sn}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TIP}">{{$lang.LOG_TRADE_CREATE_TIME}}:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$theme.TEXT}">
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TIP}">{{$lang.LOG_TRADE_DW_DESC}}:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$theme.TEXT}">
						{{item.reason}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<!-- <view style="flex:5%;">
						<image :src="item.icon" :style="$util.setImageSize(24)"></image>
					</view> -->
					<view style="flex:30%;" :style="{color:$theme.TIP}">{{$lang.LOG_STATUS}}</view>
					<text style="flex:70%;white-space:pre-wrap;text-align: right;"
						:style="{color:item.color}">{{item.text}}</text>
				</view>
				<template v-if="item.status==0">
					<view class="trade_modal_btn"
						style="background-color:#FF6700;height: 32px;line-height:32px;width: 100%;margin-top: 10px;text-align: center;"
						@click="handleCancel(item.id)">
						{{$lang.BTN_CANCEL}}
					</view>
				</template>
				<template v-if="item.status==2">
					<view class="trade_modal_btn"
						style="background-color: #A400DE;height: 32px;line-height:32px;display: flex;align-items: center;justify-content:center;width: 100%;margin-top: 10px;"
						@click="handleService()">
						<image src="/static/service.png" mode="aspectFit" :style="$util.setImageSize(40)"
							style="padding-right: 20px;"></image>
						{{$lang.BTN_SEND_SERVICE}}
					</view>
				</template>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogWithdraw",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList()
		},
		methods: {
			// 联系客服
			handleService() {
				this.$util.linkCustomerService();
			},
			// 取消提现
			handleCancel(id) {
				let _this = this;
				uni.showModal({
					title: this.$lang.TRADE_LOG_TIP_MODAL_TITLE,
					cancelText: this.$lang.BTN_CANCEL,
					confirmText: this.$lang.BTN_CONFIRM,
					success: function(res) {
						if (res.confirm) {
							_this.qx_post(id);
						} else if (res.cancel) {}
					}
				})
			},
			async qx_post(id) {
				const result = await this.$http.post(`api/app/qx`, {
					id: id
				});
				if (!result) return false;
				this.getList();
			},
			async getList() {
				this.list = []; // 每次请求前，清空数组。
				const result = await this.$http.get(`api/user/withdraw`);
				if (!result) return false;
				this.list = result.map((item, index) => {
					return {
						...item,
						...this.$util.setWithdrawLogStatus(item.status)
					}
				});
			},
		}
	}
</script>

<style>

</style>