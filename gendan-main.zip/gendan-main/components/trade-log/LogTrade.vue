<template>
	<view>
		<EmptyData v-if="list.length<=0"></EmptyData>
		<block v-for="(item,index) in list" :key="index">
			<view class="common_block" style="margin-bottom:20px;padding:10px;border-radius: 10px;line-height: 1.6;">
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TITLE}">
						{{$lang.LOG_TRADE_AMOUNT_BEFORE}}
					</view>
					<view style="flex:70%;text-align: right;" :style="{color:$theme.TEXT}">
						{{$util.formatNumber(item.before)}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TITLE}">
						{{$lang.LOG_TRADE_AMOUNT_AFTER}}
					</view>
					<view style="flex:70%;font-size: 18px;font-weight: 700;text-align: right;"
						:style="{color:$theme.PRIMARY}">
						{{$util.formatNumber(item.after)}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TITLE}">
						{{$lang.LOG_TRADE_DW}}
					</view>
					<view style="flex:70%;text-align: right;" :style="{color:$theme.TEXT}">
						{{$util.formatNumber(item.money)}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TITLE}">{{$lang.LOG_TRADE_CREATE_TIME}}:</view>
					<view style="flex:70%;text-align: right;" :style="{color:$theme.TIP}">
						{{item.created_at}}
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;" :style="{color:$theme.TITLE}">{{$lang.LOG_TRADE_DESC}}:</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="flex:30%;"></view>
					<text :style="{color:$theme.TEXT}"
						style="white-space:pre-wrap;text-align: right;">{{item.desc}}</text>
				</view>
			</view>
		</block>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "LogTrade",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList()
		},
		methods: {
			async getList() {
				const result = await this.$http.get(`api/user/finance`);
				if (!result) return false;
				this.list = result;
			},
		}
	}
</script>

<style>

</style>