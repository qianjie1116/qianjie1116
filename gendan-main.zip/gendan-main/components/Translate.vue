<template>
	<view style="height: 40rpx;">
		<!-- <image :src="`/static/lang/${curIcon}.png`" :style="$util.setImageSize(70)" @click="isShow=true"
			style="margin-left:10px;"></image> -->
			<image src="/static/yuyan.png" :style="$util.setImageSize(40)" @click="isShow=true"
				style="margin-left:20px;"></image>

		<template v-if="isShow">
			<view class="common_mask" @click="isShow=false">
				<view class="common_block common_popup" style="min-height:35vh;margin:auto;top:50%;background-color: #000;"
					:style="{animation:`bottomToCenter 300ms forwards`}">
					<view class="popup_header" style="color:#FFFFFF;background-color: #000;">
						{{$lang.TRANSLATE_TITLE}}

						<image src="/static/close_light.png" mode="aspectFit" :style="$util.setImageSize(40)"
							style="position: absolute;top:50%;right: 30px;transform: translateY(-50%);"
							@click="handleClose()"></image>
					</view>

					<view style="display: flex;align-items: center;flex-wrap: wrap;padding-top: 20px;">
						<block v-for="(item,index) in langList" :key="index">
							<view style="flex:50%;text-align: center;" @click="handleSelected(item,index)">
								<image :src="`/static/lang/${item.icon}.png`" mode="widthFix" style="width: 60px; border-radius: 10px;margin-top: 30px;"></image>
								<view style="text-align: center;color: #FFFFFF;">{{item.name}}</view>
							</view>
						</block>
					</view>
				</view>
			</view>
		</template>
	</view>
</template>

<script>
	import languages from '@/static/locale/index.js';

	export default {
		name: "Translate",
		data() {
			return {
				isShow: false,
				curIcon: '',
			};
		},
		computed: {
			langList() {
				return [{
						lang: 'en',
						name: 'English',
						icon: 'usa-80'
					},
					{
						lang: 'zh',
						name: '中文繁体',
						icon: 'china-80'
					},
					 {
						lang: 'ko',
						name: '한국어',
						icon: 'korea-80'
					},{
						lang: 'ja',
						name: '日本語',
						icon: 'japan-80'
					},{
						lang: 'fy',
						name: 'Français',
						icon: 'faguo'
					},{
						lang: 'tuer',
						name: 'Türkçe',
						icon: 'tuer'
					}
				];
			}
		},

		created() {
			this.calcCurLang();
		},

		methods: {
			handleClose() {
				this.isShow = false;
			},

			// 当前语言标志
			calcCurLang() {
				const temp = uni.getStorageSync('lang') || 'en';
				console.log(temp);
				this.curIcon = this.langList.filter(item => item.lang == temp)[0].icon;
				console.log(this.curIcon)
			},

			handleSelected(val, index) {
				console.log(index, val);
				this.isShow = false;
				uni.setStorageSync('lang', val.lang);
				this.$lang = languages[val.lang];
				this.calcCurLang();
				console.log(this.$lang);
				uni.setStorageSync('lang', val.lang);
				console.log(uni.getStorageSync('lang'));
				window.location.reload();

				uni.reLaunch({
					url: this.$paths.HOME,
				})
			},
		}
	}
</script>

<style>

</style>