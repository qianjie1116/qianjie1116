<template>
	<view style="background-color: #000;">
		<!-- <image src="/static/home_banner.png" mode="widthFix" style="width: 100%;"></image> -->
		<view class="home_header_bg">
			<HeaderPrimary :title="$lang.TABBAR_HOME" isSearch></HeaderPrimary>
		</view>

	<!-- 	<view class="flex" style="padding: 0px 10px;" @click="tongzhi()">
			<view style="margin-top: 5px;">
				<image src="/static/tongzhi.png" mode="widthFix" style="width: 15px;"></image>
			</view>
			<view class="flex-1" style="margin-left: 5px;color: #fff;">{{$lang.ZJING_DEHUIYUAN}}</view>
			<image src="/static/baijiantou.png" mode="widthFix" style="width: 8px;"></image>
		</view> -->

		<view class="flex" style=" justify-content: space-between;padding: 10px;">
			<view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTradejiaoyi()">
				<image src="/static/top3.png" mode="widthFix" style="width: 50px;"></image>
				<view style="color: #fff;margin-top: 5px;">{{$lang.GUPIAO_JIOAYI}}</view>
			</view>
			<view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTradeipo()">
				<image src="/static/ipo.png" mode="widthFix" style="width: 50px;"></image>
				<view style="color: #fff;margin-top: 5px;">{{$lang.IPO}}</view>
			</view>
			<view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTradeotc()">
				<image src="/static/otc.png" mode="widthFix" style="width: 50px;"></image>
				<view style="color: #fff;margin-top: 5px;">{{$lang.DAZONG_JIAOYI}}</view>
			</view>
			<view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTradekeieo()">
				<image src="/static/ieo.png" mode="widthFix" style="width: 50px;"></image>
				<view style="color: #fff;margin-top: 5px;">{{$lang.JIJIN}}</view>
			</view>
		</view>

		<view class="flex" style=" justify-content: space-between;padding: 10px;">
			<view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTradeCopy()">
				<image src="/static/gendan.png" mode="widthFix" style="width: 50px;"></image>
				<view style="color: #fff;margin-top: 5px;">{{$lang.TIKUAN}}</view>
			</view>
			<view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTradeFOF()">
				<image src="/static/fof.png" mode="widthFix" style="width: 50px;"></image>
				<view style="color: #fff;margin-top: 5px;">{{$lang.CHONGZHI}}</view>
			</view>
			<view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTradeheyue()">
				<image src="/static/heyue.png" mode="widthFix" style="width: 50px;"></image>
				<view style="color: #fff;margin-top: 5px;">{{$lang.SHIMING_RENZHENG}}</view>
			</view>
			<view class="flex-1 flex flex-wrap justify-center" style="flex-direction: column;" @tap="linkTradekefu()">
				<image src="/static/kefu.png" mode="widthFix" style="width: 50px;"></image>
				<view style="color: #fff;margin-top: 5px;">{{$lang.KEFU}}</view>
			</view>
		</view>

		<view class="flex" style="padding:10px 10px;margin-top: 10px;" @click="linkTradejiaoyi()">
			<view style="background-color: #fff;width: 3px; height: 15px;color: #fff;"></view>
			<view style="margin-left: 5px;font-size: 16px;color: #fff;">{{$lang.XIANGMU_HUIBAOLV}}</view>
			<view style="margin-left: 20px;">
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 8px;margin-top: 5px;"></image>
			</view>
		</view>

		<view style="padding:20rpx 5rpx;">
			<view>
				<scroll-view class="scroll-view_H " scroll-x="false" @scroll="scroll()" @click="home()">
					<view class="flex" style="color: #00AA98;justify-content: space-between;padding: 10px;">
						<view class="flex-2">{{$lang.MINGCHEN}}</view>
						<view class="text-center flex-1">{{$lang.ZUIXIN_JIA}}</view>
						<view class="flex-1" style="text-align: right;">{{$lang.ZAHNGDIE_FU}}</view>
					</view>
					<view>
						<block v-for="(item,index) in listinfo" :key="index">
							<view class="flex" style="justify-content: space-between;padding: 10px;"
								@tap="linkDetail(item)">
								<view class="flex-2" style="color: #fff;">
									<view>{{item.ct_name}}</view>
									<view style="color: #566872;">{{item.ct_name}}</view>
								</view>
								<view class="text-center flex-1" style="color: #fff;">
									<view>{{item.current_price}}</view>
									<view style="color: #566872;">P{{item.rate_num}}</view>
								</view>
								<view class="flex-1" style="color: #fff;">
									<view :style="$util.setStockRiseFall(item.rate>0)" style="text-align: right;">{{item.rate}}%</view>
								</view>

							</view>
							<view style="border-top: 1px #ccc solid;">.</view>
						</block>
					</view>
				</scroll-view>
			</view>
		</view>

		<view class="flex" style="padding:0px 10px;margin-top: 20px;">
			<view style="background-color: #fff;width: 3px; height: 15px;color: #fff;"></view>
			<view style="margin-left: 5px;font-size: 16px;color: #fff;">{{$lang.XINWEN}}</view>
			<view style="margin-left: 20px;">
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 8px;margin-top: 5px;"></image>
			</view>
		</view>

		<view style="padding:0rpx 5rpx;">
			<view>
				<scroll-view class=" " scroll-x="false" @scroll="scroll()" @click="home()">
					<view>
						<block v-for="(item, index) in levelinfo" :key="index">
							<view @click="open(item.url)"
								style="display: flex;align-items: center;margin-bottom: 10px;padding-bottom: 10px;padding: 10px;">
								<template v-if="curTab==0">
									<view style="flex:60%;padding-right: 30px;padding-top: 10px;color: #fff;">
										<view>{{item.title}}</view>
										<view style="margin:6px;margin-top: 16px;color: #fff;"><text
												style="padding: 4px 0;">{{item.updated_at}}</text>
										</view>
									</view>
									<image :src="item.pic" :style="$theme.setImageSize(220,150)" mode="scaleToFill"
										style="border-radius: 10px;"></image>
								</template>
								<template v-else>
									<view style="flex:100%">
										<view style="color: #fff;">{{item.title}}</view>
										<view style="margin:6px;margin-top: 16px;text-align: right;color: #fff;">
											{{item.updated_at}}
										</view>
									</view>
								</template>
							</view>
							<view style="border-top: 1px #ccc solid;">.</view>
						</block>
					</view>
				</scroll-view>
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import ButtonGroup from '@/components/ButtonGroup.vue';
	import GoodsList from '@/components/GoodsList.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import TabsFifth from '@/components/tabs/TabsFifth.vue';
	import index from 'uview-ui';
	export default {
		name: 'MarketNews',
		components: {
			HeaderPrimary,
			ButtonGroup,
			GoodsList,
			TabsFifth,
			CustomTitle,


		},
		data() {
			return {
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				info: {}, // 基本信息
				scrollTop: 0,
				selectedContent: 0,
				message: [],
				listinfo: [],
				list: [],
				curTab: 0,
				levelinfo: [],
				AccountInfo: [],
				old: {
					scrollTop: 0
				}
			}
		},

		onShow() {
			this.getLevelInfo();
			this.getList()
			// this.getAccountInfo();

		},
		onLoad() {},

		onHide() {
			this.closeAll();
		},
		onUnload() {
			this.closeAll();
		},
		deactivated() {
			this.closeAll();
		},

		methods: {
			open(url) {
				window.open(url)
			},
			// 跳转到交易的股票分栏
			linkTradejiaoyi() {
				uni.reLaunch({
					url: '/pages/trading/jiaoyi' + `?tag=0`,
				})
			},
			// 跳转到 Market / Currency 列表
			linkTradeCopy() {
				uni.reLaunch({
					url: '/pages/account/withdraw',
				})
			},

			linkTradeFOF() {
				uni.navigateTo({
					url: '/pages/account/deposit'
				})
			},
			linkTradekeieo() {
				uni.navigateTo({
					url: '/pages/trade/wealth/index'
				})
			},
			linkTradekefu() {
				// uni.navigateTo({
				// 	url: '/pages/service'
				// })
				this.$util.linkService()
			},
			linkTradeheyue() {
				uni.navigateTo({
					url: '/pages/Introduction/auth'
				})
			},
			linkTradeipo() {
				uni.navigateTo({
					url: '/pages/trade/ipo/index'
				})
			},
			linkTradeotc() {
				uni.navigateTo({
					url: '/pages/trade/large/index'
				})
			},
			// 跳转到详情
			linkDetail(val) {
				uni.navigateTo({
					url: this.$paths.TRADE_COPY_DETAIL + `?id=${val}`
				});
			},

			licai() {
				uni.switchTab({
					url: "/pages/trade/wealth/index"
				})
			},
			tongzhi() {
				uni.navigateTo({
					url: "/pages/tongzhi"
				})
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			handleInfo(item) {
				console.log(item);
				this.infos = item;
				this.isShow = true;
			},
			// 跳转到市场
			linkMarket() {
				uni.switchTab({
					url: '/pages/trade/wealth/index',
				})
			},
			home() {

				uni.switchTab({
					url: '/pages/trade/wealth/index',
				})
			},

			closeAll() {
				if (this.$refs.goods) this.$refs.goods.disconnect();
			},
			upper: function(e) {
				console.log(e)
			},
			lower: function(e) {
				console.log(e)
			},
			scroll: function(e) {
				console.log(e)
				this.old.scrollTop = e.detail.scrollTop
			},
			goTop: function(e) {
				// 解决view层不同步的问题
				this.scrollTop = this.old.scrollTop
				this.$nextTick(function() {
					this.scrollTop = 0
				});
				uni.showToast({
					icon: "none",
					title: "纵向滚动 scrollTop 值已被修改为 0"
				})
			},
			// 
			linkDetail(val) {
				uni.navigateTo({
					url: this.$paths.STOCK_OVERVIEW + `?code=${val.locate}`
				})
			},

			async getList() {
				const result = await this.$http.post(`api/goods/list`, {
					gp_index: 6
				});
				console.log(result);
				if (!result) return false;
				this.listinfo = Object.values(result).slice(0, 10);
				console.log(this.listinfo);
			},

			connect() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_COIN_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
					fail: (res) => {
						console.log('fail', res);
					}
				})
				console.log('ws', this.socket);
				// 监听WebSocket连接打开事件
				this.socket.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				// 接收websocket消息及处理
				this.socket.onMessage((res) => {
					const data = JSON.parse(res.data);
					// console.log(data);
					// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
					if (this.list[data.market] && data.market && data.lastPrice > 0 && data.type == 'ticker') {
						this.list[data.market].current_price = data.lastPrice;
						this.list[data.market].rate = data.rate || 0;
						this.list[data.market].rate_num = data.rate_num || 0;
					}
				});
			},
			connect1() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_Zonghe_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
					fail: (res) => {
						console.log('fail', res);
					}
				})
				console.log('ws', this.socket);
				// 监听WebSocket连接打开事件
				this.socket.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				// 接收websocket消息及处理
				this.socket.onMessage((res) => {
					const data = JSON.parse(res.data);
					// console.log(data);
					// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
					if (this.list[data.pid] && data.pid && data.last > 0) {
						this.list[data.pid].current_price = data.last;
						this.list[data.pid].rate = data.pcp || 0;
						this.list[data.pid].rate_num = data.pc || 0;
						// this.list[data.market].vol = data.vol || 0;
					}
				});
			},

			async getLevelInfo() {
				const result = await this.$http.get(`api/article/list`, {
					type: 11
				});
				if (!result) return false;
				this.levelinfo = result;
			},
		},

	}
</script>

<style>
	.scroll-Y {
		height: 300rpx;
	}

	.scroll-view_H {
		white-space: nowrap;
		width: 100%;
	}

	.scroll-view-item {
		height: 300rpx;
		line-height: 300rpx;
		text-align: center;
		font-size: 36rpx;
	}

	.scroll-view-item_H {
		display: inline-block;
		border-radius: 10px;
		width: 80%;
		/* height: 300rpx; */
		/* line-height: 60rpx; */
		/* text-align: center; */
		font-size: 36rpx;
	}
</style>