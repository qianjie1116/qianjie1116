<template>
	<view :class="isAnimat?'fade_in':'fade_out'" style="min-height: 100vh;">
		<view style="">
			<HeaderSecond :title="$lang.ADDRESS_INDEX_TITLE" color="#fff"></HeaderSecond>
		</view>
		<view style="border-top: 1px #272729 solid;margin-top: -10px;">.</view>
		

		<view style="margin: 0rpx 20rpx;min-height: 100vh;">
			<template v-if="!list || list.length<=0">
				<EmptyData></EmptyData>
			</template>
			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view class="padding-15" style="border-radius: 24rpx;border: 1px #272729 solid;margin-top: 10px;">
						<view style="display: flex;align-items: center;">
							<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
							<view style="padding-left: 10rpx;flex:1 1 auto;">
								<view style="display: flex;align-items: center;justify-content: space-between;">
									<view style="font-size: 32rpx;" :style="{color:$theme.SECOND}">
										{{item.name}}
									</view>
									<view>
										<view style="display: flex;align-items: center;">
											<!-- <image mode="aspectFit" src="/static/shanchu.png"
												 style="padding-right: 40rpx;"
												:style="$theme.setImageSize(32)">
											</image> -->
											<view class="common_tag" :style="setStyle" @tap="handleCopy(item.address)">
												{{$lang.FUZHI}}
											</view>
										</view>
									</view>
								</view>
								<view style=" width: 260px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;" :style="{color:$theme.LOG_LABEL}" >{{item.address}}</view>
							</view>
						</view>
						
						<!-- <view>
							<view class="flex" style="padding:10px 5px;">
								<view :style="{color:$theme.LOG_LABEL}">今日收入</view>
								<view :style="{color:$theme.SECOND}" style="padding: 0px 20px;">320535</view>
							</view>
							<view class="flex" style="padding:10px 5px;">
								<view :style="{color:$theme.LOG_LABEL}">累计收入</view>
								<view style="color: #fff;padding: 0px 20px;" >320535</view>
							</view>
						</view> -->
						
					</view>
				</block>
			</template>
		</view>

		<view style="position: fixed;bottom: 0;left: 0;right: 0;">
			<view class="common_btn" style="margin:40rpx auto;width: 80%;background-color: #16e2e2;border-radius: 30px;" @click="linkAdd()">
				{{$lang.ADDRESS_ADD_TITLE}}
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/HeaderSecond.vue';
	import TitlePrimary from '@/components/TitlePrimary.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		components: {
			HeaderSecond,
			TitlePrimary,
			EmptyData,
			CustomLogo,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				isShow: uni.getStorageSync('show') || false, // 地址显隐
				hideAddress: '******', // 隐藏金额
				list: [{
					name: 'ERC20-USDT',
					address: 'addressaddressaddressaddress'
				}, {
					name: 'TRC20-USDT',
					address: 'addressaddressaddressaddress'
				}], // 提现地址列表
			};
		},
		computed: {
			setStyle() {
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(this.$theme.RISE, 20),
					color: this.$theme.RISE,
				}
			}
		},
		onLoad() {},
		onShow() {
			this.isAnimat = true;
			this.getList();
		},
		onHide() {
			this.isAnimat = false;
		},
		methods: {
			// 切换地址显隐
			toggleShow() {
				this.isShow = !this.isShow;
				this.$util.setShowData(this.isShow);
			},
			linkAdd() {
				uni.navigateTo({
					url: '/pages/address/add'
				})
			},

			async handleCopy(val) {
				const result = await uni.setClipboardData({
					data: val, //要被复制的内容
				});
				if (result[1].confirm) {
					uni.showToast({
						title: this.$lang.COMMON_COPY_SUCCESS,
						duration: 2000,
						icon: 'success'
					})
				}
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/user/fastinfo`);
				if (!result) return false;
				console.log(`result:`, result);
				if (result.bank_card_info) {
					this.list = !result.bank_card_info || result.bank_card_info.length <= 0 ? [] :
						result.bank_card_info.map(item => {
							return {
								name: item.huobi,
								address: item.address,
							}
						})
				}

			}
		}
	}
</script>

<style>
</style>