<template>
	<view>
		<template v-if="!list || list.length<=0">
			<view class="" style="padding:10px;margin-bottom: 20px;">
				<EmptyData></EmptyData>
			</view>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view class="" style="padding:10px;">
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;color: #fff;">
						<view>{{item.goods.name}}</view>
						<view style="font-size: 16px;color:seagreen;color: #fff;">
							<!-- <view v-if="item.status==2" class="" @click="subscription(item)">구독하다</view> -->
						</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;color: #fff;">
						<view >{{$lang.SHENGOU_JIA}}</view>
						<view style="text-align: right;">
							{{$util.formatNumber(item.price)}}<text style="padding:0 4px"></text>
						</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;color: #fff;">
						<view >{{$lang.SHENGOU_SHULIANG}}</view>
						<view  style="text-align: right;padding-right: 4px;">
							{{$util.formatNumber(item.apply_amount)}}
						</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;color: #fff;">
						<view >{{$lang.ZHONGQIAN_JINE}}</view>
						<view  style="text-align: right;">
							{{$util.formatNumber(item.success_num_amount)}}<text style="padding:0 4px"></text>
						</view>
					</view>
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding-bottom: 6px;color: #fff;">
						<view >{{$lang.ZHONGQAIN_SHULIANG}}</view>
						<view style="text-align: right;padding-right: 4px;">
							{{$util.formatNumber(item.success)}}
						</view>
					</view>

					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;color: #fff;"
						>
						<view>{{$lang.SHENGOU_RIQI}}</view>
						<view>{{item.created_at}}</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 6px;color: #fff;"
						>
						<view>{{$lang.DINGDAN_HAO}}</view>
						<view>{{item.order_sn}}</view>
					</view>
				</view>
				<view style="border-top: #fff 1px solid;">.</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: 'TradeIPOSuccessLog',
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
				item: ''
			};
		},
		created(option) {
			this.getList()
		},
		methods: {
			// 우승기록
			async getList() {
				const result = await this.$http.get(`api/goods-shengou/user-success-log`);
				if (!result) return false;
				this.list = result;
			},

			async subscription(item) {
				const result = await this.$http.post(`api/goods-shengou/pay`, {
					id: item.id
				})
				if (result.success == 0) {
					setTimeout(() => {
						this.$util.linkCustomerService();
					}, 500)
				} else {
					uni.redirectTo({
						url: this.$paths.TRADE_IPO_SUCCESS,
					});
					this.$router.go(0)
				}
			},
		},
	}
</script>