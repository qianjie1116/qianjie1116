<template>
	<view>
		<template v-if="!list || list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view style="border-bottom: 1px solid #E5E5E5;padding-top: 28rpx;">
					<view class="bold" style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
						<view  style="font-size: 32rpx;color: #fff;">{{item.goods.name}}</view>
					</view>
					
					<view class="flex" style="padding: 10px;">
						<view class="flex-1">
							<view style="color: #fff;">{{$lang.MAIRU_JIAGE}}</view>
							<view style="margin-top: 5px;color: #fff;">{{$util.formatMoney(item.price)}}</view>
						</view>
						<view class="flex-1" style="color: #fff;">
							<view style="color: #fff;">{{$lang.ZHIFU_JINE}}</view>
							<view style="margin-top: 5px;text-align: center;">{{$util.formatMoney(item.amount)}}</view>
						</view>
						<view style="color: #fff;text-align: center;">
							<view>{{$lang.SHULIANG}}</view>
							<view style="margin-top: 5px;">{{item.num}}</view>
						</view>
					</view>

					<!-- <view style="align-items: center;justify-content: space-between;line-height: 1.8;">
						<view :style="{color:$theme.LOG_LABEL}">
							{{$lang.TRADE_LARGE_LOG_PRICE}}
						</view>
						<view style="font-size: 36rpx;" :style="{color:$theme.PRIMARY}">
							{{$util.formatMoney(item.price)+` ${$lang.CURRENCY_UNIT}`}}
						</view>
					</view> -->
					<view style="border-radius: 12rpx;background-color: #F7F9FF;padding:20rpx;margin-bottom: 28rpx;">
						<!-- <view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.TRADE_LARGE_LOG_NUM}}
							</view>
							<view style="font-size: 32rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.num}}
							</view>
						</view> -->
						<!-- <view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.GANGGAN}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{item.double}}
							</view>
						</view> -->
						<view
							style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;margin-top: 10px;">
							<view :style="{color:$theme.LOG_LABEL}">
								{{$lang.ZHIFU_JINE}}
							</view>
							<view style="font-size: 28rpx;" :style="{color:$theme.LOG_VALUE}">
								{{$util.formatMoney(item.amount)}}
							</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;margin-top: 10px;"
							:style="{color:$theme.LOG_LABEL}">
							<view>{{$lang.MAIRU_SHIJIAN}}</view>
							<text>{{item.created_at}}</text>
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "TradeLargeRecord",
		components: {
			EmptyData,
		},
		data() {
			return {
				list: [],
			};
		},
		created() {
			this.getList();
		},
		methods: {
			async getList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.get(`api/goods-bigbill/user-order-log`);
				console.log(result);
				this.list = result || [];
				console.log(this.list);
			},
		},
	}
</script>