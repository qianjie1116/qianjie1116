<template>
	<view style="display: flex;align-items: center;justify-content: center;padding-bottom: 36rpx;">
		<view class="charts" id="kline-returns"> </view>
	</view>
</template>

<script>
	import {
		init,
		dispose
	} from '@/common/klinecharts.min.js';
	import {
		klineGird,
		klineArea
	} from '@/common/klineConfig.js';
	export default {
		name: 'KlineTotalReturns',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				klineChart: null,
			}
		},
		computed: {
			// 处理图表数据
			chartData() {
				// console.log(this.list);
				const tempSort = this.list.sort((a, b) => a.date * 100 - b.date * 1000);
				// console.log(tempSort);
				return tempSort.map(item => {
					return {
						timestamp: item.date * 1000,
						close: item.zonggentou * 1
					}
				});
			}
		},
		created() {},
		mounted() {
			this.renderInit();
		},
		unmounted() {
			dispose("kline-returns");
		},
		destroyed() {
			dispose('kline-returns');
		},
		methods: {
			renderInit() {
				setTimeout(() => {
					this.genKline();
				}, 1000)
			},

			clearData() {
				if (this.klineChart) this.klineChart.clearData();
			},

			genKline() {
				if (!this.klineChart)
					this.klineChart = init('kline-returns');
				this.klineChart.setStyles({
					grid: klineGird,
					candle: klineArea,
				});

				// console.log(this.chartData)

				// this.klineChart.createIndicator('MA', false);
				this.klineChart.applyNewData(this.chartData, 0)
			},
		}
	}
</script>

<style lang="scss" scoped>
	.charts {
		width: 680upx;
		height: 500upx;
	}
</style>