<template>
	<view>
		<ChartSpeciesPreferences :info="chartData"></ChartSpeciesPreferences>

		<view style="padding:0 36rpx;">
			<view style="display: flex;align-items: center;justify-content: space-between;">
				<view style="color:#8E8D92;font-size: 22rpx;">
					{{$lang.COPY_DETAIL_DATA_THEAD_SPECIES}}
				</view>
				<view style="color:#8E8D92;font-size: 22rpx;text-align: center;">
					{{$lang.COPY_DETAIL_DATA_THEAD_PROFIT}}
				</view>
				<view style="color:#8E8D92;font-size: 22rpx;text-align: right;">
					{{$lang.COPY_DETAIL_DATA_THEAD_VOL}}
				</view>
			</view>

			<block v-for="(item,index) in list" :key="index">
				<view
					style="display: flex;align-items: center;justify-content: space-between;border-bottom: 1px solid #3B3B3D; line-height: 2.8;">
					<view style="color:#FFFFFF;font-size: 28rpx;">
						{{item.name}}
					</view>
					<view style="font-size: 28rpx;text-align: center;"
						:style="{color:item.profit>0?$theme.RISE:$theme.FALL}">
						{{item.profit}}
					</view>
					<view style="color:#FFFFFF;font-size: 28rpx;text-align: right;">
						{{item.vol}}
					</view>
				</view>
			</block>

			<view style="display: flex;align-items: center;padding:48rpx 0 36rpx 0;">
				<view style="background-color: #FFFFFF;width: 8rpx;height: 28rpx;"></view>
				<view style="font-size: 28rpx;font-weight: 700;color:#FFFFFF;padding-left: 40rpx;">
					{{$lang.COPY_DETAIL_DATA_TRADE_DATA}}
				</view>
			</view>

			<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 40rpx;">
				<view>
					<view style="color:#8E8D92;font-size: 22rpx;">{{$lang.COPY_DETAIL_DATA_MAX}}</view>
					<view style="color:#FFFFFF;font-size: 28rpx;">{{setInfo.maxRetracement}}</view>
				</view>
				<view>
					<view style="color:#8E8D92;font-size: 22rpx;text-align: right;">
						{{$lang.COPY_DETAIL_DATA_HOLD_PROFIT}}
					</view>
					<view style="color:#FFFFFF;font-size: 28rpx;text-align: right;">{{setInfo.holdProfit}}</view>
				</view>
			</view>
			<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 40rpx;">
				<view>
					<view style="color:#8E8D92;font-size: 22rpx;">{{$lang.COPY_DETAIL_DATA_TRADE_COUNT}}</view>
					<view style="color:#FFFFFF;font-size: 28rpx;">{{setInfo.tradeCount}}</view>
				</view>
				<view>
					<view style="color:#8E8D92;font-size: 22rpx;text-align: right;">
						{{$lang.COPY_DETAIL_DATA_WIN_RATE}}
					</view>
					<view style="color:#FFFFFF;font-size: 28rpx;text-align: right;">{{setInfo.winRate}}</view>
				</view>
			</view>

			<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 40rpx;">
				<view>
					<view style="color:#8E8D92;font-size: 22rpx;">{{$lang.COPY_DETAIL_DATA_AVERAGE_PROFIT}}</view>
					<view style="color:#FFFFFF;font-size: 28rpx;">{{setInfo.averageProfit}}</view>
				</view>
				<view>
					<view style="color:#8E8D92;font-size: 22rpx;text-align: right;">
						{{$lang.COPY_DETAIL_DATA_AVERAGE_LOSS}}
					</view>
					<view style="color:#FFFFFF;font-size: 28rpx;text-align: right;">{{setInfo.averageLoss}}</view>
				</view>
			</view>

			<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 40rpx;">
				<view>
					<view style="color:#8E8D92;font-size: 22rpx;">{{$lang.COPY_DETAIL_DATA_TRADE_WEEK}}</view>
					<view style="color:#FFFFFF;font-size: 28rpx;">{{setInfo.tradeWeek}}</view>
				</view>
				<view>
					<view style="color:#8E8D92;font-size: 22rpx;text-align: right;">
						{{$lang.COPY_DETAIL_DATA_MAX_DECAY_PERIOD}}
					</view>
					<view style="color:#FFFFFF;font-size: 28rpx;text-align: right;">{{setInfo.maxDecay}}</view>
				</view>
			</view>

			<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 40rpx;">
				<view>
					<view style="color:#8E8D92;font-size: 22rpx;">{{$lang.COPY_DETAIL_DATA_NET_BALANCE}}</view>
					<view style="color:#FFFFFF;font-size: 28rpx;">{{setInfo.netBalance}}</view>
				</view>
				<view>
					<view style="color:#8E8D92;font-size: 22rpx;text-align: right;">
						{{$lang.COPY_DETAIL_DATA_DEPOSIT}}
					</view>
					<view style="color:#FFFFFF;font-size: 28rpx;text-align: right;">{{setInfo.deposit}}</view>
				</view>
			</view>

			<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 40rpx;">
				<view>
					<view style="color:#8E8D92;font-size: 22rpx;">{{$lang.COPY_DETAIL_DATA_WITHDRAWAL}}</view>
					<view style="color:#FFFFFF;font-size: 28rpx;">{{setInfo.withdrawal}}</view>
				</view>
				<view>
					<view style="color:#8E8D92;font-size: 22rpx;text-align: right;">
						{{$lang.COPY_DETAIL_DATA_TIME_ZONE}}
					</view>
					<view style="color:#FFFFFF;font-size: 28rpx;text-align: right;">{{setInfo.timeZone}}</view>
				</view>
			</view>
			<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 40rpx;">
				<view>
					<view style="color:#8E8D92;font-size: 22rpx;">{{$lang.COPY_DETAIL_DATA_RECENT_TRADE}}</view>
					<view style="color:#FFFFFF;font-size: 28rpx;">{{setInfo.recentTrade}}</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	// Species Preferences
	import ChartSpeciesPreferences from './ChartSpeciesPreferences.vue';
	export default {
		name: 'TabData',
		components: {
			ChartSpeciesPreferences
		},
		props: {
			info: {
				type: Object,
				default: {}
			}
		},
		computed: {
			// 图表数据
			chartData() {
				if (this.info) return this.info.pinzhong;
			},
			list() {
				let temp = [];
				this.chartData.bi.forEach((item, index) => {
					temp.push({
						name: item.toUpperCase(),
						profit: this.chartData.shouyi[index] * 1,
						vol: this.chartData.jiaoyi[index] * 1
					})
				});
				return temp;
			},
			setInfo() {
				return {
					// 最大回撤
					maxRetracement: this.info.tubiaoshuju[0].value * 1,
					// 持有盈亏
					holdProfit: this.info.tubiaoshuju[1].value * 1,
					// 交易笔数
					tradeCount: this.info.tubiaoshuju[2].value * 1,
					// 胜率
					winRate: this.info.tubiaoshuju[3].value * 1,
					// 平均盈利(USD)
					averageProfit: this.info.tubiaoshuju[4].value * 1,
					// 平均亏损(USD)
					averageLoss: this.info.tubiaoshuju[5].value * 1,
					// 交易周数
					tradeWeek: this.info.tubiaoshuju[6].value * 1,
					// 最大衰落期(天)
					maxDecay: this.info.tubiaoshuju[7].value * 1,
					// 净值/余额(USD)
					netBalance: this.info.tubiaoshuju[8].value,
					// 存款(USD)
					deposit: this.info.tubiaoshuju[9].value * 1,
					// 取款(USD)
					withdrawal: this.info.tubiaoshuju[10].value * 1,
					// 账户时区
					timeZone: this.info.tubiaoshuju[11].value,
					// 最近交易 this.info.zuijin_at
					recentTrade: this.info.zuijin_at,
				}
			}
		},
	}
</script>

<style>
</style>