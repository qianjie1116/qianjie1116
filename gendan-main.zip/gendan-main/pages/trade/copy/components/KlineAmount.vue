<template>
	<view>
		<view style="display: flex;align-items: center;padding:36rpx;">
			<view style="background-color: #FFFFFF;width: 8rpx;height: 28rpx;"></view>
			<view style="font-size: 28rpx;font-weight: 700;color:#FFFFFF;padding-left: 40rpx;">
				{{$lang.COPY_DETAIL_INVESTORS_AMOUNT}}
			</view>
		</view>

		<view style="display: flex;align-items: center;justify-content: center;padding-bottom: 36rpx;">
			<view class="charts" id="kline-amount"> </view>
		</view>
	</view>
</template>

<script>
	import {
		init,
		dispose
	} from '@/common/klinecharts.min.js';
	import {
		klineGird,
		klineArea
	} from '@/common/klineConfig.js';
	export default {
		name: 'KlineAmount',
		props: {
			list: {
				type: Array,
				default: []
			}
		},
		data() {
			return {
				klineCount: null,
				klineAmount: null,
			}
		},
		computed: {
			chartDataAmount() {
				if (this.list && this.list.length > 0) {
					const tempSort = this.list.sort((a, b) =>
						new Date(a.updated_at).getTime() - new Date(b.updated_at).getTime());
					// console.log(`temp`, tempSort);
					return tempSort.map(item => {
						return {
							timestamp: new Date(item.updated_at).getTime(),
							close: item.zonggentou * 1
						}
					});
				}
			}
		},
		created() {},
		mounted() {
			setTimeout(() => {
				this.genKlineAmount();
			}, 1000)
		},
		unmounted() {
			dispose("kline-amount");
		},
		methods: {

			clearData() {
				if (this.klineAmount) this.klineAmount.clearData();
			},
			genKlineAmount() {
				if (!this.klineAmount)

					this.klineAmount = init('kline-amount', {
						customApi: {
							formatBigNumber: 1000,
						}
					});
				this.klineAmount.setStyles({
					grid: klineGird,
					candle: klineArea,
				});
				// console.log(`count:`, this.chartDataAmount)
				this.klineAmount.applyNewData(this.chartDataAmount, 0)
			}
		}
	}
</script>

<style lang="scss" scoped>
	.charts {
		width: 680upx;
		height: 500upx;
	}
</style>