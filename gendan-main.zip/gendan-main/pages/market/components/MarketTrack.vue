<template>
	<view>
		<template v-if="list.length<=0">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<block v-for="(item,index) in list" :key="index">
				<view class="common_block" style="padding:10px;background-color: #FFFFFF;margin:20rpx;"
					@click="linkInfo(item.stock_id)">
					<template v-if="item.logo">
						<view style="width: 90rpx;text-align: center;">
							<CustomLogo :logo="item.logo" :name="item.name"></CustomLogo>
						</view>
					</template>

					<view style="display: flex;align-items: center;justify-content: space-between;">
						<view :style="{color:$theme.SECOND}"
							style="font-size: 32rpx;border-bottom: 1px solid #CCCCCC;line-height: 1.6;">
							{{item.name}}
						</view>
					</view>
					<view style="display: flex;align-items: center;justify-content: space-between;padding-top: 10rpx;">
						<view :style="{color:$theme.LOG_LABEL}">{{item.code}}</view>
						<view :style="$theme.setStockRiseFall(item.rate*1>0)">
							{{$util.formatMoney(item.close)}}
						</view>
						<view :style="$theme.setStockRiseFall(item.rate*1>0)">
							{{$util.formatNumber(item.rate)}}%
						</view>
					</view>
				</view>
			</block>
		</template>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	import CustomLogo from '@/components/CustomLogo.vue';
	export default {
		name: 'MarketTrack',
		components: {
			EmptyData,
			CustomLogo
		},
		data() {
			return {
				list: [],
			}
		},
		computed: {},
		created() {
			this.getList();
		},
		methods: {
			// 跳转到详情
			linkInfo(val) {
				uni.navigateTo({
					url: this.$paths.COIN_OVERVIEW + `?code=${val}`
				})
			},
			async getList() {
				uni.showToast({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/user/collect_list`, {
					limit: 50
				});
				console.log('result:', result);
				if (!result) return false;
				this.list = result.list || [];
			}
		}
	}
</script>

<style>
</style>