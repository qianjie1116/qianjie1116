<template>
	<view :class="isAnimat?'fade_in':'fade_out' " style="min-height: 100vh;">
		<template v-if="info">
			<header class="common_header" style="padding-bottom: 0;">
				<view class="center" style="padding-left: 0;">
					<text :style="{color:$theme.SECOND}">{{info.name}}</text>
					<!-- <image src="/static/coin_choose.png" mode="aspectFit" style="padding-left: 20rpx;"
						:style="$theme.setImageSize(24)" @tap="chooseCoin()"></image> -->
				</view>
				<view class="right">
					<view @click="linkCoinInfo()">
						<image src="/static/cantract_detail.png" mode="aspectFit" style="padding-right: 30rpx;"
							:style="$theme.setImageSize(32)">
						</image>
					</view>
				</view>
				<!-- <view class="right">
					<view @click="handleUnFollow(info.gid)">
						<image :src="`/static/${info && info.is_collected==1?'stock_follow':'stock_unfollow'}.png`"
							:style="$theme.setImageSize(32)"></image>
					</view>
				</view> -->
			</header>
			<template v-if="info">
				<view style="margin:20rpx 60rpx;display: flex;align-items: center;justify-content: space-between;">
					<text style="font-size: 28rpx;"
						:style="$theme.setStockRiseFall(info.rate>0)">{{$util.formatNumber(info.current_price)}}</text>
					<text style="font-size: 26rpx;padding:0 40rpx;"
						:style="$theme.setStockRiseFall(info.rate>0)">{{info.rate}}%</text>
					<image src="/static/contract_desc.png" mode="aspectFit" style="padding-left: 20rpx;"
						:style="$theme.setImageSize(24)" @tap="showDesc()"></image>
				</view>
			</template>

			<view style="margin: 20rpx;padding:20rpx;display: flex;align-items: center;">
				<view style="width:60%;">
					<u-radio-group v-model=" radiovalue1" placement="row" @change="groupChange">
						<u-radio :customStyle="{marginRight: '24rpx'}" v-for="(item, index) in radioList" :key="index"
							:label="item.name" :name="item.name" @change="radioChange"
							:activeColor="curTab==0?$theme.RISE:$theme.FALL" labelSize="28rpx"
							:labelColor="item.name==radiovalue1?$theme.RISE:'#CFCFCF' ">
						</u-radio>
					</u-radio-group>
					<view
						style="display: flex;align-items: center;justify-content: space-between; padding: 20rpx 20rpx 20rpx 0;">
						<view style="width: 40%;" :style="{color:$theme.LOG_LABEL}"> {{$lang.CONTRACT_LEVER}} </view>
						<view style="width: 60%;">
							<view @tap="handleChooseLever()"
								style="background-color:#F5F6FB0A;border-radius: 8rpx;height: 40rpx;line-height: 40rpx;display: flex;align-items: center;justify-content: space-around;padding:6rpx 0;color:aliceblue">
								<view>{{curLever+` X`}}</view>
								<image src="/static/arrow_down_solid.png" mode="aspectFit"
									:style="$theme.setImageSize(16)">
								</image>
							</view>
						</view>
					</view>

					<!-- 限价模式，输入金额 -->
					<template v-if="isShowAmountInput">
						<view class="common_input_wrapper"
							style="background-color:#F5F6FB0A;border-radius: 8rpx;height: 32rpx;padding-left: 20rpx;margin:0 20rpx 20rpx 0;">
							<input v-model="amount" type="digit" :placeholder="$lang.COIN_BUY_TIP_ENTER_PRICE"
								:placeholder-style="$theme.setPlaceholder()"></input>
						</view>
					</template>
					<template v-else>
						<view class="common_input_wrapper"
							style="background-color:#F5F6FB0A;border-radius: 8rpx;height: 32rpx;padding-left: 20rpx;margin:0 20rpx 20rpx 0;"
							:style="{color:$theme.LOG_LABEL}">
							{{info.current_price}}
						</view>
					</template>

					<view class="common_input_wrapper"
						style="background-color:#F5F6FB0A;border-radius: 8rpx;height: 32rpx;padding-left: 20rpx;margin:20rpx 20rpx 20rpx 0;">
						<input v-model="quantity" type="digit" :placeholder="$lang.COIN_BUY_TIP_ENTER_QTY"
							:placeholder-style="$theme.setPlaceholder()"></input>
					</view>
					<!-- <view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
					{{$lang.CONTRACT_PROFIT_LOSS_SET}}
				</view>
				<view style="display: flex;align-items: center;">
					<view style="width: 50%;">
						<view class="common_input_wrapper"
							style="background-color:#F5F6FB;border-radius: 8rpx;height: 32rpx;padding-left: 20rpx;margin:20rpx 20rpx 20rpx 0;">
							<input v-model="profitAmount" type="digit" :placeholder="$lang.CONTRACT_PROFIT"
								:placeholder-style="$theme.setPlaceholder()"></input>
						</view>
					</view>
					<view style="width: 50%;">
						<view class="common_input_wrapper"
							style="background-color:#F5F6FB;border-radius: 8rpx;height: 32rpx;padding-left: 20rpx;margin:20rpx 20rpx 20rpx 0;">
							<input v-model="lossAmount" type="digit" :placeholder="$lang.CONTRACT_LOSS"
								:placeholder-style="$theme.setPlaceholder()"></input>
						</view>
					</view>
				</view> -->

					<view style="margin-right: 20rpx; background-color:#F5F6FB0A;border-radius: 4rpx;">
						<view style="display: flex;align-items: center;line-height: 1.8;">
							<block v-for="(item,index) in percentList" :key="index">
								<view :style="setStylePercent(item==curPercent)" @click="changePercent(item)">
									{{item*100+` %`}}
								</view>
							</block>
						</view>
					</view>

					<template v-if="userInfo">
						<view style="text-align: right;font-size: 24rpx;padding-right: 20rpx;line-height: 1.8;"
							:style="{color:$theme.LOG_LABEL}">
							{{$lang.COIN_BUY_BALANCE}}{{`: ${userInfo.money} USDT`}}
						</view>
					</template>

					<view style="text-align: right;font-size: 24rpx;padding-right: 20rpx;line-height: 1.6;"
						:style="{color:$theme.LOG_LABEL}">
						{{$lang.COIN_BUY_MAX_QTY}} {{`: ${$util.formatNumber(curMaxQTY,4)} ${info.number_code}`}}
					</view>

					<view
						style="display: flex;align-items: center;justify-content: space-between;margin:10rpx 20rpx;line-height:1.6;">
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
							{{$lang.COIN_BUY_TOTAL_AMOUNT}}
						</view>
						<view style="font-size: 26rpx;" :style="{color:$theme.LOG_VALUE}">
							{{totalAmount+` USDT`}}
						</view>
					</view>

					<view
						style="display: flex;align-items: center;justify-content: space-between;padding-right: 20rpx;">
						<view :style="setStyle(true)" @tap="handleSubmit(0)">
							{{$lang.CONTRACT_DETAIL_BNT_BUY}}
						</view>
						<view :style="setStyle(false)" @tap="handleSubmit(1)">
							{{$lang.CONTRACT_DETAIL_BTN_SELL}}
						</view>
					</view>

				</view>
				<view style="width:40%;">
					<view>
						<template v-if="asks && asks.length>0">
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
									{{$lang.COIN_BUY_TITLE_PRICE}}
								</view>
								<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
									{{$lang.COIN_BUY_TITLE_QTY}}
								</view>
							</view>

							<AskList :list="asks" :max="asksMax"></AskList>
							<BidList :list="bids" :max="bidsMax" dir="right"></BidList>
						</template>
					</view>
				</view>
			</view>

			<!-- 當前委托 持有倉位 历史记录 -->
			<ContractTabs :tabs="setTabs" @action="changeTab" :active="curTab1"></ContractTabs>

			<template v-if="curTab1==0">
				<CurrentRecord :code="code" ref="current"></CurrentRecord>
			</template>
			<template v-else-if="curTab1==1">
				<HoldRecord :list="holdList" @action="handleHoldList"></HoldRecord>
			</template>
			<template v-else>
				<HistoryRecord :list="historyList" ref="history" @action="toggleCoin"></HistoryRecord>
			</template>
		</template>

		<!-- 顯示合約説明 -->
		<template v-if="isShowDesc">
			<ContractDesc @action="handleClose"></ContractDesc>
		</template>

		<!-- 杠桿選擇器 -->
		<u-picker :show="isShowLever" :columns="[leverList]" @change="changeLever" @cancel="isShowLever=false"
			@confirm="confirmLever" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY"></u-picker>

		<!-- Coin  選擇器 -->
		<u-picker :show="isShowCoinList" :columns="[coinList]" @change="changeCoin" @cancel="isShowCoinList=false"
			@confirm="confirmCoin" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" keyName="label"
			visibleItemCount="9"></u-picker>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import TitleSecond from '@/components/TitleSecond.vue';
	import ContractTabs from './components/ContractTabs.vue';
	import CurrentRecord from './components/CurrentRecord.vue';
	import HistoryRecord from './components/HistoryRecord.vue';
	import AskList from './components/AskList.vue';
	import BidList from './components/BidList.vue';
	import HoldRecord from './components/HoldRecord.vue';
	import ContractDesc from './components/ContractDesc.vue';
	export default {
		components: {
			HeaderSecond,
			TitleSecond,
			ContractTabs,
			CurrentRecord,
			HistoryRecord,
			HoldRecord,
			AskList,
			BidList,
			ContractDesc,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				code: '', // url ?code=
				curTab: 0, // 当前显示的tab buy or sell
				curTab1: 1, // 列表区域

				isShowDesc: false, // 是否顯示合約説明
				isShowCoinList: false, // 是否顯示 coin選擇器
				coinList: null, // coin 選項組

				leverList: null, // 杠桿選項組				
				asks: [],
				bids: [],
				asksMax: 0, // asks 當前最大數量
				bidsMax: 0, // bids 當前最大數量
				socket: null,
				isConnected: false, // 是否链接socket
				isShowLever: false, // 是否顯示杠桿選擇器
				curLever: 1, // 当前选中杠杆值

				quantity: '', // 数量输入框 
				curPercent: -1, // 當前選中百分比


				// profitAmount: '', // 止盈輸入金額
				// lossAmount: '', // 止損輸入金額



				show: false,
				info: null,
				userInfo: null,
				// u-radio-group的v-model绑定的值如果设置为某个radio的name，就会被默认选中
				radiovalue1: this.$lang.COIN_PRICE_TYPE_MARKET,
				amount: '', // 限价模式 输入金额

				holdList: [], // 持有列表
				isShowCurCoin: true, // 是否仅显示当前coin				

				historyList: [], // 历史记录数据
			};
		},
		computed: {
			setTabs() {
				return [this.$lang.CONTRACT_RECORD_CURRENT,
					this.$lang.CONTRACT_RECORD_HOLD,
					this.$lang.CONTRACT_RECORD_HISTORY
				]
			},
			// 单选项的选项组
			radioList() {
				return [{
					name: this.$lang.COIN_PRICE_TYPE_MARKET,
					disabled: false
				}, {
					name: this.$lang.COIN_PRICE_TYPE_LIMIT,
					disabled: false
				}];
			},
			// 可用餘額的百分之多少
			percentList() {
				return [0.25, 0.50, 0.75, 1]
			},

			// 当前交易模式
			isShowAmountInput() {
				return this.radiovalue1 == this.radioList[1].name;
			},
			// 當前最大可買或可買數量
			curMaxQTY() {
				// 市價模式： 餘額/單價。 限價模式：餘額/輸入值
				if (this.info && this.userInfo) {
					// 市價或限價模式下的單價
					const temp = this.isShowAmountInput ? this.amount : this.info.current_price;
					// console.log(`curMaxQty:`, temp);
					return temp * 1 > 0 ? this.$util.formatNumber(this.userInfo.money * this.curLever / temp, 4) : '';
				}
			},
			// 计算总价
			totalAmount() {
				if (!this.info) return 0;

				// console.log(this.info.current_price);
				const temp = this.isShowAmountInput ? this.amount : this.info.current_price;
				// 價格*數量/杠桿
				const temmTotal = temp * 1 * this.quantity * 1 / this.curLever;
				// console.log(`total amount:`, temmTotal);
				// const result = temmTotal.toString().split('.')[1]?.length || 0;
				// return result < 3 ? temmTotal : Number(temmTotal.toFixed(4));
				return this.$util.formatNumber(temmTotal, 4);
			},
		},
		onLoad(opt) {
			console.log(opt);
			this.code = opt.code || 'btcusdt'; // 默認 btcusdt
			// this.curTab = opt.tag || 0; // buy(long) or sell(short)
		},
		onShow() {
			this.isAnimat = true;
			if (this.socket) this.disconnect();
			this.getData();
			this.getAccountInfo();
			if (this.curTab1 == 0 && this.$refs.current) this.$refs.current.getList();
			if (this.curTab1 == 2 && this.$refs.history) this.getHistoryList();
			if (this.curTab1 == 1) this.getHoldList();
		},
		onHide() {
			this.isAnimat = false;
			if (this.socket) this.disconnect();
		},
		onUnload() {
			if (this.socket) this.disconnect();
		},
		deactivated() {
			if (this.socket) this.disconnect();
		},
		methods: {
			changeTab(val) {
				console.log(`val111:`, val);
				this.curTab1 = val;
				if (this.curTab1 == 1) this.getHoldList();
				if (this.curTab1 == 2) this.getHistoryList();
			},
			// 是否只显示当前数据
			toggleCoin(val) {
				console.log(`Only current coin data:`, val);
				this.isShowCurCoin = val;
				if (this.curTab1 == 2) this.getHistoryList();
			},
			// 
			async getHistoryList() {
				let formData = {
					status: 2, // 1持仓，2历史
				}
				if (this.isShowCurCoin) {
					formData.code = this.code;
				}
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/user/heyueorder`, formData);
				if (!result) return false;
				console.log(`result:`, result);
				const temp = !Array.isArray(result) || result.length < 0 ? [] :
					result.filter(item => item.orderheyuebuy && item.orderheyuebuy.gid > 0 && item.orderheyuebuy.gid >
						0 &&
						item.orderheyuebuy);

				console.log(2222, temp)
				this.historyList = temp.length <= 0 ? [] : temp.map(item => {
					return {
						id: item.orderheyuebuy.id,
						name: item.orderheyuebuy.name,
						// fx   1市价 2限价
						fx: item.orderheyuebuy.fx,
						fxText: item.orderheyuebuy.fx == 1 ? this.$lang.COIN_PRICE_TYPE_MARKET : this.$lang
							.COIN_PRICE_TYPE_LIMIT,
						direct: item.orderheyuebuy.direct,
						// direct   1:买涨 买入；2：买跌 卖出
						directText: item.orderheyuebuy.direct == 1 ? this.$lang.CONTRACT_DETAIL_BNT_BUY : this
							.$lang.CONTRACT_DETAIL_BTN_SELL,
						yingkui: item.interest * 1,
						buy_price: item.orderheyuebuy.price * 1,
						buy_fee: item.orderheyuebuy.buy_fee * 1,
						rate: item.interest * 1 / (item.orderheyuebuy.amount * 1) * 100,
						price: item.price * 1,
						quantity: item.num * 1,
						total: item.orderheyuebuy.amount * 1,
						sn: item.orderheyuebuy.order_sn,
						created_at: item.orderheyuebuy.created_at,
						fee: item.sell_fee * 1,
						lever: item.orderheyuebuy.double,
					}
				});
			},

			// 選擇杠桿 Lever
			handleChooseLever() {
				this.isShowLever = true;
			},
			changeLever(e) {
				console.log(`changeMode e:`, e);
			},
			confirmLever(e) {
				console.log(`confirmMode e:`, e);
				this.curLever = e.value[0];
				this.isShowLever = false;
			},

			// 合約交易説明
			showDesc() {
				this.isShowDesc = true;
				uni.hideTabBar(); // 隐藏tabBar
			},
			handleClose(val) {
				console.log('val:', val);
				this.isShowDesc = false;
				uni.showTabBar(); // 显示tabBar
			},

			// 選擇一種coin
			chooseCoin() {
				// 請求數據。
				this.getCoinList();
			},
			changeCoin(e) {
				console.log(`changeMode e:`, e);
			},
			// coin選擇器確認事件
			confirmCoin(e) {
				console.log(`confirmMode e:`, e);
				this.code = e.value[0].code;
				this.isShowCoinList = false;
				// 重置一些值
				this.quantity = '';
				this.curLever = 1;
				this.curPercent = -1;
				this.getData();
			},
			// 在切換coin時，需請求列表，製作coin選擇器數組
			async getCoinList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.get(`api/goods/list`);
				if (!result) return false;
				console.log(result);
				this.coinList = Object.values(result).map(item => {
					return {
						label: item.name,
						code: item.code
					}
				});
				// 獲取數據之後，顯示選擇器
				this.isShowCoinList = true;
			},

			// 跳轉到 詳情頁面
			linkCoinInfo() {
				uni.navigateTo({
					url: this.$paths.CONTRACT_DETAIL + `?code=${this.code}`
				});
			},
			// 選擇輸入值的百分比
			changePercent(val) {
				// 選中值與當前值相同，是爲取選。
				if (this.curPercent == val) {
					this.curPercent = -1;
					return false;
				}
				this.curPercent = val;

				if (this.curPercent > 0) {
					// 市價或限價模式下的單價
					const temp = this.isShowAmountInput ? this.amount : this.info.current_price;
					// console.log(`curMaxQty:`, temp);
					// 余额*杠杆/实时价*百分比
					this.quantity = temp * 1 > 0 ?
						this.$util.formatNumber(this.userInfo.money * this.curLever / temp * this.curPercent, 4) : '';
				}
			},
			// 設置百分比的選中樣式
			setStylePercent(val) {
				return {
					width: `50%`,
					textAlign: `center`,
					backgroundColor: val ? this.$theme.RGBConvertToRGBA(this.$theme.RISE, 20) : this.$theme.TRANSPARENT,
					color: val ? this.$theme.RISE : this.$theme.LABEL
				}
			},

			// 设置样式
			setStyle(val) {
				return {
					width: `40%`,
					margin: '0',
					padding: `12rpx`,
					textAlign: 'center',
					backgroundColor: val ? this.$theme.RISE : this.$theme.FALL,
					color: '#FFFFFF',
					borderRadius: `44rpx`,
				}
			},


			// 选择杠杆
			chooseLever(val) {
				this.curLever = val;
			},
			groupChange(n) {
				console.log('groupChange', n);
				this.radiovalue1 = n;
			},
			radioChange(n) {
				console.log('radioChange', n);
				this.radiovalue1 = n;
			},

			// 产品详情
			async getData() {
				if (this.socket) this.disconnect();
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.post(`api/product/info`, {
					code: this.code,
				});
				if (!result) return false;
				console.log(`coin info:`, result);
				this.info = result[0];
				this.getDepthList();
				this.getAccountAssets();
				this.connect();
				this.amount = this.info.current_price;
				if (this.curTab1 == 1) this.getHoldList();
			},

			checkFrom() {
				if (this.quantity == '' || this.quantity <= 0) {
					uni.showToast({
						title: this.$lang.COIN_BUY_TIP_ENTER_QTY,
						icon: 'none'
					});
					return false;
				}
				if (!this.$util.checkInputNumber(this.quantity)) return false;

				if (this.isShowAmountInput) {
					if (this.amount == '' || this.amount <= 0) {
						uni.showToast({
							title: this.$lang.COIN_BUY_TIP_ENTER_PRICE,
							icon: 'none'
						});
						return false;
					}
				}
				return true;
			},

			// 買賣  
			async handleSubmit(val) {
				if (this.checkFrom()) {
					// const result = await uni.showModal({
					// 	title: '',
					// 	content: `${this.info.name} Quantity ${this.quantity}`,
					// 	cancelText: this.$lang.COIN_MODAL_CANCEL,
					// 	confirmText: this.$lang.COIN_MODAL_COMFIRM,
					// 	showCancel: true, // 是否显示取消按钮，默认为 true
					// 	confirmColor: this.$theme.SECOND,
					// 	cancelColor: this.$theme.MODAL_CANCEL,
					// });
					// if (result[1].confirm) {
					if (val == 0) {
						this.buy();
					} else if (val == 1) {
						this.sell();
					}
					// }
				}
			},
			async buy(val) {
				let formData = {
					type: 2,
					num: this.quantity,
					gid: this.info.gid,
					fx: this.isShowAmountInput ? 2 : 1, // 1市价 2限价
					direct: 1, // direct   1买多    2卖少
					ganggan: this.curLever, // 杠桿
				}
				if (this.isShowAmountInput) {
					formData.price = this.amount;
				}
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/product/bipurchase`, formData);
				if (!result) return false;
				console.log(`buy result:`, result);
				uni.showToast({
					title: result.message,
					icon: 'success'
				});
				this.getAccountAssets();
				// 刷新当前激活的列表
				if (this.curTab1 == 0 && this.$refs.current) {
					this.$refs.current.getList();
				}
				if (this.curTab1 == 1) {
					this.getHoldList();
				}
				if (this.curTab1 == 2 && this.$refs.history) {
					this.$refs.history.getList();
				}
			},

			async sell() {
				let formData = {
					type: 2,
					num: this.quantity,
					gid: this.info.gid,
					fx: this.isShowAmountInput ? 2 : 1, // 1市价 2限价
					direct: 2, // direct   1买多    2卖少
					ganggan: this.curLever, // 杠桿
				}
				if (this.isShowAmountInput) {
					formData.price = this.amount;
				}
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/product/bipurchase`, formData);
				if (!result) return false;
				uni.showToast({
					title: result.message,
					icon: 'success'
				});
				this.getAccountAssets();
				// 刷新当前激活的列表
				if (this.curTab1 == 0 && this.$refs.current) {
					this.$refs.current.getList();
				}
				if (this.curTab1 == 1) {
					this.getHoldList();
				}
				if (this.curTab1 == 2 && this.$refs.history) {
					this.$refs.history.getList();
				}
			},

			// 获取账户 資產 信息 (每次切換買賣時，都調用一次該函數)
			async getAccountAssets() {
				// const result = await this.$http.post(`api/user/assets`, {
				// 	type: 1, // 合約賬戶
				// 	name: 'USDT',
				// });
				// 单钱包模式
				const result = await this.$http.post(`api/user/assets`, {
					type: 2, // 合約賬戶
					name: 'USDT',
				});
				console.log(`assets:`, result);
				if (!result) return false;
				this.userInfo = result;
				this.userInfo.money = this.userInfo.money * 1;
				console.log(`assets:`, this.userInfo);
			},

			async getAccountInfo() {
				uni.showLoading({
					title: this.$lang.API_GET_ACCOUNT_INFO
				});
				const result = await this.$http.get(`api/user/fastInfo`);
				if (!result) return false;
				// 处理杠杆，后端数据返回不一致。
				this.leverList = this.$util.leverList(result.ganggan);
				console.log('leverList:', this.leverList);
			},

			async getDepthList() {
				const response = await uni.request({
					url: `https://api.huobi.pro/market/depth`,
					method: 'GET',
					data: {
						symbol: this.info.locate,
						depth: 5,
						type: 'step0'
					},
				});
				const [err, res] = response;
				console.log('err:', err, 'res:', res);
				if (res && res.data.status == 'ok') {
					const temp = res.data;
					this.asks = res.data.tick.asks;
					this.bids = res.data.tick.bids;
					// 當前數組中，數量最大值， *1.01(餘量，避免求出100%)
					this.asksMax = Math.max(...this.asks.map(item => item[1])) * 1.01;
					// 當前數組中，數量最大值， *1.01(餘量，避免求出100%)
					this.bidsMax = Math.max(...this.bids.map(item => item[1])) * 1.01;
				}
				console.log('asks:', this.asks);
				console.log('bids:', this.bids);
			},

			// websocket 断线重连
			reconnectWebSocket() {
				// 连接中，并且非手动关闭
				if (this.isConnected) return;
				console.log(`reconnect!`, this.isConnected);
				this.socket = null;
				console.log(`reconnect! socket:`, this.socket);
				this.connect();
			},
			// websocket链接
			connect() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_COIN_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.info(`success res:`, res);
					},
					fail: (res) => {
						console.info(`fail res:`, res);
					}
				});
				console.log(`socket:`, this.socket);
				if (this.socket) {
					this.isConnected = true; // 已连接
					this.socket.onOpen((res) => {
						console.info("socket onOpen:", res)
					});
					this.socket.onClose((res) => {
						// code:1000(手动关闭) 1006(异常关闭) 
						console.log(`onClose:`, res);
						this.isConnected = false;
						if (res.code !== 1000) {
							this.reconnectWebSocket();
						}
					});

					this.socket.onError((err) => {
						console.log(`onError:`, err);
						this.isConnected = false;
						this.reconnectWebSocket();
					});
					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);
						if (this.info.code == data.market && data.lastPrice > 0) {
							// console.log('data:', data);
							this.info.current_price = data.lastPrice || 0;
							this.info.rate = data.rate || 0;
							// this.info.rate_num = data.rate_num || 0;
							// this.info.vol = data.vol || 0;
						}
						// 當前買賣盤的數據
						if (this.info.code == data.market && data.type == "depth") {
							// 直接提取前五條，替換數據		
							const tempAsk = data.ask.slice(0, 5);
							const tempBid = data.bid.slice(0, 5);
							// console.log('data depth:', data);
							this.asks = tempAsk.map(item => [item.price, item.quantity]);
							this.bids = tempBid.map(item => [item.price, item.quantity]);
							// 當前數組中，數量最大值， *1.01(餘量，避免求出100%)
							this.asksMax = Math.max(...this.asks.map(item => item[1])) * 1.01;
							// 當前數組中，數量最大值， *1.01(餘量，避免求出100%)
							this.bidsMax = Math.max(...this.bids.map(item => item[1])) * 1.01;
						}

						// 匹配hold列表的每条数据。计算对应数据的floatPL值
						this.holdList.forEach(item => {
							if (item.code == data.market && data.lastPrice > 0) {
								item.curPrice = data.lastPrice;
								if (item.direct == 1) {
									// ~~买多的计算公式: (当前价-买入价-手续费)*数量~~ 
									// item.floatPLBuy = this.$util.formatNumber((data.lastPrice * 1 - item
									// 	.price * 1 - item.fee *
									// 	1) * item.quantity, 4);

									// （实时价-买入价）*数量/杠杆-手续费 /by 2024.08.26
									item.floatPLBuy = this.$util.formatNumber(
										(data.lastPrice * 1 - item.price * 1) *
										item.quantity * item.lever - (item.fee * 1), 4);

									// （实时价-买入价）*数量/杠杆 /by 2024.08.26
									item.profitLossBuy = this.$util.formatNumber(
										(data.lastPrice * 1 - item.price * 1) * item.quantity * item
										.lever, 4);

									item.rateBuy = this.$util.formatNumber((data.lastPrice * 1 - item
										.price * 1) / item.price * 100, 2) + "%";

								}
								if (item.direct == 2) {
									// // 卖少的计算公式: (买入价-当前价-手续费)*数量
									// item.floatPLSell = this.$util.formatNumber((item.price * 1 - data
									// 	.lastPrice * 1 - item.fee *
									// 	1) * item.quantity, 4);
									// (买入价-当前价）*数量/杠杆-手续费 /by 2024.08.26
									const temp = (item.price * 1 - data.lastPrice * 1) *
										item.quantity * item.lever - (item.fee * 1);
									item.floatPLSell = this.$util.formatNumber(temp, 4);

									// (买入价-当前价）*数量/杠杆 /by 2024.08.26
									item.profitLossSell = this.$util.formatNumber((item.price * 1 - data
											.lastPrice * 1) * item.quantity * item
										.lever, 4);

									item.rateSell = this.$util.formatNumber((item.price * 1 - data
										.lastPrice * 1) / item.price * 100, 2) + "%";
								}
							}
						});
					});
				}
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
			},
			// 子组件改变checkbox的状态
			handleHoldList(val) {
				console.log(`val:`, val);
				this.isShowCurCoin = val;
				this.getHoldList();
			},
			async getHoldList() {
				let formData = {
					status: 1, // 1持仓，2历史
				}
				if (this.isShowCurCoin) {
					formData.code = this.code;
				}
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/user/heyueorder`, formData);
				if (!result) return false;
				console.log(`hold result:`, result);
				const temp = !Array.isArray(result) || result.length < 0 ? [] :
					result.filter(item => item.orderheyuebuy && item.orderheyuebuy.gid > 0 && item.orderheyuebuy &&
						item
						.orderheyuebuy.gid > 0);
				console.log(`hold result temp:`, temp);
				this.holdList = temp.length <= 0 ? [] : temp.map(item => {
					return {
						id: item.orderheyuebuy.id,
						code: item.orderheyuebuy.code,
						name: item.orderheyuebuy.name,
						// fx   1市价 2限价
						fx: item.orderheyuebuy.fx,
						fxText: item.orderheyuebuy.fx == 1 ? this.$lang.COIN_PRICE_TYPE_MARKET : this.$lang
							.COIN_PRICE_TYPE_LIMIT,
						direct: item.orderheyuebuy.direct,
						// direct   1:买涨 买入 买多；2：买跌 卖出 卖少
						directText: item.orderheyuebuy.direct == 1 ? this.$lang.CONTRACT_DETAIL_BNT_BUY : this
							.$lang
							.CONTRACT_DETAIL_BTN_SELL,
						price: item.orderheyuebuy.price,
						quantity: item.orderheyuebuy.num,
						total: item.orderheyuebuy.user_pay,
						sn: item.orderheyuebuy.order_sn,
						created_at: item.orderheyuebuy.created_at,
						lever: item.orderheyuebuy.double,
						profit: item.orderheyuebuy.zhiying || '--',
						loss: item.orderheyuebuy.zhisun || '--',
						curPrice: item.orderheyuebuy.current_price, // 最新价
						fee: item.orderheyuebuy.buy_fee,
						profitLossBuy: item.orderheyuebuy.yingkui, // 1买多 盈亏
						profitLossSell: item.orderheyuebuy.yingkui, // 2 卖少 盈亏
						floatPLBuy: item.orderheyuebuy.float_yingkui, // 1买多 浮动盈亏
						floatPLSell: item.orderheyuebuy.float_yingkui, // 2 卖少 浮动盈亏
					}
				})
			},
		},
	}
</script>

<style lang="scss" scoped>
	//  u-picker 样式覆盖
	/deep/.u-popup__content {
		background-color: #151517 !important;

		.uni-picker-view-mask {
			background: none !important;
		}

		.u-picker__view__column__item {
			color: #C9C9C9 !important;
		}
	}

	input {
		color: #999999;
	}

	.common_header {
		padding: 40rpx;
		display: flex;
		align-items: center;
		padding-top: 30px;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 500;
			padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: left;
		}
	}
</style>