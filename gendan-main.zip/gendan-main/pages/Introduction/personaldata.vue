<template>
	<view>
		<!-- <view class="flex" style="justify-content: space-between;padding: 30px 20px;">
			<image src="/static/zuojiantou.png" mode="widthFix" style="width: 8px;" @click="$util.goBack()"></image>
			<view class="color-white flex-3 font-size-16 text-center">{{$lang.GEREN_XINXI}}</view>
		</view>
		<view style="border-top: 1px #272729 solid;margin-top: -15px;">.</view> -->
		<view style="background-color: #10193d;height: 230px;">
			<view class="flex">
				<view class="flex-1">
					<HeaderPrimary :title="$lang.TABBAR_HOME"></HeaderPrimary>
				</view>
				<view style="margin-right: 20px;margin-top: 10px;">
					<Translate></Translate>
				</view>
			</view>
			<view class="flex" style="padding: 0px 20px;">
				<template v-if="userInfo">
					<u-avatar :src="userInfo.avatar" default-url='/static/logo.png' size="60"></u-avatar>
					<view class="color-white flex-1 margin-left-20">
						<view class="flex">
							<view class="font-size-16 flex-1">{{userInfo.mobile}}</view>
							<image src="/static/bitou.png" mode="widthFix" style="width: 12px;" @click="bianji()"></image>
						</view>
						<view class="font-size-10">{{userInfo.real_name}}</view>
						<view class="flex">
							<view class="font-size-10" style="color: #5f5e62;">UID :{{userInfo.uid}}</view>
							<view class="margin-left-10 font-size-12" style="color: #16c0c1;">{{$lang.FUZHI}}</view>
						</view>
					</view>
				</template>
			</view>
			</view>
			
			<view style="margin-top: -100px;">
				
				<view style="display: flex;align-items: center;justify-content: center;margin: 40rpx 0;">
					<view class="center_card">
						<view style="display: flex;padding:20rpx 40rpx;color:#222;font-size: 32rpx;">
							{{$lang.ACCOUNT_AMOUNT_TOTAL}}(GBX)
							<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
								:style="$theme.setImageSize(40)" style="padding-left: 20rpx;">
							</image>
							<view style="margin-left: auto;" @click="linkTradRecord()">
								<view
									style="background-color: #FFFFFF;color:#333333;border-radius: 12rpx;padding:6rpx 12rpx;font-size: 20rpx;">
									{{$lang.TRADE_RECORD_TITLE}}
								</view>
							</view>
						</view>
						<template v-if="showAmount">
							<view style="color:#222;padding:0 40rpx;display: flex;align-items: center;">
								<view style="font-size: 55rpx;font-weight: 500;">{{$util.formatMoney(Info.GBX_money)}}
								</view>
								<view style="padding-left: 10rpx;font-size: 18px;">GBX</view>
							</view>
						</template>
						<template v-else>
							<view style="color:#222;padding:0 40rpx;">{{hideAmount}} </view>
						</template>
						<view style="color: #222;padding-left: 40rpx;font-size: 28rpx;padding-top: 20rpx;">
							{{$lang.ACCOUNT_AMOUNT_TOTAL}}(USDT)
						</view>
						<template v-if="showAmount">
							<view style="color:#555;padding:0 40rpx;display: flex;align-items: center;">
								<view style="font-size: 45rpx;font-weight: 500;">{{$util.formatMoney(Info.GBX_usdtmoney)}}
								</view>
								<view style="padding-left: 10rpx;">USDT</view>
							</view>
						</template>
						<template v-else>
							<view style="color:#222;padding: 40rpx;">{{hideAmount}} </view>
						</template>
					</view>
				</view>
				
			</view>
			
			<view class="flex" style=" justify-content: space-between;padding: 5px 20px;">
				<view class="bold color-white text-center" style="background-color: #ff6357;border-radius: 30px; padding: 10px;width: 80px; " @tap="linkTradeHuazhuang()">{{$lang.HUAZHUAN}}</view>
				<view class="bold color-white text-center" style="background-color: #ff6357;border-radius: 30px; padding: 10px;width: 80px; " @tap="linkTradeCopy()">{{$lang.TIKUAN}}</view>
				<view class="bold color-white text-center" style="background-color: #16e2e2;border-radius: 30px; padding: 10px;width: 80px; " @tap="linkTradeFOF()">{{$lang.CHONGZHI}}</view>
			</view>

		<view class="flex" style="padding: 20px 20px;">
			<view style="border-right: 3px #FFF solid; height: 15px;">.</view>
			<view class="color-white margin-left-5 font-size-16">{{$lang.CHANGYONG_SHEZHI}}</view>
		</view>

		<view style="color: #8e8e8f;padding: 0px 20px;">
			<view class="flex justify-between" @click="pwd()">
				<view>{{$lang.GENGGAI_DENGLUMIMA}}</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 8px;"></image>
			</view>
			<view class="flex justify-between margin-top-20" @click="zhifu()">
				<view>{{$lang.GENGGAI_ZHIFUMIMA}}</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 8px;"></image>
			</view>
			<view class="flex justify-between margin-top-20" @click="tixian()">
				<view>{{$lang.GUANLI_TIXIANDIZHI}}</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 8px;"></image>
			</view>
			<!-- <view class="flex justify-between margin-top-20" @click="chongzhi()">
				<view>{{$lang.GUANLI_CHONGZHIDIZHI}}</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 8px;"></image>
			</view> -->
			<view class="flex justify-between margin-top-20" @click="shiming()">
				<view class="flex-1">{{$lang.SHIMING_RENZHENG}}</view>
				<view class="margin-right-10 font-size-12" :style="setStyle()">
					<template v-if="userInfo">
						{{curAuth}}
					</template>
				</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 8px;"></image>
			</view>
			<!-- <view class="flex justify-between margin-top-20">
				<view class="flex-1">语言切换</view>
				<view class="margin-right-10">日语</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 8px;"></image>
			</view> -->
		</view>


		<!-- <view class="flex" style="padding: 30px 20px;">
			<view style="border-right: 3px #FFF solid; height: 15px;">.</view>
			<view class="color-white margin-left-5 font-size-16">{{$lang.QITA_FUWU}}</view>
		</view> -->

		<view style="color: #8e8e8f;padding: 0px 20px;">
			<!-- <view class="flex justify-between" @click="yonghu()">
				<view>{{$lang.YONGHU_XIEYI}}</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 8px;"></image>
			</view>
			<view class="flex justify-between margin-top-20" @click="yinshi()">
				<view>{{$lang.YINSI_SHUOMING}}</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 8px;"></image>
			</view>
			<view class="flex justify-between margin-top-20" @click="huancun()">
				<view>{{$lang.QINGCHU_HUANCUN}}</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 8px;"></image>
			</view> -->
			<!-- <view class="flex justify-between margin-top-20">
				<view>意见反馈</view>
				<image src="/static/baijiantou.png" mode="widthFix" style="width: 8px;"></image>
			</view> -->
		</view>

		<view class="color-white text-center"
			style="border-radius: 30px;background-color: #ff6357;padding: 10px;margin: 30px 20px;"
			@click="handleSignOut()">{{$lang.TUICHU_DENGLU}}</view>
		<view>.</view>


	</view>
</template>

<script>
</script>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import Translate from '@/components/Translate.vue';
	export default {
		components: {
			HeaderPrimary,
			Translate,
		},
		data() {
			return {
				
				showAmount: false, // 显示金额
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 交易信息
			}
		},
		computed: {
			curAuth() {
				if (this.userInfo) {
					console.log(`?`, this.userInfo);
					// 实名验证：-1未提交 0未审核  1通过 2未通过
					return [
						this.$lang.PROFILE_AUTH_UNSUBMIT,
						this.$lang.PROFILE_AUTH_UNAPPLY,
						this.$lang.PROFILE_AUTH_VERIFIED,
						this.$lang.PROFILE_AUTH_UNVERIFIED
					][!this.userInfo.is_check ? 0 : this.userInfo.is_check + 1]
				}
			},
			// 当前语言
			setLang() {
				const temp = uni.getStorageSync('lang') || this.$LANGCODE;
				const tempName = this.$util.LANGUAGE_LIST.filter(item => item.lang == temp)[0].name;
				return tempName;
			}
		},

		onShow() {
			this.getAccountInfo()
			this.getAccountmoney()
		},
		//下拉刷新
		onPullDownRefresh() {
			this.getAccountInfo()
			this.getAccountmoney()
			uni.stopPullDownRefresh()
		},

		methods: {
			//用户信息
			async getAccountInfo() {
				const result = await this.$http.get(`api/user/info`);
				console.log('info result：', result);
				if (!result) return false;
				this.userInfo = result;
			},
			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},
			// 交易记录
			linkTradRecord() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_TRADE_LOG
				})
			},
			linkTradeCopy() {
				uni.reLaunch({
					url: '/pages/account/withdraw',
				})
			},
			
			linkTradeHuazhuang() {
				uni.reLaunch({
					url: '/pages/transfer/index',
				})
			},
			
			linkTradeFOF() {
				uni.navigateTo({
					url: '/pages/account/deposit'
				})
			},
			bianji() {
				uni.navigateTo({
					url: '/pages/Introduction/EditProfile'
				})
			},
			pwd() {
				uni.navigateTo({
					url: '/pages/account/pwd'
				})
			},
			zhifu() {
				uni.navigateTo({
					url: '/pages/Introduction/Paymentpwd'
				})
			},
			tixian() {
				uni.navigateTo({
					url: '/pages/account/bangk'
				})
			},
			chongzhi() {
				uni.navigateTo({
					url: '/pages/deposit/index'
				})
			},
			shiming() {
				uni.navigateTo({
					url: '/pages/Introduction/auth'
				})
			},
			yonghu() {
				uni.navigateTo({
					url: '/pages/about'
				})
			},
			yinshi() {
				uni.navigateTo({
					url: '/pages/account/pact'
				})
			},
			huancun() {
				uni.showToast({
					title: this.$lang.COMMON_QINGCHU,
				})
			},

			linkPassword(val = '') {
				this.handleClose();
				const temp = val.length > 0 ? `?role=${val}` : '';
				uni.navigateTo({
					url: this.$paths.ACCOUNT_PASSWORD + temp
				});
			},

			// 登出
			handleSignOut() {
				uni.removeStorageSync('token');
				try {
					let version = uni.getStorageSync('version')
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast(this.$lang.TIP_SIGN_OUT_SUCCESS);
				setTimeout(() => {
					uni.navigateTo({
						url: this.$paths.ACCOUNT_ACCESS
					});
				}, 500)
			},
			setStyle() {
				const temp = this.userInfo && this.userInfo.is_check == 1 ? this.$theme.RISE : this.$theme.FALL;
				return {
					backgroundColor: this.$theme.RGBConvertToRGBA(temp, 20),
					color: temp,
				}
			},
			async getAccountmoney() {
				const result = await this.$http.get(`api/user/moneychange`);
				console.log('info result：', result);
				if (!result) return false;
				this.Info = result;
				console.log(this.Info.userlevel);
			},


			//用户信息
			async getAccountInfo() {
				const result = await this.$http.get(`api/user/info`);
				console.log('info result：', result);
				if (!result) return false;
				this.userInfo = result;
				console.log(this.userInfo.userlevel);
			}
		},
	}
</script>