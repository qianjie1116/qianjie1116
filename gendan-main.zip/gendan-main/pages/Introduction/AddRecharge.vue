<template>
	<view style="min-height: 100vh;">
		<view 
			v-if="selectedContent == 2">
			<view class="flex" style="justify-content: space-between;padding: 30px 20px;">
				<image src="/static/zuojiantou.png" mode="widthFix" style="width: 8px;" @click="$util.goBack()"></image>
				<view class="color-white flex-3 font-size-16 text-center">添加充值地址</view>
			</view>
			<view style="border-top: 1px #272729 solid;margin-top: -15px;">.</view>


			<view class="color-white" style="padding: 0px 20px;">
				<view>选择货币</view>
				<view class="flex padding-15 margin-top-10 justify-between"
					style="background-color: #1c1c1f;border-radius: 10px;" @tap="chooseCoin()">
					<view>{{curMode}}</view>
					<image src="/static/baisexia.png" mode="widthFix" style="width: 10px;"></image>
				</view>
			</view>

			<view class="padding-20">
				<view class="color-white">钱包地址</view>
				<input placeholder="请输入钱包地址" v-model="curAddress"
					style="background-color: #1c1c1f;padding: 15px;border-radius: 10px;margin-top: 10px;" />
			</view>

			<view style="padding: 0px 20px;">
				<view class="color-white">备注</view>
				<u--textarea v-model="value1"  border="none" placeholder="请输入内容..." style="background-color: #1c1c1f;padding: 10px 15px;margin-top: 10px;"></u--textarea>
			</view>

			<view class="padding-20">
				<view class="color-white padding-10 text-center"
					style="background-color: #16e2e2;border-radius: 30px;margin-top: 150px;"
					@click="showContent(2)">确认</view>
			</view>
			<view style="background-color: #000;">
				<u-picker :show="isShowCoinList" :columns="[coinList]" @change="changeCoin"
					@cancel="isShowCoinList=false" @confirm="confirmCoin" :cancelText="$lang.COMMON_CANCEL"
					:confirmText="$lang.COMMON_CONFIRM" :cancelColor="$theme.MODAL_CANCEL"
					:confirmColor="$theme.PRIMARY" visibleItemCount="9"></u-picker>
			</view>
		</view>


		<view v-else-if="selectedContent == 1">
			<view class="flex" style="justify-content: space-between;padding: 30px 20px;">
				<image src="/static/zuojiantou.png" mode="widthFix" style="width: 8px;" @click="$util.goBack()"></image>
				<view class="color-white flex-3 font-size-16 text-center">管理充值地址</view>
			</view>
			<view style="border-top: 1px #272729 solid;margin-top: -15px;">.</view>

			<view style="padding: 20px 20px;border: #272729 1px solid;width: 85%;margin-left: 7px;border-radius: 10px;">
				<view class="flex">
					<view class="flex-1 ">
						<view class="flex">
							<view class="color-white ">USDT-TRC20</view>
							<image src="../../static/shanchu.png" mode="widthFix"
								style="width: 15px;margin-left: auto;"></image>
						</view>
						<view class="hui1 font-size-11">3sdg3r1sg65reg1ergr5gr5grsg5</view>
					</view>
				</view>
			</view>
			<view
				style="padding: 20px 20px;border: #272729 1px solid;width: 85%;margin-left: 7px;border-radius: 10px;margin-top: 10px;">
				<view class="flex">
					<view class="flex-1">
						<view class="flex">
							<view class="color-white ">USDT-bep20</view>
							<image src="../../static/shanchu.png" mode="widthFix"
								style="width: 15px;margin-left: auto;"></image>
						</view>
						<view class="hui1 font-size-11">3sdg3r1ssdgvregve95qwefg845gre1r5gr5grsg5</view>
					</view>
				</view>
			</view>
			<view class="padding-20" @click="showContent(1)">
				<view class="color-white padding-10 text-center"
					style="background-color: #16e2e2;border-radius: 30px;margin-top: 300px;"
					@click="showContent(2)">添加新账户</view>
			</view>


		</view>
	</view>
	</view>
</template>

<script>
	export default {
		components: {

		},
		data() {
			return {
				isShowCoinList: false, // 是否顯示 coin選擇器
				curMode: 'USDT（ERC20）', // 当前选中模式
				curAddress: '', // 当前选中coin的address
				selectedContent: 1,
			};
		},
		computed: {
			coinList() {
				return ['USDT（ERC20）', 'USDT（TRC20）', 'BTC（BTC）', 'ETH（ETH）']
			},
			// 如果选择非银行
			isCoin() {
				return !this.curMode.includes('Bank');
			},
		},
		methods: {
			chooseCoin() {
				this.isShowCoinList = true;
			},
			changeCoin(e) {
				console.log(`changeMode e:`, e);
			},
			confirmCoin(e) {
				console.log(`confirmMode e:`, e);
				this.curMode = e.value[0];
				this.isShowCoinList = false;
				this.getCoinfg();
				// 重置一些值
				this.isNextStep = false;
			},
			showContent(content) {
				this.selectedContent = content;
			},
			async handleSubmit() {
				if (!this.amount || this.amount <= 0) {
					uni.showToast({
						title: this.$lang.DEPOSIT_ENTER_AMOUNT,
						icon: 'none'
					});
					return false;
				}
				uni.showLoading({
					title: this.$lang.API_DATA_SUBMIT,
				});
				const result = await this.$http.post(`api/app/recharge`, {
					money: this.amount,
					type: this.curMode,
					image: this.obverseUrl || '',
					desc: '',
				});
				if (!result) return false;
				console.log('result:', result);
				uni.showToast({
					// title: result,
					icon: 'success'
				});
				setTimeout(() => {
					this.curAddress = '';
					this.curMode = this.coinList[0];
					this.isNextStep = false;
					this.amount = '';
					this.obverseUrl = '';
					this.linkRecord();
				}, 1000);
			},
			async getCoinfg() {
				const result = await this.$http.post(`api/app/config`);
				if (!result) return false;
				console.log(`result:`, result);
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				if (this.curMode.includes('ERC')) {
					this.curAddress = temp.get('erc20') || '';
				} else if (this.curMode.includes('TRC')) {
					this.curAddress = temp.get('trc20') || '';
				} else if (this.curMode.includes('BTC')) {
					this.curAddress = temp.get('btc') || '';
				} else if (this.curMode.includes('ETH')) {
					this.curAddress = temp.get('eth') || '';
				}
			},
		},
	}
</script>

<style>
</style>