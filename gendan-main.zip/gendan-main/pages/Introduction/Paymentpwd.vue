<template>
	<view style="background-color: #000;min-height: 100vh;">

		<view style="background-image: linear-gradient(180deg, #000, transparent);">
			<view class="flex" style="justify-content: space-between;padding: 30px 20px;">
					<image src="/static/zuojiantou.png" mode="widthFix" style="width: 8px;" @click="$util.goBack()"></image>
				<view class="color-white flex-3 font-size-16 text-center">{{$lang.GENGGAI_ZHIFUMIMA}}</view>
			</view>
			<view style="border-top: 1px #272729 solid;margin-top: -15px;">.</view>
		</view>

		<view style="padding: 0px 20px;">
			<view class="color-white">{{$lang.JIUMI_MA}}</view>
			<view class="common_input_wrapper" style="background-color: #1c1c1f;">
				<!-- <image mode="aspectFit" src="/static/old_pwd.png" :style="$util.setImageSize(32)">
				</image> -->
				<input v-model="value" type="password" :placeholder="$lang.TIP_OLD_PWD"
					:placeholder-style="$util.setPlaceholder()" style="padding: 0px 20px;color: #fff;"></input>
			</view>
             
			 <view class="color-white" style="padding-top: 15px;">{{$lang.XINMI_MA}}</view>
			<view class="common_input_wrapper" style="background-color: #1c1c1f;margin-bottom: 20px;">
				<!-- <image mode="aspectFit" src="/static/account_password.png" :style="$util.setImageSize(32)">
				</image> -->
				<template v-if="isShow" >
					<input v-model="value2" type="text" :placeholder="$lang.TIP_NEW_PWD"
						:placeholder-style="$util.setPlaceholder()" style="width: 80%;padding: 0px 20px;color: #fff;"></input>
				</template>
				<template v-else>
					<input v-model="value2" type="password" :placeholder="$lang.TIP_NEW_PWD"
						:placeholder-style="$util.setPlaceholder()" style="width: 80%;padding: 0px 20px;color: #fff;"></input>
				</template>
				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					:style="$util.setImageSize(40)" @click="toggleShow">
				</image>
			</view>
            
			 <view class="color-white" style="padding-top: 10px;">{{$lang.ZAICI_QUERENXINMIMA}}</view>
			<view class="common_input_wrapper" style="background-color: #1c1c1f;margin-bottom: 30px;">
				<!-- <image mode="aspectFit" src="/static/account_password.png" :style="$util.setImageSize(32)">
				</image> -->
				<template v-if="isShow">
					<input v-model="value3" type="text" :placeholder="$lang.TIP_NEW_PWD_VERIFY"
						:placeholder-style="$util.setPlaceholder()" style="width: 80%;padding: 0px 20px;color: #fff;"></input>
				</template>
				<template v-else>
					<input v-model="value3" type="password" :placeholder="$lang.TIP_NEW_PWD_VERIFY"
						:placeholder-style="$util.setPlaceholder()" style="width: 80%;padding: 0px 20px;color: #fff;"></input>
				</template>
				<image :src="`/static/${isShow?'show':'hide'}_dark.png`" mode="aspectFit"
					:style="$util.setImageSize(40)" @click="toggleShow">
				</image>
			</view>
			<view class="access_btn" style=" width: 90%;" @click="changePassword()">
				{{$lang.BTN_CONFIRM}}
			</view>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				isShow: false, // 密码显隐
				value: "",
				value2: "",
				value3: "",
			};
		},
		methods: {
			// 切换密码显隐
			toggleShow() {
				this.isShow = !this.isShow;
			},
			//修改支付密码
			async changePassword() {
				const result = await this.$http.post(`api/user/updatePayPassword`, {
					oldpass: this.value,
					newpass: this.value2,
					confirmpass: this.value3,
				});
				if (!result) return false;
					// this.actionEvent();
					uni.showToast({
					title: this.$lang.COMMON_QINGCHU,
					});
				if (!result) return false;
				setTimeout(() => {
					uni.switchTab({
						url: this.$paths.COMMON_QINGCHU
					});
				}, 1000);
			},
		},
	}
</script>