<template>
	<view style="background-color: #000;min-height: 100vh;">
		<!-- <view class="flex" style=" justify-content: space-between; text-align: center;padding: 30px 0px;">
			<view class="flex-1" @click="showContent(index)" v-for="(item,index) in top_list">
				<view :style="selectedContent==index?'color:#fff;':'color:#77767b;'">{{item}}</view>
				<view style="border-bottom: 3px #fff solid;margin-top: 5px;width: 60%;margin-left: 20%;"
					v-if="selectedContent == index"></view>
			</view>

		</view> -->
		<view class="bold color-white font-size-19 padding-30 text-center">{{$lang.GUPIAO}}</view>
		<view style="border-top: 1px #77767b solid; margin-top: -30px;"></view>

		<view>
			<view class="flex padding-10 flex-b" style="color: #77767b;margin-top: 25px;">
				<view class="flex-2">{{$lang.MINGCHEN}}</view>
				<view class="flex-2 text-center">
					{{$lang.ZUIXIN_JIA}}
				</view>
				<view class="flex-1 text-right">{{$lang.ZAHNGDIE_FU}}</view>
			</view>
			<view v-for="(item,index) in list">
				<view class="flex" style="justify-content: space-between;padding: 10px;" @tap="linkDetail(item)">
					<view class="flex flex-2 gap10">
						<view class="flex justify-center align-center" v-if="selectedContent==1">
							<image :src="item.logo" mode="widthFix" style="width: 28px;height: 28px;"
								:class="selectedContent==1?'bg-white radius50':''"></image>
						</view>
						<view>
							<view style="color: #fff;">{{item.name}}</view>
							<view style="color: #77767b;font-size: 9px;">{{item.ct_name}}</view>
						</view>
					</view>

					<view class="flex-2 text-center">
						<view style="color: #fff;">{{item.current_price}}</view>
						<view style="color: #77767b;font-size: 10px;">P{{item.rate_num}}</view>
					</view>
					<view class="flex-1 text-right" :style="$util.setStockRiseFall(item.rate>0)">{{item.rate}}%</view>
				</view>
				<view style="border-top: 1px #77767b solid; ">.</view>
			</view>
			<view style="height: 100px;"></view>
		</view>



	</view>
</template>

<script>
	export default {
		data() {
			return {
				selectedContent: 0,
				list: [],
				top_list: [this.$lang.GUPIAO, this.$lang.HUOBI]
			};
		},
		onShow() {
			this.getList()
		},
		onLoad(opt) {
			this.selectedContent = opt.tag || this.selectedContent;
		},
		methods: {
			linkDetail(val) {
				if (this.selectedContent == 0) {
					uni.navigateTo({
						url: this.$paths.STOCK_OVERVIEW + `?code=${val.locate}`
					})
				} else {
					uni.navigateTo({
						url: this.$paths.COIN_DETAIL + `?code=${val.locate}`
					})
				}
			},

			async getList() {
				uni.showToast({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});

				const result = await this.$http.post(`api/goods/list`, {
					gp_index: this.selectedContent == 0 ? 6 : 1
				});
				console.log(result);
				if (!result) return false;
				this.list = result;
				console.log(this.list);
				// 启动 websocket链接
				this.connect();
				this.connect1();
			},

			showContent(content) {
				this.selectedContent = content;
				this.getList()
			},
			connect() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_COIN_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
					fail: (res) => {
						console.log('fail', res);
					}
				})
				console.log('ws', this.socket);
				// 监听WebSocket连接打开事件
				this.socket.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				// 接收websocket消息及处理
				this.socket.onMessage((res) => {
					const data = JSON.parse(res.data);
					// console.log(data);
					// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
					if (this.list[data.market] && data.market && data.lastPrice > 0 && data.type == 'ticker') {
						this.list[data.market].current_price = data.lastPrice;
						this.list[data.market].rate = data.rate || 0;
						this.list[data.market].rate_num = data.rate_num || 0;
					}
				});
			},
			connect1() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_Zonghe_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.log('成功', res);
					},
					fail: (res) => {
						console.log('fail', res);
					}
				})
				console.log('ws', this.socket);
				// 监听WebSocket连接打开事件
				this.socket.onOpen((res) => {
					console.info("监听WebSocket连接打开事件", res)
				});

				// 监听WebSocket错误
				uni.onSocketError((res) => {
					console.info("监听WebSocket错误" + res)
				});
				// 接收websocket消息及处理
				this.socket.onMessage((res) => {
					const data = JSON.parse(res.data);
					// console.log(data);
					// check websocket返回的数据，能够在list中找到。ws价格>0，更新数据。
					if (this.list[data.pid] && data.pid && data.last > 0) {
						this.list[data.pid].current_price = data.last;
						this.list[data.pid].rate = data.pcp || 0;
						this.list[data.pid].rate_num = data.pc || 0;
						// this.list[data.market].vol = data.vol || 0;
					}
				});
			},
		},
	};
</script>