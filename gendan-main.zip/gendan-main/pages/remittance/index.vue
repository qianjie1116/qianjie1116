<template>
	<view style="background-color: #FFFFFF;min-height: 100vh;">

		<view style="background-image: linear-gradient(180deg, #00aa99, transparent);">
			<HeaderSecond :title="$lang.REMITTANCE_TITLE"></HeaderSecond>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
	}
</script>

<style>
</style>