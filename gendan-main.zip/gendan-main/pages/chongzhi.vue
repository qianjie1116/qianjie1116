<template>
	<view>
		<view class="flex padding-20">
			<view @click="chongzhi()">
				<image src="/static/zuojiantou.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="bold color-white font-size-18 flex-1 text-center">{{$lang.CHONGZHI}}</view>
		</view>
		
		<!-- <view class="text-center" style="color: #fff;font-size: 23px;padding: 30px;">{{$lang.CHONGZHI_KEFU}}</view>
		
		<view style="padding: 50px;" @click="kefu()">
			<view class="text-center" style="background-color:#fff ;padding: 10px;font-size: 20px;border-radius: 30px;">{{$lang.LIANXI_KEFU}}</view> -->
			
			<view class="color-white">通道1</view>
			<view class="color-white">USDT-ERC20</view>
		</view>
		
	</view>
</template>

<script>
	
	export default {
		components: {
			
		},
		data() {
			return {
			
			};
		},
		onLoad() {
			
		},
		methods: {
			chongzhi(){
				uni.navigateBack({
					delta:1,
				})
			},
			kefu(){
				uni.navigateTo({
					url:'/pages/service'
				})
			},
		},
	}
</script>
<style>
</style>