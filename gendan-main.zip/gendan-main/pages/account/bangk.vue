<template>
	<view style="background-color: #000;min-height: 100vh;">
		<view >
			<!-- <HeaderSecond :title="$lang.PAGE_TITLE_DE"></HeaderSecond> -->
			<view class="flex padding-20">
				<view @click="chongzhi()">
					<image src="/static/zuojiantou.png" mode="widthFix" style="width: 10px;"></image>
				</view>
				<view class="bold color-white font-size-18 flex-1 text-center">{{$lang.PAGE_TITLE_DE}}</view>
			</view>
		</view>

		<view class="padding-20 radius20" style="margin: 20px;" v-for="(item,index) in cardManagement">
			<view class="flex">
				<image :src="'/static/'+item.huobi+'.png'" mode="widthFix" style="width: 60px;height: 60px;"></image>
				<view class="margin-left-20">
					<view class="bold font-size-18 color-white">{{item.huobi}}</view>
					<view style="color: #999999;margin-top: 10px;">{{item.address}}</view>
				</view>
			</view>
		</view>
		<view class="access_btn" style="margin:20px auto; width: 90%;" @tap='renewal()'>Add Account</view>
		<view style="height: 50px;"></view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				cardManagement: [],
			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: this.$paths.HOME
				});
			},
			chongzhi() {
				uni.switchTab({
					url:'/pages/Introduction/personaldata'
				})
			},
			renewal() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_BING_BANK_ADD
				});
			},
			async gaint_info() {
				const result = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				console.log(result);
				if (result  && result.bank_card_info) {
					this.cardManagement = result.bank_card_info
					console.log(88888,this.cardManagement );

				}
			},
		},
		onLoad(option) {
			this.gaint_info()
		},
	}
</script>

<style lang="scss">
	uni-view,
	uni-text {
		box-sizing: border-box;
	}

	.page {
		background: #f8f8f8;
		min-height: 100vh;
	}

	.top-pad {
		padding-top: 50px;
	}

	.header {
		height: 50px;
		background: #fff;
		padding: 0 15px;
		width: 100vw;
		position: fixed;
		top: 0;
		left: 0;
		z-index: 999;

		.header-center {
			font-size: 18px;
			font-weight: 700;
			color: #333;
			text-align: center;
		}

		.header-right {
			width: 9px;
			height: 16px;
		}

		.header-left {
			width: 24px;
			height: 24px;
		}
	}

	.card {
		margin: 15px 15px 0 15px;
		padding: 15px;
		background: -webkit-linear-gradient(315deg, #1c4199, #40a2db);
		background: linear-gradient(135deg, #1c4199, #40a2db);
		border-radius: 6px;

		.card-top {
			color: #fff;
		}

		.card-num {
			font-size: 18px;
			font-weight: 700;
			color: #fff;
			margin-top: 15px;
		}
	}

	.pad {
		padding: 40px 15px;
	}

	.b-btn {
		width: 100%;
		height: 44px;
		line-height: 44px;
		background: #1c4199;
		border-radius: 22px;
		text-align: center;
		font-size: 16px;
		font-weight: 500;
		color: #FFFFFF;
		margin: 15px 0;
	}
</style>