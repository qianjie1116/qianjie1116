<template>
	<view :style="$theme.setBGSize(`480rpx`)">
		<HeaderSecond :title="$lang.ACCOUNT_LEVEL_TITLE" color="#FFFFFF"></HeaderSecond>

		<template v-if="!this.info || !this.info.userinfo">
			<EmptyData></EmptyData>
		</template>
		<template v-else>
			<view class="common_block" style="padding:30rpx 40rpx;">
				<view style="display: flex;align-items: center;">
					<view style="color:#666666;">{{$lang.LEVEL_CURRENT_LEVEL}}</view>
					<view style="padding-left: 20rpx;" @click="linkDesc()">
						<image src="/static/level_desc.png" mode="aspectFit" :style="$theme.setImageSize(30)">
						</image>
					</view>
					<view style="margin-left: auto;">
					 	<image :src="`/static/level${setInfo.curLevel}.png`" mode="aspectFit"
							style="width: 200rpx;height: 60rpx;">
						</image>
					</view>
				</view>
				<view style="display: flex;align-items: center;">
					<view style="color:#666666;">{{$lang.LEVEL_CURRENT_TEAM}}</view>
					<view style="margin-left: auto;padding-right: 20rpx;">
						<view style="display: flex;align-items: center;justify-content: flex-end;">
							<text style="font-weight: 700;font-size: 15px;color: #333333;padding-right: 10rpx;">
								{{setInfo.teamNum}} People</text>
							<view class="arrow rotate_45" style="border-color: #999999;"
								:style="$theme.setImageSize(10)">
							</view>
						</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;line-height: 2.8;">
					<view style="color:#121212;font-size: 32rpx;">{{$lang.LEVEL_NEXT_LEVEL}}</view>
				</view>
				<view style="display: flex;align-items: center;line-height: 1.8;">
					<view style="color:#666666;">{{$lang.LEVEL_SELF_HOLD_MONEY+` > `+setInfo.holdMoney}}</view>
					<view style="margin-left: auto;">
						<view style="display: flex;align-items: center;justify-content: flex-end;">
							<text style="font-weight: 700;font-size: 15px;color: #333333;padding-right: 10rpx;">
								{{setInfo.curHoldMoney}}</text>
							<image :src="`/static/level_${setInfo.holdMoneyPass?'ok':'info'}.png`" mode="aspectFit"
								:style="$theme.setImageSize(28)"></image>
						</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;line-height: 1.8;">
					<view style="color:#666666;">{{$lang.LEVEL_L1_TEAM_USERS+` > `+setInfo.l1TeamNum}}</view>
					<view style="margin-left: auto;">
						<view style="display: flex;align-items: center;justify-content: flex-end;">
							<text style="font-weight: 700;font-size: 15px;color: #333333;padding-right: 10rpx;">
								{{setInfo.curL1TeanNum}}</text>
							<image :src="`/static/level_${setInfo.l1Pass?'ok':'info'}.png`" mode="aspectFit"
								:style="$theme.setImageSize(28)"></image>
						</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;line-height: 1.8;">
					<view style="color:#666666;">
						{{$lang.LEVEL_L1_TEAM_MONEY+` > `+setInfo.l1Money}}
					</view>
					<view style="margin-left: auto;">
						<view style="display: flex;align-items: center;justify-content: flex-end;">
							<text style="font-weight: 700;font-size: 15px;color: #333333;padding-right: 10rpx;">
								{{setInfo.curL1Money}}</text>
							<image :src="`/static/level_${setInfo.l1PassMoney?'ok':'info'}.png`" mode="aspectFit"
								:style="$theme.setImageSize(28)"></image>
						</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;line-height: 1.8;">
					<view style="color:#666666;">
						{{$lang.LEVEL_L2_TEAM_USERS+` > `+setInfo.l2TeamNum}}
					</view>
					<view style="margin-left: auto;">
						<view style="display: flex;align-items: center;justify-content: flex-end;">
							<text style="font-weight: 700;font-size: 15px;color: #333333;padding-right: 10rpx;">
								{{setInfo.curL2TeanNum}}</text>
							<image :src="`/static/level_${setInfo.l2Pass?'ok':'info'}.png`" mode="aspectFit"
								:style="$theme.setImageSize(28)"></image>
						</view>
					</view>
				</view>
				<!-- <view style="display: flex;align-items: center;line-height: 1.8;">
					<view style="color:#666666;">
						{{$lang.LEVEL_L2_TEAM_MONEY+` > `+setInfo.l2Money}}
					</view>
					<view style="margin-left: auto;">
						<view style="display: flex;align-items: center;justify-content: flex-end;">
							<text style="font-weight: 700;font-size: 15px;color: #333333;padding-right: 10rpx;">
								{{setInfo.curL2Money}}</text>
							<image :src="`/static/level_${setInfo.l2Pass?'ok':'info'}.png`" mode="aspectFit"
								:style="$theme.setImageSize(28)"></image>
						</view>
					</view>
				</view> -->
			</view>

			<TabsFourth :tabs="tabs" color="#FFF" @action="changeTab" :acitve="curTab"></TabsFourth>


			<view class="common_block" style="padding:0;border-radius: 16rpx;min-height: 48vh;">
				<view
					style="display: flex;align-items: center;justify-content: space-between;color:#666666;background-color: #F3F3F3;padding:20rpx;line-height: 2.4;;border-radius: 16rpx 16rpx 0 0;">
					<view>{{$lang.LEVEL_TEAM_LIST_HEAD_MOBILE}}</view>
					<view>{{$lang.LEVEL_TEAM_LIST_HEAD_AMOUNT}}</view>
				</view>
				<template v-if="!list ||list.length<=0">
					<EmptyData></EmptyData>
				</template>
				<template v-else>
					<block v-for="(item,index) in list" :key="index">
						<view style="border-bottom: 1px solid #DBDBDB;padding:20rpx;">
							<view style="display: flex;align-items: center;justify-content: space-between;">
								<view>{{item.mobile}}</view>
								<view>{{$util.formatCoin(item.total_price)}}</view>
							</view>
						</view>
					</block>
				</template>
			</view>
		</template>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import TabsFourth from '@/components/tabs/TabsFourth.vue';
	export default {
		components: {
			HeaderSecond,
			EmptyData,
			TabsFourth,
		},
		data() {
			return {
				info: {}, // 等级信息
				list: [], // 团队列表
				curTab: 0,
			}
		},
		computed: {
			// 团队tab
			tabs() {
				return [this.$lang.LEVEL_L1_TEAM, this.$lang.LEVEL_L2_TEAM]
			},

			// check 并格式化渲染数据
			setInfo() {
				if (this.info && this.info.userinfo) {
					console.log(this.info, this.info.userinfo);
					return {
						teamNum: this.info.team_num, // 团队人数
						// level_mx 后端直接返回是否达标结果
						l1Pass: this.info.level_mx.if_l1, // L1团队人数是否达标
						l1PassMoney: this.info.level_mx.if_l1_licai_money, // L1理财金额是否达标
						l2Pass: this.info.level_mx.if_l2, // L2团队人数是否达标						
						holdMoneyPass: this.info.level_mx.if_licai_money, // 自身持有金额是否达标
						// 距 下一等级
						// 自身持有金额(目标)
						holdMoney: this.$util.formatMoney(this.info.level_mx.level_up_info.licai_money, 0),
						l1TeamNum: this.info.level_mx.level_up_info.l1, // L1 团队人数(目标)
						// L1 理财金额(目标)
						l1Money: this.$util.formatMoney(this.info.level_mx.level_up_info.l1_licai_money, 0),
						l2TeamNum: this.info.level_mx.level_up_info.l2, // L2 团队人数(目标)
						// L2 理财金额(目标)
						l2Money: this.$util.formatMoney(this.info.level_mx.level_up_info.l2_licai_money, 0),
						// 用户的当前等级数据
						// 当前自身持有金额
						curHoldMoney: this.$util.formatMoney(this.info.level_mx.licai_money, 0),
						curL1TeanNum: this.info.level_mx.l1, // 当前L1团队人数
						// 当前L1团队总金额
						curL1Money: this.$util.formatMoney(this.info.level_mx.l1_licai_money, 0),
						curL2TeanNum: this.info.level_mx.l2, // 当前L2团队人数
						// 当前L2团队总金额					
						curL2Money: this.$util.formatMoney(this.info.level_mx.l2_licai_money, 0),
						curLevel: this.info.userinfo.level, // 用户的当前等级
					}
				}
			}
		},
		onShow() {
			this.getLevelInfo();
			this.getTeamList();
		},
		//下拉刷新
		onPullDownRefresh() {
			this.getLevelInfo();
			this.getTeamList();
			uni.stopPullDownRefresh();
		},
		methods: {
			// tab切换
			changeTab(val) {
				console.log(val)
				this.curTab = val;
				this.getTeamList();
			},
			linkDesc() {
				uni.navigateTo({
					url: this.$paths.LEVEL_DESC
				})
			},
			//用户信息
			async getLevelInfo() {
				const result = await this.$http.get(`api/user/tuandui`);
				console.log('info result：', result);
				if (!result) return false;
				this.info = result;
			},
			// 团队列表
			async getTeamList() {
				const result = await this.$http.get(`api/user/l${this.curTab+1}`);
				console.log(result);
				if (!result) return false;
				this.list = result;
			},
		}
	}
</script>