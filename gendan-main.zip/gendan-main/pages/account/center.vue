<template>
	<view style="background-color: #000;min-height: 100vh;">
		<view style="background-color: #10193d;">
			<view class="flex">
				<view class="flex-1">
					<HeaderPrimary :title="$lang.TABBAR_HOME"></HeaderPrimary>
				</view>
				<view style="margin-right: 20px;margin-top: 10px;">
					<Translate></Translate>
				</view>
				
			</view>
			<!-- <view style="margin-left: auto;">
				<Translate></Translate>
			</view> -->

			<Profile :info="userInfo"></Profile>

			<!-- <view style="padding: 10px 0px;position: relative;" @click="Promotion()">
				<image src="/static/wode.png" mode="widthFix" style="width: 95%;margin-left: 10px;"></image>
				<image src="/static/xing.png" mode="widthFix"
					style="width: 58%;position: absolute;bottom: 45%;left: 30px; "></image>
				<image src="/static/zuanshi.png" mode="widthFix"
					style="width: 15px;position: absolute;bottom: 60%;left:100px; "></image>
				<view class="flex"
					style="color: #fff;position: absolute;bottom: 13%;left: 13px; background-color: #16516B;width: 88%;padding: 10px;border-radius: 20px;">
					<view class="flex-1" style="font-size: 10px;">距离下一等级还需要邀请4人</view>
					<view style="font-size: 10px;color: #15a4a5;">前往查看</view>
					<image src="/static/baijiantou.png" mode="widthFix" style="width: 6px;margin-left: 10px;"></image>
				</view>
			</view> -->
		</view>

		<view class="flex" style=" justify-content: space-between; text-align: center;width: 98%;margin-top: 15px;">
			<view class="flex-1 text-center" @click="showContent(1)">
				<view :style="selectedContent==1?'color:#fff;':'color:#77767b;'">{{$lang.ZONGZI_CHAN}}</view>
				<view style="border-bottom: 3px #fff solid;width: 60%;margin-top: 5px;margin-left: 20%;"
					v-if="selectedContent == 1"></view>
			</view>
			<!-- <view class="flex-1" @click="showContent(2)">
				<view :style="selectedContent==2?'color:#fff;':'color:#77767b;'">{{$lang.FOF}}</view>
				<view style="border-bottom: 3px #fff solid;width: 60%;margin-top: 5px;margin-left: 20%;"
					v-if="selectedContent === 2"></view>
			</view> -->
			<view class="flex-1 text-center" @click="showContent(3)">
				<view :style="selectedContent==3?'color:#fff;':'color:#77767b;'">{{$lang.JIAOYI}}</view>
				<view style="border-bottom: 3px #fff solid;width: 60%;margin-top: 5px;margin-left: 20%;"
					v-if="selectedContent ==3"></view>
			</view>
			<view class="flex-1 text-center" @click="showContent(4)">
				<view :style="selectedContent==4?'color:#fff;':'color:#77767b;'">{{$lang.LICAI_CHICANG}}</view>
				<view style="border-bottom: 3px #fff solid;width: 60%;margin-top: 5px;margin-left: 20%;"
					v-if="selectedContent ==4"></view>
			</view>
			<view class="flex-1" @click="showContent(5)">
				<view :style="selectedContent==5?'color:#fff;':'color:#77767b;'">{{$lang.ZIJIN}}</view>
				<view style="border-bottom: 3px #fff solid;width: 60%;margin-top: 5px;margin-left: 20%;"
					v-if="selectedContent ==5"></view>
			</view>
			<!-- 	<view class="flex-1"  @click="showContent('content6')" >
				<view  :style="selectedContent=='content6'?'color:#fff;':'color:#77767b;'" >社交</view>
				<view style="border-bottom: 3px #fff solid;width: 60%;margin-top: 5px;margin-left: 20%;"
					v-if="selectedContent === 'content6'"></view>
			</view> -->
		</view>

		<!-- 总资产 -->
		<view v-if="selectedContent ==1">
			<view>
				<view class="flex"
					style="padding:0px 15px; justify-content: space-between;margin-top: 20px;width: 90%;color: #77767b;">
					<view class="flex">
						<view>{{$lang.DANGQIAN_GUZHI}}(GBX)</view>
						<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`"
							@click="handleShowAmount" :style="$theme.setImageSize(40)" style="padding-left: 20rpx;">
						</image>
					</view>
					<view style="color:#15a1a2;border-radius: 12rpx;padding:6rpx 12rpx;font-size: 20rpx;"
						@click="linkTradRecord()">
						{{$lang.JILV}}
					</view>
				</view>

				<template v-if="showAmount">
					<view class="flex">
						<view style="color:#fff;padding:0px 40rpx;display: flex;align-items: center; margin-top: 10px;">
							<view style="font-size: 48rpx;font-weight: 500;">{{$util.formatMoney(info.GBX_money)}}
							</view>
							<view class="margin-left-10">GBX</view>
						</view>
					</view>

				</template>
				<template v-else>
					<view style="color:#77767b;padding:0px 40rpx;margin-top: 10px;font-size: 25px;">{{hideAmount}}
					</view>
				</template>
				<!-- <view style="color: #222;padding-left: 40rpx;font-size: 28rpx;padding-top: 20rpx;">
				{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}
			</view> -->
				<!-- <template v-if="showAmount">
					<view style="color:#77767b;padding:0 40rpx;display: flex;align-items: center;">
						<view style="font-size: 30rpx;font-weight: 500;">= {{$util.formatMoney()}}
						</view>
						<view style="padding-left: 15rpx;">USDT</view>
					</view>
				</template>
				<template v-else>
					<view style="color:#77767b;padding:0px 40rpx;font-size: 25px;">{{hideAmount}} </view>
				</template> -->
			</view>

			<!-- <view class="flex" style="padding: 10px 20px;">
				<view style="color: #77767b;">{{$lang.ZUORI_SHOUYI}}</view>
				<view style="color: #15d6d6;margin-left: 10px;">{{info.zuorishouyi}}55</view>
				<view style="color: #15d6d6;">+64.23%</view>
			</view> -->

			<view class="flex text-center" style="justify-content: space-between;width: 85%;padding: 10px 30px;">
				<view style="background-color: #ff6357;padding: 10px 45px;border-radius: 30px;color: #fff;"
					@click="linkWithdraw()">{{$lang.PAGE_TITLE_WITHDRAW}}</view>
				<view style="background-color: #16e2e2;padding: 10px 45px;border-radius: 30px;color: #fff;"
					@click="linkDeposit()">{{$lang.PAGE_TITLE_DEPOSIT}}</view>
			</view>

			<view style="border-bottom: 1px #272729 solid; ">.</view>

			<!-- <view style="padding: 15px;">
				<view class="flex">
					<view style="border-left: #fff 3px solid;color: ;height: 15px;"></view>
					<view style="margin-left: 5px;color: #fff; ">{{$lang.ZHANGHU_XIANGQING}}</view>
				</view>
				<view class="flex" style="justify-content: space-between;">
					<view
						style="background-color: #153e3f; color: #15a2a2;padding: 3px 10px;border-radius: 5px;font-size: 13px;">
						{{$lang.FOF}}</view>
					<view>
						<view style="font-size: 15px;color: #fff;">62374.94 USDT</view>
						<view style="font-size: 12px;margin-left: 10px;color: #77767b;">= 62374.94 USDT</view>
					</view>
				</view>
				<view class="flex" style="margin-top: 20px;justify-content: space-between;">
					<view>
						<view style="color: #77767b;">{{$lang.TOUZI_SHOUYI}}</view>
						<view style="color: #15a4a5;">23L4.54</view>
					</view>
					<view>
						<view style="color: #77767b;">一级收益</view>
						<view style="color: #15a4a5;">1234.23</view>
					</view>
					<view style="color: #77767b;">
						<view>二级收益</view>
						<view style="color: #15a4a5;">4234.14</view>
					</view>
				</view>
				<view style="border-bottom: 1px #272729 solid; ">.</view>
			</view> -->

			<!-- <view style="padding: 15px;border-bottom: 1px #272729 solid;">
				<view class="flex" style="justify-content: space-between;">
					<view
						style="background-color: #153e3f; color: #15a2a2;padding: 3px 10px;border-radius: 5px;font-size: 13px;">
						{{$lang.JIAOYI_ZHANGHU}}
					</view>
					<view>
						<view style="font-size: 15px;color: #fff;">{{info.jiaoyizhanghu}} USDT</view>
						<view style="font-size: 12px;margin-left: 10px;color: #77767b;">= {{info.jiaoyizhanghu}} USDT
						</view>
					</view>
				</view>
				<view class="flex" style="margin-top: 20px;justify-content: space-between;">
					<view>
						<view style="color: #77767b;">{{$lang.JINRI_BIANDONG}}</view>
						<view style="color: #15a4a5;">{{info.jiaoyibiandong}}</view>
					</view>

					<view>
						<view style="color: #77767b;">{{$lang.BIANDONG_LV}}</view>
						<view style="color: #15a4a5;">{{info.jiaoyilv}}</view>
					</view>
				</view> -->
				<!-- <view style="border-bottom: 1px #272729 solid; ">.</view> -->
			<!-- </view> -->

			<!-- <view style="padding: 15px;border-bottom: 1px #272729 solid;">
				<view class="flex" style="justify-content: space-between;">
					<view
						style="background-color: #153e3f; color: #15a2a2;padding: 3px 10px;border-radius: 5px;font-size: 13px;">
						{{$lang.GENDAN}}
					</view>
					<view>
						<view style="font-size: 15px;color: #fff;">{{info.gentouzhanghu}} USDT</view>
						<view style="font-size: 12px;margin-left: 10px;color: #77767b;">= {{info.gentouzhanghu}} USDT
						</view>
					</view>
				</view>
				<view class="flex" style="margin-top: 20px;justify-content: space-between;">
					<view>
						<view style="color: #77767b;">{{$lang.JINRI_YINGKUI}}</view>
						<view style="color: #bd4b44;">{{info.gentoubiandong}}</view>
					</view>

					<view>
						<view style="color: #77767b;">{{$lang.JINRI_YINGKUILV}}</view>
						<view style="color: #bd4b44;">{{info.gentoulv}}</view>
					</view>
				</view>
				<view style="border-bottom: 1px #272729 solid; ">.</view>
			</view> -->

			<view style="padding: 15px;border-bottom: 1px #272729 solid;">
				<view class="flex" style="justify-content: space-between;">
					<view
						style="background-color: #153e3f; color: #15a2a2;padding: 3px 10px;border-radius: 5px;font-size: 13px;">
						{{$lang.ZIJIN_ZHANGHU}}
					</view>
					<view>
						<view style="font-size: 15px;color: #fff;">{{info.zijinzhanghu}} USDT</view>
						<view style="font-size: 12px;margin-left: 10px;color: #77767b;">= {{info.zijinzhanghu}} USDT
						</view>
					</view>
				</view>
				<view class="flex" style="margin-top: 20px;justify-content: space-between;">
					<view>
						<view style="color: #77767b;">{{$lang.JINRI_BIANDONG}}</view>
						<view style="color: #bd4b44;">{{info.zijinbiandong}}</view>
					</view>

					<view>
						<view style="color: #77767b;">{{$lang.JINRI_YINGKUILV}}</view>
						<view style="color: #bd4b44;">{{info.zijinlv}}</view>
					</view>
				</view>
				<!-- <view style="border-bottom: 1px #272729 solid; ">.</view> -->
			</view>

			<!-- GBP -->
			<view style="padding: 15px;border-bottom: 1px #272729 solid;">
				<view class="flex" style="justify-content: space-between;">
					<view
						style="background-color: #153e3f; color: #15a2a2;padding: 3px 10px;border-radius: 5px;font-size: 13px;">
						{{$lang.GBP_ACCOUNT}}
					</view>
					<view>
						<view style="font-size: 15px;color: #fff;">{{info.GBX_money}} GBX</view>
						<view style="font-size: 12px;margin-left: 10px;color: #77767b;">=
							{{$util.formatNumber(info.GBX_money*gbpToUST,4)}} USDT
						</view>
					</view>
				</view>
				<view style="display: flex;align-items: center;justify-content: space-around;padding-top: 24rpx;">
					<view
						style="background-color: #ff6357;padding:12rpx;border-radius: 44rpx;color: #fff;text-align: center;width: 36%;"
						@click="huazhuan()">{{$lang.HUAZHUAN}}</view>
					<view
						style="background-color: #16e2e2;padding:12rpx;border-radius: 44rpx;color: #fff;text-align: center;width: 36%;"
						@click="linkDeposit()">{{$lang.PAGE_TITLE_DEPOSIT}}</view>
				</view>
			</view>

			<!-- <view style="padding: 15px;">
				<view class="flex" style="justify-content: space-between;">
					<view
						style="background-color: #153e3f; color: #15a2a2;padding: 3px 10px;border-radius: 5px;font-size: 13px;">
						社交账户</view>
					<view>
						<view style="font-size: 15px;color: #fff;">62374.94 USDT</view>
						<view style="font-size: 12px;margin-left: 10px;color: #77767b;">= 62374.94 USDT</view>
					</view>
				</view>
				<view class="flex" style="margin-top: 20px;justify-content: space-between;">
					<view>
						<view style="color: #77767b;">今日变动</view>
						<view style="color: #15a4a5;">2135.54</view>
					</view>

					<view>
						<view style="color: #77767b;">今日变动</view>
						<view style="color: #15a4a5;">53.14%</view>
					</view>
				</view>
				<view style="border-bottom: 1px #272729 solid; ">.</view>
			</view> -->
			<!-- <view style="padding:0 10px;">
			<CustomTitle :title="$lang.ACCOUNT_MORE_FEATURES"></CustomTitle>
		</view>

		<NavList :code="userInfo.code"> </NavList> -->

			<!-- <view class="access_btn" style="margin:20px auto; width: 90%;" @click="handleSignOut()">
				{{$lang.SIMGN_OUT}}
			</view> -->
		</view>

		<!-- FOF账单 -->
		<view v-if="selectedContent ==2">
			<view class="flex" style="padding: 15px;">
				<view style="border-left: #fff 3px solid;color: ;height: 15px;"></view>
				<view style="margin-left: 5px;color: #fff; ">{{$lang.ZICHAN_MINGXI}}</view>
			</view>
			<block v-for="(item,index) in order">
				<view class="flex" style="padding: 0px 15px;">
					<!-- <image src="/static/top7.png" mode="widthFix" style="width: 30px;"></image> -->
					<view>
						<view style="color: #fff;">{{item.goods.name}}</view>
						<!-- <view style="color: #706f74;">Scientific FINFfd fsjdff fsjd</view> -->
					</view>
				</view>
				<view class="flex" style=" justify-content: space-between;width: 95%;padding: 5px 10px;">
					<view>
						<view style="color: #706f74;">{{$lang.YUNXING_SHIJIAN}}</view>
						<view style="color: #fff;">{{item.goods.days}} Days</view>
					</view>
					<view>
						<view style="color: #706f74;">{{$lang.DANGQIAN_GENTOUJINE}}</view>
						<view style="color: #fff;text-align: right;">{{item.goods.amount}} K</view>
					</view>
				</view>
				<view class="flex" style=" justify-content: space-between;width: 95%;padding: 5px 10px;">
					<view>
						<view style="color: #706f74;">{{$lang.PINGJUN_MEIRISHOUYI}}</view>
						<view style="color: #fff;">{{item.goods.syl}}</view>
					</view>
					<view>
						<view style="color: #706f74;">{{$lang.DANGQIAN_GENTOURENSHU}}</view>
						<view style="color: #fff;text-align: right;">{{item.goods.people}} M</view>
					</view>
				</view>
				<view class="flex" style=" justify-content: space-between;width: 95%;padding: 5px 10px;">
					<view>
						<view style="color: #706f74;">{{$lang.TOUZI_JINE}}</view>
						<view style="color: #14a5a6;">{{item.goods.amount}} USD</view>
					</view>
					<view>
						<view style="color: #706f74;text-align: right;">{{$lang.LEIJI_SHOUYI}}</view>
						<view style="color: #14a5a6;text-align: right;">{{item.goods.shouyi}} USD</view>
					</view>
				</view>
				<view class="flex" style=" justify-content: space-between;width: 95%;padding: 5px 10px;">
					<view>
						<view style="color: #706f74;">{{$lang.QISHI_SHIJIAN}}</view>
						<view style="color: #fff;">{{item.cretime}}</view>
					</view>
					<view>
						<view style="color: #706f74;text-align: right;">{{$lang.JIEZHI_RIQI}}</view>
						<view style="color: #fff;text-align: right;">{{item.endtime}}</view>
					</view>
				</view>
				<view style="border-top: 1px #272729 solid; ">.</view>
			</block>
		</view>

		<!-- 交易账户 -->
		<view v-if="selectedContent == 3">
			<view class="flex"
				style="padding:0px 15px;justify-content: space-between;margin-top: 20px;width: 90%;color: #77767b;">
				<view class="flex">
					<view>{{$lang.DANGQIAN_GUZHI}}(USDT)</view>
					<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
						:style="$theme.setImageSize(40)" style="padding-left: 20rpx;">
					</image>
				</view>
			</view>
			<template v-if="showAmount">
				<view style="color:#fff;padding:0px 40rpx;display: flex;align-items: center; margin-top: 10px;">
					<view style="font-size: 48rpx;font-weight: 500;">{{$util.formatMoney(info.zijinzhanghu)}}
					</view>
				</view>
			</template>
			<template v-else>
				<view style="color:#77767b;padding:0px 40rpx;margin-top: 10px;font-size: 25px;">{{hideAmount}} </view>
			</template>
			<!-- <view style="color: #222;padding-left: 40rpx;font-size: 28rpx;padding-top: 20rpx;">
					{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}
				</view> -->
			<template v-if="showAmount">
				<view style="color:#77767b;padding:0 40rpx;display: flex;align-items: center;">
					<view style="font-size: 30rpx;font-weight: 500;">{{$lang.KEYONG}}
						{{$util.formatMoney(assets.money)}}
					</view>
					<view style="padding-left: 15rpx;">USDT</view>
				</view>
			</template>
			<template v-else>
				<view style="color:#77767b;padding:0px 40rpx;font-size: 25px;">{{hideAmount}} </view>
			</template>
			<view class="flex" style="padding: 10px 20px;justify-content: space-between;width:65%;" v-if="assets">
				<view style="color: #77767b;">{{$lang.ZUORI_SHOUYI}}</view>
				<view style="color: #15d6d6;">{{$util.formatMoney(assets.zuoshou)}}</view>
				<!-- <view style="color: #15d6d6;">{{assets.zuobi}}%</view> -->
			</view>
			<view class="flex" style=" justify-content: space-between;padding: 5px 20px;">
				<view style="background-color: #ffa641;color: #fff;padding: 5px 25px;border-radius: 30px;"
					@click="huazhuan()">{{$lang.HUAZHUAN}}</view>
				<view style="background-color: #ff6357;color: #fff;padding: 5px 25px;border-radius: 30px;"
					@click="linkWithdraw()">{{$lang.TIXIAN}}</view>
				<view style="background-color: #16e2e2;color: #fff;padding: 5px 25px;border-radius: 30px;"
					@click="linkDeposit()">{{$lang.CHONGZHI}}</view>
			</view>
			<view style="border-bottom: 1px #272729 solid; ">.</view>
			<view class="flex" style="padding: 15px;">
				<view style="border-left: #fff 3px solid;color: ;height: 15px;"></view>
				<view style="margin-left: 5px;color: #fff; ">{{$lang.ZICHAN_MINGXI}}</view>
			</view>
			<view style="padding: 0px 20px;margin-top: 10px;" v-for="(item,index) in log_list">
				<view class="flex flex-b" style="">
					<view>
						<view style="color: #fff;">{{item.money}}</view>
					</view>
					<view>
						<!-- <view style="color: #77767b;text-align: right;">手续费</view> -->
						<view style="color: #77767b;">{{item.created_at}}</view>
					</view>
				</view>
				<view style="color: #77767b;" class="margin-top-10">{{item.desc}}</view>
			</view>
			<view style="border-bottom: 1px #272729 solid;margin-top: 10px; "></view>

		</view>

		<!-- 持仓 -->
		<view v-if="selectedContent ==4">
			<view class="flex"
				style="padding:0px 15px;justify-content: space-between;margin-top: 20px;width: 90%;color: #77767b;">
				<view class="flex">
					<view>{{$lang.DANGQIAN_GUZHI}}(GBX)</view>
					<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
						:style="$theme.setImageSize(40)" style="padding-left: 20rpx;">
					</image>
				</view>
			</view>
			<template v-if="showAmount">
				<view style="color:#fff;padding:0px 40rpx;display: flex;align-items: center; margin-top: 10px;">
					<view style="font-size: 48rpx;font-weight: 500;">{{info.GBX_money}} GBX
					</view>
				</view>
			</template>
			<template v-else>
				<view style="color:#77767b;padding:0px 40rpx;margin-top: 10px;font-size: 25px;">{{hideAmount}} </view>
			</template>
			<!-- <view style="color:#77767b;padding-left: 40rpx;font-size: 28rpx;padding-top: 20rpx;">
			 					{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}
			 				</view>
			<template v-if="showAmount">
				<view style="color:#77767b;padding:0 40rpx;display: flex;align-items: center;">
					<view style="font-size: 30rpx;font-weight: 500;">= {{$util.formatMoney(userInfo.money)}}
					</view>
					<view style="padding-left: 15rpx;">USDT</view>
				</view>
			</template> -->
			<!-- <template v-else>
				<view style="color:#77767b;padding:0px 40rpx;font-size: 25px;">{{hideAmount}} </view>
			</template> -->
			<!-- <view class="flex" style="padding: 10px 20px;justify-content: space-between;width:55%;">
				<view style="color: #77767b;">{{$lang.ZUORI_SHOUYI}}</view>
				<view style="color: #15d6d6;">{{$util.formatMoney(info.zuorishouyi)}}</view>
				<view style="color: #15d6d6;">+64.23%</view>
			</view>
			<view class="flex" style="margin-left: 20px;">
				<image src="/static/gantanhao.png" mode="widthFix" style="width: 30px;"></image>
				<view style="color:#77767b;margin-left: 5px;">{{$lang.GENTOU_DAOQI}}</view>
			</view>
			<view style="border-bottom: 1px #272729 solid; ">.</view>
			<view class="flex" style="padding: 15px;">
				<view style="border-left: #fff 3px solid;color: ;height: 15px;"></view>
				<view style="margin-left: 5px;color: #fff; ">{{$lang.ZICHAN_MINGXI}}</view>
			</view> -->

			<TabsFourth :tabs="$lang.TRADE_TABS" color="#FFF" @action="changeTab" :acitve="curTab"></TabsFourth>

			<template v-if="curTab==0">
				<TradeHoldList></TradeHoldList>
			</template>
			<template v-else>
				<TradeSellList></TradeSellList>
			</template>

			<template v-if="isShow">
				<view class="common_mask" @click="isShow=false">
					<view class="common_block common_popup" style="min-height:35vh;margin:auto;padding-bottom: 20px;">
						<view class="popup_header">
							<text :style="{color:$theme.ACCESS_TEXT}"
								style="text-align: center;font-size: 16px;">{{$lang.TRADE_MOADL_TITLE}}</text>
							<image src="/static/close.png" :style="$util.setImageSize(36)" @click="isShow=false"
								style="position: absolute;right: 10px;top:8px;"></image>
						</view>
						<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
							<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[0]}}
							</view>
							<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
								{{info.goods_info.name}}
							</view>
						</view>
						<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
							<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[1]}}
							</view>
							<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
								{{info.order_buy.created_at}}
							</view>
						</view>
						<template v-if="!isHold">
							<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
								<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[2]}}
								</view>
								<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
									{{info.order_sell.created_at}}
								</view>
							</view>
						</template>
						<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
							<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[3]}}
							</view>
							<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
								{{$util.formatNumber(
								isHold?info.order_buy.float_yingkui*1
								:!info.order_sell?0:info.order_sell.float_yingkui*1)}}{{$lang.CURRENCY_UNIT}}
							</view>
						</view>

						<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
							<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[5]}}
							</view>
							<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
								{{$util.formatNumber(isHold?info.order_buy.yingkui*1:!info.order_sell?0:info.order_sell.yingkui*1)}}{{$lang.CURRENCY_UNIT}}
							</view>
						</view>
						<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
							<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[6]}}
							</view>
							<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
								{{$util.formatNumber(info.order_buy.price)}}
							</view>
						</view>

						<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
							<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[7]}}
							</view>
							<view style="flex: 30%;" :style="{color:$theme.TEXT}">
								{{$util.formatNumber(info.order_buy.num)}}
							</view>
							<view style="flex: 20%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[4]}}
							</view>
							<view style="flex: 20%;text-align: right;" :style="{color:$theme.TEXT}">
								{{info.order_buy.double}}
							</view>
						</view>
						<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
							<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[8]}}
							</view>
							<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
								{{$util.formatNumber(isHold?info.order_buy.buy_fee:!info.order_sell?0:info.order_sell.sell_fee)}}
							</view>
						</view>
						<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
							<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[9]}}
							</view>
							<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
								{{$util.formatNumber(info.order_buy.amount)}}{{$lang.CURRENCY_UNIT}}
							</view>
						</view>
						<view class="line" style="display: flex;align-items: center;padding:6px;margin:0 10px;">
							<view style="flex: 30%;" :style="{color:$theme.TIP}">{{$lang.TRADE_MODAL_LABELS[10]}}
							</view>
							<view style="flex: 70%;text-align: right;" :style="{color:$theme.TEXT}">
								{{info.goods_info.number_code}}
							</view>
						</view>

						<view style="display: flex;align-items: center;justify-content: space-around;padding-top: 20px;"
							v-if="isHold">
							<view class="trade_modal_btn" style="background-color: #FF6700;"
								@tap="handleStockDetail(info.goods_info.number_code)">
								{{$lang.BTN_DETAIL}}
							</view>
							<view class="trade_modal_btn" style="background-color:#00aa99;" @tap="handleSell(info.id)">
								{{$lang.BTN_SELL}}
							</view>
						</view>
					</view>
				</view>
			</template>

			<block v-for="(item,index) in orderlist">

			</block>
		</view>


		<!-- 跟投 -->
		<!-- <view v-if="selectedContent ==4">
			<view class="flex"
				style="padding:0px 15px;justify-content: space-between;margin-top: 20px;width: 90%;color: #77767b;">
				<view class="flex">
					<view>{{$lang.DANGQIAN_GUZHI}}(USDT)</view>
					<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
						:style="$theme.setImageSize(40)" style="padding-left: 20rpx;">
					</image>
				</view>
			</view>
			<template v-if="showAmount">
				<view style="color:#fff;padding:0px 40rpx;display: flex;align-items: center; margin-top: 10px;">
					<view style="font-size: 48rpx;font-weight: 500;">{{$util.formatMoney(userInfo.totalZichan)}}
					</view>
				</view>
			</template>
			<template v-else>
				<view style="color:#77767b;padding:0px 40rpx;margin-top: 10px;font-size: 25px;">{{hideAmount}} </view>
			</template>
			<view style="color: #222;padding-left: 40rpx;font-size: 28rpx;padding-top: 20rpx;">
			 					{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}
			 				</view>
			<template v-if="showAmount">
				<view style="color:#77767b;padding:0 40rpx;display: flex;align-items: center;">
					<view style="font-size: 30rpx;font-weight: 500;">= {{$util.formatMoney(userInfo.money)}}
					</view>
					<view style="padding-left: 15rpx;">USDT</view>
				</view>
			</template>
			<template v-else>
				<view style="color:#77767b;padding:0px 40rpx;font-size: 25px;">{{hideAmount}} </view>
			</template>
			<view class="flex" style="padding: 10px 20px;justify-content: space-between;width:55%;">
				<view style="color: #77767b;">{{$lang.ZUORI_SHOUYI}}</view>
				<view style="color: #15d6d6;">{{$util.formatMoney(info.zuorishouyi)}}</view>
				<view style="color: #15d6d6;">+64.23%</view>
			</view>
			<view class="flex" style="margin-left: 20px;">
				<image src="/static/gantanhao.png" mode="widthFix" style="width: 30px;"></image>
				<view style="color:#77767b;margin-left: 5px;">{{$lang.GENTOU_DAOQI}}</view>
			</view>
			<view style="border-bottom: 1px #272729 solid; ">.</view>
			<view class="flex" style="padding: 15px;">
				<view style="border-left: #fff 3px solid;color: ;height: 15px;"></view>
				<view style="margin-left: 5px;color: #fff; ">{{$lang.ZICHAN_MINGXI}}</view>
			</view>
			<block v-for="(item,index) in orderlist">
				<view class="flex" style="width: 90%;padding-left: 10px;">
					<image src="/static/logo.png" mode="widthFix" style="width: 30px;"></image>
					<view class="flex-1" style="margin-left: 10px;">
						<view style="color: #fff;">{{item.gentousf.name}}</view>
						<view class="flex">
							<image src="/static/top2.png" mode="widthFix" style="width: 20px;"></image>
							<view style="color:#77767b ;">{{item.gentousf.guojia}}</view>
						</view>
					</view>
					<view style="background-color: #153e3f;color: #15d6d6;padding: 2px 5px;border-radius: 3px;">
						{{item.gentousf.pingfen}}
					</view>
				</view>
				<view class="flex"
					style="justify-content: space-between;width: 95%;padding: 5px 10px;margin-top: 10px;">
					<view>
						<view style="color: #77767b;">{{$lang.GENDAN_ZIJIN}}</view>
						<view style="color: #fff;margin-top: 5px;">{{item.price}} U</view>
					</view>
					<view>
						<view style="color: #77767b;text-align: right;">{{$lang.GENDAN_SHOUYI}}</view>
						<view style="color: #fff;margin-top: 5px;text-align: right;">{{item.shouyi}} U</view>
					</view>
				</view>
				<view class="flex"
					style="justify-content: space-between;width: 95%;padding: 5px 10px;margin-top: 10px;">
					<view>
						<view style="color: #77767b;">{{$lang.GENTOU_JIAGE}}</view>
						<view style="color: #fff;margin-top: 5px;">{{item.shouxu_fee}} U</view>
					</view>
					<view>
						<view style="color: #77767b;text-align: right;">{{$lang.DAOQI_RIQI}}</view>
						<view style="color: #fff;margin-top: 5px;">{{item.endtime}}</view>
					</view>
				</view>
				<view style="border-bottom: 1px #272729 solid; margin-top: 10px;">.</view>
			</block>
		</view> -->

		<!-- 资金账户 -->
		<view v-if="selectedContent ==5">
			<view class="flex"
				style="padding:0px 15px;justify-content: space-between;margin-top: 20px;width: 90%;color: #77767b;">
				<view class="flex">
					<view>{{$lang.ZONGZI_CHAN}}(USDT)</view>
					<image mode="aspectFit" :src="`/static/${showAmount?'show':'hide'}.png`" @click="handleShowAmount"
						:style="$theme.setImageSize(40)" style="padding-left: 20rpx;">
					</image>
				</view>
			</view>
			<template v-if="showAmount">
				<view style="color:#fff;padding:0px 40rpx;display: flex;align-items: center; margin-top: 10px;">
					<view style="font-size: 48rpx;font-weight: 500;">{{$util.formatMoney(info.zijinzhanghu)}} USDT
					</view>
				</view>
			</template>
			<template v-else>
				<view style="color:#77767b;padding:0px 40rpx;margin-top: 10px;font-size: 25px;">{{hideAmount}} </view>
			</template>
			<!-- <view style="color: #222;padding-left: 40rpx;font-size: 28rpx;padding-top: 20rpx;">
					{{$lang.ACCOUNT_AMOUNT_AVAILABLE}}
				</view> -->

			<template v-else>
				<view style="color:#77767b;padding:0px 40rpx;font-size: 25px;">{{hideAmount}} </view>
			</template>
			<view class="flex" style="padding: 10px 20px; justify-content: space-between; width:90%;" v-if="assets">
				<view>
					<view style="color: #77767b;">{{$lang.KEYONG}}(USDT)</view>
					<view style="color: #fff;">{{$util.formatMoney(assets.money)}}</view>
				</view>
				<view>
					<view style="color: #77767b;">{{$lang.DONGJIE_YUE}}(USDT)</view>
					<view style="color: #fff;text-align: right;">{{$util.formatMoney(assets.freeze)}}</view>
				</view>
			</view>
			<view class="flex" style=" justify-content: space-between; width: 90%;padding: 5px 20px;">
				<view style="background-color: #ffa641;color: #fff;padding: 5px 25px;border-radius: 30px;"
					@click="huazhuan()">{{$lang.HUAZHUAN}}</view>
				<view style="background-color: #ff6357;color: #fff;padding: 5px 25px;border-radius: 30px;"
					@click="linkWithdraw()">{{$lang.TIXIAN}}</view>
				<view style="background-color: #16e2e2;color: #fff;padding: 5px 25px;border-radius: 30px;"
					@click="linkDeposit()">{{$lang.CHONGZHI}}</view>
			</view>
			<view style="border-bottom: 1px #272729 solid; ">.</view>
			<view class="flex" style="padding: 15px;">
				<view style="border-left: #fff 3px solid;color: ;height: 15px;"></view>
				<view style="margin-left: 5px;color: #fff; ">{{$lang.ZICHAN_MINGXI}}</view>
			</view>
			<view style="padding: 0px 20px;margin-top: 10px;" v-for="(item,index) in log_list">
				<view class="flex flex-b" style="">
					<view>
						<view style="color: #fff;">USDT</view>
					</view>
					<view>
						<!-- <view style="color: #77767b;text-align: right;">手续费</view> -->
						<view style="color: #77767b;">{{item.created_at}}</view>
					</view>
				</view>
				<view style="color: #77767b;" class="margin-top-10">{{item.desc}}</view>
			</view>
			<view style="border-bottom: 1px #272729 solid; margin-top: 10px;"></view>
		</view>


	</view>
</template>

<script>
	import HeaderPrimary from '@/components/header/HeaderPrimary.vue';
	import Profile from '@/components/Profile.vue';
	import Translate from '@/components/Translate.vue';
	import NavList from '@/components/NavList.vue';
	import CustomTitle from '@/components/CustomTitle.vue';
	import TabsFourth from '@/components/tabs/TabsFourth.vue';
	import TradeHoldList from "@/components/trade/TradeHoldList.vue";
	import TradeSellList from "@/components/trade/TradeSellList.vue";
	export default {
		components: {
			HeaderPrimary,
			Profile,
			Translate,
			NavList,
			CustomTitle,
			TabsFourth,
			TradeHoldList,
			TradeSellList,
		},
		data() {
			return {
				showAmount: false, // 显示金额
				yan_show: true,
				hideAmount: '****', // 隐藏金额
				userInfo: {}, // 基本信息
				selectedContent: 1,
				log_list: "",
				goods: "",
				info: "",
				curTab: 0, //
				isShow: false, // 买卖弹出
				orderlist: "",
				order: "",
				gbpToUST: 1, // GBP值转UST的转换率
			}
		},
		onLoad(opt) {
			this.selectedContent = opt.tag && opt.tag.length > 0 ? 4 : this.selectedContent;
			this.showContent(this.selectedContent);
		},

		onShow() {
			this.showContent(this.selectedContent);
			this.getConfig();
		},

		//下拉刷新
		onPullDownRefresh() {
			this.showContent(this.selectedContent);
			this.getConfig();
			uni.stopPullDownRefresh()
		},
		methods: {
			// gbp转 gbp_usd
			async getConfig() {
				const result = await this.$http.get(`api/app/config`);
				if (!result) return false;
				console.log(`config:`, result);
				const temp = result.reduce((map, item) => {
					map.set(item.key, item.value);
					return map;
				}, new Map());
				this.gbpToUST = temp.get('gbp_usd') * 1 || this.gbpToUST;
			},
			changeTab(val) {
				console.log(val)
				this.curTab = val;
				// if (this.curTab == 1) {
				// 	this.isHold = false;
				// } else {
				// 	this.isHold = true;
				// }
				// this.getList();
			},

			// 总资产显隐控制
			handleShowAmount() {
				this.showAmount = !this.showAmount;
			},

			linkWithdraw() {
				uni.navigateTo({
					url: '/pages/address/index'
				})
			},
			linkDeposit() {
				uni.navigateTo({
					url: '/pages/deposit/index'
				})
			},
			huazhuan() {
				uni.navigateTo({
					url: '/pages/transfer/index'
				})
			},

			linkExchange() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_BING_BANK,
				})
			},

			linkService() {
				this.$util.linkCustomerService();
			},
			// 交易记录
			linkTradRecord() {
				uni.navigateTo({
					url: this.$paths.ACCOUNT_TRADE_LOG
				})
			},
			Promotion() {
				uni.navigateTo({
					url: '/pages/Promotion'
				})
			},
			showContent(content) {
				this.selectedContent = content;
				if (content == 1) {
					this.getAccountInfo()
					this.getMoneychange()

				} else if (content == 2) {
					this.getEafof()
				} else if (content == 3) {
					this.getassets(2)
					this.getMoneychange()
				} else if (content == 4) {
					this.getMoneychange()
					this.getGentouEa()
				} else if (content == 5) {
					this.getassets(1)
					this.getMoneychange()
				}
			},

			// 登出
			// handleSignOut() {
			// 	uni.removeStorageSync('token');
			// 	try {
			// 		let version = uni.getStorageSync('version')
			// 		uni.setStorageSync('version', version)
			// 	} catch (e) {
			// 		// error
			// 	}
			// 	uni.$u.toast(this.$lang.TIP_SIGN_OUT_SUCCESS);
			// 	setTimeout(() => {
			// 		uni.navigateTo({
			// 			url: this.$paths.ACCOUNT_ACCESS
			// 		});
			// 	}, 500)
			// },

			async getassets(type) {
				this.assets = ""
				const result = await this.$http.get(`api/user/assets`, {
					type: type
				});
				console.log('info result：', result);
				if (!result) return false;
				this.assets = result;

				this.typelog(type)
			},


			async typelog(type) {
				const result = await this.$http.get(`api/user/typelog`, {
					type: type
				});
				console.log('info result：', result);
				if (!result) return false;
				this.log_list = result;
			},

			async getEafof() {
				const result = await this.$http.get(`api/jijin/order`);
				console.log('info result：', result);
				if (!result) return false;
				this.order = result;
			},


			async getGentouEa() {
				const result = await this.$http.get(`api/Gentouea/orderlist`);
				console.log('info result：', result);
				if (!result) return false;
				this.orderlist = result;
			},

			async getMoneychange() {
				const result = await this.$http.get(`api/user/moneychange`);
				console.log('info result：', result);
				if (!result) return false;
				this.info = result;
				console.log(this.info.userlevel);
			},


			//用户信息
			async getAccountInfo() {
				const result = await this.$http.get(`api/user/info`);
				console.log('info result：', result);
				if (!result) return false;
				this.userInfo = result;
				console.log(this.userInfo.userlevel);
			}
		},
	}
</script>