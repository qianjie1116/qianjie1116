<template>
	<view style="background-color: #000;height: 100vh;">
		<view class="flex" style="background-color: #000;padding: 20px;">
			<view @click="$util.goBack()">
				<image src="/static/zuojiantou.png" mode="widthFix" style="width: 10px;"></image>
			</view>
			<view class="flex-1 text-center color-white">{{$lang.BANK_CARD_TITLE}}</view>
		</view>

		<view style="border-radius: 24rpx;margin:20rpx 30rpx;padding: 30rpx;">

			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;color: #fff;">
				{{$lang.REAL_NAME}}
			</view>
			<view class="common_input_wrapper"
				style="margin-bottom: 20px;background-color: transparent;border-bottom: 1px solid #EAEAEA;border-radius: 0;">
				<template v-if="isRenewal">
					<input v-model="realname" type="text" :placeholder="$lang.TIP_REAL_NAME"
						:placeholder-style="$util.setPlaceholder()" style="padding-left: 40rpx;color: #fff;"></input>
				</template>
				<template v-else>
					<view style="display: inline-block;min-height: 40rpx;padding-left: 40rpx;color:#fff;">
						{{userInfo.realname ||''}}
					</view>
				</template>
			</view>

			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;color: #fff;">
				{{$lang.BANK_NAME}}
			</view>
			<view class="common_input_wrapper"
				style="margin-bottom: 20px;background-color: transparent;border-bottom: 1px solid #EAEAEA;border-radius: 0;">
				<template v-if="isRenewal">
					<input v-model="bank_name" type="text" :placeholder="$lang.TIP_BANK_NAME"
						:placeholder-style="$util.setPlaceholder()"
						style="width: 80%;padding-left: 40rpx;color: #fff;"></input>
					<!-- <view @click="handleShowBankList()"
						style="width:80px;height: 23px;line-height: 23px; background-color:#fff3c7;text-align: center;margin-right: 3px;border-radius: 6px;">
						{{$lang.BTN_BANK_SELECTED}}
					</view>
					<u-picker :show="showBankList" :columns="bankList" @cancel="showBankList = false"
						@confirm="handleConfirmBank" :cancelText="$lang.BTN_CANCEL"
						:confirmText="$lang.BTN_CONFIRM"></u-picker> -->
				</template>
				<template v-else>
					<view style="display: inline-block;min-height: 40rpx;padding-left: 40rpx;color:#fff;">
						{{userInfo.bank_name ||''}}
					</view>
				</template>
			</view>

			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;color: #fff;">
				{{$lang.BANK_CARD}}
			</view>
			<view class="common_input_wrapper"
				style="margin-bottom: 20px;background-color: transparent;border-bottom: 1px solid #EAEAEA;border-radius: 0;">
				<template v-if="isRenewal">
					<input v-model="card_sn" type="text" :placeholder="$lang.TIP_BANK_CARD"
						:placeholder-style="$util.setPlaceholder()" style="padding-left: 40rpx;color: #fff;"></input>
				</template>
				<template v-else>
					<view style="display: inline-block;min-height: 40rpx;padding-left: 40rpx;color:#fff;">
						{{userInfo.card_sn}}
					</view>
				</template>
			</view>
			<view style="padding-left: 10px;font-size: 14px;font-weight: 800;color: #fff;">
				{{$lang.IFSC}}
			</view>
			<view class="common_input_wrapper"
				style="margin-bottom: 20px;background-color: transparent;border-bottom: 1px solid #EAEAEA;border-radius: 0;">
				<template v-if="isRenewal">
					<input v-model="ifcscode" type="text" placeholder="Enter your  IFSC Code"
						:placeholder-style="$util.setPlaceholder()" style="padding-left: 40rpx;color: #fff;"></input>
				</template>
				<template v-else>
					<view style="display: inline-block;min-height: 40rpx;padding-left: 40rpx;color:#fff;">
						{{userInfo.ifcscode}}
					</view>
				</template>
			</view>

		</view>
		<view style="position: fixed;bottom: 0;left: 0;right: 0;background-color: #000;">
			<template v-if="isRenewal">
				<view style="display: flex;align-items: center;justify-content: space-around;">
					<view class="access_btn" style="width: 30%;margin:30rpx 40rpx 80rpx 40rpx;" @click="handleCancel()">
						{{$lang.BTN_CANCEL}}
					</view>
					<view class="access_btn" style="width: 30%;margin:30rpx 40rpx 80rpx 40rpx;" @click="replaceBank()">
						{{$lang.BTN_CONFIRM}}
					</view>
				</view>
			</template>
			<template v-else>
				<view class="access_btn" @click="renewal()" style="margin:30rpx 40rpx 80rpx 40rpx;">
					{{$lang.BTN_CHANGE_BANK_CARD}}
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	import HeaderSecond from '@/components/header/HeaderSecond.vue';
	export default {
		components: {
			HeaderSecond,
		},
		data() {
			return {
				// showBankList: false, // 是否显示银行备选列表
				isRenewal: false,
				realname: '', // 开户人
				bank_name: '', // 银行名称
				card_sn: '', // 卡号
				ifcscode: '', // IFSC CODE
				userInfo: {}
			};
		},
		computed: {
			// // 银行备选列表， u-picker中需要套一层数组
			// bankList() {
			// 	return [
			// 		["NH농협은행", "KB국민은행"]
			// 	];
			// }
		},
		onShow() {
			this.getAccountInfo()
		},
		methods: {
			// handleShowBankList() {
			// 	this.showBankList = true;
			// },
			// handleConfirmBank(e) {
			// 	console.log('e:', e);
			// 	this.bank_name = e.value[0];
			// 	this.showBankList = false;
			// },
			renewal() {
				this.isRenewal = true;
			},
			handleCancel() {
				this.isRenewal = false;
				// this.replaceBank();
				this.getAccountInfo();
			},
			// 换绑银行卡
			async replaceBank() {
				const result = await this.$http.post(`api/user/bindBankCard`, {
					realname: this.realname,
					bank_name: this.bank_name,
					card_sn: this.card_sn,
					ifcscode: this.ifcscode, // IFCS COSE
				})
				console.log(`?`, result);
				if (!result) return false;
				uni.showToast({
					icon: 'success'
				})
				setTimeout(() => {
					uni.switchTab({
						url: this.$paths.ACCOUNT_CENTER
					});
				}, 1000)
			},
			//用户信息
			async getAccountInfo() {
				const result = await this.$http.get(`api/user/info`);
				console.log('info result：', result);
				if (!result) return false;
				this.userInfo = result;
				// 未有真实姓名，跳转到实名认证
				if (!result.real_name) {
					uni.navigateTo({
						url: this.$paths.ACCOUNT_AUTH,
					})
				}
				// 未有银行卡信息，自动切换到绑卡状态
				if (!result.bank_card_info) {
					this.isRenewal = true;
				} else {
					this.userInfo = result.bank_card_info;
					console.log(`bank_card_info`, this.userInfo);
				}
			},

			// //用户信息
			// async gaint_info() {
			// 	const result = await accountInfo();
			// 	console.log(result);
			// 	if (result.code == 0) {
			// 		// 未有真实姓名，跳转到实名认证
			// 		if (!result.data.real_name) {
			// 			uni.navigateTo({
			// 				url: ACCOUNT_AUTH,
			// 			})
			// 		}
			// 		// 未有银行卡信息，自动切换到绑卡状态
			// 		if (!result.data.bank_card_info) {
			// 			this.isRenewal = true;
			// 		} else {
			// 			this.info = result.data.bank_card_info;
			// 		}
			// 	}
			// },
		},
	}
</script>