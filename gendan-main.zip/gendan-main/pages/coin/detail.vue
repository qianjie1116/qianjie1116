<template>
	<view :class="isAnimat?'fade_in':'fade_out' " style="min-height: 100vh;">
		<template v-if="info">
			<header class="common_header">
				<view class="left" @click="actionEvent()">
					<image src="/static/arrow_left.png" mode="aspectFit" :style="$theme.setImageSize(32)"></image>
				</view>
				<view class="center">
					<image src="/static/coin_choose.png" mode="aspectFit" :style="$theme.setImageSize(24)"
						@tap="chooseCoin()"></image>
					<text style="padding:0 30rpx;" :style="{color:$theme.SECOND}">{{setTitle}}</text>
				</view>
				<!-- <view class="right">
					<view @click="handleUnFollow(info.gid)">
						<image :src="`/static/${info && info.is_collected==1?'stock_follow':'stock_unfollow'}.png`"
							:style="$theme.setImageSize(32)"></image>
					</view>
				</view> -->
			</header>

			<view style="margin:0 20rpx;padding:20rpx;">
				<view style="display: flex;align-items: center;justify-content: space-between;">
					<view>
						<view style="font-size: 32rpx;" :style="$theme.setStockRiseFall(info.rate>0)">
							{{$util.formatNumber(info.current_price,info.shudian) }}
						</view>
						<view style="font-size: 24rpx;color:#8E8D92;line-height: 1.6;">
							{{$util.formatNumber(info.rate_num,info.shudian) }}
						</view>
						<view style="font-size: 24rpx;line-height: 1.6;" :style="$theme.setStockRiseFall(info.rate>0)">
							{{`${info.rate>0?'+':'-'} `+ ($util.formatNumber($util.formatMathABS(info.rate),2))}}%
						</view>
					</view>
					<view style="margin-left: auto;">
						<template v-if="info && info.high">
							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
								<view style="font-size: 24rpx;padding-right: 20rpx;" :style="{color:$theme.LOG_LABEL}">
									{{$lang.COIN_VIEW_HIGH}}
								</view>
								<view style="font-size: 24rpx;" :style="{color:$theme.WHITE}">
									{{$util.formatCoin(info.high)}}
								</view>
							</view>
						</template>
						<template v-if="info && info.low">
							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
								<view style="font-size: 24rpx;padding-right: 20rpx;" :style="{color:$theme.LOG_LABEL}">
									{{$lang.COIN_VIEW_LOW}}
								</view>
								<view style="font-size: 24rpx;" :style="{color:$theme.WHITE}">
									{{$util.formatCoin(info.low)}}
								</view>
							</view>
						</template>
						<template v-if="info && info.vol">
							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.6;">
								<view style="font-size: 24rpx;padding-right: 20rpx;" :style="{color:$theme.LOG_LABEL}">
									24H
								</view>
								<view style="font-size: 24rpx;" :style="{color:$theme.WHITE}">
									{{$util.formatNumber(info.vol,0)}}
								</view>
							</view>
						</template>
					</view>
				</view>
				<!-- <view style="display: flex;align-items: center;">
					<template v-if="info.logo">
						<view style="flex:0 0 auto;">
							<CustomLogo :logo="info.logo" :name="info.name"></CustomLogo>
						</view>
					</template>
					<view style="flex:1 1 auto;">
						<view style="padding-left:20rpx;" :style="{color:$theme.LOG_LABEL}">
							<text>24H: {{$util.formatNumber(info.info.vol,0)}}</text>
							<view
								style="display: flex;align-items: center;justify-content: space-between;line-height: 1.8;"
								:style="$theme.setStockRiseFall(info.rate>0)">
								<view style="font-size: 32rpx;">
									{{$util.formatNumber(info.info.lastPrice,info.shudian) }}
								</view>
								<view style="font-size: 32rpx;">{{$util.formatNumber(info.info.rate_num,info.shudian) }}
								</view>
								<view style="font-size: 32rpx;">
									{{`${info.info.rate>0?'+':'-'} `+ ($util.formatNumber($util.formatMathABS(info.info.rate),2))}}%
								</view>
							</view>
						</view>
					</view>
				</view> -->
				<!-- <template v-if="info.info && info.info.open">
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;">
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">{{$lang.COIN_VIEW_OPEN}}
						</view>
						<view style="font-size: 24rpx;" :style="{color:$theme.WHITE}">
							{{$util.formatCoin(info.info.open)}}
						</view>
					</view>
				</template>
				<template v-if="info.info && info.info.close">
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;">
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">{{$lang.COIN_VIEW_CLOSE}}
						</view>
						<view style="font-size: 24rpx;" :style="{color:$theme.WHITE}">
							{{$util.formatCoin(info.info.close)}}
						</view>
					</view>
				</template> -->

				<!-- <template v-if="info.info && info.info.amount">
					<view style="display: flex;align-items: center;justify-content: space-between;line-height: 1.4;">
						<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">{{$lang.COIN_VIEW_AMOUNT}}
						</view>
						<view style="font-size: 24rpx;" :style="{color:$theme.WHITE}">
							{{$util.formatCoin(info.info.amount)}}
						</view>
					</view>
				</template> -->
			</view>

			<view style="padding:36rpx;">
				<view style="display: flex;align-items: center;justify-content: space-between;padding-bottom: 36rpx;">
					<block v-for="(item,index) in $lang.COIN_DETAIL_TABS_TIME" :key="index">
						<view :style="setStyle(curKLine ==index)" @click="handleShowKLine(index)">
							{{item}}
						</view>
					</block>
				</view>
				<view class="chart" id="chart-type-k-line" style="width: 99%;height: 500rpx;">
				</view>
			</view>

			<view style="display: flex;align-items: center;padding:0 36rpx;">
				<view style="background-color: #FFFFFF;width: 8rpx;height: 28rpx;"></view>
				<view style="font-size: 28rpx;font-weight: 700;color:#FFFFFF;padding-left: 40rpx;">
					{{$lang.COIN_VIEW_TAB_TRADE}}
				</view>
			</view>

			<view style="padding:0 36rpx 200rpx 36rpx;">
				<!-- <view style="display: flex;align-items: center;justify-content: space-between;">
					<block v-for="(item,index) in listTabs" :key="index">
						<view :style="setStyle(curTab ==index)" @click="changeList(index)">
							{{item}}
						</view>
					</block>
				</view>
				<template v-if="curTab==0"> -->
				<template v-if="!asks || asks.length<=0">
					<EmptyData></EmptyData>
				</template>
				<template v-else>
					<view style="display: flex;align-items: center;padding:20rpx 0;">
						<view style="flex:0 0 auto;text-align: center;" :style="{color:$theme.LOG_LABEL}">
							{{$lang.COIN_VIEW_DEPTH_TITLE_BUY_QTY}}
						</view>
						<view style="flex:1 1 auto;text-align: center;" :style="{color:$theme.LOG_LABEL}">
							{{$lang.COIN_VIEW_TRADE_TITLE_PRICE}}
						</view>
						<view style="margin-left: auto;" :style="{color:$theme.LOG_LABEL}">
							{{$lang.COIN_VIEW_DEPTH_TITLE_SELL_QTY}}
						</view>
					</view>
					<block v-for="(item,index) in asks" :key="index">
						<view style="display: flex;align-items: center;line-height: 2.2;margin:10rpx 0;">
							<view style="flex:0 0 50%;" :style="$theme.depathAsksBG(item[1],asksMax)">
								<view
									style="display: flex;align-items: center;justify-content: space-between;padding-right:10rpx;">
									<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
										{{$util.formatNumber(item[1],4)}}
									</view>
									<view style="font-size: 24rpx;" :style="$theme.setStockRiseFall(true)">
										{{$util.formatNumber(item[0],4)}}
									</view>
								</view>
							</view>
							<view style="flex:0 0 50%;" :style="$theme.depathBidsBG(bids[index][1],bidsMax)">
								<view
									style="display: flex;align-items: center;justify-content: space-between;padding-left:10rpx;">
									<view style="font-size: 24rpx;" :style="$theme.setStockRiseFall(false)">
										{{$util.formatNumber(bids[index][0],4)}}
									</view>
									<view style="font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
										{{$util.formatNumber(bids[index][1],4)}}
									</view>
								</view>
							</view>
						</view>
					</block>
				</template>
				<!-- </template>
				<template v-else>
					<template v-if="!tradeList || tradeList.length<=0">
						<EmptyData></EmptyData>
					</template>
					<template v-else>
						<view style="display: flex;align-items: center;padding:20rpx 0;">
							<view style="flex:0 0 40%;" :style="{color:$theme.LOG_LABEL}">
								{{$lang.COIN_VIEW_TRADE_TITLE_DATE}}
							</view>
							<view style="flex:0 0 auto; padding-left: 40rpx;" :style="{color:$theme.LOG_LABEL}">
								{{$lang.COIN_VIEW_TRADE_TITLE_PRICE}}
							</view>
							<view style="margin-left: auto;" :style="{color:$theme.LOG_LABEL}">
								{{$lang.COIN_VIEW_TRADE_TITLE_AMOUNT}}
							</view>
						</view>
						<block v-for="(item,index) in tradeList" :key="index">
							<view style="display: flex;align-items: center;line-height: 1.8;">
								<view style="flex:0 0 40%; font-size: 24rpx;" :style="{color:$theme.LOG_LABEL}">
									{{$util.formatDate(item.ts)}}
								</view>
								<view style="flex:0 0 auto; padding-left: 40rpx;"
									:style="$theme.setStockRiseFall(item.dir>0)">
									{{item.price}}
								</view>
								<view style="margin-left: auto;">{{$util.formatNumber(item.amount,4)}}</view>
							</view>
						</block>
					</template>
				</template> -->
			</view>

			<view
				style="position: fixed;bottom:0;left: 0;right: 0;background-color: #151517;border-top: 1px solid #3B3B3D;z-index: 999;">
				<view style="display: flex; align-items: center;justify-content: space-around;">
					<view
						style="margin:28rpx auto;width: 40%;border-radius:50rpx;background-color:#16E2E2;color:#FFFFFF;padding:24rpx 0;font-size: 28rpx;text-align: center;"
						@click="linkIndex(0)">
						{{$lang.COIN_VIEW_BTN_BUY}}
					</view>
					<view
						style="margin:28rpx auto;width: 40%;border-radius:50rpx;background-color:#FF6357;color:#FFFFFF;padding:24rpx 0;font-size: 28rpx;text-align: center;"
						@click="linkIndex(1)">
						{{$lang.COIN_VIEW_BTN_SELL}}
					</view>
				</view>
			</view>
		</template>

		<!-- Coin  選擇器 -->
		<u-picker :show="isShowCoinList" :columns="[coinList]" @change="changeCoin" @cancel="isShowCoinList=false"
			@confirm="confirmCoin" :cancelText="$lang.COMMON_CANCEL" :confirmText="$lang.COMMON_CONFIRM"
			:cancelColor="$theme.MODAL_CANCEL" :confirmColor="$theme.PRIMARY" keyName="label"
			visibleItemCount="9"></u-picker>
	</view>
</template>

<script>
	import CustomLogo from '@/components/CustomLogo.vue';
	import EmptyData from '@/components/EmptyData.vue';
	import {
		init,
		dispose
	} from '@/common/klinecharts.min.js';
	import {
		klineGird,
		klineArea,
		klineCandle
	} from '@/common/klineConfig.js';
	export default {
		components: {
			EmptyData,
			CustomLogo,
		},
		data() {
			return {
				isAnimat: false, // 页面动画
				code: '', // url 带入值
				gpIndex: '', // url 带入值
				// curTab: 0,
				tradeList: [],
				asks: [],
				bids: [],
				asksMax: 0, // asks 當前最大數量
				bidsMax: 0, // bids 當前最大數量

				info: null, // 单股信息，
				kLineChart: null, // Kline实例化
				curKLine: 0, // 当前显示的Kline数据图标
				socket: null,
				curType: 0, // 当前點擊底部按鈕[0买|1卖]
				temp: {},
				indicator: null, // 创建技术指标，移除时需使用
				isShowCoinList: false, // 是否顯示 coin選擇器
				coinList: null, // coin 選項組
			}
		},
		computed: {
			// header title
			setTitle() {
				if (this.info) {
					return this.info.name || 'Detail';
				}
			},
			// 
			// listTabs() {
			// 	return [this.$lang.COIN_VIEW_TAB_DEPTH,
			// 		this.$lang.COIN_VIEW_TAB_TRADE,
			// 	]
			// }
		},
		onLoad(opt) {
			console.log(`opt:`, opt);
			this.code = opt.code || '';
			this.gpIndex = opt.type || '';
		},
		onShow() {
			this.isAnimat = true;
			if (this.socket) this.disconnect();
			this.getData();
		},
		onHide() {
			this.isAnimat = false;
			if (this.socket) this.disconnect();
		},
		onUnload() {
			if (this.socket) this.disconnect();
		},
		deactivated() {
			if (this.socket) this.disconnect();
		},
		methods: {
			actionEvent() {
				// 固定跳轉到市場
				uni.switchTab({
					url: `/pages/trading/jiaoyi`
				})
			},
			// 選擇一種coin
			chooseCoin() {
				// 請求數據。
				this.getCoinList();
			},
			changeCoin(e) {
				console.log(`changeMode e:`, e);
			},
			// coin選擇器確認事件
			confirmCoin(e) {
				console.log(`confirmMode e:`, e);
				this.code = e.value[0].code;
				this.isShowCoinList = false;
				// 重置一些值
				this.quantity = '';
				this.getData();
			},
			// 在切換coin時，需請求列表，製作coin選擇器數組
			async getCoinList() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
					icon: 'loading'
				});
				const result = await this.$http.post(`api/goods/list`, {
					gp_index: this.gpIndex,
				});
				if (!result) return false;
				console.log(result);
				this.coinList = Object.values(result).map(item => {
					return {
						label: item.name,
						code: item.code
					}
				});
				// 獲取數據之後，顯示選擇器
				this.isShowCoinList = true;
			},

			// 买入 卖出
			linkIndex(val) {
				// 0:币买入 1:币卖出
				console.log(`val:`, val);
				this.curType = val;
				uni.navigateTo({
					// &type=${this.gpIndex}
					url: `${ this.$paths.COIN_INDEX}?code=${this.code}&tag=${this.curType}`
				});
			},
			// linkIndex() {
			// 	uni.navigateTo({
			// 		url: '/pages/stock/buy'
			// 	})
			// },
			// 取关
			async handleUnFollow(id) {
				const result = await this.$http.post(`api/user/collect_edit`, {
					gid: id,
				})
				this.info.is_collected = this.info.is_collected == 1 ? 0 : 1;
			},
			// 设置样式
			setStyle(val) {
				return {
					fontSize: `24rpx`,
					textAlign: `center`,
					borderRadius: `32rpx`,
					padding: `4rpx 8rpx`,
					color: val ? this.$theme.WHITE : '#8E8D92',
					border: `1px solid ${val ? '#3B3B3D' : this.$theme.TRANSPARENT}`,
					backgroundColor: this.$theme.TRANSPARENT,
					minWidth: `60rpx`,
				}
			},
			// 列表切換
			// changeList(val) {
			// 	this.curTab = val;
			// 	if (this.curTab == 1) {
			// 		this.getTradeList();
			// 	} else {
			// 		this.getDepthList();
			// 	}
			// },
			// websocket链接
			connect() {
				//创建webSocket
				this.socket = uni.connectSocket({
					url: this.$http.WS_COIN_URL,
					header: {
						'content-type': 'application/json'
					},
					success(res) {
						console.info(`success res:`, res);
					},
					fail: (res) => {
						console.info(`fail res:`, res);
					}
				});
				console.log(`socket:`, this.socket);
				if (this.socket) {
					this.socket.onOpen((res) => {
						console.info("socket onOpen:", res)
					});
					uni.onSocketError((res) => {
						console.info("onSocketError:" + res)
					});

					this.socket.onMessage((res) => {
						const data = JSON.parse(res.data);

						// 當前買賣盤的數據
						if (this.info.code == data.market && data.type == "depth") {
							// console.log('data depth:', data);
							// if (this.curTab == 0) {
							// 直接提取前五條，替換數據
							const tempAsk = data.ask.slice(0, 10);
							const tempBid = data.bid.slice(0, 10);
							this.asks = tempAsk.map(item => [item.price, item.quantity]);
							this.bids = tempBid.map(item => [item.price, item.quantity]);
							// 當前數組中，數量最大值， *1.01(餘量，避免求出100%)
							this.asksMax = Math.max(...this.asks.map(item => item[1])) * 1.01;
							// 當前數組中，數量最大值， *1.01(餘量，避免求出100%)
							this.bidsMax = Math.max(...this.bids.map(item => item[1])) * 1.01;
							// }
						}
						// // 更新當前最新交易記錄
						// if (this.info.code == data.market && data.type == "tradelog" && data.num * 1 > 0) {
						// 	console.log('data trade:', data);
						// 	if (this.curTab == 1) {
						// 		this.tradeList.unshift({
						// 			amount: data.num,
						// 			price: data.price,
						// 			ts: data.id,
						// 			dir: data.trade_type, // 1買 2 賣
						// 		});
						// 		this.tradeList.pop();
						// 		console.log(this.tradeList.length);

						// 		// this.tradeList[0].amount = data.num;
						// 		// this.tradeList[0].price = data.price;
						// 		// this.tradeList[0].ts = data.id;								
						// 		// this.tradeList[0].dir = data.trade_type;
						// 	}
						// }

						if (this.info.code == data.market && data.lastPrice > 0) {
							// console.log('data:', data);
							this.info.current_price = data.lastPrice;
							this.info.rate = data.rate || 0;
							this.info.rate_num = data.rate_num || 0;
							this.info.high = data.high || 0;
							this.info.low = data.low || 0;
							this.info.vol = data.vol || 0;

							// 	当前k线在分钟走势图，且当前回执数据type='kline'时， 执行以下逻辑		
							if (this.curKLine == 0 && data.type == "kline") {
								// 创建一个Date对象，使用该时间戳创建
								let date = new Date(data.time);
								// 获取当前分钟的起始毫秒时间戳
								let currentMinuteStart = new Date(date.getFullYear(), date.getMonth(), date
									.getDate(),
									date.getHours(), date.getMinutes(), 0, 0).getTime();
								// console.log(currentMinuteStart);

								const temp = {
									close: data.close,
									high: data.high,
									low: data.low,
									open: data.open,
								};
								this.temp = temp;
								this.kLineChart.updateData(temp);
							} else {
								this.temp.close = data.lastPrice;
								this.kLineChart.updateData(this.temp);
							}
						}
					});
				}
			},
			// 关闭 websocket链接
			disconnect() {
				if (this.socket) {
					const result = this.socket.close();
					console.log('disconnect result:', result);
					this.socket = null;
				}
			},

			handleShowKLine(val) {
				this.disconnect();
				this.curKLine = val;
				this.getData();
			},

			kLineInit() {
				if (!this.kLineChart) {
					this.kLineChart = init('chart-type-k-line');
				}
				this.kLineChart.setStyles({
					grid: klineGird,
					// 第一个用面积图 后面用蜡烛图
					candle: this.curKLine == 0 ? klineArea : klineCandle,
				});
				// 只有 curKLine==0 显示技术指标
				if (this.curKLine == 0 && !this.indicator) {
					this.indicator = this.kLineChart.createIndicator('MA', false);
				} else {
					if (this.indicator) {
						this.kLineChart.removeIndicator(this.indicator);
						this.indicator = null;
					}
				}
				this.genKLineData(); // 获取并生成KLine数据
			},

			// 产品详情
			async getData() {
				uni.showLoading({
					title: this.$lang.REQUEST_DATA,
				});
				const result = await this.$http.post(`api/product/info`, {
					code: this.code,
					time_index: this.curKLine
				});
				console.log(`getData result:`, result);
				if (!result) return false;
				this.info = result[0];
				console.log(`info:`, this.info);

				// this.changeList(this.curTab);
				this.getDepthList();

				// 当前实时更新模式
				this.connect();

				// 延时,等DOM渲染
				setTimeout(() => {
					this.kLineInit();
				}, 50);
			},

			// 获取并生成KLine数据
			async genKLineData() {
				const result = await this.$http.post(`api/product/lishi`, {
					ac_time: this.curKLine,
					project_type_id: this.info.project_type_id,
					code: this.info.code
				})
				console.log('k data:', result);
				if (!result) return false;
				if (result.length > 0) {
					const temp = {
						close: result[result.length - 1].close,
						high: result[result.length - 1].high,
						low: result[result.length - 1].low,
						open: result[result.length - 1].open,
						timestamp: result[result.length - 1].timestamp,
						turnover: result[result.length - 1].turnover,
					};
					this.temp = temp;
					this.kLineChart.setPriceVolumePrecision(this.info.shudian, 0)
					this.kLineChart.applyNewData(result)
				}
			},

			// latest trading list
			// async getTradeList() {
			// 	const response = await uni.request({
			// 		url: `https://api.huobi.pro/market/history/trade`,
			// 		method: 'GET',
			// 		data: {
			// 			symbol: this.info.locate,
			// 			size: 10,
			// 		},
			// 	});
			// 	const [err, res] = response;
			// 	console.log('err:', err, 'res:', res);
			// 	if (res && res.data.status == 'ok') {
			// 		const temp = res.data.data;
			// 		console.log(`trade temp:`, temp);
			// 		this.tradeList = temp.map(item => {
			// 			return {
			// 				...item.data[0],
			// 				dir: item.data[0].direction == 'buy' ? 1 : 2,
			// 			}
			// 		});
			// 	}
			// 	console.log(`tradeList:`, this.tradeList);
			// },

			async getDepthList() {
				const response = await uni.request({
					url: `https://api.huobi.pro/market/depth`,
					method: 'GET',
					data: {
						symbol: this.code,
						depth: 10,
						type: 'step0'
					},
				});
				const [err, res] = response;
				console.log('err:', err, 'res:', res);
				if (res && res.data.status == 'ok') {
					const temp = res.data;
					this.asks = res.data.tick.asks;
					this.bids = res.data.tick.bids;
					// 當前數組中，數量最大值， *1.01(餘量，避免求出100%)
					this.asksMax = Math.max(...this.asks.map(item => item[1])) * 1.01;
					// 當前數組中，數量最大值， *1.01(餘量，避免求出100%)
					this.bidsMax = Math.max(...this.bids.map(item => item[1])) * 1.01;
				}
				console.log('asks:', this.asks);
				console.log('bids:', this.bids);
			}
		},
	}
</script>

<style lang="scss" scoped>
	//  u-picker 样式覆盖
	/deep/.u-popup__content {
		background-color: #151517 !important;

		.uni-picker-view-mask {
			background: none !important;
		}

		.u-picker__view__column__item {
			color: #C9C9C9 !important;
		}
	}

	.common_header {
		padding: 56rpx 36rpx 20rpx 36rpx;
		display: flex;
		align-items: center;
		border-bottom: 1px solid #3B3B3D;

		.left {
			flex: 0 0 auto;
		}

		.right {
			flex: 0 0 auto;
		}

		.center {
			color: #FFFFFF;
			font-size: 36rpx;
			font-weight: 500;
			// padding-left: 40rpx;
			flex: 1 1 auto;
			text-align: center;
		}
	}
</style>