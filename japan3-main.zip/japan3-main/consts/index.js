export const TYPES = [{
		name: '금융 뉴스',
		type: 11,
		index: 1
	},
	{
		name: '경제 데이터',
		type: 12,
		index: 2
	},
	{
		name: '글로벌 주주',
		type: 13,
		index: 3
	},
	{
		name: '전세계 7*24',
		type: 14,
		index: 4
	},
	{
		name: '제품정보',
		type: 15,
		index: 5
	},
	{
		name: '상장됨',
		type: 16,
		index: 6
	},
	{
		name: '글로벌 중앙 은행',
		type: 17,
		index: 7
	}

]
