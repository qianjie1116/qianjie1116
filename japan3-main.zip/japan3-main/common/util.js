import LANGUAGE_DATA from '@/common/language.js';
// 配色方案
const THEME = {
	PRIMARY_COLOR: '#181945',
	SECONDARY_COLOR: '#4b5fcc',
}
// 计算图片尺寸
const calcImageSize = (val) => {
	return {
		width: `${val}px`,
		height: `${val}px`,
	};
};

/* 数字格式化， 比如 123,464.23 */
const formatNumber = (value, fixed = 0) => {
	if (isNaN(value)) return '0';
	let result = Number(value).toFixed(fixed);
	result = result.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
	return result;
};

// 日期格式化
const formatDate = (timeString) => {
	const date = new Date(timeString);
	const year = date.getFullYear();
	const month = String(date.getMonth() + 1).padStart(2, '0');
	const day = String(date.getDate()).padStart(2, '0');

	return `${year}.${month}.${day}`;
}

// 计算页面高度
const calcPageHeight = () => {
	const systemInfo = uni.getSystemInfoSync();
	const tabBarHeight = systemInfo.screenHeight - systemInfo.windowHeight;
	return systemInfo.screenHeight - tabBarHeight;
};

// 计算剩余高度
const calcListHeight = (arr) => {
	return calcPageHeight() - arr.reduce((a, b) => a + b, 0);
};

// 主页功能按钮组配置
const businessBtnsConfig = () => {
	return [{
		name: LANGUAGE_DATA.TRADE_LARGE,
		url: '/pages/trade/large',
		icon: 'large'
	},{
		name: 'IPO',
		url: '/pages/trade/ipo',
		icon: 'shares'
	}, {
		name: 'ニュース',
		url: '/pages/market/market',
		icon: 'apply_purchase'
	}, {
		name: '入金',
		url: '/pages/certificateBank/silver',
		icon: 'short_trade'
	}, {
		name: '出金',
		url: '/pages/prove',
		icon: 'discount_trade'
	}, {
		name: '本人確認',
		url: '/pages/authentication/authentication',
		icon: 'auth'
	}]
};

// 行情主页面，按钮组
const mqBtnsConfig = () => {
	return [{
		name: LANGUAGE_DATA.FULL_INFO,
		url: '',
		icon: 'full_info'
	},  {
		name: LANGUAGE_DATA.MARKET_ISSUES,
		url: '',
		icon: 'maket_issues'
	}];
}

// 个人中心 认证相关功能列表
const navListAuthConfig = (code) => {
	const data = [{
		name: LANGUAGE_DATA.VERIFIED,
		url: 'authentication',
		icon: 'verify',
		code: -1,
	}, {
		name: LANGUAGE_DATA.AUDIT,
		url: 'authentication',
		icon: 'verify',
		code: 0,
	}, {
		name: LANGUAGE_DATA.AUDIT_FAILED,
		url: 'authentication',
		icon: 'failed',
		code: 2
	}];
	const temp = data.filter(item => item.code == code);
	return [...temp, {
		name: LANGUAGE_DATA.SERVICE,
		url: 'service',
		icon: 'service'
	}];
};

// 个人中心，功能列表
const navListConfig = () => {
	return [{
		name: LANGUAGE_DATA.CHANGE_PWD,
		url: 'changePwd',
		icon: 'key'
	}, {
		name: LANGUAGE_DATA.CHANGE_PAY_PWD,
		url: 'payPwd',
		icon: 'paypwd'
	}, {
		name: LANGUAGE_DATA.CARD_MANAGEMENT,
		url: 'bankCard',
		icon: 'card'
	}, {
		name: LANGUAGE_DATA.CAPITAL_DETAIL,
		url: 'capitalDetails?index=0',
		icon: 'capital_deatil'
	}, 
	// {
	// 	name: LANGUAGE_DATA.ABOUT,
	// 	url: 'about',
	// 	icon: 'about'
	// },
	]
};

const TRADE_LOG_STATUS =[
	{label:'審査待ち',color:'gray'},
	{label:'約定',color:'red'},
	{label:'拒否する',color:'green'}];
// 1是通过   0是待审核   2是拒绝     通过红色   拒绝绿色   待审核灰色
const calcTradeLogStatusLabel=(val)=>{
	return TRADE_LOG_STATUS[val].label;
}
const calcTradeLogStatusColor=(val)=>{
	return TRADE_LOG_STATUS[val].color;
}

const UTIL = {
	THEME,
	calcImageSize,
	formatNumber,
	formatDate,
	calcPageHeight,
	calcListHeight,
	businessBtnsConfig,
	mqBtnsConfig,
	navListAuthConfig,
	navListConfig,
	calcTradeLogStatusLabel,
	calcTradeLogStatusColor,
}

export default UTIL;