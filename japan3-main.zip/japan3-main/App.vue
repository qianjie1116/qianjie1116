<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show',uni.getLocale())
			
			this.$i18n.locale = uni.getLocale();
		
			uni.setLocale("ja");
			if(uni.getLocale()=="zh-Hant"){
				uni.setLocale("ja");
			}
		},
		onHide: function() {
			console.log('App Hide')
		},
	}
</script>

<style lang="scss">
	
	@import "@/node_modules/uview-ui/index.scss";
	
	@import url("common/css/rc.css");
	// @import url("common/css/icon.css");
	
	@import url("common/style.css");
	//公共css 结束
	@media (min-width: 1000px) {
		page {
			width: 900rpx;
			margin: auto;
		}
	
		/deep/.uni-tabbar {
			width: 900rpx !important;
			margin: auto;
		}
	}
	view{
		font-size: 14px;
	}


	//版本更新
	.download .upgrade {
		position: relative;
		background: #fff;
		width: 468rpx;
		min-height: 238rpx;
		border-radius: 20rpx;
	}

	.download .logo image {
		width: 208rpx;
		height: 208rpx;
		position: absolute;
		top: -80rpx;
		left: 0;
		right: 0;
		margin: 0 auto;
	}

	.download .content {
		padding-top: 80rpx;
	}

	.download .content .title {
		text-align: center;
		font-size: 30rpx;
		font-weight: bold;
	}

	.download .content .container {
		color: #666;
	}

	.download .content .container .descriptions {
		padding: 0rpx 30rpx;
		text-align: center;
		font-size: 28rpx;
	}

	.download .content .container .details,
	.download .content .prpgroess {
		padding: 16rpx 46rpx;
		box-sizing: border-box;
		font-size: 24rpx;
	}

	.download .content .prpgroess {
		padding: 16rpx 22rpx;
		margin: 20rpx 0;
	}

	.download .content .btn-group {
		display: flex;
		justify-content: center;
		align-items: center;
		margin-top: 20rpx;
	}

	.download .content .btn-group view {
		width: 200rpx;
		height: 68rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		margin: 14rpx;
		font-size: 24rpx;
		border-radius: 16rpx;
		line-height: 1.5;
	}

	.download .content .btn-group .confirm {
		background: #ef5656;
		color: #fff;
	}
	
</style>