<!-- 登录 -->
<template>
	<view class="signin">
		<view
			style="display: flex;flex-direction: column;align-items: center; justify-content: center;padding-top:6vh;width: 80%;">
			<image mode="aspectFit" src="/static/chuanggai/logo.png" :style="$util.calcImageSize(150)"></image>
			<view style="height: 30px; text-align: center;font-size: 18px;font-weight: bold;">プラチナ・エクスプローラー</view>
			
			
			<u--input shape="circle" :placeholder="$t('index.Please_ente_ your_phone_number')" prefixIcon="account-fill"
				color='#121212' placeholderStyle="font-size: 14px;color: #999"
				prefixIconStyle="font-size: 30px;color: #999;margin-left:10px" v-model="value1" type="number"
				maxlength="11" style="margin-top:30px;background-color: rgba(255,255,255,0.75);width: 100%;"></u--input>
				
				
			<u--input shape="circle" :placeholder="$lang.PASSWORD" prefixIcon="lock-fill" color='#121212'
				placeholderStyle="font-size: 14px;color: #999"
				prefixIconStyle="font-size: 30px;color: #999;margin-left:10px" v-model="value2" type="password"
				style="margin-top:20px;background-color: rgba(255,255,255,0.75);width: 100%;"></u--input>

			<!-- <view style="width: 90%;margin-top:4px;line-height: 20px;height: 20px;position: relative;">
			<u-checkbox-group>
				<u-checkbox :activeColor="$util.THEME.PRIMARY" label="ログインしたまま" v-model="checked"
					labelColor="#B3BFD0"></u-checkbox>
			</u-checkbox-group>
			<view
				style="font-size: 14px;color: #ababab;position: absolute;top: 50%;transform: translateY(-50%);right: 0;"
				@tap="register()">
				{{$lang.SIGN_UP}}
				<u-icon name="arrow-right" color="#B3BFD0" size="14" :bold="true"
					style="display: inline-block;"></u-icon>
			</view>
		</view>
			</view> -->
			<view class="common_btn" style="width: 100%;margin-top: 20px; background-color: #ff0000;font-size: 16px;"
				@click="gain_login()">{{$lang.SIGN_IN}}</view>

			<view style="width: 90%;margin-top:4px;line-height: 20px;height: 20px;position: relative;">
				<!-- <u-checkbox-group>
					<u-checkbox :activeColor="$util.THEME.PRIMARY" label="ログインしたまま" v-model="checked"
						labelColor="#B3BFD0"></u-checkbox> -->
				</u-checkbox-group>
				<view
					style="font-size: 18px;  color: #ff0000;position: absolute;top: 50%;transform: translateY(30%);right: 80px;"
					@tap="register()">
					{{$lang.SIGN_UP}}
					<u-icon name="arrow-right" color="#ff0000" size="14" :bold="true"
						style="display: inline-block; margin-left: 10px;"></u-icon>
				</view>
			</view>
		</view>
	</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				value1: "",
				value2: '',
				checked: false,
			};
		},
		onShow() {
			let userinput = uni.getStorageSync('userinput');
			let passinput = uni.getStorageSync('passinput');
			console.log(userinput);

			if (userinput) {
				this.value1 = userinput
			}
			if (passinput) {
				this.value2 = passinput
			}

		},
		methods: {
			register() {
				console.log(22222)

				// uni.navigateTo({
				// 	url:"/pages/register/register"
				// })
				uni.redirectTo({
					url: "/pages/register/register"
				})
			},
			//登录
			async gain_login() {
				let list = await this.$http.post('api/app/login', {
					username: this.value1,
					password: this.value2,
				})
				if (list.data.code == 0) {
					const token = list.data.data.token.access_token
					uni.setStorageSync('token', token);
					uni.setStorageSync('userinput', this.value1);
					uni.setStorageSync('passinput', this.value2);
					uni.$u.toast(this.$t('index.successful_login'));
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/index/index',
						});
						this.$router.go(0)
					}, 100)

				} else {
					uni.$u.toast(list.data.message);
				}
			},
		},
		async mounted() {}
	}
</script>