<!-- 客服 -->
<template>
	<view>
		<template>
			<web-view :src="list"></web-view>
		</template>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: "",
				full: false,
				webviewStyles: {
					height: '91vh',
					width: "100%",
				},
				webview: {
					height: '91vh',
					width: "100%",
				},
			};
		},
		methods: {
			home() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			async get_url() {
				let list = await this.$http.get('api/app/config', {})
				this.list = list.data.data[8].value
			},
		},
		mounted() {
			this.get_url()
		},
	}
</script>

<style lang="scss">
	::v-deep .uni-page-head {
		background: #007AFF !important;
		color: #fff !important;
	}

	iframe {
		width: 600px !important;
	}

	/deep/ .webview {
		width: 100% !important;
		height: 100% !important;
	}
</style>