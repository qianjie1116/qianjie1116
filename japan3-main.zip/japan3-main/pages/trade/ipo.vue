<!-- 新股申购 -->
<template>
	<view>
		<CustomHeader title="ブックビルディング" @action="handleBack()"></CustomHeader>
		<!-- <view style="display: flex;align-items: center;justify-content:space-around;" class="margin-left-10 margin-right-10 gap20">
			<view @click="handleChangeTab(0)" class="common_btn btn_primary flex-1" style="padding:2px 4ma;">
				申込履歴</view>
			<view @click="handleChangeTab(1)" class="common_btn btn_secondary flex-1" style="padding:2px 4px;">
				当選履歴</view>
		</view> -->
		<view class="margin-top-20">
			<view class="white-background">
				<view class="take-notes">
					<view class="purchase" @tap="applyPurchase()">
						<image src="../../static/erceng/shengou.png" mode=""></image>
						<view class="">{{$t('index.dyjl')}}</view>
					</view>
					<view class="purchase" @tap="luckyNumber()">
						<image src="../../static/erceng/shengou.png" mode=""></image>
						<view class="">
							{{$t('index.hsjl')}}
						</view>
					</view>
				</view>
			</view>
			<view class="padding-10">
				<view
					style="box-shadow: rgba(0, 0, 0, 0.05) 0px 6px 24px 0px, rgba(0, 0, 0, 0.08) 0px 0px 0px 1px;background-color: #f5f6f7;"
					v-for="(item,index) in list" :key="item.index">
					<view style="background-color: #fff;" class="padding-10">
						<view class="flex">
							<view class="radius10 color-white font-size-12"
								style="background-color: #dc004c;padding: 2px 5px;">
								IPO
							</view>
							<view class="bold font-size-16 margin-left-10">{{item.goods.name}}</view>
						</view>
						<view class="hui2">{{item.jianjie}}</view>
						<u-button color="#212487" class="margin-top-10"  @click="id=item.id;show_mima=true">
							{{ $t('index.tsjsyy') + '&nbsp;&nbsp;&nbsp;' + '' }}</u-button>
						<view class="margin-top-10">

							<view class="flex flex-b padding-bottom-10" style="border-bottom: 1px solid #fff;">
								<view>{{$t('index.fxjh')}}</view>
								<view>{{$t('index.zdtj')}}</view>
							</view>
							<view class="flex flex-b padding-bottom-10"
								style="border-bottom: 1px solid #e6e8f0;margin-top: -10px;">
								<view>{{$t('index.xsjg')}}</view>
								<view>{{item.price}}{{$t('index.dw_')}}</view>
							</view>
							<view class="flex flex-b padding-bottom-10" style="border-bottom: 1px solid #e6e8f0;">
								<view>{{$t('index.sqdw')}}</view>
								<view>{{$t('index.100g')}}</view>
							</view>
							<view class="flex flex-b padding-bottom-10" style="border-bottom: 1px solid #e6e8f0;">
								<view>{{$t('index.ssr')}}</view>
								<view>{{item.online_date}}</view>
							</view>

						</view>
					</view>
					<view class="margin-top-10 padding-10">
						<view class="flex flex-c gap10">
							<view style="border: 1px solid #092987;height: 25px;"
								class="flex-1 padding-10 text-center flex  justify-center" @click="webview(item.baipi)"  v-if="item.baipi">
								{{$t('index.zgsms')}}
								<u-icon
									name="https://sbisec.akamaized.net/sbisec/sp/static/2.3.0/images/pdf_primary.svg"></u-icon>
							</view>
							<view style="border: 1px solid #092987;height: 25px;"
								class="flex-1 padding-10 text-center flex  justify-center"
								v-if="item.guanwang"
								@click="webview(item.guanwang)">
								{{$t('index.wz')}}
								<u-icon name="share-square" size="24" color="#092987"></u-icon>
							</view>

						</view>
						<view class="margin-top-10 hui margin-bottom-10">
							<u-parse :content="item.content"></u-parse>
						</view>
					</view>

				</view>

				<view class="finished-text">
					{{$t('index.eryi')}}
				</view>

			</view>
			<u-modal :show="show_mima" :confirm-text="$t('index.tc')" @close="show_mima=false" @confirm="purchase()"
				:closeOnClickOverlay="true">
				<u--input :placeholder="$t('index.qsrsgsl')" border="surround" type="number"
					v-model="number"></u--input>
			</u-modal>
		</view>





		<!-- <view style="margin: 10px;background-color: #FFF;padding: 10px;min-height: 88vh;">
			<EmptyData v-if="list.length<=0"></EmptyData>
			<template v-if="current == 0">
				<block v-for="(item,index) in list" :key="index">
					<view style="border-bottom: 0.01rem solid #e0e0e0;">
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$util.THEME.TEXT}" style="font-size: 18px;">{{item.goods.name}}</view>
							<view @click="to_skip(item.id)" class="common_btn btn_primary font-size-16"
								style="padding:2px 10px;transform: scale(0.75);margin-top: 0;">購読申し込み</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$util.THEME.TIP}">申請金額</view>
							<view :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(item.price)}}</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$util.THEME.TIP}">収益率</view>
							<view :style="{color:$util.THEME.PRIMARY}">{{$util.formatNumber(item.shiying)}}</view>
						</view>
						<view style="display: flex;align-items: center;justify-content: space-between;">
							<view :style="{color:$util.THEME.TIP}">申請日</view>
							<view :style="{color:$util.THEME.TIP}">{{item.shengou_date}}</view>
						</view>
					</view>
				</block>
			</template>

			<template v-else>
				<block v-for="(item,index) in list" :key="index">
					<view style="border-bottom: 2rpx solid #e0e0e0;padding-bottom:20rpx;">
						<view class="display approve">
							<view>
								<view class="corporation">{{item.goods.name}}</view>
								
							</view>
							<view class="subscription-times">購読時間<text>{{item.shengou_date}}</text> </view>
						</view>

						<view class="display" style="margin-top: 10rpx;">
							<view class="display price">購読価格<text>{{$util.formatNumber(item.price)}}</text>
							</view>
							<view class="display price">
								株価収益率<text>{{$util.formatNumber(item.shiying)}}</text>
							</view>
						</view>
						<view class="display price">
							循環<text>{{$util.formatNumber(item.fa_amount)}}</text>
						</view>
					</view>
				</block>
			</template>
		</view>
	</view> -->
	</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				content: 0,
				show_mima:false,
				id:0,
				number:"",
				list:''
		
			};
		},
		
		onLoad(item) {},
		onShow() {
			this.getList();
		},

		methods: {
			handleBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			handleChangeTab(val) {
				if (val == 0) {
					this.applyPurchase();
				} else if (val == 1) {
					this.luckyNumber();
				}
			},
			to_skip(id) {
				uni.navigateTo({
					url: `/pages/index/components/newShares/nullElement/nullElement?id=${id}`
				});
				// console.log(gid, fa_price, '携带');
			},
			async purchase() {
				if(this.number<=0){
					return uni.$u.toast(this.$t('index.qsrzqdsl'));
				}
				let list = await this.$http.post('api/goods-shengou/doOrder', {
					num: this.number,
					id: this.id,
					// price: this.price
				})
				if (list.data.code == 0) {
					uni.showLoading({
						title: this.$t('index.Your_subscription_is_in_progress_Please_wait_a_moment'),
						mask: true, // 显示透明蒙层，防止触摸穿透
					});
					setTimeout(() => {
						uni.navigateTo({
							url: '/pages/trade/ipoLog'
						});
						uni.hideLoading();
					}, 1000)
				} else {
					uni.$u.toast(list.data.message);
				}
			},
			webview(url){
				
				uni.navigateTo({
					url:"/pages/index/webview?url="+encodeURIComponent(url)
				})
			},
			//구독기록
			applyPurchase() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/applyPurchase/applyPurchase'
				});
			},
			//우승기록
			luckyNumber() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/luckyNumber/luckyNumber'
				});
			},
			
			to_skip(id) {
				uni.navigateTo({
					url: '/pages/index/components/newShares/nullElement/nullElement' +
						`?id=${id}`
				});
				// console.log(gid, fa_price, '携带');
			
			},

			async getList() {
				uni.showLoading({
					title: this.$lang.LOADING,
				})
				const result = await this.$http.post(`api/goods-shengou/calendar`, {
					type: this.current + 1, // 传参 1或2
				})
				this.list = result.data.data;
				uni.hideLoading();
			},

			//구독기록 订阅记录
			applyPurchase() {
				uni.navigateTo({
					url: `/pages/trade/ipoLog`
				});
			},
			//우승기록 获胜记录
			luckyNumber() {
				uni.navigateTo({
					url: '/pages/index/components/newShares/luckyNumber/luckyNumber'
				});
			},
		}
	}
</script>
<style lang="scss">
	//公共css 开始
	.display {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	/deep/uni-rich-text span {
		background-color: #f5f6f7 !important;
		color: #676b74 !important;
	}

	//깊은북쪽상하이
	.area {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	//깊은
	.deep {
		width: 30rpx;
		height: 30rpx;
		background: #f85252;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.deep-number {
		display: inline-block;
		padding: 0 0.04rem;
		background: rgba(59, 79, 222, .1);
		border-radius: 10rpx;
		color: #f85252;
		font-size: 24rpx;
		vertical-align: middle;
	}


	//북쪽
	.north {
		width: 30rpx;
		height: 30rpx;
		background: #ea6248;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.north-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #ea6248;
		background: rgba(234, 98, 72, .1);
	}

	//상하이
	.shanghai {
		width: 30rpx;
		height: 30rpx;
		background: #aa3bde;
		border-radius: 0.4rpx;
		text-align: center;
		line-height: 30rpx;
		color: #fff;
		font-size: 24rpx;
		display: inline-block;
	}

	.shanghai-number {
		display: inline-block;
		padding: 0 0.04rem;
		border-radius: 10rpx;
		font-size: 24rpx;
		vertical-align: middle;
		color: #aa3bde;
		background: rgba(170, 59, 222, .1);
	}

	//公共css 结束

	// 没有更多
	.finished-text {
		color: #969799;
		font-size: 28rpx;
		margin: 30rpx auto;
		text-align: center;
		padding: 30rpx 0;
	}

	// 新购申购 开始
	.white-background {
		background: #fff;
		margin-top: -50rpx;
		border-radius: 20rpx 20rpx 0 0;

		.take-notes {
			display: flex;
			justify-content: space-around;
			align-items: center;
			text-align: center;
			padding: 60rpx 60rpx 30rpx;

			.purchase {
				font-size: 28rpx;

				image {
					width: 40rpx;
					height: 40rpx;
				}
			}
		}
	}

	// .tab-header {
	// 	background-color: #aac0ff;
	// 	height: 60rpx;
	// 	display: flex;
	// }

	.tab-content {
		font-size: 28rpx;
		flex: 1;
		text-align: center;
		color: #363636;
		height: 60rpx;
		line-height: 60rpx;
		position: relative;
	}

	.content-selection {
		font-size: 28rpx;
		font-family: PingFang SC;
		font-weight: bold;
		color: #f85050;
	}

	.approve {
		padding: 30rpx 30rpx 0;

		.corporation {
			font-size: 30rpx;
			font-weight: 800;
			margin-bottom: 10rpx;
		}

		.zero {
			display: flex;
			justify-content: space-around;
			align-items: center;
			background-color: #ea6248;
			border-radius: 20px;
			color: #fff;
			margin: 20rpx 0rpx 20rpx 20rpx;
			height: 50rpx;
			width: 220rpx;
			font-size: 22rpx;

		}

		.thousand {
			display: flex;
			justify-content: space-around;
			align-items: center;
			background-image: url('../../static/erceng/shen2.png');
			background-size: cover;
			color: #fff;
			margin: 20rpx 20rpx;
			height: 50rpx;
			width: 220rpx;
			font-size: 24rpx;
		}
	}

	.treat {
		display: flex;
		justify-content: flex-start;
		align-items: center;

		.subscription {
			margin-right: 100rpx;
		}
	}

	.subscription-time {
		margin: 6rpx 30rpx;
		font-size: 28rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;

		text {
			color: #f85252;
			margin-left: 10rpx;
		}
	}

	.subscription-times {
		// margin: 10rpx 20rpx;
		font-size: 28rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;
		width: 44%;

		text {
			color: #f85252;
			// margin-left: 10rpx;
		}
	}

	.price {
		margin: 6rpx 30rpx;
		width: 42%;
		font-size: 28rpx;

		text {
			color: #f85252;
			// margin-left: 10rpx;
		}
	}

	// 新购申购 结束
</style>