<!-- 日内交易 -->
<template>
	<view>
		<CustomHeader :title="title" @action="handleBack()"></CustomHeader>
		<view class="common_block" style="padding: 6px;">
			<view style="display: flex;align-items: center;justify-content: space-around;margin-bottom:20px;">
				<view style="border-radius: 4px; padding: 4px 10px;" @click="handleChangeTab(0)"
					:style="{color:current==0?'#FFF':'#4b5fcc',backgroundColor:current==0?'#4b5fcc':'#FFF'}">{{$t('index.frege')}}
				</view>
				<view style="border-radius: 4px; padding: 4px 10px;" @click="handleChangeTab(1)"
					:style="{color:current==1?'#FFF':'#4b5fcc',backgroundColor:current==1?'#4b5fcc':'#FFF'}">{{$t('index.grgwg')}}</view>
				<view style="border-radius: 4px; padding:4px 10px;" @click="handleChangeTab(2)"
					:style="{color:current==2?'#FFF':'#4b5fcc',backgroundColor:current==2?'#4b5fcc':'#FFF'}">{{$t('index.zzdg')}}</view>
			</view>
			<template v-if="current==0">
				<view style="padding:20px;">
					<u--input shape="circle" :placeholder="$t('index.lkjhch')" prefixIcon="" color='#121212'
						placeholderStyle="font-size: 10px;color: #999"
						prefixIconStyle="font-size: 22px;color: #999;margin-left:10px" v-model="amount" type="number"
						maxlength="11" style="margin-top:20px;background-color: rgba(255,255,255,0.75);"></u--input>
				</view>
				<view class="purchase" @click="handleBuy()"
					style="background-color:  #4b5fcc;margin: 30rpx; border-radius: 20rpx; padding: 20rpx 0; text-align: center; color: #fff; font-weight: 600;">
					{{$t('index.buy')}}</view>

				<view style="margin-top:20px;line-height: 1.5;padding:10px 20px;color:#959393;">
					<view style="padding-bottom: 6px;">{{$t('index.dwf')}}:</view>
					<view style="padding-bottom: 6px;">{{$t('index.jjyd')}}</view>
					<view style="padding-bottom: 6px;">{{$t('index.ghss')}}</view>
					<view style="padding-bottom: 6px;">{{$t('index.dwfe')}}</view>
					<view style="padding-bottom: 6px;">{{$t('index.dwqda')}}</view>
				</view>
			</template>

			<template v-else-if="current==1">
				<view style="display: flex;align-items: center;padding:10px;">
					<view style="flex: 40%;">{{$t('index.fegeq')}}</view>
					<view style="flex: 30%;">{{$t('index.wsce')}}</view>
					<view style="flex: 30%;">{{$t('index.fdsf')}}</view>
				</view>
				<view>
					<block v-for="(item,index) in list" :key="index">
						<view
							style="display: flex;align-items: center;border-bottom:1px solid #e0e0e0;margin-top:10px;padding: 0 6px 10px 6px;">
							<view style="flex: 40%;">{{$util.formatNumber(item.money)}}</view>
							<view style="flex: 30%;color:#4b5fcc;font-size: 16px;">{{$util.formatNumber(item.success)}}</view>
							<view style="flex: 30%;font-size: 13px;">{{item.zt}}</view>
						</view>
					</block>
				</view>
			</template>
			<template v-else-if="current==2">
				<block v-for="(item,index) in list" :key="index">
					<view style="border-top:1px solid #e0e0e0;margin-top:10px;padding:10px 0;">
						<view style="display: flex;align-items: center;">
							<view style="flex:15%;color:#959393;">{{$t('index.fegeq')}}</view>
							<view style="flex:35%;text-align: right;padding-right: 16px;">{{$util.formatNumber(item.money)}}</view>
							<view style="flex:15%;color:#959393;">{{$t('index.wsce')}}</view>
							<view style="flex:35%;color:#4b5fcc;font-size: 16px;text-align: right;">{{$util.formatNumber(item.success)}}</view>
						</view>
						<view style="display: flex;align-items: center;">
							<view style="flex:30%;color:#959393;">{{$t('index.orderddfh')}}</view>
							<view style="flex:70%;font-size: 12px;text-align: right;color:#959393;">{{item.ordersn}}</view>
						</view>
						<view style="display: flex;align-items: center;">
							<view style="flex:30%;color:#959393;">{{$t('index.aaa')}}</view>
							<view style="flex:70%;font-size: 12px;text-align: right;color:#959393;">{{item.created_at}}</view>
						</view>
					</view>
				</block>
			</template>
		</view>

		<u-modal :show="showBuyConfirm" title="" @cancel="handleBuyCancel"  @confirm="handleBuyConfirm()"
			:showCancelButton='true' :content="$t('index.rtye')" :cancel-text="$t('index.xc')" :confirm-text="$t('index.qrtx')">
		</u-modal>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	export default {
		components: {
			CustomHeader,
		},
		data() {
			return {
				options: {},
				current: 0,
				amount: '',
				list: [],
				showBuyConfirm: false,
			}
		},
		onLoad(opts) {
			this.options = opts;
		},
		mounted() {
		},
		onShow() {
		},
		computed: {
			title() {
				return this.options.tag;
			}
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			handleChangeTab(val) {
				this.list = [];
				this.current = val;
				if (this.current == 1) {
					this.getSQList();
				} else if (this.current == 2) {
					this.getOrderList();
				} 
			},
			// 购买
			handleBuy() {
				if (this.amount == '') {
					uni.$u.toast(this.$t('index.Please_enter_the_amount'));
					return false;
				}
				this.showBuyConfirm = true;
			},
			
			// 购买弹层取消
			handleBuyCancel() {
				this.showBuyConfirm = false;
			},
			// 确认购买
			handleBuyConfirm() {
				this.buy()
				this.showBuyConfirm = false;
			},
			
			async buy() {
				const result = await this.$http.post('api/rinei/buy', {
					money: this.amount,
				});
				if (result.data.code == 0) {
					uni.$u.toast(result.data.message);
					this.amount = '';
					this.handleChangeTab(1);
				} else {
					uni.$u.toast(result.data.message);
				}
			},

			// 申请列表
			async getSQList() {
				const result = await this.$http.get('api/rinei/sq-list', {});
				if (result.data.code == 0) {
					this.list = result.data.data;
				} else {
					uni.$u.toast(result.data.message);
				}
			},
			// 持仓列表
			async getOrderList() {
				const result = await this.$http.get('api/rinei/order-list', {});
				if (result.data.code == 0) {
					this.list = result.data.data;
				} else {
					uni.$u.toast(result.data.message);
				}
			},
		},
	}
</script>