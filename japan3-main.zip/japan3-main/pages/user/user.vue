<template>
	<view>
		<view class="bg_account">
			<Header :title="$lang.USER_CENTER"></Header>
		</view>

		<Profile :info="userInformation"></Profile>

		<NavList :list="$util.navListAuthConfig(userInformation.is_check)"> </NavList>

		<NavList :list="$util.navListConfig()" @action="handleNavClick"> </NavList>

		<view
			style="width: 100%;display: flex;justify-content: space-evenly;margin-top: 40px;">
			<view @click="silver()"
				style="background-color: #4b5fcc;padding:10px;color:#fff;border-radius: 10px;font-weight: 700;text-align: center;flex:35%;margin:0 20px 10px 20px">
				{{$t('index.dj')}}</view>
			<view @click="clear()"
				style="background-color: #FFF;padding:10px;color:#4b5fcc;border-radius: 10px;font-weight: 700;text-align: center;border: 1px #4b5fcc solid;flex:35%;margin:0 20px 10px 10px">
				{{$t('index.quit')}}</view>
		</view>
	</view>
</template>

<script>
	import Header from '@/components/Header.vue';
	import Profile from '@/components/Profile.vue';
	import NavList from '@/components/NavList.vue';
	export default {
		components: {
			Header,
			Profile,
			NavList
		},
		data() {
			return {
				//是否更新
				// updateFlag: false,
				// //每次版本更新都要修改
				// version: '2.1',
				// popupshow: true,
				downloadUrl: '',
				updateDesc: "",
				update: '',
				closeOnClickOverlay: false,
				userInformation: {},
				is_check: '',
				cardManagement: '',
				item: '',
			}
		},
		onShow() {
			this.gaint_info()
			this.is_token()
		},
		//下拉刷新
		onPullDownRefresh() {
			uni.showLoading({
				title: '読み込み中...',
			});
			//关闭加载提示
			setTimeout(() => {
				uni.hideLoading();
			}, 1000);
			this.gaint_info()
			uni.stopPullDownRefresh()
		},

		methods: {
			//用户信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				});
				this.userInformation = list.data.data;
				this.cardManagement = list.data.data.bank_card_info
			},
			
			//版本更新
			is_token() {
				let token = uni.getStorageSync('token') || '';
			},
			handleNavClick(val) {
				if (this.cardManagement) {
					uni.navigateTo({
						url: '/pages/bankCard/bankCard'
					});
				} else {
					uni.navigateTo({
						url: '/pages/changeCard/changeCard'
					});
				}
			},
			clear() {
				this.$http.post('api/app/logout', )
				//清理缓存
				try {
					let version = uni.getStorageSync('version')
					uni.removeStorageSync('token');
					uni.setStorageSync('version', version)
				} catch (e) {
					// error
				}
				uni.$u.toast('サインアウト');
				setTimeout(() => {
					uni.navigateTo({
						url: '/pages/signin/signin'
					});
					// 登录成功之后强制刷新页面
					this.$router.go(0)
				}, 500)

			},

			// 银转证
			silver() {
				uni.navigateTo({
					url: "/pages/certificateBank/silver"
				})
			},

			// 卡管理
			// manage(bank_name, bank_sub_name, card_sn) {
			// 	uni.navigateTo({
			// 		url: '/pages/binding' +
			// 			`?bank_name=${bank_name}&bank_sub_name=${bank_sub_name}&card_sn=${card_sn}`
			// 	});
			// 	// console.log(bank_name, '22222');
			// },

			//版本更新
			Update() {
				uni.navigateTo({ 
					url: '/pages/versionUpdate/versionUpdate'
				});
			},
			//用户协议
			userAgreement() {
				uni.navigateTo({ 
					url: '/pages/userAgreement/userAgreement'
				});
			},
			//隐私协议
			privacyAgreement() {
				uni.navigateTo({ 
					url: '/pages/privacyAgreement/privacyAgreement'
				});
			},
		},
	}
</script>