<!-- 银转证 -->
<template>
	<view >
		<CustomHeader :title="$t('index.ckxx')" @action="handleBack()"></CustomHeader>
		<view
			style="padding: 10px;margin:10px 10px;background-color: #fff;border-radius: 10px;box-shadow: rgba(0, 0, 0, 0.15) 1.95px 1.95px 2.6px;">
		<view style="text-align: center; font-size: 52rpx;
		color: #4b5fcc;
		margin: 5px 0;"> {{userInformation.money}}</view>
			<view style="text-align: center;
		color: #f47b78;
		font-size: 26rpx;margin: 5px 0;">{{$t('index.dqkyye')}}</view>

			<view style="display: flex;justify-content:center;align-items: center;">
				<view v-for="(item,index) in items" :key="index"
					style="border-radius: 100px;height: 24px;text-align: center;line-height: 24px;width: 100px;"
					:style="{color:Inv==index?'#FFF':'#666',backgroundColor:Inv==index?'#f85252':''}"
					@click="Inv=index">{{item}} </view>
			</view>

			<view v-show="Inv == 0">
				<view
					style="display: flex;align-items: center;font-size:14px;color: #000;font-weight: 700;padding:10px;border-bottom:1px solid #ccc;margin-top: 10px;">
					<text style="flex:20%;">{{$t('index.yhm')}}</text>
					<text style="flex:60%;text-align: center;font-weight: 500;">   </text>
					<text style="flex:20%;text-align: right;" @click="copy(BankUser)">{{$t('index.copy')}}</text>
					<!-- <view class="duplicate" @tap="service()">客服</view> -->
				</view>
				<view
					style="display: flex;align-items: center;font-size:14px;color: #000;font-weight: 700;padding:10px;border-bottom:1px solid #ccc;margin-top: 10px;">
					<text style="flex:20%;">{{$t('index.zdm')}}</text>
					<text style="flex:60%;text-align: center;font-weight: 500;" @click="service()">  </text>
					<text style="flex:20%;text-align: right;" @click="copy(BankName)">{{$t('index.copy')}}</text>
				</view>
				<view
					style="display: flex;align-items: center;font-size:14px;color: #000;font-weight: 700;padding:10px;border-bottom:1px solid #ccc;margin-top: 10px;">
					<text style="flex:20%;">支店番号</text>
					<text style="flex:60%;text-align: center;font-weight: 500;">{{BankNo}}</text>
					<text style="flex:20%;text-align: right;" @click="copy(BankNo)">{{$t('index.copy')}}</text>
				</view>
				
				<view
					style="display: flex;align-items: center;font-size:14px;color: #000;font-weight: 700;padding:10px;border-bottom:1px solid #ccc;margin-top: 10px;">
					<text style="flex:20%;">取引種類</text>
					<text style="flex:60%;text-align: center;font-weight: 500;">{{Transaction_type}}</text>
					<text style="flex:20%;text-align: right;" @click="copy(Transaction_type)">{{$t('index.copy')}}</text>
				</view>
				<view
					style="display: flex;align-items: center;font-size:14px;color: #000;font-weight: 700;padding:10px;border-bottom:1px solid #ccc;margin-top: 10px;">
					<text style="flex:20%;">口座名義</text>
					<text style="flex:60%;text-align: center;font-weight: 500;">{{Account_number}}</text>
					<text style="flex:20%;text-align: right;" @click="copy(Account_number)">{{$t('index.copy')}}</text>
				</view>
				<view
					style="display: flex;align-items: center;font-size:14px;color: #000;font-weight: 700;padding:10px;border-bottom:1px solid #ccc;margin-top: 10px;">
					<text style="flex:20%;">口座番号</text>
					<text style="flex:60%;text-align: center;font-weight: 500;">{{Account_holder}}</text>
					<text style="flex:20%;text-align: right;" @click="copy(Account_holder)">{{$t('index.copy')}}</text>
				</view>
				
				
			</view>
			

			<view v-show="Inv == 1">
				<view
					style="display: flex;align-items: center;font-size:14px;color: #000;font-weight: 700;padding:10px;border-bottom:1px solid #ccc;margin-top: 10px;">
					<text style="flex:20%;">{{$t('index.yhm')}}</text>
					<text style="flex:60%;text-align: center;font-weight: 500;">   </text>
					<text style="flex:20%;text-align: right;" @click="copy(BankUser)">{{$t('index.copy')}}</text>
					<!-- <view class="duplicate" @tap="service()">客服</view> -->
				</view>
				<view
					style="display: flex;align-items: center;font-size:14px;color: #000;font-weight: 700;padding:10px;border-bottom:1px solid #ccc;margin-top: 10px;">
					<text style="flex:20%;">{{$t('index.zdm')}}</text>
					<text style="flex:60%;text-align: center;font-weight: 500;" @click="service()">  </text>
					<text style="flex:20%;text-align: right;" @click="copy(BankName)">{{$t('index.copy')}}</text>
				</view>
				<view
					style="display: flex;align-items: center;font-size:14px;color: #000;font-weight: 700;padding:10px;border-bottom:1px solid #ccc;margin-top: 10px;">
					<text style="flex:20%;">支店番号</text>
					<text style="flex:60%;text-align: center;font-weight: 500;">{{BankNo}}</text>
					<text style="flex:20%;text-align: right;" @click="copy(BankNo)">{{$t('index.copy')}}</text>
				</view>
				
				<view
					style="display: flex;align-items: center;font-size:14px;color: #000;font-weight: 700;padding:10px;border-bottom:1px solid #ccc;margin-top: 10px;">
					<text style="flex:20%;">取引種類</text>
					<text style="flex:60%;text-align: center;font-weight: 500;">{{Transaction_type2}}</text>
					<text style="flex:20%;text-align: right;" @click="copy(Transaction_type2)">{{$t('index.copy')}}</text>
				</view>
				<view
					style="display: flex;align-items: center;font-size:14px;color: #000;font-weight: 700;padding:10px;border-bottom:1px solid #ccc;margin-top: 10px;">
					<text style="flex:20%;">口座名義</text>
					<text style="flex:60%;text-align: center;font-weight: 500;">{{Account_number2}}</text>
					<text style="flex:20%;text-align: right;" @click="copy(Account_number2)">{{$t('index.copy')}}</text>
				</view>
				<view
					style="display: flex;align-items: center;font-size:14px;color: #000;font-weight: 700;padding:10px;border-bottom:1px solid #ccc;margin-top: 10px;">
					<text style="flex:20%;">口座番号</text>
					<text style="flex:60%;text-align: center;font-weight: 500;">{{Account_holder2}}</text>
					<text style="flex:20%;text-align: right;" @click="copy(Account_holder2)">{{$t('index.copy')}}</text>
				</view>
			</view>
			<!-- 查看 -->
			<view
				style="display: flex;align-items: center;font-size:14px;color: #000;font-weight: 700;padding:10px;border-bottom:1px solid #ccc;margin-top: 10px;">
				<text style="flex:20%;">{{$t('index.czjl')}}</text>
				<text style="flex:60%;text-align: center;font-weight: 500;"> </text>
				<text style="flex:20%;text-align: right;" @tap="capitalDetails()">{{$t('index.ck')}}</text>
			</view>

			<!-- 充值金额 -->
			<view style="display: flex;align-items: center;font-size:12px;color: #000;padding:10px;margin-top: 10px;">
				<text style="flex:20%;">{{$t('index.sfje')}}</text>
				<text style="flex:60%;text-align: center;font-weight: 500;color:#ccc;">{{$t('index.zdczjew')}} <text
						style="color:#f85252">{{$t('index.yuan')}}</text></text>
				<text style="flex:20%;text-align: right;"></text>
			</view>

			<view class="recharge">
				<input :placeholder="$t('index.qsrczje')" type="number" v-model="value1"></input>
				<view class="select">
					<view :style="{ 'background':shadow,'color':character}" @click="quantity('1000000')">1000000
					</view>
					<view :style="{ 'background':shadow1, 'color':character1}" @click="quantity('5000000')">
						5000000
					</view>
					<view :style="{ 'background':shadow2, 'color':character2}" @click="quantity('10000000')">
						10000000
					</view>
					<view :style="{ 'background':shadow3, 'color':character3}" @click="quantity('50000000')">
						50000000
					</view>
				</view>
			</view>
<!-- 			<view style="display: flex;align-items: center;font-size:12px;color: #000;padding:10px;margin-top: 10px;">
				<text style="flex:30%;text-align: left;">인증서 업로드</text>
				<text style="flex:60%;text-align: center;font-weight: 500;color:#ccc;">인증서를 업로드하렴 클릭하세요.</text>
				<text style="flex:10%;text-align: right;"></text>
			</view> -->
			
<!-- 			<u-upload
				:fileList="fileList6"
				@afterRead="afterRead"
				@delete="deletePic"
				name="6"
				multiple
				:maxCount="1"
				width="250"
				height="150"
				style="margin:10vw;"
			>
				<image src="/static/positive.png" 
				mode="widthFix" style="width: 250px;height: 150px;"></image>
			</u-upload> -->
			
			<!-- 儲值 -->
			<view @click="to_recharge()" style="background-color:#4b5fcc;margin: 50rpx 30rpx;
					border-radius: 10rpx;
					padding: 20rpx 0;
					text-align: center;
					color: #fff;
					font-size: 28rpx;">
				{{$t('index.dj')}}
			</view>
			<view style="font-size: 14px;font-weight: 700;text-align: center;margin-top: -10px;">重要なご案内</view>
			<view style="padding-bottom:6px;">1.入金受付時間について</view>
			<view>平日の09:00から18:00までが入金可能時間となります。土日及び祝日は休業日とさせていただいておりますので、ご了承ください。</view>
			<view>2.お客様へのお願い</view>
			<view>当社では、資金の安全を最優先に考え、指定の口座情報をプラットフォーム上でリアルタイムに反映しております。ご入金の際には必ず最新の口座情報のご確認をお願いいたします。</view>
			<view>3.安全な取引のために</view>
			<view>ご入金は、公式プラットフォーム上に表示される指定の口座をご入金ください。指定口座への振込による損失につきましては、当社が責任を負います。</view>
			<view>皆様の継続的なご支持に心より感謝申し上げます。</view>
		</view>
	</view>
</template>

<script>
	import CustomHeader from '@/components/CustomHeader.vue';
	import {
		pathToBase64
	} from '@/common/js_sdk.js'
	export default {
		components: {
			CustomHeader
		},
		data() {
			return {
				serviceService:  this.$t('index.kefuchakan'),
				value1: '',
				shadow: '',
				shadow1: '',
				shadow2: '',
				shadow3: '',
				character: '',
				character1: '',
				character2: '',
				character3: '',
				fileList6: [],
				userInformation: "",
				queryFunction: '',
				value3: '',
				value4: "",
				// lookOver: "",
				BankUser: '',
				BankName: '',
				BankNo: '',
				BankUser_2: '',
				BankName_2: '',
				Account_holder: '',
				Account_number:'',
				Transaction_type:'',
				Account_holder2:'',
				Account_number2:'',
				Transaction_type2:'',
				BankNO_2: '',
				current: 0,
				list1: [{
						name: this.$t('index.pd1')
					},
					{
						name: this.$t('index.pd2')
					},
				],
				Inv: 0,
				items: [this.$t('index.pd1'), this.$t('index.pd2')]
			};
		},
		methods: {
			handleBack() {
				uni.switchTab({
					url: '/pages/index/index'
				});
			},
			//选项卡
			strike(item) {
				// console.log(item);
				this.current = item.index;
			},
			//选项卡
			changeTab(Inv) {
				that.navIdx = Inv;

			},
			//客服
			service() {
				uni.navigateTo({
					url: '/pages/service/service'
				});
			},
		
			//充值记录
			capitalDetails() {
				uni.navigateTo({
					//保留当前页面，跳转到应用内的某个页面
					url: '/pages/my/capitalDetails?index=1'
				});
			},



			copy(value) {
				//提示模板
				if (value == '') {
					uni.$u.toast(this.$t('index.qxjcmm'));
				} else {
					uni.setClipboardData({
						data: value, //要被复制的内容
						success: () => { //复制成功的回调函数
							// console.log(value);
							uni.showToast({
								title: this.$t('index.fzcg'),
								duration: 2000,
								icon: 'success'
							})
						}
					});
				}

			},
			quantity(value1) {
				if (value1 == 1000000) {
					this.value1 = 1000000
					// this.shadow = "#ea4445";
					// this.character = "#fff";
				}
				// else if (value1 != 50000) {
				// 	this.shadow = "";
				// 	this.character = "";
				// }
				if (value1 == 5000000) {
					this.value1 = 5000000
					// this.shadow1 = "#ea4445";
					// this.character1 = "#fff";
				}
				// else if (value1 != 100000) {
				// 	this.shadow1 = "";
				// 	this.character1 = "";
				// }
				if (value1 == 10000000) {
					this.value1 = 10000000
					// this.shadow2 = "#ea4445";
					// this.character2 = "#fff";
				}
				// else if (value1 != 300000) {
				// 	this.shadow2 = "";
				// 	this.character2 = "";
				// }
				if (value1 == 50000000) {
					this.value1 = 50000000
					// this.shadow3 = "#ea4445";
					// this.character3 = "#fff";
				}
				// else if (value1 != 500000) {
				// 	this.shadow3 = "";
				// 	this.character3 = "";
				// }
				// if (value1 != 50000 || value1 != 100000 || value1 != 300000 || value1 != 500000) {
				// 	// this.shadow3 = "";
				// 	// this.character3 = "";
				// }
			},
			// 回调参数为包含columnIndex、value、values
			async to_recharge() {
				uni.showLoading({
					title:  this.$t('index.sfqsh'),
					mask: true, // 显示透明蒙层，防止触摸穿透
				});
				let list = await this.$http.post('api/app/recharge', {
					money: this.value1,
					type: 5,
					image: this.is_url,
					desc: this.value2,
				})

				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.value2 = '';
					this.value1 = '';
					this.is_url = '';
					this.fileList6 = [];
					this.title = this.$t('index.yhk'),
						setTimeout(() => {
							uni.switchTab({
								url: '/pages/user/user'
							});
							uni.hideLoading();
						}, 2000)
				} else {
					uni.$u.toast(list.data.message);
					uni.hideLoading();
					// if (list.data.message === '充值金额错误') {
					// 	uni.$u.toast('请填写充值金额金额');
					// } else if (list.data.message === '您还未实名') {
					// 	uni.$u.toast('请先实名认证');
					// 	setTimeout(() => {
					// 		uni.navigateTo({
					// 			url: '/pages/index/components/openAccount/openAccount'
					// 		});
					// 		uni.hideLoading();
					// 	}, 2000)

					// } else if (list.data.message === '请先添加银行卡信息') {
					// 	uni.$u.toast('请先添加银行卡');
					// 	setTimeout(() => {
					// 		uni.navigateTo({
					// 			url: '/pages/my/components/bankCard/renewal'
					// 		});
					// 		uni.hideLoading();
					// 	}, 2000)
					// }
					// uni.$u.toast(list.data.message);
					// if (list.data.message != '您还未实名' || '请先添加银行卡信息') {

					// }
				}
			},

			//凭证
			deletePic(event) {
				this[`fileList${event.name}`].splice(event.index, 1)
			},
			// 新增图片
			async afterRead(event) {
				// 当设置 multiple 为 true 时, file 为数组格式，否则为对象格式
				let lists = [].concat(event.file)
				let fileListLen = this[`fileList${event.name}`].length
				lists.map((item) => {
					this[`fileList${event.name}`].push({
						...item,
					})
				})
				for (let i = 0; i < lists.length; i++) {
					const result = await this.uploadFilePromise(lists[i].url)
					let item = this[`fileList${event.name}`][fileListLen]
					this[`fileList${event.name}`].splice(fileListLen, 1, Object.assign(item, {
						status: 'success',
						message: '',
						url: result
					}))
					fileListLen++
				}
			},
			//个人信息
			async gaint_info() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.userInformation = list.data.data
			},
			uploadFilePromise(url) {
				// console.log(url)
				pathToBase64(url).then(base64 => {
						// 这就是转为base64格式的图片
						this.is_url = base64
						// console.log(base64)
					})
					.catch(error => {
						console.error(error)
					})
			},
			//显示银行信息
			async queryPassword() {
				let list = await this.$http.get('api/user/info', {
					// language: this.$i18n.locale
				})
				this.queryFunction = list.data.data.bank_card_info
				// console.log(this.queryFunction, '收款人银行');
			},
			//点击验证
			async testVerify() {

				let list = await this.$http.get('api/app/config', {
					// language: this.$i18n.locale
				})
				this.BankUser = list.data.data[13].value
				this.BankName = list.data.data[12].value
				this.BankNo = list.data.data[9].value
				this.Transaction_type = list.data.data[23].value
				this.Account_number = list.data.data[3].value
				this.Account_holder = list.data.data[1].value

				this.BankUser_2 = list.data.data[22].value
				this.BankName_2 = list.data.data[23].value
				this.BankNO_2 = list.data.data[24].value
				this.Transaction_type2 = list.data.data[9].value
				this.Account_number2 = list.data.data[9].value
				this.Account_holder2 = list.data.data[9].value
				uni.hideLoading();


			},
		},

		onLoad(option) {
			this.gaint_info()
			this.testVerify()
		},

	}
</script>

<style lang="scss">
	//充值金额
	.recharge {
		font-size: 28rpx;

		.title {
			color: #333;
		}

		.minimum {
			color: #999;
			font-size: 26rpx;
			margin: 20rpx 0;

			text {
				color: #ffa1a1;
			}
		}

		input {
			background: #f5f5f5;
			border-radius: 10rpx;
			color: #000;
			padding: 30rpx 20rpx;
			font-size: 28rpx;
		}

		.select {
			display: flex;
			justify-content: space-between;
			align-items: center;
			margin: 30rpx 0;
			font-size: 28rpx;

			view {
				background: #f5f5f5;
				color: #999;
				border-radius: 10rpx;
				width: 23%;
				text-align: center;
				padding: 20rpx 0;
			}

			.shadow {
				background-image: linear-gradient(to right, #1a73e8, #014b8d);
			}
		}
	}
</style>