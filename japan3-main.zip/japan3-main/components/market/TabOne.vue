<!-- 国内品 국내종목 -->
<template>
	<view>
		<view class="common_block" style="padding: 6px;">
			<view class="flex padding-top-10">
				<view style="border-radius: 0 16rpx 16rpx 0;width: 5px;height: 30px;background-color: #4b5fcc;"></view>
				<view class="margin-left-10">主要</view>
			</view>
			<view class="zhishuList">
				<view class="itemBox flex flex-b">
					<view class="item text-center" :class="item.change_ratio>0?'red':'green'" v-for="(item,index) in top1" v-if="index<=2">
						<view class="name">{{item.financial_item.name}}</view>
						<view class="price">{{item.price}}</view>
						<view>
							<image :src="item.change_ratio>0?'/static/hong.png':'/static/lv.png'" ></image>
						</view>
						<view class="per">{{item.d_change}}
							[{{item.change_ratio}}%]</view>
					</view>
				
				</view>
			</view>
		</view>

		<view class="common_block" style="padding: 6px;">
			<view class="flex padding-top-10 padding-bottom-10">
				<view style="border-radius: 0 16rpx 16rpx 0;width: 5px;height: 30px;background-color: #4b5fcc;"></view>
				<view class="margin-left-10">ヒット</view>
			</view>
			<view class="flex padding-10">
				<view v-for="(item,index) in top22" class="text-center color-white radius10 flex-1"
					style="padding: 5px 0px;margin-right: 5px;" :class="current2==index?'current1-a':'current1'"
					@click='qiehuan2(index)'>
					{{item}}
				</view>
			</view>

			<view class="lists">
				<view class="item flex flex-b" v-for="(item,index) in top2"
					@click="$u.route('/pages/productDetails',{code:item.code});">
					<view class="flex flex-3">
						<view class="t">{{index+1}}</view>
						
						<view style="margin-left: 20px;">
							<view class="name">{{item.name}}</view>
							<span style="font-weight: 700;font-size: 13px;"
								:style="item.returns*1>0?'color:#ef4d4b':'color:#72a7f3'">{{item.close.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",")}}
							</span>
							<span style="font-weight: 700;font-size: 13px;margin-left: 10px;"
								:style="item.returns*1>0?'color:#ef4d4b':'color:#72a7f3'">
								{{(item.returns*1).toFixed(2)}}%</span>
						</view>
					</view>
					<view class="flex-1 flex flex-e" @click="handleClickDelProduct(item.gid)">
						<!-- <u-icon name="photo" ></u-icon> -->
						<!-- <u-image src="/static/icon/sc.png" width="18" height="18" v-if="!item.sc"></u-image> -->
						<u-image src="/static/icon/qxsc.png" width="18" height="18" v-if="item.sc"></u-image>
					</view>
				</view>
			</view>
			
			<view style="height: 20px;"></view>
		</view>


	</view>
</template>

<script>
	import {
		init,
		registerLocale,
		dispose
	} from 'klinecharts'
	import uCharts from '@/common/u-charts.js';
	var uChartsInstance = {};
	export default {
		name: 'TabOne',
		components: {},
		props: {},
		data() {

			return {
				tablist: [{
					name: '시장요약'
				}, {
					name: '특징종목'
				}, {
					name: '시장지표'
				}, {
					name: '시장이슈'
				}],
				top11: ["국내", "해외", "가상화폐"],
				top22: ["上昇率", "下落率", "出来高"],
				top111: {
					17470: "코스피 200",
					255: "코스피",
					141: "코스닥",
					157: "다우",
					155: "S&P500",
					144: "나스닥",
					16709: "비트코인",
					16710: "이더리움",
					16714: "리플",
				},
				current: 0,
				top1: [],
				kline: [],
				kLineChart: [],
				current1: 0,
				current2: 0,
				current3: 0,
				current33: 0,
				article: [],
				top2: [],
				top3: [],
				bottom: [],
				klineindex: 141
			}
		},

		methods: {
			open(url) {
				window.open(url)
			},
			//删除
			async handleClickDelProduct(e) {
				let list = await this.$http.post('api/user/collect_edit', {
					gid: e,
				})
				if (list.data.code == 0) {
					uni.$u.toast(list.data.message);
					this.top_two()
					this.top_three()
				} else {
					this.show = false
					uni.$u.toast(list.data.message);
				}
			},
			qiehuan33(current) {
				this.current33 = current;
				this.top_three()
			},
			qiehuan3(current) {
				this.current3 = current;
				this.top_three()
			},
			qiehuan2(current) {
				this.current2 = current;
				this.top_two()
			},
			qiehuan(current1) {
				this.current1 = current1;
				this.top_one()
			},
			qiehuan111(index) {
				this.klineindex = index;
				this.top_one()
			},
			async top_one() {
				// uni.showLoading({

				// })
				let list = await this.$http.post('api/goods/top1', {
					current1: this.current1,
					stockid: this.klineindex
				})

				this.top1 = list.data.data
				// this.kline = list.data.data.kline
				// this.article = list.data.data.article
				// this.bottom = list.data.data.bottom
				// console.log();
				// this.klineindex=Object.keys(list.data.data.top1)[0]
				// this.kLineChart.applyNewData(list.data.data.kline)
				// uni.hideLoading()
				this.$forceUpdate()
			},

			async top_two() {
				// uni.showLoading({

				// })
				let list = await this.$http.post('api/goods/top2', {
					current: this.current2
				})
				this.top2 = list.data.data
				uni.hideLoading()
			},
			async top_three() {
				// uni.showLoading({

				// })
				let list = await this.$http.post('api/goods/top3', {
					current: this.current3,
					current33: this.current33
				})
				this.top3 = list.data.data
				// uni.hideLoading()
			},

			//定时器
			startTimer() {
				const storedTimerId = uni.getStorageSync('timerId');
				if (storedTimerId) {
					clearInterval(storedTimerId);
				}
				this.timerId = setInterval(() => {
					this.top_one()
					this.top_two()
					this.top_three()
					// this.dataUpdate()
				}, 5000);
				uni.setStorageSync('timerId', this.timerId);


			},
		},

		mounted() {


			// this.kLineChart = init('chart-type-k-line')

			// this.kLineChart.setStyles({
			// 	"candle": {
			// 		"type": "area",
			// 		"tooltip": {
			// 			"showRule": "none",
			// 		}
			// 	},

			// });
			this.top_one()
			this.top_two()
			this.top_three()
			this.startTimer()


		},

		onUnload() {
			clearInterval(this.timerId);
		},
		onHide() {
			clearInterval(this.timerId);
		},
	}
</script>

<style lang="scss">
	.page {
		min-height: 100vh;
		background-color: #fff;
		padding: 60px 0 70px;
	}

	view,
	text {
		box-sizing: border-box;
	}
	.item.green {
	    background:  #d8efff;
	    color: #1677ff;
	}
	.item.red{
	    background: linear-gradient(180deg,rgba(253,67,49,.06),rgba(255,120,95,.06));
	    color: #fd4331;
	}
	.zhishuList {
	    background: #fff;
	    border-radius: 0px 0px 18px 18px;
	    padding: 15px;
	    padding-top: 0;
	    margin-bottom: 15px;
		.item {
		    width: 32%;
		    border-radius: 10px;
		    padding-bottom: 10px;
			
			
			.name {
			    padding: 10px 0 5px 0;
			    font-size: 13px;
			    color: #333;
			}
			.price {
			    font-size: 16px;
			    font-weight: 600;
			}
			uni-image {
			    width: 100px;
			    height: 26px;
			}
			.per {
			    font-size: 10px;
			}
		}
		
	}
	.current1-a {
		background-color: #4b5fcc;
		color: #fff;
	}

	.current1 {
		background-color: #e3edff;
		color: #666666;
	}

	.yinying-red {
		box-shadow: #ffcfd7 0px 1px 6px 0px;
	}

	.yinying-blue {
		box-shadow: #d1e0ff 0px 1px 6px 0px;
	}

	.container {
		display: flex;
		align-items: center;
		/* 垂直居中 */
		justify-content: center;
		/* 水平居中 */
	}

	.left-element {
		/* 左边元素的样式，可以指定宽度和高度 */
		width: 50px;
		/* 例如 */
		height: 50px;
		/* 例如 */
		display: flex;
		align-items: center;
		/* 内部元素垂直居中 */
		justify-content: center;
		/* 内部元素水平居中 */
	}

	.right-text {
		/* 右边文本的样式，可以指定宽度和行高 */
		width: auto;
		/* 自动宽度 */
		text-align: center;
		/* 文本水平居中 */
		line-height: normal;
		/* 根据需要设置行高 */
	}

	.container1 {
		display: flex;
		flex-wrap: wrap;
		max-width: 100%;

		/* 或者设置具体的宽度 */
		.item {
			flex: 0 0 calc(33.333% - 20px);
			/* 假设容器宽度能均匀容纳3个元素，并且留有一定间隙 */
			margin: 10px;
			/* 元素之间的间隙 */
			box-sizing: border-box;
			/* 确保元素宽度包含内边距和边框 */
		}
	}



	.charts {
		width: 100%;
		height: 200px;
		margin: 10px;

	}




	.more {
		padding: 10px 0;
		color: #333;

		.icon {
			margin-left: 5px;
		}
	}



	.lists {
		padding: 16px 10px 10px;

		.item {
			margin-bottom: 16px;
		}

		.t {
			font-size: 19px;
			font-weight: 700;
			color: #333;
			margin-right: 10px;
		}

		.name {
			font-size: 14px;
			font-weight: 600;
			color: #333;
			margin-bottom: 5px;
		}

		.code {
			background: #f0f3fa;
			border-radius: 5px;
			padding: 5px 10px;
			font-size: 12px;
			font-family: Roboto;
			font-weight: 400;
			color: #333;
		}

		.nums {
			background: #f7e8e8;
			border-radius: 10px;
			padding: 5px 10px;
			-webkit-box-flex: 1;
			-webkit-flex: 1;
			flex: 1;

			.t1 {
				font-size: 14px;
				font-family: Roboto;
				font-weight: 400;
				color: #ff3636;
			}
		}
	}
</style>