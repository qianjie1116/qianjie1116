<template>
	<view class="common_header">
		<text class="common_header_left">{{title}}</text>
		<view class="common_header_center" @click="$u.route({url:'/pages/searchFor/searchFor'});">
			<image mode="aspectFit" src="/static/sousuo.png" :style="$util.calcImageSize(16)"></image>
		</view>
		<!-- <view class="common_header_right" @click="$u.route({url:'/pages/email/email'});">
			<image mode="aspectFit" src="/static/laba.png" :style="$util.calcImageSize(24)"></image>
		</view> -->
	</view>
</template>

<script>
	export default {
		name: "Header",
		props: ["title"],
		data() {
			return {};
		}
	}
</script>
