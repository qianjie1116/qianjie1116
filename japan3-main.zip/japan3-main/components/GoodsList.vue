<template>
	<view class="common_block" style="padding: 0 6px 6px 0;">
		<view
			style="border-radius:10px 0 7px 0px;padding:4px 10px;width: 70px;text-align: center;font-size: 13px;color: #fff;" :style="{backgroundColor:$util.THEME.PRIMARY_COLOR}">
			{{$lang.ALL_MSG}}
		</view>
		<view >
			<view v-for="(item,index) in list" @click="$u.route('/pages/productDetails/productDetails',{code:item.code});"
				style="padding-top: 6px;width: 100%;display: flex;line-height: 36px;border-bottom:1px solid #e3ebfa;"
				:style="{backgroundColor:index%2===0?'#fff':'#f0f3fa'}">
				<!-- <view style="display: inline-block;flex:10%"><u--image :src="item.logo" shape="circle" width="30px" height="30px"></u--image></view> -->
				<view style="margin-left:10px;display: inline-block;flex:36%;">
					{{item.name}}
				</view>
				<text style="display: inline-block;flex:20%;margin:0 10px;"
					:style="{color:`${item.returns>0?'#ff3636':'#2DD872'}`}">{{item.close}}
				</text>
				<view style="border-radius: 3px;font-weight: 700; display: inline-block;flex:29%"
					:style="{color:`${item.returns>0?'#ff3636':'#2DD872'}`}">
					<u-icon :name="`/static/${item.returns>0?'up':'down'}.png`" size="12"
						style="display: inline-block;padding-right:10px;"></u-icon>
					{{item.returns>0?'+':""}}{{(1*item.returns).toFixed(2)}}%
				</view>
			</view>
			<EmptyData v-if="list.length<=0"></EmptyData>
		</view>
	</view>
</template>

<script>
	import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "GoodsList",
		props: ['list'],
		components: {
			EmptyData,
		},
		data() {
			return {};
		}
	}
</script>
