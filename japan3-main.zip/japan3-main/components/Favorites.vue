<template>
	<view class="common_block" style="padding: 10px 6px 6px 0;">
		<view class="zhishuList">
			<view class="itemBox flex flex-b">
				<view class="item text-center" :class="item.change_ratio>0?'red':'green'" v-for="(item,index) in list" v-if="index<=2">
					<view class="name">{{item.financial_item.name}}</view>
					<view class="price">{{item.price}}</view>
					<view>
						<image :src="item.change_ratio>0?'/static/hong.png':'/static/lv.png'" ></image>
					</view>
					<view class="per">{{item.d_change}}
						[{{item.change_ratio}}%]</view>
				</view>
			
			</view>
		</view>
		
	</view>
</template>

<script>
 import EmptyData from '@/components/EmptyData.vue';
	export default {
		name: "Favorites",
		props:['list'],
		components: {
			EmptyData,
		},
		data() {
			return {};
		}
	}
</script>

<style lang="scss">
.zhishuList {
	    background: #fff;
	    border-radius: 0px 0px 18px 18px;
	    padding: 15px;
	    padding-top: 0;
		.item {
		    width: 32%;
		    border-radius: 10px;
		    padding-bottom: 10px;
			
			
			.name {
			    padding: 10px 0 5px 0;
			    font-size: 13px;
			    color: #333;
			}
			.price {
			    font-size: 16px;
			    font-weight: 600;
			}
			uni-image {
			    width: 100px;
			    height: 26px;
			}
			.per {
			    font-size: 10px;
			}
		}
		
	}
</style>